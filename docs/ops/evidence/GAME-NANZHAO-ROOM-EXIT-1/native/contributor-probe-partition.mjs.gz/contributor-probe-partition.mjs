import {readFileSync,writeFileSync} from 'node:fs'
import {execFileSync} from 'node:child_process'
import {createHash} from 'node:crypto'
import {parseSss} from '../../packages/pal-extract/src/io/sss.ts'
import {parseMessages} from '../../packages/pal-extract/src/io/msg.ts'
import {parseWordDat} from '../../packages/pal-extract/src/io/word.ts'
import {openMkf,readChunk} from '../../packages/pal-extract/src/io/mkf.ts'
import {parseItems,parseSpells,parseEnemyObjects,parseObjectPlayers} from '../../packages/pal-extract/src/resources/tables.ts'
import {applyScriptCorrectionPlan,correctScripts} from '../../packages/pal-extract/src/events/script-corrections.ts'
import {collectScriptEntries} from '../../packages/pal-extract/src/events/script-entries.ts'
import {sliceByScene} from '../../packages/pal-extract/src/events/slice.ts'
const raw=readFileSync('data/raw/SSS.MKF'),sss=parseSss(raw),sha=createHash('sha256').update(raw).digest('hex'),messages=parseMessages(readFileSync('data/raw/M.MSG'),sss.messageOffsets)
const oldPlan=JSON.parse(execFileSync('git',['show','b110b68249c6fada85781c1473b765202ec4e5b0:packages/pal-extract/src/events/win-script-corrections.json']))
const old=applyScriptCorrectionPlan(sss,sha,messages,oldPlan),current=correctScripts(sss,sha,messages)
const words=parseWordDat(readFileSync('data/raw/WORD.DAT')),objectBytes=readChunk(openMkf(raw),2)
const globals=collectScriptEntries({scenes:sss.scenes,eventObjects:sss.eventObjects,items:parseItems(objectBytes,words),spells:parseSpells(objectBytes,words),enemyObjects:parseEnemyObjects(objectBytes,words),objectPlayers:parseObjectPlayers(objectBytes)}).globalScriptEntries
// Label every existing instruction to retain its original IP through slice copying/rewrite.
// The production reachability walker never reads command.label; all control fields stay exact.
const commands=JSON.parse(readFileSync('data/extracted/events/all.json','utf8')).segments[0].commands.map((c,ip)=>({...c,label:`L_${ip}`}))
const base=sliceByScene(commands,old.sss.scenes,old.sss.eventObjects,globals)
const withTrigger=structuredClone(old.sss.eventObjects);withTrigger[4841].triggerScript=41999
const withAuto=structuredClone(old.sss.eventObjects);withAuto[4841].autoScript=41099
const slices={trigger:sliceByScene(commands,current.sss.scenes,withTrigger,globals,{286:[43518]}),auto:sliceByScene(commands,current.sss.scenes,withAuto,globals,{286:[43518]}),current:sliceByScene(commands,current.sss.scenes,current.sss.eventObjects,globals,{286:[43518]})}
function ids(file){return file.segments.flatMap(s=>s.commands).map(c=>Number(c.label.slice(2)))}
function delta(before,after){const a=ids(before),b=ids(after),aa=new Set(a),bb=new Set(b);return {removed:a.filter(i=>!bb.has(i)),added:b.filter(i=>!aa.has(i))}}
const result={sourceSha256:sha,producer:'actual-sliceByScene-root-isolation-no-resource-write',note:'Labels added only to retain IP identities; command control fields and parsed root tables are exact.',variants:{}}
for(const [key,value]of Object.entries(slices))result.variants[key]={scenes:Object.fromEntries([21,286,289].map(id=>[id,delta(base.scenes[id],value.scenes[id])])),shared:delta(base.shared,value.shared)}
writeFileSync('build/map204-supplemental/partition-probes.json',JSON.stringify(result,null,2));console.log(JSON.stringify(result))
const oldSource=execFileSync('git',['show','b110b68249c6fada85781c1473b765202ec4e5b0:packages/pal-extract/src/events/slice.ts'],{encoding:'utf8'}).replace("from './opcodes.js'","from '../../packages/pal-extract/src/events/opcodes.ts'")
writeFileSync('build/map204-supplemental/slice-at-prior-extraction.ts',oldSource)
const priorWalker=await import('./slice-at-prior-extraction.ts')
const realCommands=JSON.parse(readFileSync('data/extracted/events/all.json','utf8')).segments[0].commands
const previousExact=priorWalker.sliceByScene(realCommands,old.sss.scenes,old.sss.eventObjects,globals)
const currentExact=sliceByScene(realCommands,current.sss.scenes,current.sss.eventObjects,globals,{286:[43518]})
const historical=priorWalker.sliceByScene(commands,old.sss.scenes,old.sss.eventObjects,globals)
const publishedRoot='/Users/zhangxu/illegal/type-pal/build/map204-integration/'
const regeneratedRoot='/Users/zhangxu/illegal/type-pal/data/extracted/events/'
const same=(a,b)=>JSON.stringify(a)===JSON.stringify(b)
const priorComparison={priorSliceGit:'b110b68249c6fada85781c1473b765202ec4e5b0',currentSliceGit:'1e00fd113886bb41ddf05f8913ecb89b4d1f383f',priorPublishedMatches:{},currentRegeneratedMatches:{},existingMainTraversalChange:{}}
for(const id of [21,289]){const pad=String(id).padStart(3,'0');priorComparison.priorPublishedMatches[id]=same(previousExact.scenes[id],JSON.parse(readFileSync(`${publishedRoot}production-events-scene-${pad}.json`,'utf8')));priorComparison.currentRegeneratedMatches[id]=same(currentExact.scenes[id],JSON.parse(readFileSync(`${regeneratedRoot}scene-${pad}.json`,'utf8')));priorComparison.existingMainTraversalChange[id]=delta(historical.scenes[id],base.scenes[id])}
writeFileSync('build/map204-supplemental/prior-partition-comparison.json',JSON.stringify(priorComparison,null,2));console.log(JSON.stringify(priorComparison))
