from pathlib import Path
import json,subprocess,re,hashlib
r93='docs/phase-governance/reviews/20261017-r93-phase-governance-artifacts.json';r94='docs/phase-governance/reviews/20261017-r94-final-machine-artifacts.json';originals=json.load(open('build/map204-integration/binding-originals.json'));leaves={x['reviewFile'] for x in originals if x['reviewFile'] not in [r93,r94]};owned={x['path'] for x in originals}
def write(name,d):
 s=json.dumps(d,ensure_ascii=False,indent=2)+'\n';s=re.sub(r'\[\n\s*(?:"(?:[^"\\]|\\.)*"(?:,\n\s*)?)+\n\s*\]',lambda m:json.dumps(json.loads(m.group()),ensure_ascii=False,separators=(',',':')),s);Path(name).write_text(s);subprocess.run(['pnpm','exec','biome','format','--write',name],check=True)
for name in sorted(leaves):
 d=json.load(open(name))
 for e in d['entries']:
  if e['path'] in owned and e.get('history',[])[-1].get('action')=='map204-input-owned-delta':e['evidence']['kind']='owned-delta-review'
 write(name,d)
for name,targets in [(r93,leaves),(r94,{r93})]:
 d=json.load(open(name))
 for e in d['entries']:
  if e['path'] in targets:
   h=hashlib.sha256(Path(e['path']).read_bytes()).hexdigest();e['afterSha256']=h;e['revision']['implementationSha']=h;e['evidence']['currentMaintenance']['afterSha256']=h;e['evidence']['currentMaintenance']['lineCount']=len(Path(e['path']).read_text().splitlines())
 write(name,d)
