from pathlib import Path
import json,gzip,hashlib,subprocess,datetime
out=Path('docs/ops/evidence/GAME-NANZHAO-ROOM-EXIT-1'); base=Path('build/map204-release')
def sha(b):return hashlib.sha256(b).hexdigest()
result=json.loads((base/'coverage-ratchet-final.run.json').read_text());assert result['exitCode']==0 and result['signal'] is None
summary=json.loads(Path('coverage/fast/summary.json').read_text());baseline=json.loads(Path('scripts/coverage/baseline.fast.json').read_text())
for k in ['schemaVersion','profile','generatedAt','provider','sourceFileCount','testCount','total']:assert baseline[k]==summary[k]
for k,p in baseline['packages'].items():
 s=summary['packages'][k]
 for field in p:
  expected={a:b for a,b in s[field].items() if a!='identities'} if field=='fastTests' else s[field]
  assert p[field]==expected
old=json.loads(subprocess.check_output(['git','show','123595ac3a651957b36061eacced329369c495e5:scripts/coverage/baseline.fast.json'],text=True))
comparisons={}
for name,p in baseline['packages'].items():
 comparisons[name]={}
 for m,v in p['metrics'].items():
  previous=old['packages'][name]['metrics'][m]
  assert v['covered']*previous['total']>=previous['covered']*v['total']
  comparisons[name][m]={'previous':previous,'current':v}
native=[]
files=[Path('coverage/fast/summary.json'),Path('scripts/coverage/baseline.fast.json'),base/'quality-inventory-final.json',base/'prepare-docs.py',base/'bind-docs.py',Path(__file__)]
for stem in ['coverage-ratchet-final','pre-pr-docs','pre-pr-lint','pre-pr-types']:
 for suffix in ['.run.json','.stdout','.stderr']:files.append(base/(stem+suffix))
for p in files:
 b=p.read_bytes();z=gzip.compress(b,mtime=0);dest=out/'native'/('local-release-gates-'+p.name+'.gz');dest.write_bytes(z)
 assert gzip.decompress(z)==b
 native.append({'path':str(dest.relative_to(out)),'sourcePath':str(p),'sourceSha256':sha(b),'archiveSha256':sha(z),'bytes':len(b)})
gates={}
for name in ['pre-pr-docs','pre-pr-lint','pre-pr-types']:
 gates[name]=json.loads((base/(name+'.run.json')).read_text()); assert gates[name]['exitCode']==0 and gates[name]['signal'] is None
receipt={'schemaVersion':1,'template':'evidence-receipt-v1','id':'map204-input-local-release-gates','owner':'Codex','recordedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'candidate':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'scope':'Actual complete official fast coverage collection, before protected remote CI. Test/source execution identity included in original summary; no rule/config changes or exclusions. Five-file functional review and original red logs remain in release-preparation.json.','coverage':{'run':result,'testCount':summary['testCount'],'sourceFileCount':summary['sourceFileCount'],'total':summary['total'],'packages':{k:{'tests':v['selectedTests']['testCount'],'sources':v['sourceFileCount'],'metrics':v['metrics']} for k,v in summary['packages'].items()},'baselineSha256':sha(Path('scripts/coverage/baseline.fast.json').read_bytes()),'baselineEqualsProducerOutput':True,'allMetricsAtLeastProtectedMain':True,'comparisons':comparisons},'staticGates':gates,'native':native,'notRun':['Remote required CI, merge, deployment, issue closure in this local receipt','Natural story E2E or physical gamepad']}
(out/'release-gates.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'officialTests':summary['testCount'],'sources':summary['sourceFileCount'],'packages':list(summary['packages']),'native':len(native)}))
