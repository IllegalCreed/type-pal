import { readFileSync, writeFileSync } from 'node:fs'
import { createHash } from 'node:crypto'
import { parseSss } from '../../packages/pal-extract/src/io/sss.ts'
import { dumpAllEventObjects } from '../../packages/pal-extract/src/resources/scene.ts'
import { createInitialGameState, npcFromEventObject, sliceSceneEventObjects } from '../../packages/game/src/core/game-state.ts'
import { setStartBattleHandler, setSceneLoader, tickEventSystem } from '../../packages/game/src/core/event-system.ts'
import { finalizeBattleCleanup } from '../../packages/game/src/core/battle/battle-finalization.ts'
import { setGlobalEvents } from '../../packages/game/src/core/script-catalog.ts'
import { Save } from '../../packages/game/src/core/save/api.ts'
import { serializeSave, parseImportedSave } from '../../packages/game/src/tools/save-io.ts'
const raw=readFileSync('data/raw/SSS.MKF'),sss=parseSss(raw)
const source=dumpAllEventObjects(sss.scenes,sss.eventObjects)
const commands=JSON.parse(readFileSync('data/extracted/events/all.json','utf8')).segments[0].commands
let now=0
const previous=performance.now
Object.defineProperty(performance,'now',{configurable:true,value:()=>now})
const rows=[]
setGlobalEvents(structuredClone(commands))
setStartBattleHandler(({gs})=>{gs.mode='battle'})
setSceneLoader(async()=>{})
const snap=()=>({held:new Set(),pressed:new Set(['Confirm']),frameNum:0})
try{
 for(const outcome of ['won','fled','terminated']){
  const gs=createInitialGameState({x:1040,y:744,facing:'down'})
  gs.wNumScene=287;gs.allEventObjects=source.eventObjects.map(e=>npcFromEventObject(e));gs.sceneEventRanges=source.sceneRanges;gs.npcs=sliceSceneEventObjects(gs,287)
  gs.mode='event';gs.eventCursor={ip:41999,currentEventObjectId:4841,triggerOwnerId:4841}
  now+=1000;gs.nowMs=now;tickEventSystem(gs,snap())
  const battle={mode:gs.mode,postBattleResume:structuredClone(gs.postBattleResume)}
  finalizeBattleCleanup(gs,outcome)
  for(let n=0;n<50&&gs.mode==='event';n++){now+=1000;gs.nowMs=now;tickEventSystem(gs,snap())}
  await Save.saveSlot(1,gs)
  const saved=await Save.loadSlot(1)
  if(!saved)throw new Error('missing saved snapshot')
  const imported=parseImportedSave(serializeSave(saved))
  const beforeReturn=structuredClone(imported.allEventObjects[4841])
  imported.wNumScene=286;imported.npcs=sliceSceneEventObjects(imported,286)
  imported.wNumScene=287;imported.npcs=sliceSceneEventObjects(imported,287)
  rows.push({outcome,battle,mode:gs.mode,stored:beforeReturn,reentered:imported.npcs.find(n=>n.id===4841),globalReference:imported.npcs.find(n=>n.id===4841)===imported.allEventObjects[4841],saveIoValid:true})
 }
 console.log(JSON.stringify({kind:'actual-event-battle-return-and-public-save-roundtrip',limits:['Battle execution is a host seam that sets mode; no combat mechanics/visual acceptance.','Real opcode7 captures resume, real finalizeBattleCleanup chooses outcome, real event interpreter runs original victory/flee tail, actual Save API and V1 import/export retain values.'],sourceSha256:createHash('sha256').update(raw).digest('hex'),scenarios:rows},null,2))
}finally{setGlobalEvents([]);setStartBattleHandler(null);setSceneLoader(null);await Save.deleteSlot(1);Object.defineProperty(performance,'now',{configurable:true,value:previous})}
