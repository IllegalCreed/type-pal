import json,pathlib
p=pathlib.Path('build/map204-integration/generation-check.json');r=json.load(open(p));allcmd=[c for s in json.load(open('data/extracted/events/all.json'))['segments'] for c in s['commands']];pool={json.dumps(c,sort_keys=True,ensure_ascii=False) for c in allcmd};labels={c.get('label') for c in allcmd if c.get('label')};d=json.load(open('build/map204-integration/partition-delta.json'));bridges=[]
for x in d:
 for key in ['removed','added']:
  for c in x[key]:
   if json.dumps(c,sort_keys=True,ensure_ascii=False) in pool:continue
   assert c['op']=='goto' and c['to'].startswith('shared#') and c['to'].split('#')[1] in labels,(x['path'],key,c)
   bridges.append({'path':x['path'],'delta':key,'command':c})
r['partitionObservation']={'oldFilesMatchBeforeManifest':True,'nonSyntheticCommandsPresentUnmodifiedInGlobalTable':True,'sharedBridgeTargetsValid':bridges,'classificationBoundary':'Scene289/shared delta follows restored native trigger41999; scene021 delta belongs to current-main battle continuation traversal added after previous extraction. Actual old/new slice source probe is preserved separately.','initialOracleCalibration':'Whole-object equality to global table rejected two expected synthetic shared# fallthrough gotos; corrected oracle explicitly validates those bridge targets and exact identity of all other commands. This is not a product regression red.'}
p.write_text(json.dumps(r,indent=2,ensure_ascii=False)+'\n');print(json.dumps(r['partitionObservation'],ensure_ascii=False))
