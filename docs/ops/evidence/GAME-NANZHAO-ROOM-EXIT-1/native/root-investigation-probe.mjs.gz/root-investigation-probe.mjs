import { readFileSync } from 'node:fs'
import { createHash } from 'node:crypto'
import { parseSss } from '../../packages/pal-extract/src/io/sss.ts'
import { dumpAllEventObjects } from '../../packages/pal-extract/src/resources/scene.ts'
import { createInitialGameState, npcFromEventObject, sliceSceneEventObjects, hydrateNpcStaticDefaults } from '../../packages/game/src/core/game-state.ts'
import { tickSceneSystem, isWalkable } from '../../packages/game/src/core/scene-system.ts'
import { setSceneLoader, tickEventSystem } from '../../packages/game/src/core/event-system.ts'
import { setGlobalEvents } from '../../packages/game/src/core/script-catalog.ts'
const read = p => JSON.parse(readFileSync(p,'utf8'))
const sourcePaths = ['data/raw/SSS.MKF','data/en/win_files/Sss.mkf']
const inputs = sourcePaths.map(path => { const bytes=readFileSync(path); return {path,sha256:createHash('sha256').update(bytes).digest('hex'),sss:parseSss(bytes)} })
const corrected = read('data/extracted/data/event-objects.json')
const commands=read('data/extracted/events/all.json').segments[0].commands
const map=read('data/extracted/data/tilemap/204.json')
const summarizeInput = ({path,sha256,sss}) => {
 const view=new DataView(sss.bytecode.buffer,sss.bytecode.byteOffset,sss.bytecode.byteLength)
 const ip=n=>[0,2,4,6].map(i=>view.getUint16(n*8+i,true))
 const object=sss.eventObjects[4841]
 return {path,sha256,scene287:sss.scenes[286],scene286:sss.scenes[285],object4841:object,exitScript:[0,1,2,3].map(n=>({ip:object.triggerScript+n,words:ip(object.triggerScript+n)})),entry35091:[35091,35092,35093,35094].map(n=>({ip:n,words:ip(n)}))}
}
let now=0
const originalNow=performance.now
Object.defineProperty(performance,'now',{configurable:true,value:()=>now})
setGlobalEvents(structuredClone(commands))
const originalObjects=dumpAllEventObjects(inputs[0].sss.scenes,inputs[0].sss.eventObjects)
const dirs=[['Down',-16,8],['Up',16,-8],['Left',-16,-8],['Right',16,8]]
function route(npcs,start) {
 const exit=corrected.eventObjects[4841], queue=[{...start,path:[]}], seen=new Set([`${start.x},${start.y}`])
 for(let i=0;i<queue.length;i++) { const p=queue[i];if(Math.abs(p.x-exit.x)+2*Math.abs(p.y-exit.y)<48)return p
 for(const [dir,dx,dy]of dirs){const q={x:p.x+dx,y:p.y+dy},k=`${q.x},${q.y}`;if(!seen.has(k)&&isWalkable(map,q.x,q.y,npcs,0,true)){seen.add(k);queue.push({...q,path:[...p.path,dir]})}}}return null
}
function run(kind,data) {
 const gs=createInitialGameState({x:928,y:816,facing:'down'})
 gs.wNumScene=287;gs.allEventObjects=data.eventObjects.map(npcFromEventObject);gs.sceneEventRanges=data.sceneRanges;gs.npcs=sliceSceneEventObjects(gs,287)
 hydrateNpcStaticDefaults(gs.npcs,corrected.eventObjects.slice(...corrected.sceneRanges[286]))
 setSceneLoader(async()=>{gs.sceneLoading=false})
 const trace=[]
 for(const keys of [['Down'],['Down'],[]]){
  now+=1000;gs.nowMs=now
  tickSceneSystem(gs,{held:new Set(keys),pressed:new Set(),frameNum:trace.length},{tilemap:map})
  trace.push({keys,x:gs.party.x,y:gs.party.y,mode:gs.mode,cursor:gs.eventCursor?{ip:gs.eventCursor.ip,owner:gs.eventCursor.currentEventObjectId}:null})
 }
 const triggered=gs.eventCursor?.currentEventObjectId
 for(let n=0;n<50&&gs.mode==='event';n++){now+=1000;gs.nowMs=now;tickEventSystem(gs,{held:new Set(),pressed:new Set(['Confirm']),frameNum:n})}
 return {kind,exit:gs.allEventObjects[4841],trace,triggered,final:{scene:gs.wNumScene,x:gs.party.x,y:gs.party.y,mode:gs.mode},mapPathFromIssueWithDynamicBlockers:route(gs.npcs,{x:1040,y:744})}
}
try{console.log(JSON.stringify({sourceGit:'123595ac3a651957b36061eacced329369c495e5',limits:['Headless native trigger/interpreter caller; no browser render, deployment version or user save inspection.','Dynamic blocker route is a fixed-position connectivity diagnosis, excludes moving enemies and battle consequences.','Legacy-state scenario uses a legal original event-object table with corrected script catalog, models persisted pre-correction save state; it is not the issue author save.'],inputs:inputs.map(summarizeInput),correctedExit:corrected.eventObjects[4841],scenarios:[run('fresh corrected resources',corrected),run('pre-correction event state plus corrected resources',originalObjects)]},null,2))}finally{setGlobalEvents([]);setSceneLoader(null);Object.defineProperty(performance,'now',{configurable:true,value:originalNow})}
