import {readFileSync,writeFileSync,mkdirSync} from 'node:fs'
import {createHash} from 'node:crypto'
import {parseSss} from '../../packages/pal-extract/src/io/sss.ts'
import {parseMessages} from '../../packages/pal-extract/src/io/msg.ts'
import {correctScripts} from '../../packages/pal-extract/src/events/script-corrections.ts'
import {dumpAllEventObjects,dumpScene} from '../../packages/pal-extract/src/resources/scene.ts'
const raw=readFileSync('data/raw/SSS.MKF'),sss=parseSss(raw)
const sha=createHash('sha256').update(raw).digest('hex')
const corrected=correctScripts(sss,sha,parseMessages(readFileSync('data/raw/M.MSG'),sss.messageOffsets))
const out=dumpAllEventObjects(corrected.sss.scenes,corrected.sss.eventObjects,corrected.eventMetadata,corrected.supplementalObjects)
writeFileSync('data/extracted/data/event-objects.json',JSON.stringify(out))
mkdirSync('data/extracted/data/scene',{recursive:true})
for(const id of [285,286])writeFileSync(`data/extracted/data/scene/${id}.json`,JSON.stringify(dumpScene(id,corrected.sss.scenes,corrected.sss.eventObjects,corrected.eventMetadata,corrected.supplementalObjects)))
console.log(JSON.stringify({sourceSha256:sha,kind:'directed-canonical-event-table-and-two-scene-generation-only',version:corrected.manifest.version,bytecodeSha256:createHash('sha256').update(corrected.sss.bytecode).digest('hex'),eventObjectsSha256:createHash('sha256').update(JSON.stringify(out)).digest('hex')}))
