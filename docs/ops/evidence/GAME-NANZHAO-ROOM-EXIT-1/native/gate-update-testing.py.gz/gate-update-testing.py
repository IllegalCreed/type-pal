from pathlib import Path
import json,hashlib,re,sys,copy
receipt='docs/ops/evidence/GAME-NANZHAO-ROOM-EXIT-1/review.json';candidate=sys.argv[1]
epath=Path('docs/testing/domains/cross-phase/script-corrections/evidence.json');rpath=epath.with_name('report.md');cpath=Path('docs/testing/catalog.json')
e=json.loads(epath.read_text());c=json.loads(cpath.read_text());report=rpath.read_text();m=re.search(r'<!-- testing-meta\n(.*?)\n-->',report,re.S);meta=json.loads(m.group(1));entry=next(x for x in c['entries'] if x['id']==e['id'])
oldrefs=copy.deepcopy(e['sourceRefs'])
for ref in e['sourceRefs']:
 p=Path(ref['path']);text=p.read_text();anchor=ref['anchor'].replace('pal-win-1','pal-win-2');ref['anchor']=anchor;ref['lines']=str(next(i for i,l in enumerate(text.splitlines(),1) if anchor in l));ref['sha256']=hashlib.sha256(p.read_bytes()).hexdigest()
newrefs=[
 ('packages/game/src/core/scene-supplemental-objects.ts','export function supplySupplementalSceneObjects','supplement-owner'),
 ('packages/game/src/core/scene-loading.ts','supplySupplementalSceneObjects(gs','load-scene-caller'),
 ('packages/game/src/shell/bootstrap.ts','supplySupplementalSceneObjects(gs','saved-game-caller'),
 ('packages/pal-extract/src/resources/scene.ts','export function dumpAllEventObjects','native-range-owner'),
 ('packages/pal-extract/src/events/slice.ts','sceneExtraRoots:','scene-script-root-owner'),
 ('projects/pal/content/scenes/s286.json','"id": "palace-isolated-exit"','canonical-exit'),
 ('packages/game/src/core/scene-supplemental-objects.pal.test.ts','loaded %s palace save','save-caller-oracle'),
 ('packages/reforge/src/main.pal-palace-exit.test.ts','canonical palace zone returns','zone-delivery-oracle')]
for path,anchor,role in newrefs:
 p=Path(path);lines=p.read_text().splitlines();e['sourceRefs'].append({'path':path,'lines':str(next(i for i,l in enumerate(lines,1) if anchor in l)),'anchor':anchor,'role':role,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
e['publicCallers'] += ['Save.saveSlot/loadSlot -> serializeSave/parseImportedSave -> loadScene -> actual tickSceneSystem/tickEventSystem; raw-native normal/won/fled and already-published D10 saves','bootGame -> canonical collision -> real input move/touch zone delivery -> loadScene -> return/reenter; isolated shell IO artwork seam']
e['legalInputs'] += ['Native5077 event array and unchanged scene ranges; explicit independent scene286 addition5077; prepared legal original-raw save at928,816, not reporter save or natural-story checkpoint']
e['businessOracle']['assertions'] += ['New D10 appends stable5077, leaves enemy4841 and every native ID/range unchanged; both all.json and scene286 contain exit root43518; missing old-save object is shared with global state without resetting native progress.','Old normal/won/fled/published-portal saves exit through real contact, reach scene286 at1392,616 and do not loop; Reforge original team267 enemy remains beside the separate palace-isolated-exit zone, with real touch exit/reentry.']
e['dedupe']['notes'] += ' 2026-10-27 keeps the original topology case and updates its present-era exit identity4841->5077. New save lifecycle, missing-tail/collision and actual shell zone delivery are distinct callers; historical source hash still includes the restored original enemy and removes only the strictly asserted new zone.'
h={'date':'2026-10-27','action':'map204-independent-exit-and-old-save-supply','candidate':candidate,'previousSourceRefs':oldrefs,'evidence':receipt,'scope':'pal-win-2 keeps native5077 IDs/ranges and original enemy4841, appends resource-authored5077 plus owner roots, supplies absent old-save tail only. Both phases tested; original coverage and historical results retain their dates. Full story/device/CI/release remain separate.'}
e['history'].append(h)
for target in [meta,entry]:
 for k in ['sourceRefs','publicCallers','legalInputs','businessOracle','dedupe']:target[k]=copy.deepcopy(e[k])
 target['revision']['history'].append(copy.deepcopy(h))
entry['lastVerified']='2026-10-27';entry['reviewBy']='2026-11-27'
e['claims'].append({'id':'map204-independent-exit-old-save-and-two-phase-contact','result':'runtime-backed','evidence':[receipt]})
e['artifacts'].append({'path':receipt,'sha256':hashlib.sha256(Path(receipt).read_bytes()).hexdigest()})
e['runtimeExecution']['scope'] += '; 2026-10-27 supplemental-map204 old-save lifecycle and real two-phase touch exit/reentry, root repeated extraction and prepared-save browser smoke'
report=report[:m.start(1)]+json.dumps(meta,ensure_ascii=False,separators=(',',':'))+report[m.end(1):]
report+='''\n2026-10-27 D10后续修复：按用户决定保留原遇敌4841，另加稳定ID5077出口；原生5077对象与sceneRanges不变，出口root同时进入全局和scene286。旧档加载只补缺失的显式新增对象；normal/战胜/逃跑和已发布旧portal档均经过真实保存/导入/加载和接触退出，旧进度保留，退出下一帧不循环。第二阶段恢复team267遇敌，独立zone经真实boot/input/touch返回并再次进房。\n\n本轮原生game初次88通过；随后以真实party加严5项PAL夹具并完整文件重验5绿，其余83邻测沿相同字节复用，未宣称第二次完整88；extract49、Reforge5421通过；断开装载补缺与改错原敌team两条独立反控：断开补缺在完整文件产生4个对应旧档合同AssertionError/1pass/0skip；原敌team改错产生1个指定AssertionError/5413pass/0skip，逐字节恢复后全绿。[当前接收与原件](../../../../ops/evidence/GAME-NANZHAO-ROOM-EXIT-1/review.json)记录提取两次一致及普通UI导入准备旧档后的浏览器出口实跑；它不代表取得issue作者存档或完成自然剧情E2E。本轮未重算官方覆盖率，前文20,081及比例是原2026-10-22窗口历史；统一静态门见任务卡关联集成回执。\n'''
rpath.write_text(report);epath.write_text(json.dumps(e,ensure_ascii=False,indent=2)+'\n')
c['_governance']['entryReadings'].append({'id':e['id'],'conclusion':'2026-10-27只核独立新增出口/原敌保留/旧档加载与两阶段真实接触合同；复用83邻测+当前PAL5、extract49、Reforge5421和两有效业务反控及精确恢复，根提取/准备旧档浏览器另核；不续签历史coverage或完整剧情。'})
c['_governance']['history'].append({'date':'2026-10-27','action':'map204-independent-exit-publication','candidate':candidate,'evidence':receipt,'scope':'Only game-script-corrections current refs/contracts/readings; all other entries and old execution dates/history retained.'})
cpath.write_text(json.dumps(c,ensure_ascii=False,indent=2)+'\n')
print('updated only script-corrections report/evidence/catalog and appended bounded current history')
