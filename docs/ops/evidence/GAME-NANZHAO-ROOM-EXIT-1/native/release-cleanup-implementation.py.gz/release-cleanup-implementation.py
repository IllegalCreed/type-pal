from pathlib import Path
import subprocess,json,hashlib
b=Path('build/map204-release');backup=json.loads((b/'retirement-backup.json').read_text());bundle=Path(backup['bundle'])
assert backup['verified'] and hashlib.sha256(bundle.read_bytes()).hexdigest()==backup['sha256']
assert not Path('/Users/zhangxu/.codex/worktrees/input-rotation/type-pal').exists()
primary=Path('/Users/zhangxu/.codex/worktrees/map204-exit/type-pal');assert primary.exists()
g=lambda *args:subprocess.check_output(['git',*args],text=True).strip()
assert g('-C',str(primary),'rev-parse','HEAD')=='bde596695d9c4d90a8031443ddd1ea033edd5245'
assert not g('-C',str(primary),'status','--porcelain','--untracked-files=no')
refs=[r for r in backup['refs'] if not r['ref'].startswith('refs/tags/')]
assert all(g('rev-parse',r['ref'])==r['sha'] for r in refs)
branch='codex/map204-input-rotation';expected=next(r['sha'] for r in refs if r['ref']==branch)
git=['git','-c','http.version=HTTP/1.1','-c','http.proxy=http://127.0.0.1:7897']
def read_remote():
 for proxy in ['http://127.0.0.1:7897','socks5h://127.0.0.1:7897','http://127.0.0.1:7897']:
  p=subprocess.run(['git','-c','http.version=HTTP/1.1','-c','http.proxy='+proxy,'ls-remote','--heads','origin','refs/heads/'+branch],capture_output=True,text=True)
  if p.returncode==0:return p
 return p
remote=read_remote();assert remote.returncode==0,remote.stderr
before=remote.stdout.split()[0] if remote.stdout.strip() else None
assert before is None or before==expected
push=None
if before:
 push=subprocess.run([*git,'push','--force-with-lease=refs/heads/'+branch+':'+expected,'origin',':refs/heads/'+branch],capture_output=True,text=True)
 (b/'cleanup-remote-push.txt').write_text(push.stdout+push.stderr)
after=read_remote();assert after.returncode==0 and not after.stdout.strip(),after.stderr
removed=[]
for r in refs:
 assert g('rev-parse',r['ref'])==r['sha']
 subprocess.run(['git','branch','-D',r['ref']],check=True)
 removed.append(r)
assert all(subprocess.run(['git','show-ref','--verify','--quiet','refs/heads/'+r['ref']]).returncode==1 for r in refs)
result={'passed':True,'removedLocalBranches':removed,'remoteBranch':{'name':branch,'before':before,'after':None,'lease':expected,'pushExit':None if push is None else push.returncode},'backup':backup,'worktrees':{'archived':'/Users/zhangxu/.codex/worktrees/input-rotation/type-pal','retainedPrimary':str(primary),'retainedReason':'archive_worktree explicitly rejects deletion of the task primary checkout. Retained and detached at deployed main; no filesystem removal bypass.','primaryHead':'bde596695d9c4d90a8031443ddd1ea033edd5245','ignoredBuildArtifactsPreserved':406},'scope':'Only this release implementation refs; documentation-closeout branch remains until its protected PR merges. Unrelated worktrees/branches and root untracked English data remain.'}
(b/'cleanup-implementation.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'passed':True,'localBranchesRemoved':len(removed),'remoteAbsent':True,'archivedWorktrees':1,'protectedPrimaryKept':True}))
