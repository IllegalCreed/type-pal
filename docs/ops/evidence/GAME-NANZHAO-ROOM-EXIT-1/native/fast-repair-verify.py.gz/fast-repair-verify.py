from pathlib import Path
import hashlib,json,subprocess,sys
folder=Path(__file__).resolve().parent
r=json.loads((folder/'review.json').read_text())
issues=[]
if subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()!=r['candidate']: issues.append('HEAD candidate drift')
for item in r['files']:
 p=Path(item['path'])
 if not p.exists() or hashlib.sha256(p.read_bytes()).hexdigest()!=item['sha256']: issues.append('source drift:'+str(p))
for item in r['artifacts']:
 p=folder/item['path']
 if not p.exists() or hashlib.sha256(p.read_bytes()).hexdigest()!=item['sha256']: issues.append('artifact drift:'+str(p))
for name,count in [('coverage-final-native.json',372),('restored.json',31)]:
 native=json.loads((folder/name).read_text())
 if not native['success'] or (native['numTotalTests'],native['numFailedTests'],native['numPendingTests'],native['numTodoTests'])!=(count,0,0,0): issues.append('native result mismatch:'+name)
counter=json.loads((folder/'counter.json').read_text())
if (counter['numPassedTests'],counter['numFailedTests'],counter['numPendingTests'],counter['numTodoTests'])!=(2,1,0,0): issues.append('counter result mismatch')
manifest=json.loads((folder/'counter.manifest.json').read_text())
if manifest['originalSha256']!=manifest['restoredSha256']: issues.append('counter restore mismatch')
for name in ['coverage-final','restored','typecheck-final','biome']:
 meta=json.loads((folder/(name+'.run.json')).read_text())
 if meta['exit']!=0 or meta['signal'] is not None or meta['spawnError'] is not None: issues.append('completion mismatch:'+name)
biome=json.loads((folder/'biome.stdout').read_text())
if biome['diagnostics'] or any(biome['summary'][k]!=0 for k in ['errors','warnings','infos','skipped','diagnosticsNotPrinted','changed']): issues.append('Biome diagnostics')
comparison=json.loads((folder/'coverage-comparison.json').read_text())
for key,m in comparison['metrics'].items():
 if m['candidate']['covered']*m['baseline']['total']<m['baseline']['covered']*m['candidate']['total']: issues.append('metric regression:'+key)
print(json.dumps({'status':'failed' if issues else 'matched','candidate':r['candidate'],'issues':issues,'scope':'Readonly identity/native/metric verification only; no official baseline or full-repository acceptance'},indent=2))
if issues:sys.exit(1)
