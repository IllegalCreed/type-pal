from pathlib import Path
import json,hashlib,subprocess,re
receipt='docs/ops/evidence/GAME-NANZHAO-ROOM-EXIT-1/release.json'
paths=['docs/ops/audits/code-quality-file-ledger.md','docs/ops/board.md','docs/ops/tasks/index.md','docs/testing/catalog.json']+[p for p in subprocess.check_output(['git','diff','--name-only'],text=True).splitlines() if p.startswith('docs/testing/indexes/')]
files={p:json.loads(p.read_text()) for p in Path('docs/phase-governance/reviews').glob('*.json')}
owner={e['path']:(p,e) for p,d in files.items() for e in d.get('entries',[])}
touched=set(); before=[]
def update(target,artifact=False):
 if target not in owner:return
 p,e=owner[target];h=hashlib.sha256(Path(target).read_bytes()).hexdigest()
 if e['afterSha256']==h:return
 before.append({'record':str(p),'path':target,'entry':json.loads(json.dumps(e))})
 e.setdefault('history',[]).append({'date':'2026-10-27','action':'release','previousAfterSha256':e['afterSha256']})
 e['afterSha256']=h;e['revision']['implementationSha']=h
 e['coreConclusion']='Owned release bindings; historical scope retained.'
 e['readMethod']='Read owned delta and release receipt.'
 e['reviewedLines']='Owned delta only.'
 e['nextStep']='Release verified; documentation PR separate.'
 maintenance={'path':receipt,'afterSha256':h,'scope':'Release delta.','lineCount':len(Path(target).read_text().splitlines())}
 if artifact:
  e['coreConclusion']='Release binding; history retained.'
  e['readMethod']='Read release binding.'
  e['nextStep']='Documentation PR pending.'
  maintenance['scope']='Release.'
  e['evidence']['currentMaintenance']=maintenance
 else:e['evidence']={'kind':'owned-release-preparation',**maintenance}
 touched.add(p)
def write(p):
 data=json.dumps(files[p],ensure_ascii=False,indent=2)+'\n'
 data=re.sub(r'\[\n\s*(?:"(?:[^"\\]|\\.)*"(?:,\n\s*)?)+\n\s*\]',lambda m:json.dumps(json.loads(m.group()),ensure_ascii=False,separators=(',',':')),data)
 assert json.loads(data)==files[p]
 if len(data.encode())>1048576:raise RuntimeError('Review record formatter limit exceeded: '+str(p))
 p.write_text(data);subprocess.run(['pnpm','exec','biome','format','--write',str(p)],check=True)
for path in paths:update(path)
for p in list(touched):write(p)
for name in ['20261017-r93-phase-governance-artifacts.json','20261017-r94-final-machine-artifacts.json']:
 p=Path('docs/phase-governance/reviews')/name
 for e in files[p]['entries']:
  if Path(e['path']) in touched:update(e['path'],True)
 if p in touched:write(p)
Path('build/map204-release/closeout-binding-before.json').write_text(json.dumps(before,ensure_ascii=False,indent=2)+'\n')
print([(str(p),p.stat().st_size) for p in sorted(touched)])
