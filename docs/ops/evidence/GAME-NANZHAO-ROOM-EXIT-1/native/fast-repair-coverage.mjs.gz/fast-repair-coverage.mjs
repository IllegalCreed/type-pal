import { spawnSync } from 'node:child_process'
import { mkdirSync, writeFileSync } from 'node:fs'
import { resolve } from 'node:path'
import { coveragePackages,coverageExcludes,testSelection } from '../../scripts/coverage/config.mjs'
import { preciseCoverageEnvironment } from '../../scripts/coverage/environment.mjs'
const config = coveragePackages.find((item) => item.id === 'pal-extract')
const folder = resolve('build/map204-fast')
mkdirSync(folder,{recursive:true})
const selection = testSelection(config,'fast')
const args = ['--filter',config.name,'exec','vitest','run','--reporter=default',...selection.args,...selection.excludes.flatMap((pattern)=>['--exclude',pattern]),'--coverage','--coverage.provider=v8',`--coverage.reportsDirectory=${folder}/coverage`,'--coverage.reporter=text-summary','--coverage.reporter=json-summary','--coverage.reporter=html','--coverage.reporter=lcov']
for (const pattern of config.include) args.push('--coverage.include',pattern)
for (const pattern of coverageExcludes) args.push('--coverage.exclude',pattern)
// Additional native test JSON changes no selection or instrumentation rule.
args.push('--reporter=json',`--outputFile=${folder}/coverage-native.json`)
const environment = preciseCoverageEnvironment({TYPE_PAL_COVERAGE:'1',TYPE_PAL_COVERAGE_PROFILE:'fast'})
writeFileSync(`${folder}/coverage-command.json`,JSON.stringify({command:'pnpm',args,environmentOverrides:{TYPE_PAL_COVERAGE:'1',TYPE_PAL_COVERAGE_PROFILE:'fast',NODE_DISABLE_COMPILE_CACHE:'1',NODE_COMPILE_CACHE:'deleted'},scope:'Nonofficial isolated pal-extract only, unchanged official selection/include/exclude/provider/report arguments; no baseline writes'},null,2)+'\n')
const result=spawnSync('pnpm',args,{cwd:process.cwd(),env:environment,encoding:'utf8',maxBuffer:64*1024*1024})
process.stdout.write(result.stdout??'');process.stderr.write(result.stderr??'')
if(result.error) throw result.error
if(result.signal) throw new Error(`Coverage child signal:${result.signal}`)
process.exitCode=result.status??1
