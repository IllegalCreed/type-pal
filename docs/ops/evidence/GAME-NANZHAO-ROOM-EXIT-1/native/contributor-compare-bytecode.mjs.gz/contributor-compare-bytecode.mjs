import {readFileSync,writeFileSync} from 'node:fs'
import {execFileSync} from 'node:child_process'
import {createHash} from 'node:crypto'
import {parseSss} from '../../packages/pal-extract/src/io/sss.ts'
import {parseMessages} from '../../packages/pal-extract/src/io/msg.ts'
import {applyScriptCorrectionPlan,correctScripts} from '../../packages/pal-extract/src/events/script-corrections.ts'
const digest=b=>createHash('sha256').update(b).digest('hex')
const bytes=readFileSync('data/raw/SSS.MKF'),sss=parseSss(bytes),messages=parseMessages(readFileSync('data/raw/M.MSG'),sss.messageOffsets)
const oldBytes=execFileSync('git',['show','b110b68249c6fada85781c1473b765202ec4e5b0:packages/pal-extract/src/events/win-script-corrections.json'])
const old=applyScriptCorrectionPlan(sss,digest(bytes),messages,JSON.parse(oldBytes))
const current=correctScripts(sss,digest(bytes),messages)
const result={sourceSha256:digest(bytes),oldPlanGit:'b110b68249c6fada85781c1473b765202ec4e5b0',oldPlanSha256:digest(oldBytes),oldVersion:old.manifest.version,currentVersion:current.manifest.version,oldBytecodeSha256:digest(old.sss.bytecode),currentBytecodeSha256:digest(current.sss.bytecode),bytecodeEqual:Buffer.from(old.sss.bytecode).equals(Buffer.from(current.sss.bytecode)),oldPortalLabel:`L_${old.sss.eventObjects[4841].triggerScript}`,newPortalLabel:current.supplementalObjects[0].object.triggerLabel,nativeCount:current.sss.eventObjects.length,publishedCount:current.sss.eventObjects.length+current.supplementalObjects.length}
if(!result.bytecodeEqual||result.oldPortalLabel!==result.newPortalLabel)throw new Error('published script pointer drift')
writeFileSync('build/map204-supplemental/bytecode-comparison.json',JSON.stringify(result,null,2))
console.log(JSON.stringify(result))
