import subprocess,sys,json,time,datetime,pathlib,hashlib
root=pathlib.Path('/Users/zhangxu/illegal/type-pal');out=root/'build/map204-integration';name=sys.argv[1];cmd=sys.argv[2:]
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
start=now();t=time.monotonic()
p=subprocess.run(cmd,cwd=root,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
(out/(name+'.stdout')).write_bytes(p.stdout);(out/(name+'.stderr')).write_bytes(p.stderr)
r={'command':cmd,'cwd':str(root),'startUtc':start,'endUtc':now(),'elapsedSeconds':time.monotonic()-t,'exitCode':p.returncode,'signal':None if p.returncode>=0 else -p.returncode,'gitHead':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'native':[{'path':str((out/(name+s)).relative_to(root)),'sha256':hashlib.sha256((out/(name+s)).read_bytes()).hexdigest()} for s in ['.stdout','.stderr']]}
(out/(name+'.run.json')).write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r));print(p.stdout.decode(errors='replace')[-9000:]);print(p.stderr.decode(errors='replace')[-9000:],file=sys.stderr);sys.exit(p.returncode)
