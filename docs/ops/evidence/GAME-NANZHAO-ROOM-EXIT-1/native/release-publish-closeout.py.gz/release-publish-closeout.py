from pathlib import Path
import json,re,copy,gzip,hashlib,datetime,subprocess
base=Path('build/map204-release'); out=Path('docs/ops/evidence/GAME-NANZHAO-ROOM-EXIT-1'); receipt=str(out/'release.json')
def read(p):return json.loads(Path(p).read_text())
def save(p,d):Path(p).write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
def sha(b):return hashlib.sha256(b).hexdigest()
ci=read(base/'pr-accepted-status.json'); merge=read(base/'merge.json'); deploy=read(base/'deploy.run.json'); post=read(base/'postflight.stdout'); browser=read(base/'browser-production.json'); release=read(base/'release-created.json'); cleanup=read(base/'cleanup-implementation.json')
assert ci['requiredPassed'] and merge['merged'] and deploy['exitCode']==0 and post['passed'] and browser['passed'] and cleanup['passed']
commit=merge['sha']; assert post['expected']['localHead']==commit and deploy['gitHead']==commit
assert release['tag_name']=='v1.1.0' and not release['draft'] and not release['prerelease']
issues={str(n):read(base/f'issue{n}-closed.json') for n in [24,27]}
assert all(d['state']=='closed' and d['state_reason']=='completed' for d in issues.values())
native=[]
names=['pr-created.json','pr-accepted-status.json','pr-accepted-checks.json','pr-accepted-pull.json','merge.json','deploy.run.json','deploy.stdout','deploy.stderr','postflight.run.json','postflight.stdout','postflight.stderr','browser-production.json','server-backup.txt','server-before-deploy.txt','cdn-refresh-status.json','release-created.json','release-notes.md','issue24-comment.json','issue27-comment.json','issue24-closed.json','issue27-closed.json','contributor-backup.json','cleanup-implementation.json','final-submit-docs.run.json','final-submit-docs.stdout','final-submit-docs.stderr','final-submit-lint.run.json','final-submit-lint.stdout','final-submit-lint.stderr']
names+= ['tag.json','retirement-backup.json','retirement-bundle-verify.txt','archive-map204.json','archive-input.json','cleanup-implementation.py','issue-actions.py','merged-tree.json','main-before-merge.json','deploy-initial.run.json','deploy-initial.stdout','deploy-initial.stderr','deploy-runtime.json','deploy-with-gnu-rsync.py','publish-closeout.py','bind-closeout.py','api.py','snapshot-pr.py']
for name in names:
 p=base/name;b=p.read_bytes();z=gzip.compress(b,mtime=0);dest=out/'native'/('release-'+name+'.gz');dest.write_bytes(z);assert gzip.decompress(z)==b
 native.append({'path':str(dest.relative_to(out)),'sourcePath':str(p),'sourceSha256':sha(b),'archiveSha256':sha(z),'bytes':len(b)})
for p in sorted((base/'browser').glob('*')):
 if p.is_file():
  b=p.read_bytes();z=gzip.compress(b,mtime=0);dest=out/'native'/('release-browser-'+p.name+'.gz');dest.write_bytes(z);native.append({'path':str(dest.relative_to(out)),'sourcePath':str(p),'sourceSha256':sha(b),'archiveSha256':sha(z),'bytes':len(b)})
readme_delta=[]
for name in ['README.md','README.en.md']:
 p=Path(name);before=p.read_bytes();t=before.decode()
 if name=='README.md':
  old=next(l for l in t.splitlines() if l.startswith('| 第一阶段 · 忠实复刻 |'))
  t=t.replace(old,'| 第一阶段 · 忠实复刻 | [v1.1.0](https://github.com/IllegalCreed/type-pal/releases/tag/v1.1.0) 已上线 | 浏览器运行时 [`@type-pal/game`](packages/game)，新增英文、移动端与手柄等支持；[v1.0.0](https://github.com/IllegalCreed/type-pal/releases/tag/v1.0.0) 保留首次完整通关的里程碑。 |')
  t=t.replace('第一阶段已经做到的，来自 [v1.0.0 发布说明](https://github.com/IllegalCreed/type-pal/releases/tag/v1.0.0) 和仓库里的实现说明：','第一阶段的功能见 [v1.1.0 发布说明](https://github.com/IllegalCreed/type-pal/releases/tag/v1.1.0) 与当前实现：')
  line=next(l for l in t.splitlines() if l.startswith('- 手机、窄窗口'))
  t=t.replace(line,line+'\n- 标准手柄支持；「系统」中可选择虚拟方向键与左摇杆顺时针旋转45°，默认关闭并记住选择。键盘和手柄十字键保持原映射。')
 else:
  old=next(l for l in t.splitlines() if l.startswith('| Phase 1 · faithful recreation |'))
  t=t.replace(old,'| Phase 1 · faithful recreation | [v1.1.0](https://github.com/IllegalCreed/type-pal/releases/tag/v1.1.0) is live | The browser runtime [`@type-pal/game`](packages/game), with English, mobile and gamepad support. [v1.0.0](https://github.com/IllegalCreed/type-pal/releases/tag/v1.0.0) remains the first complete-playthrough milestone. |')
  t=t.replace('Phase 1, from the [v1.0.0 release notes](https://github.com/IllegalCreed/type-pal/releases/tag/v1.0.0) and the in-repo implementation notes:','Phase 1 features, from the [v1.1.0 release notes](https://github.com/IllegalCreed/type-pal/releases/tag/v1.1.0) and the current implementation:')
  line=next(l for l in t.splitlines() if l.startswith('- An on-screen direction pad'))
  t=t.replace(line,line+'\n- Standard gamepad support. System offers an optional clockwise 45° rotation for the on-screen direction pad and left stick, off by default and remembered locally. Keyboard and hardware D-pad mappings stay unchanged.')
 p.write_text(t)
 readme_delta.append({'path':name,'beforeSha256':sha(before),'afterSha256':sha(p.read_bytes()),'sourceCommit':commit,'scope':'Both complete current READMEs read; only actual v1.1.0 entry, old v1.0.0 milestone and optional control-setting bullet updated. Setup, licenses, phase2 status and images retained.'})
r={'schemaVersion':1,'template':'evidence-receipt-v1','id':'map204-input-production-release','owner':'Codex','recordedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'deployed-verified-issues-closed','tasks':['GAME-NANZHAO-ROOM-EXIT-1','GAME-INPUT-ROTATION-1'],'userAuthorization':'2026-10-27 accepted both local features and authorized push/CI/merge/deploy/issue replies+closure/related cleanup; later requested a new phase1 release milestone.','pullRequest':'https://github.com/IllegalCreed/type-pal/pull/28','candidate':ci['head'],'mergedAndDeployedCommit':commit,'requiredCI':ci,'deployment':{'run':deploy,'mode':'all --skip-check after actual complete local gates and both required protected CI checks; fresh merged production build, resources before app switch','backup':'/var/www/type-pal/release-backups/map204-controls-20261027T062435Z.tgz','backupSha256':'a6ad5d5097fd5a505b4999951b28ad2ab6157c367f3474cbed0385c25c533394','rollbackBoundary':'App switch is atomic; extracted is shared/file-level atomic. Full previous dist+extracted backup retained.'},'postflight':{'passed':post['passed'],'manifest':post['expected']['manifest'],'resourceCount':post['remote']['resourceCount'],'resourceBytes':post['remote']['resourceTotalBytes'],'exactFileSets':post['remote']['appExactFileSet'] and post['remote']['resourceExactFileSet'],'httpsChecks':len(post['remote']['http']),'issues':post['remote']['issues'],'scope':'Actual SSH all-file checks, original ranges/enemy/independent exit and root/language semantics; certificate-validated origin+CDN status/body SHA/cache/MIME, without redirect, cache-busting or TLS bypass.'},'browser':browser,'release':{'tag':release['tag_name'],'url':release['html_url'],'target':commit,'phase':'phase1','assetsUploaded':len(release['assets']),'scope':'Source milestone and player-facing release notes; no raw/exe upload or phase2 release claim.'},'issues':{n:{'url':d['html_url'],'state':d['state'],'reason':d['state_reason']} for n,d in issues.items()},'cleanup':cleanup,'native':native,'notRun':['Physical gamepad/phone','Reporter original save','Full natural-story E2E or offline cache activation'],'closeoutBoundary':'This receipt records already completed product deployment/release. Its documentation-only protected PR and own branch retirement are separately verified after publication.'}
r['rootReadmeDelta']=readme_delta
save(receipt,r)
subprocess.run(['pnpm','exec','biome','format','--write',receipt],check=True)
for name in ['GAME-INPUT-ROTATION-1','GAME-NANZHAO-ROOM-EXIT-1']:
 p=Path('docs/ops/tasks')/(name+'.md');t=p.read_text().replace('Status: review','Status: done',1);t+='\n## 2026-10-27 发布收口\n\n用户本地验收已确认。PR [#28](https://github.com/IllegalCreed/type-pal/pull/28) 的 documentation / fast-coverage（Actions App15368）在最新base、精确候选`'+ci['head']+'`上通过；按保护规则合并为`'+commit+'`。本地官方20,203例/812源、七包类型检查、lint与完整文档门零诊断见[本地门](../evidence/GAME-NANZHAO-ROOM-EXIT-1/release-gates.json)。\n\n实际从合并树新构建并部署阿里云应用和资源；源站/CDN逐字节及完整资源清单、浏览器设置/刷新回退验证通过，两个issue已回复并关闭；第一阶段[v1.1.0]('+release['html_url']+')固定该部署提交。实现分支已按可恢复备份清理；一份临时worktree已归档，当前聊天主工作树按工具保护规则保留并同步最新main。完整命令、原件、CDN任务、备份与限制见[发布回执](../evidence/GAME-NANZHAO-ROOM-EXIT-1/release.json)。未宣称实物手柄、issue原存档、离线激活或自然全剧情E2E。无下一位Agent；收尾文档继续走受保护PR。\n';p.write_text(t)
p=Path('docs/ops/board.md');p.write_text(''.join(l for l in p.read_text().splitlines(True) if not any(n in l for n in ['| GAME-INPUT-ROTATION-1 |','| GAME-NANZHAO-ROOM-EXIT-1 |'])))
cpath=Path('docs/testing/catalog.json');c=read(cpath)
for domain,id in [('phase1-runtime/control-rotation','game-input-rotation'),('cross-phase/script-corrections','game-script-corrections')]:
 ep=Path('docs/testing/domains')/domain/'evidence.json';rp=ep.with_name('report.md');e=read(ep);t=rp.read_text();m=re.search(r'<!-- testing-meta\n(.*?)\n-->',t,re.S);meta=json.loads(m.group(1));entry=next(x for x in c['entries'] if x['id']==id)
 h={'date':'2026-10-27','action':'protected-production-release','candidate':ci['head'],'deployedCommit':commit,'evidence':receipt,'scope':'Actual official20203/812, protected CI, merged fresh build/all deployment, origin+CDN semantics and finite browser smoke. Hardware, full-story and offline activation remain untested.'}
 e['history'].append(copy.deepcopy(h));e['artifacts'].append({'path':receipt,'sha256':sha(Path(receipt).read_bytes())})
 for x in [meta,entry]:x['revision']['history'].append(copy.deepcopy(h))
 if id=='game-input-rotation':
  for x in [e,meta,entry]:x['status']='verified'
  e['candidateSha']=commit
  for x in [meta,entry]:x['revision']['currentSha']=commit
  e['runtimeExecution']['officialCoverage']=True
  e['runtimeExecution']['scope']+='; complete official fast coverage and actual production release, see release receipt'
  t=t.replace('active：统一窗口和用户体验尚待收口。','verified：用户已接受，统一门和实际部署已完成。').replace('尚未执行实物触屏/手柄、完整自然剧情E2E和本窗口全仓/官方coverage/受保护门；用户体验待用户试用。','未执行实物触屏/手柄和完整自然剧情E2E；本窗口官方coverage、受保护CI与部署已完成，用户已确认本地体验。')
 t=t[:m.start(1)]+json.dumps(meta,ensure_ascii=False,separators=(',',':'))+t[m.end(1):]
 t+='\n2026-10-27发布：本地官方20,203例/812源与全仓静态零诊断，PR#28受保护两门通过后合并；应用与资源部署、源站/CDN和有限网页设置烟测通过，issue#24/#27已回复关闭，第一阶段v1.1.0已发布。[实际发布、原件和限制](../../../../ops/evidence/GAME-NANZHAO-ROOM-EXIT-1/release.json)。保留原始历史执行与非自然剧情/非实物手柄边界，不重复授予旧测试次数或整文件关闭信用。\n'
 save(ep,e);rp.write_text(t)
 reading=next(x for x in c['_governance']['entryReadings'] if x['id']==id)
 c['_governance']['history'].append({'date':'2026-10-27','action':'production-release-reading','id':id,'previousConclusion':reading['conclusion'],'evidence':receipt})
 reading['conclusion']='2026-10-27有限功能与用户接受、官方20203/812、保护CI及实际应用/资源部署收口；保留原合同和执行身份，真机/自然剧情/离线激活未核。'
save(cpath,c)
p=Path('docs/testing/domains/phase1-runtime/control-rotation/README.md');t=p.read_text().replace('catalog/report/evidence为 active：有限功能已独立接收，统一窗口和用户体验待收口。','catalog/report/evidence为 verified：用户已接受，统一门、受保护CI与实际部署完成。').replace('真机手柄/触屏、完整剧情与发布未测，根任务继续统一验收及用户试用。','真机手柄/触屏、完整剧情和离线激活未测；发布事实与原件见[发布回执](../../../../ops/evidence/GAME-NANZHAO-ROOM-EXIT-1/release.json)。');p.write_text(t)
print('Published only actual release and paired finite test status; now regenerate indexes/bind owned deltas and run docs/lint')
