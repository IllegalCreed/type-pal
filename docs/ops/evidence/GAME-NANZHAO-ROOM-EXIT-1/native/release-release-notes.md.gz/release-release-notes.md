第一阶段自 v1.0.0 首次完整通关以来的功能与修复汇总。

### 玩家可见变化

- 支持中英文显示切换，并调整英文对话、菜单和装备界面的布局。
- 适配手机界面，提供相对窗口定位的半透明方向键、确认和取消按钮；小地图及工具入口精简。
- 支持标准手柄；新增可记忆的顺时针45°设置，共同控制手机虚拟方向键和手柄左摇杆，默认关闭。
- 音乐音源可选择，加入 DOS FM 播放方案。
- 修复南诏地宫 map204 房间离开问题：保留原遇敌、增加独立出口，旧档补齐缺失出口并保留已有进度。
- 修复此前核实的剧情脚本、道具奖励、事件触发、战斗状态、地图切换和存档读写问题。

### 验证与范围

本次提交通过本地官方 fast coverage（20,203项测试、812个生产源码文件）、全仓类型检查、零诊断 lint、文档检查和 GitHub 必需 CI；阿里云应用与资源部署后另核源站、CDN及浏览器。

本发布针对第一阶段。没有实物手柄，手柄输入已通过标准 Gamepad 数据回归，未宣称硬件实测；本次也未重新完整跑通自然剧情。

在线游玩：[pal.illegalscreed.cn](https://pal.illegalscreed.cn/)。刷新网页加载新版后读取原有存档即可。

关联修复：[PR #28](https://github.com/IllegalCreed/type-pal/pull/28)、[方向设置 #24](https://github.com/IllegalCreed/type-pal/issues/24)、[地宫出口 #27](https://github.com/IllegalCreed/type-pal/issues/27)。

完整变更：[v1.0.0...v1.1.0](https://github.com/IllegalCreed/type-pal/compare/v1.0.0...v1.1.0)。
