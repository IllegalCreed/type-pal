import os,subprocess,pathlib,json,sys
env=os.environ.copy();env['PATH']='/opt/homebrew/opt/rsync/bin:'+env.get('PATH','')
version=subprocess.check_output(['rsync','--version'],env=env,text=True).splitlines()[0]
assert 'version 3.4.1' in version
pathlib.Path('build/map204-release/deploy-runtime.json').write_text(json.dumps({'pathPrefix':'/opt/homebrew/opt/rsync/bin','rsyncVersion':version,'reason':'System /usr/bin/rsync rejects existing deploy.sh --info=progress2. Use already-installed GNU rsync; no script/rule/global environment change. Initial attempt preserved.'},indent=2)+'\n')
p=subprocess.run(['python3','build/map204-release/run.py','deploy','env','COPYFILE_DISABLE=1','bash','scripts/deploy.sh','all','--skip-check'],env=env)
sys.exit(p.returncode)
