git status --short && git rev-parse HEAD && shasum -a 256 docs/testing/e2e/README.md docs/testing/e2e/cross-stage/README.md && git show 911ac4dcbb3ea2288ae215769ae9acd6e333d763:docs/ops/tasks/DOCS-FULL-TEMPLATE-1.md | tail -13
git show dc478db11c6b52c4e50a1d1135f8a4740796418c:docs/testing/e2e/cross-stage/README.md
cat docs/testing/e2e/cross-stage/README.md
wc -l docs/testing/e2e/cross-stage/common-issues.md docs/ops/tasks/E2E-R4-1-route-and-checkpoint-foundation.md
rg -n "^#{1,5} |^> #{1,5} |issue|family|阶段|状态|回链" docs/testing/e2e/cross-stage/common-issues.md | head -90
if git show-ref --verify --quiet refs/heads/codex/docs-semantic-cross-stage; then exit 2; else git switch -c codex/docs-semantic-cross-stage; fi
