python3 /tmp/type-pal-s04-author-20261018-p_ahi1x_/build-author-report.py
