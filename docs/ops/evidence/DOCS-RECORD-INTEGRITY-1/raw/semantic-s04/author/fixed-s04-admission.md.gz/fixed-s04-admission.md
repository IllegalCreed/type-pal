## 2026-10-18 S04：横向材料导航的隔离贡献准入

- Codex build allowed，仅单篇文档候选。Owner继续为`e2e_entry_semantic_author`，在其干净S03冻结候选之后复用隔离worktree；新增唯一写域`docs/testing/e2e/cross-stage/README.md`，中央ledger、catalog、任务/看板、产品/旧产品测试/coverage均由原Owner保护。
- root已全文核现行40行及其中原始短导航：它仍承担现行横向材料导航，采用既有governance-index-v1/1.0.0。作者必须自行全文核固定源/当前正文与必要common-issues入口、catalog发布/配对字段和R4准入窄域后，写出可用的当前入口、issue-family回链职责与真实停止线；不得把common-issues所有历史业务结论或001–005执行当作本次已审。
- 原quote/source字节及日期保留；有分隔LF、旧状态或原counter须逐项记录。只准真实所读/所跑范围，作者自验不能授reviewed/template-compliant。root随后独立实读原/新/来源与反例，再决定单篇接收；registry分片未独立接收前不批量中央入账，整卡保持rework。
