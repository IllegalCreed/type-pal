python3 /tmp/type-pal-s04-author-20261018-p_ahi1x_/edit-readme.py && cat docs/testing/e2e/cross-stage/README.md
