import assert from 'node:assert/strict'
import { execFileSync } from 'node:child_process'
import { createHash } from 'node:crypto'
import { existsSync, readFileSync } from 'node:fs'
import { resolve } from 'node:path'
import { pathToFileURL } from 'node:url'
const { markdownLinks } = await import(pathToFileURL(resolve('scripts/docs/markdown.mjs')))
const { localTarget } = await import(pathToFileURL(resolve('scripts/docs/check.mjs')))
const { checkTemplateBody } = await import(pathToFileURL(resolve('scripts/docs/document-model.mjs')))
const { validateCanonicalEvidence, validateCatalog, validateIndexes } = await import(pathToFileURL(resolve('scripts/docs/check-testing.mjs')))
const { renderIndexes } = await import(pathToFileURL(resolve('scripts/docs/generate-testing-index.mjs')))
const sha = (b) => createHash('sha256').update(b).digest('hex')
const file='docs/testing/e2e/cross-stage/README.md'
const before=execFileSync('git',['show',`f9fbf0c7c6e9b59df6c0cbe76b7b90852da76ece:${file}`])
const source=execFileSync('git',['show',`dc478db11c6b52c4e50a1d1135f8a4740796418c:${file}`])
const after=readFileSync(file), text=after.toString('utf8')
const marker='<!-- original-source-quote:start -->\n', end='<!-- original-source-quote:end -->'
const quoteBlock=text.slice(text.indexOf(marker))
assert.equal(quoteBlock,before.toString().slice(before.toString().indexOf(marker)))
const quote=quoteBlock.split(marker)[1].split(end)[0]
const lines=quote.split(/(?<=\n)/)
assert.equal(lines.length,6)
assert.ok(quote.endsWith('\n>\n'))
const direct=Buffer.from(lines.map((line)=>{ assert.ok(line.startsWith('>')); return line.startsWith('> ')?line.slice(2):line.slice(1) }).join(''))
assert.equal(source.length,243);assert.equal(direct.length,244)
assert.notDeepEqual(direct,source);assert.deepEqual(direct.subarray(-1),Buffer.from('\n'))
const conditioned=direct.subarray(0,-1)
assert.deepEqual(conditioned,source)
assert.equal(sha(source),'14d8b6e5ae98f20a3be9eebe09e7ca4c4764bfd3cc92aaf2f78413af8efcaf7c')
assert.equal(sha(readFileSync('docs/testing/e2e/README.md')),'8ddfbda4c48af97ff8c33a229f8cb45f00b1d91e5952d635def86a946be7c9e9')
console.log(JSON.stringify({check:'source and protected S03 identity',sourceSha256:sha(source),beforeSha256:sha(before),afterSha256:sha(after),quoteBlockSha256:sha(Buffer.from(quoteBlock)),quoteBlockUnchanged:true,sourceBytes:source.length,directInverseBytes:direct.length,directInverseSha256:sha(direct),directInverseEqualsSource:false,excludedSuffixHex:'0a',conditionedInverseSha256:sha(conditioned),conditionedInverseEqualsSource:true,protectedS03Sha256:sha(readFileSync('docs/testing/e2e/README.md'))}))
const registry=JSON.parse(readFileSync('docs/phase-governance/templates/registry.json'))
const template=registry.types.find(t=>t.templateId==='governance-index-v1')
const structureIssues=checkTemplateBody(text,template)
assert.deepEqual(structureIssues,[])
console.log(JSON.stringify({check:'public checkTemplateBody',templateId:template.templateId,templateVersion:template.templateVersion,issues:structureIssues,scope:'structure only; author self-check'}))
const catalog=JSON.parse(readFileSync('docs/testing/catalog.json'))
const entry=catalog.entries.find(e=>e.id==='e2e-common-issues')
assert.equal(entry.canonical,'e2e/cross-stage/common-issues.md')
assert.equal(entry.index,'e2e/README.md')
assert.equal(entry.evidence,'e2e/evidence/e2e-common-issues.json')
assert.deepEqual(entry.dependsOn,['e2e-001','e2e-002','e2e-003','e2e-004','e2e-005'])
const canonicalIssues=validateCanonicalEvidence(entry),catalogIssues=validateCatalog(catalog),indexIssues=validateIndexes(catalog)
assert.deepEqual(canonicalIssues,[]);assert.deepEqual(catalogIssues,[]);assert.deepEqual(indexIssues,[])
assert.equal(renderIndexes(catalog)['by-stage.md'],readFileSync('docs/testing/indexes/by-stage.md','utf8'))
const links=markdownLinks(text).map(l=>({...l,resolved:localTarget(file,l.target)}))
const missing=links.filter(l=>l.resolved&&!existsSync(resolve(l.resolved)))
assert.deepEqual(missing,[])
const current=text.slice(0,text.indexOf('## 历史与原文保全'))
const currentTargets=new Set(markdownLinks(current).map(l=>localTarget(file,l.target)))
for(const target of [entry.canonical,entry.index,entry.evidence].map(p=>`docs/testing/${p}`))assert.ok(currentTargets.has(target),`missing current pair link ${target}`)
console.log(JSON.stringify({check:'real publication/paired consumer and links',publicationId:entry.id,publicationIndex:entry.index,auditDependsOn:entry.dependsOn,canonicalIssues,catalogIssues,indexIssues,links,scope:'source/document publication audit; no runtime/business acceptance'}))
const inbound=[],unreadableTrackedPaths=[]
for(const path of execFileSync('git',['ls-files','-z']).toString().split('\0').filter(p=>p.endsWith('.md'))){
 if(!existsSync(path)){unreadableTrackedPaths.push(path);continue}
 for(const link of markdownLinks(readFileSync(path,'utf8')))if(localTarget(path,link.target)===file)inbound.push({source:path,line:link.line,target:link.target})
}
console.log(JSON.stringify({check:'mechanical inbound inventory only',inbound,unreadableTrackedPaths,catalogIndexUsers:catalog.entries.filter(e=>e.index==='e2e/cross-stage/README.md').map(e=>e.id)}))
