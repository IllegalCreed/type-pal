from pathlib import Path
import datetime,hashlib,json,subprocess
p=Path('/tmp/type-pal-s04-author-20261018-p_ahi1x_')
sha=lambda b:hashlib.sha256(b).hexdigest()
files=[{'path':str(f),'sha256':sha(f.read_bytes()),'bytes':f.stat().st_size} for f in sorted(p.iterdir()) if f.is_file() and not f.name.startswith('artifact-manifest')]
m={'kind':'S04-author-evidence-intake-manifest','createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'authorCanonicalTask':'/root/e2e_entry_semantic_author','nonAuthorReviewer':False,'baseCandidateCommit':'f9fbf0c7c6e9b59df6c0cbe76b7b90852da76ece','frozenCandidateCommit':'c8715c2c4ac1771a77127917812c87b53a30d676','documentPath':'docs/testing/e2e/cross-stage/README.md','documentSha256':'1c345654a9f10a19455a8df696b48d9a2f1b86e6fc36bdfe050933a48a8f574c','protectedS03Sha256':'8ddfbda4c48af97ff8c33a229f8cb45f00b1d91e5952d635def86a946be7c9e9','authorReportPath':str(p/'author-report.json'),'authorReportSha256':sha((p/'author-report.json').read_bytes()),'scope':'numbered receipts01-16 exact UTC/cwd/scripts/exit/signal/full stdout/stderr, fixed source/before/after/admission snapshots and author programs/report; manifest excluded from itself','notes':['Report frozen before finalization receipts14-16; this external manifest records those complete outputs without self-hash recursion.','Global checkdocs/strict/require-complete failures retained; fullf9fb->c871 diff0 and lint0 do not grant semantic/global acceptance.','Whole quote unchanged, direct inverse244 unequal243 source, only known LF condition equals sourceSHA14d8; no unconditional trim.','Only repository changed path is cross-stage README; S03 body and prior author report/addendum hashes remain unchanged; no central intake or main merge.'],'files':files}
raw=json.dumps(m,ensure_ascii=False,indent=2)+'\n';(p/'artifact-manifest.raw.json').write_text(raw)
r=subprocess.run(['node','/Users/zhangxu/illegal/type-pal/node_modules/@biomejs/biome/bin/biome','format','--stdin-file-path=docs/ops/evidence/DOCS-FULL-TEMPLATE-1/s04-intake-manifest.json'],input=raw.encode(),capture_output=True)
(p/'artifact-manifest-format.stderr').write_bytes(r.stderr)
assert r.returncode==0,(r.returncode,r.stderr)
(p/'artifact-manifest.json').write_bytes(r.stdout)
for e in files:assert sha(Path(e['path']).read_bytes())==e['sha256']
print('files',len(files))
print('manifest',p/'artifact-manifest.json',sha(r.stdout))
print('report',p/'author-report.json',sha((p/'author-report.json').read_bytes()))
