node /tmp/type-pal-s04-author-20261018-p_ahi1x_/verify-entry.mjs
