sed -n "1,43p" docs/testing/e2e/cross-stage/common-issues.md
sed -n "58,78p" docs/testing/e2e/cross-stage/common-issues.md
sed -n "229,285p" docs/testing/e2e/cross-stage/common-issues.md
sed -n "326,355p" docs/testing/e2e/cross-stage/common-issues.md
sed -n "1,47p" docs/ops/tasks/E2E-R4-1-route-and-checkpoint-foundation.md
sed -n "55,155p" docs/ops/tasks/E2E-R4-1-route-and-checkpoint-foundation.md
cat docs/testing/governance.md
