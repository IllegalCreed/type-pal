import assert from 'node:assert/strict'
import {readFileSync,existsSync} from 'node:fs'
import {execFileSync} from 'node:child_process'
import {resolve} from 'node:path'
import {pathToFileURL} from 'node:url'
const {checkTemplateBody}=await import(pathToFileURL(resolve('scripts/docs/document-model.mjs')));const {markdownLinks}=await import(pathToFileURL(resolve('scripts/docs/markdown.mjs')));const {localTarget}=await import(pathToFileURL(resolve('scripts/docs/check.mjs')));
const path='docs/testing/e2e/cross-stage/README.md',text=readFileSync(path,'utf8'),templates=JSON.parse(readFileSync('docs/phase-governance/templates/registry.json'));const type=templates.types.find(t=>t.templateId==='governance-index-v1');const issues=checkTemplateBody(text,type);assert.deepEqual(issues,[]);const links=markdownLinks(text).map(l=>({...l,resolved:localTarget(path,l.target)}));assert.deepEqual(links.filter(l=>l.resolved&&!existsSync(l.resolved)),[]);
const inbound=[],unreadable=[];for(const p of execFileSync('git',['ls-files','-z'],{encoding:'utf8'}).split('\0').filter(p=>p.endsWith('.md'))){if(!existsSync(p)){unreadable.push(p);continue}for(const l of markdownLinks(readFileSync(p,'utf8')))if(localTarget(p,l.target)===path)inbound.push({source:p,line:l.line,target:l.target});}
const catalog=JSON.parse(readFileSync('docs/testing/catalog.json'));console.log(JSON.stringify({kind:'actual-template-and-link-consumers-structure-only',templateId:type.templateId,templateVersion:type.templateVersion,issues,links,inbound,unreadableTrackedPaths:unreadable,catalogIndexUsersOfDirectory:catalog.entries.filter(e=>e.index==='e2e/cross-stage/README.md').map(e=>e.id),scope:'Real parsers/structure consumers, no prose regex acceptance or stage runtime result.'},null,2));
