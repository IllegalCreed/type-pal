from pathlib import Path
import json,hashlib
s=Path('/tmp/type-pal-s04-author-20261018-p_ahi1x_');sha=lambda b:hashlib.sha256(b).hexdigest();a=json.loads((s/'author-report.json').read_bytes());m=json.loads((s/'artifact-manifest.json').read_bytes());assert sha((s/'author-report.json').read_bytes())=='6d3e05cd334a1100c933fa621c9c4f949c17a6e36cdb914afbb64936470f01bb';assert sha((s/'artifact-manifest.json').read_bytes())=='4c61ecb4f7aef821dc2a44a5f6fe5f552fe7c8e2a1d9099bacf7ca8faad148ed';assert a['author']['nonAuthorReviewer'] is False and m['nonAuthorReviewer'] is False;assert len(m['files'])==76
for f in m['files']:
 p=Path(f['path']);b=p.read_bytes();assert len(b)==f['bytes'] and sha(b)==f['sha256']
records=[]
for f in sorted(s.glob('[0-9][0-9]-*.json')):
 d=json.loads(f.read_bytes());name=d['name']
 for stream in ['stdout','stderr']:
  assert d[stream+'Sha256']==sha((s/(name+'.'+stream)).read_bytes())
 assert d['script']+'\n'==(s/(name+'.sh')).read_text()
 records.append({'receipt':str(f),'sha256':sha(f.read_bytes()),'name':name,'exit':d['exit'],'signal':d['signal'],'cwd':d['cwd']})
assert len(records)==16
print(json.dumps({'kind':'author-package-exact-byte-and-command-artifact-verification','authorTask':a['author']['canonicalTask'],'authorNonAuthorReviewer':a['author']['nonAuthorReviewer'],'manifestSha256':sha((s/'artifact-manifest.json').read_bytes()),'reportSha256':sha((s/'author-report.json').read_bytes()),'verifiedFiles':76,'verifiedCommandReceipts':16,'records':records,'scope':'All manifest SHA/byte pins and command/script/stdout/stderr pairing exact. Author self-check remains self-check, not independent semantic or historical runtime acceptance. No author command rerun.'},indent=2))
