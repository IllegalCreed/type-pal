import assert from 'node:assert/strict'
import { readFileSync } from 'node:fs'
import { createHash } from 'node:crypto'
import { pathToFileURL } from 'node:url'
import { resolve } from 'node:path'
const root=process.cwd();const path=resolve(root,'docs/testing/catalog.json');const before=readFileSync(path);const sha=b=>createHash('sha256').update(b).digest('hex');
const apiPath=resolve(root,'scripts/docs/check-testing.mjs');const {validateCatalog,validateCanonicalEvidence,validateIndexes}=await import(pathToFileURL(apiPath));
const original=JSON.parse(before);const id='e2e-common-issues';const source=original.entries.find(e=>e.id===id);const stage006=original.entries.find(e=>e.id==='e2e-006');
assert.equal(stage006.status,'rework');
const baseline=validateCatalog(original);assert.deepEqual(baseline,[]);
const clone=structuredClone(original);clone.entries.find(e=>e.id===id).dependsOn.push(stage006.id);
const rejected=validateCatalog(clone);assert.deepEqual(rejected,[`${id}: dependency e2e-006 is not current/verified`]);
clone.entries.find(e=>e.id===id).dependsOn.pop();assert.deepEqual(clone,original);const restored=validateCatalog(clone);assert.deepEqual(restored,[]);
const paired=validateCanonicalEvidence(source);const indexes=validateIndexes(original);assert.deepEqual(paired,[]);assert.deepEqual(indexes,[]);assert.deepEqual(readFileSync(path),before);
console.log(JSON.stringify({kind:'real-publication-dependency-IO-control-not-E2E',pid:process.pid,nodeVersion:process.version,sourceModule:apiPath,sourceModuleSha256:sha(readFileSync(apiPath)),catalogSha256:sha(before),utcToday:new Date().toISOString().slice(0,10),baseline,mutation:{target:id,onlyChangedField:'dependsOn',addedId:stage006.id,addedIdUnchangedPublicationStatus:stage006.status},rejected,restored,originalCatalogUnchanged:true,canonicalPairIssues:paired,indexIssues:indexes,actualAuditEntry:source,scope:'Actual validateCatalog on a full in-memory clone, baseline→one exact dependency rejection→restore. No runtime/E2E/business-test execution or sourceRefs business-quality acceptance.'},null,2))
