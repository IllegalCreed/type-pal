from pathlib import Path
import hashlib,json,subprocess
r=Path.cwd();git=lambda *a:subprocess.check_output(['git',*a],cwd=r);p='docs/testing/e2e/cross-stage/README.md';old=git('show','dc478db11c6b52c4e50a1d1135f8a4740796418c:'+p);before=git('show','f9fbf0c7c6e9b59df6c0cbe76b7b90852da76ece:'+p);new=(r/p).read_bytes();sha=lambda b:hashlib.sha256(b).hexdigest();start=b'<!-- original-source-quote:start -->\n';end=b'<!-- original-source-quote:end -->';quote=lambda b:b[b.index(start):];assert quote(new)==quote(before);payload=quote(new)[len(start):].split(end)[0];parts=payload.splitlines(keepends=True);assert len(parts)==6 and parts[-1]==b'>\n'
plain=[]
for line in parts:
 if line.startswith(b'> '):plain.append(line[2:])
 else:assert line==b'>\n';plain.append(b'\n')
direct=b''.join(plain);assert len(old)==243 and len(direct)==244 and direct!=old;assert direct[-1:]==b'\n' and direct[:-1]==old;assert direct[:-2]!=old;assert sha(old)=='14d8b6e5ae98f20a3be9eebe09e7ca4c4764bfd3cc92aaf2f78413af8efcaf7c';assert sha(new)=='1c345654a9f10a19455a8df696b48d9a2f1b86e6fc36bdfe050933a48a8f574c'
changed=git('diff','--name-only','f9fbf0c7c6e9b59df6c0cbe76b7b90852da76ece..HEAD').decode().splitlines();assert changed==[p];protected=(r/'docs/testing/e2e/README.md').read_bytes();assert sha(protected)=='8ddfbda4c48af97ff8c33a229f8cb45f00b1d91e5952d635def86a946be7c9e9';assert git('status','--porcelain=v1')==b''
registry=json.loads((r/'docs/phase-governance/document-registry.json').read_bytes());entries=[e for e in registry['entries'] if e['path']==p];assert len(entries)==1
reviews=[]
for f in sorted((r/'docs/phase-governance/reviews').glob('*.json')):
 for e in json.loads(f.read_bytes()).get('entries',[]):
  if e['path']==p:reviews.append({'record':f.name,'entry':e})
assert len(reviews)==1
print(json.dumps({'kind':'fixed-body-source-and-candidate-binding-audit','candidateCommit':git('rev-parse','HEAD').decode().strip(),'source':{'bytes':len(old),'lines':len(old.splitlines()),'sha256':sha(old)},'before':{'bytes':len(before),'lines':len(before.splitlines()),'sha256':sha(before)},'after':{'bytes':len(new),'lines':len(new.splitlines()),'sha256':sha(new)},'wholeQuoteUnchanged':True,'wholeQuoteSha256':sha(quote(new)),'directInverse':{'bytes':len(direct),'sha256':sha(direct),'equalsSource':False},'conditionedInverse':{'removedExactlyOneLF':True,'removedTwoLFWouldFail':True,'bytes':len(direct[:-1]),'sha256':sha(direct[:-1]),'equalsSource':True},'changedFiles':changed,'protectedS03Sha256':sha(protected),'worktreeClean':True,'registrySchemaVersion':registry['schemaVersion'],'registryTotal':len(registry['entries']),'existingBinding':entries,'existingReview':reviews,'scope':'Mechanical source/quote/binding observation. Existing R60 exactRoundTrip assertion is not endorsed; central successor intake has not occurred.'},ensure_ascii=False,indent=2))
