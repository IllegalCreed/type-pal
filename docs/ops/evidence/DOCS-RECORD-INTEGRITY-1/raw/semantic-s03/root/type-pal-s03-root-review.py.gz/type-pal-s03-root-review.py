from pathlib import Path
import subprocess,os,json,hashlib,tempfile,datetime,concurrent.futures

root=Path('/Users/zhangxu/.codex/worktrees/docs-semantic-e2e-entry/type-pal')
out=Path(tempfile.mkdtemp(prefix='type-pal-s03-root-independent-',dir='/tmp'))
sha=lambda b:hashlib.sha256(b).hexdigest()
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
assert head=='f9fbf0c7c6e9b59df6c0cbe76b7b90852da76ece'
assert subprocess.check_output(['git','status','--porcelain'],cwd=root)==b''
paths=['docs/testing/e2e/README.md','docs/testing/catalog.json','docs/testing/indexes/by-stage.md','docs/testing/e2e/contract.md','projects/pal/e2e-checkpoints/README.md','docs/testing/governance.md','docs/phase-governance/templates/registry.json','scripts/docs/check-testing.mjs','scripts/docs/generate-testing-index.mjs','scripts/docs/check.mjs','scripts/docs/document-model.mjs','scripts/docs/markdown.mjs','docs/ops/tasks/ED-ENTITY-STATE-PLAN-1.md','docs/ops/tasks/E2E-R4-1-route-and-checkpoint-foundation.md','docs/ops/tasks/E2E-005-1-shrimp-errand-and-xianglan-news.md','docs/ops/tasks/E2E-006-1-inn-doctor-and-boat-to-island.md']
pins=[{'path':p,'sha256':sha((root/p).read_bytes()),'bytes':(root/p).stat().st_size} for p in paths]
inputs={'kind':'S03-fixed-nonauthor-inputs','createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':head,'cleanBefore':True,'reviewer':'/root','author':'/root/e2e_entry_semantic_author','nonAuthorReviewer':True,'files':pins,'scope':'Actual root full original/before/candidate/by-stage reads and selected contract/checkpoint/task/producer/validator scopes; file hashes do not imply full semantic reads of all dependencies.'}
out.joinpath('inputs.json').write_text(json.dumps(inputs,ensure_ascii=False,indent=2)+'\n')
out.joinpath('probe.mjs').write_text('''import assert from 'node:assert/strict'
import {readFileSync,existsSync} from 'node:fs'
import {execFileSync} from 'node:child_process'
import {createHash} from 'node:crypto'
import {resolve} from 'node:path'
import {pathToFileURL} from 'node:url'
const {markdownLinks}=await import(pathToFileURL(resolve('scripts/docs/markdown.mjs')))
const {localTarget}=await import(pathToFileURL(resolve('scripts/docs/check.mjs')))
const {checkTemplateBody}=await import(pathToFileURL(resolve('scripts/docs/document-model.mjs')))
const {renderIndexes}=await import(pathToFileURL(resolve('scripts/docs/generate-testing-index.mjs')))
const file='docs/testing/e2e/README.md', after=readFileSync(file), text=after.toString(), digest=b=>createHash('sha256').update(b).digest('hex')
const source=execFileSync('git',['show','dc478db11c6b52c4e50a1d1135f8a4740796418c:'+file])
const before=execFileSync('git',['show','08d95c2e255b7833ef3ce1e6d81011b766fb39d4:'+file]).toString()
const start='<!-- original-source-quote:start -->\\n', end='<!-- original-source-quote:end -->'
const quote=t=>t.split(start)[1].split(end)[0]
assert.equal(quote(text),quote(before))
const inverse=Buffer.from(quote(text).split(/(?<=\\n)/).map(l=>{assert.ok(l.startsWith('>'));return l.startsWith('> ')?l.slice(2):l.slice(1)}).join(''))
assert.equal(source.length,2212);assert.equal(inverse.length,2213)
assert.notDeepEqual(inverse,source);assert.equal(inverse.subarray(-1).toString('hex'),'0a');assert.deepEqual(inverse.subarray(0,-1),source)
assert.equal(digest(source),'310f5031be8e76964cbd1cf2d4e704c5bbfbd2cf4f6451d64a7109d93e67ca6f')
const types=JSON.parse(readFileSync('docs/phase-governance/templates/registry.json')).types
const template=types.find(t=>t.templateId==='governance-index-v1')
assert.deepEqual(checkTemplateBody(text,template),[])
const catalog=JSON.parse(readFileSync('docs/testing/catalog.json'))
const current=text.split('## 历史与原文保全')[0],links=markdownLinks(current),targets=new Set(links.map(l=>localTarget(file,l.target)))
const stages=catalog.entries.filter(e=>e.kind==='e2e-stage')
assert.equal(stages.length,6)
for(const s of stages)for(const p of [s.index,s.canonical])assert.ok(targets.has('docs/testing/'+p),s.id+' -> '+p)
for(const l of markdownLinks(text)){const target=localTarget(file,l.target);if(target)assert.ok(existsSync(target),target)}
assert.equal(renderIndexes(catalog)['by-stage.md'],readFileSync('docs/testing/indexes/by-stage.md','utf8'))
console.log(JSON.stringify({documentSha256:digest(after),sourceSha256:digest(source),sourceBytes:source.length,directInverseBytes:inverse.length,directInverseEqual:false,excludedSuffixHex:'0a',conditionedInverseEqual:true,unchangedQuote:true,templateStructureIssues:0,currentLinks:links.length,stageIndexCanonicalPairs:6,byStageExactProducerMatch:true,scope:'Mechanical consumer/preservation only. Root semantic reasoning is separately recorded; no runtime or report-wide credit.'},null,2))
''')
def run(item):
 name,cmd=item
 start=datetime.datetime.now(datetime.timezone.utc).isoformat()
 r=subprocess.run(cmd,cwd=root,env={**os.environ,'NODE_PATH':'/Users/zhangxu/illegal/type-pal/node_modules'},capture_output=True)
 for stream in ['stdout','stderr']:out.joinpath(name+'.'+stream).write_bytes(getattr(r,stream))
 receipt={'name':name,'command':cmd,'cwd':str(root),'head':head,'startedAt':start,'endedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exitCode':r.returncode,'stdoutSha256':sha(r.stdout),'stderrSha256':sha(r.stderr),'inputManifestSha256':sha(out.joinpath('inputs.json').read_bytes())}
 out.joinpath(name+'.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
 return receipt
commands=[('consumer-preservation',['node',str(out/'probe.mjs')]),('check-docs',['pnpm','check:docs']),('lint',['pnpm','lint']),('strict',['node','scripts/docs/check-content-review.mjs','--strict']),('progress',['node','scripts/docs/report-governance-progress.mjs','--require-complete']),('full-author-diff',['git','diff','--check','08d95c2e255b7833ef3ce1e6d81011b766fb39d4..'+head]),('staged-diff',['git','diff','--cached','--check'])]
with concurrent.futures.ThreadPoolExecutor(max_workers=7) as ex:
 for r in ex.map(run,commands):print(json.dumps({'name':r['name'],'exitCode':r['exitCode'],'directory':str(out)}),flush=True)
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==head
assert subprocess.check_output(['git','status','--porcelain'],cwd=root)==b''
for pin in pins:assert sha((root/pin['path']).read_bytes())==pin['sha256']
out.joinpath('unchanged-after.json').write_text(json.dumps({'head':head,'cleanAfter':True,'allPinnedInputBytesUnchanged':True,'checkedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()},indent=2)+'\n')
print(out,flush=True)
