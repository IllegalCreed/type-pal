import assert from 'node:assert/strict'
import {readFileSync,existsSync} from 'node:fs'
import {execFileSync} from 'node:child_process'
import {createHash} from 'node:crypto'
import {resolve} from 'node:path'
import {pathToFileURL} from 'node:url'
const {markdownLinks}=await import(pathToFileURL(resolve('scripts/docs/markdown.mjs')))
const {localTarget}=await import(pathToFileURL(resolve('scripts/docs/check.mjs')))
const {checkTemplateBody}=await import(pathToFileURL(resolve('scripts/docs/document-model.mjs')))
const {renderIndexes}=await import(pathToFileURL(resolve('scripts/docs/generate-testing-index.mjs')))
const file='docs/testing/e2e/README.md', after=readFileSync(file), text=after.toString(), digest=b=>createHash('sha256').update(b).digest('hex')
const source=execFileSync('git',['show','dc478db11c6b52c4e50a1d1135f8a4740796418c:'+file])
const before=execFileSync('git',['show','08d95c2e255b7833ef3ce1e6d81011b766fb39d4:'+file]).toString()
const start='<!-- original-source-quote:start -->\n', end='<!-- original-source-quote:end -->'
const quote=t=>t.split(start)[1].split(end)[0]
assert.equal(quote(text),quote(before))
const inverse=Buffer.from(quote(text).split(/(?<=\n)/).map(l=>{assert.ok(l.startsWith('>'));return l.startsWith('> ')?l.slice(2):l.slice(1)}).join(''))
assert.equal(source.length,2212);assert.equal(inverse.length,2213)
assert.notDeepEqual(inverse,source);assert.equal(inverse.subarray(-1).toString('hex'),'0a');assert.deepEqual(inverse.subarray(0,-1),source)
assert.equal(digest(source),'310f5031be8e76964cbd1cf2d4e704c5bbfbd2cf4f6451d64a7109d93e67ca6f')
const types=JSON.parse(readFileSync('docs/phase-governance/templates/registry.json')).types
const template=types.find(t=>t.templateId==='governance-index-v1')
assert.deepEqual(checkTemplateBody(text,template),[])
const catalog=JSON.parse(readFileSync('docs/testing/catalog.json'))
const current=text.split('## 历史与原文保全')[0],links=markdownLinks(current),targets=new Set(links.map(l=>localTarget(file,l.target)))
const stages=catalog.entries.filter(e=>e.kind==='e2e-stage')
assert.equal(stages.length,6)
for(const s of stages)for(const p of [s.index,s.canonical])assert.ok(targets.has('docs/testing/'+p),s.id+' -> '+p)
for(const l of markdownLinks(text)){const target=localTarget(file,l.target);if(target)assert.ok(existsSync(target),target)}
assert.equal(renderIndexes(catalog)['by-stage.md'],readFileSync('docs/testing/indexes/by-stage.md','utf8'))
console.log(JSON.stringify({documentSha256:digest(after),sourceSha256:digest(source),sourceBytes:source.length,directInverseBytes:inverse.length,directInverseEqual:false,excludedSuffixHex:'0a',conditionedInverseEqual:true,unchangedQuote:true,templateStructureIssues:0,currentLinks:links.length,stageIndexCanonicalPairs:6,byStageExactProducerMatch:true,scope:'Mechanical consumer/preservation only. Root semantic reasoning is separately recorded; no runtime or report-wide credit.'},null,2))
