python3 - <<'PY'
from pathlib import Path
import json
p=Path('/tmp/type-pal-s03-author-followup-20261018-2c1ksn5l')
for n in ['04-check-docs','05-lint','06-strict','07-require-complete']:
 print((p/(n+'.json')).read_text())
 if n=='04-check-docs':
  for line in (p/(n+'.stdout')).read_text().splitlines():
   if line.startswith(('# tests ','# pass ','# fail ','# skipped ','# cancelled ','# todo ','docs:','document model:','testing docs:','phase/lore governance:','content review:')): print(line)
  print('stderr lines',len((p/(n+'.stderr')).read_text().splitlines()))
PY
git diff --cached --check && git commit -m "docs: qualify E2E quote inverse preservation" && git rev-parse HEAD && git diff --check 08d95c2e255b7833ef3ce1e6d81011b766fb39d4..HEAD && git diff --name-only 08d95c2e255b7833ef3ce1e6d81011b766fb39d4..HEAD && git status --short
