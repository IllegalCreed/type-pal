python3 /tmp/type-pal-s03-author-followup-20261018-2c1ksn5l/revise-preservation.py && git diff -- docs/testing/e2e/README.md
