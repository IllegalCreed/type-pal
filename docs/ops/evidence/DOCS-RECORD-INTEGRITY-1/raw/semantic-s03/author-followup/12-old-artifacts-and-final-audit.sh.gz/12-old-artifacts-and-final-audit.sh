python3 - <<'PY'
from pathlib import Path
import hashlib,json
p=Path('/tmp/type-pal-s03-author-20261018-al36xarv/artifact-manifest.json')
m=json.loads(p.read_text())
for e in m['files']:
 b=Path(e['path']).read_bytes()
 assert hashlib.sha256(b).hexdigest()==e['sha256'],e['path']
 assert len(b)==e['bytes'],e['path']
print('prior evidence files unchanged:',len(m['files']))
print('prior manifest SHA:',hashlib.sha256(p.read_bytes()).hexdigest())
PY
git diff --check 08d95c2e255b7833ef3ce1e6d81011b766fb39d4..HEAD && git status --short && git rev-parse HEAD && shasum -a 256 docs/testing/e2e/README.md /tmp/type-pal-s03-author-followup-20261018-2c1ksn5l/author-addendum.json
