python3 /tmp/type-pal-s03-author-followup-20261018-2c1ksn5l/verify-preservation.py
