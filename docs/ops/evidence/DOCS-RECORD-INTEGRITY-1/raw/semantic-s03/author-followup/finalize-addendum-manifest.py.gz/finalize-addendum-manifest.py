from pathlib import Path
import datetime,hashlib,json,subprocess
p=Path('/tmp/type-pal-s03-author-followup-20261018-2c1ksn5l')
old=Path('/tmp/type-pal-s03-author-20261018-al36xarv')
sha=lambda b:hashlib.sha256(b).hexdigest()
files=[{'path':str(f),'sha256':sha(f.read_bytes()),'bytes':f.stat().st_size} for f in sorted(p.iterdir()) if f.is_file() and not f.name.startswith('artifact-manifest')]
m={'kind':'S03-append-only-author-evidence-manifest','createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'authorCanonicalTask':'/root/e2e_entry_semantic_author','nonAuthorReviewer':False,'frozenCandidateCommit':'f9fbf0c7c6e9b59df6c0cbe76b7b90852da76ece','documentSha256':'8ddfbda4c48af97ff8c33a229f8cb45f00b1d91e5952d635def86a946be7c9e9','authorAddendumPath':str(p/'author-addendum.json'),'authorAddendumSha256':sha((p/'author-addendum.json').read_bytes()),'appendOnlyPredecessor':{'manifestPath':str(old/'artifact-manifest.json'),'manifestSha256':sha((old/'artifact-manifest.json').read_bytes()),'reportPath':str(old/'author-report.json'),'reportSha256':sha((old/'author-report.json').read_bytes()),'all141PriorEvidenceFilesReverifiedUnchanged':True,'verificationReceipt':str(p/'12-old-artifacts-and-final-audit.json')},'scope':'new numbered receipts01-12 with exact cwd/scripts/time/exit/signal/full stdout/stderr plus frozen addendum, source snapshots, programs and finalizer; no self-hash recursion','notes':['Author addendum was frozen before finalization receipts10-12; those exact new outputs are carried here.','Original cafe0578 report and raw failures retained; no retroactive rewrite or acceptance.','Entire original quote unchanged; direct inverse is explicitly false; removal of exactly preexisting separator LF is a separately conditioned mechanical result.','Global checkdocs/strict/require-complete failures remain; lint zero and full frozen diff0 do not grant done or semantic acceptance.'],'files':files}
raw=json.dumps(m,ensure_ascii=False,indent=2)+'\n'
(p/'artifact-manifest.raw.json').write_text(raw)
r=subprocess.run(['node','/Users/zhangxu/illegal/type-pal/node_modules/@biomejs/biome/bin/biome','format','--stdin-file-path=docs/ops/evidence/DOCS-FULL-TEMPLATE-1/s03-addendum-manifest.json'],input=raw.encode(),capture_output=True)
(p/'artifact-manifest-format.stderr').write_bytes(r.stderr)
assert r.returncode==0,(r.returncode,r.stderr)
(p/'artifact-manifest.json').write_bytes(r.stdout)
for e in files:assert sha(Path(e['path']).read_bytes())==e['sha256']
print('files',len(files))
print('manifest',p/'artifact-manifest.json',sha(r.stdout))
print('addendum',p/'author-addendum.json',sha((p/'author-addendum.json').read_bytes()))
