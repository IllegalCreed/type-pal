cat docs/testing/e2e/README.md && git diff --check && git add -- docs/testing/e2e/README.md && git diff --cached --check && git diff --cached --stat
