cat docs/ops/agent-workflow.md docs/ops/board.md
