python3 - <<'PY'
import json
c=json.load(open('docs/testing/catalog.json'))
sel=[e for e in c['entries'] if e['canonical'].startswith('e2e/')]
fields=['id','kind','title','status','phase','engines','owner','provenance','canonical','index','evidence','tags','lastVerified','reviewBy','dependsOn','revision']
print(json.dumps([{k:e[k] for k in fields} for e in sel],ensure_ascii=False,indent=2))
print('selected count',len(sel))
assert len(sel)==9
PY
sed -n "18,50p" docs/testing/e2e/contract.md
sed -n "98,132p" docs/testing/e2e/contract.md
sed -n "239,284p" docs/testing/e2e/contract.md
sed -n "467,482p" docs/testing/e2e/contract.md
