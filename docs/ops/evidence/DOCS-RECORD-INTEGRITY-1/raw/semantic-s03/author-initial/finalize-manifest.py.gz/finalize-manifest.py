from pathlib import Path
import datetime,hashlib,json,subprocess
p=Path('/tmp/type-pal-s03-author-20261018-al36xarv')
sha=lambda b:hashlib.sha256(b).hexdigest()
files=[{'path':str(f),'sha256':sha(f.read_bytes()),'bytes':f.stat().st_size} for f in sorted(p.iterdir()) if f.is_file() and not f.name.startswith('artifact-manifest')]
m={'kind':'S03-author-evidence-intake-manifest','createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'authorCanonicalTask':'/root/e2e_entry_semantic_author','nonAuthorReviewer':False,'frozenCandidateCommit':'cafe0578acdde76405955102dd4d01427f18cffb','documentSha256':'84558465defc66b2dad8bc1a1a32242337d0b14f68c33135e5af817e5641b44a','authorReportPath':str(p/'author-report.json'),'authorReportSha256':sha((p/'author-report.json').read_bytes()),'scope':'numbered execution receipts01-32, exact scripts/full streams, source/before snapshots, temporary verification programs, fixed author report and finalizer; manifest excluded from itself','finalizationNotes':['author-report.json was project-Biome formatted; second format and check --write stdin each produced exactly equal bytes','31 optional check without --write against stdin exited1 and stopped its && chain, emitting unchanged report bytes and contents-not-fixed stdin diagnostic; receipt/raw retained','32 proper stdin check --write wrote only /tmp/author-report.checked.json, cmp proved same bytes, then full frozen diff/status/SHA audit passed; no repository write or rule change','report was frozen before receipts29-32 and does not self-embed its own content hash; this external manifest carries those finalization files'],'files':files}
raw=json.dumps(m,ensure_ascii=False,indent=2)+'\n'
(p/'artifact-manifest.raw.json').write_text(raw)
r=subprocess.run(['node','/Users/zhangxu/illegal/type-pal/node_modules/@biomejs/biome/bin/biome','format','--stdin-file-path=docs/ops/evidence/DOCS-FULL-TEMPLATE-1/s03-intake-manifest.json'],input=raw.encode(),capture_output=True)
(p/'artifact-manifest-format.stderr').write_bytes(r.stderr)
assert r.returncode==0,(r.returncode,r.stderr)
(p/'artifact-manifest.json').write_bytes(r.stdout)
for e in files:assert sha(Path(e['path']).read_bytes())==e['sha256']
print('files',len(files))
print('manifest',p/'artifact-manifest.json',sha(r.stdout))
print('report',p/'author-report.json',sha((p/'author-report.json').read_bytes()))
