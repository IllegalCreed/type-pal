cat /Users/zhangxu/.agents/skills/pnpm/SKILL.md
sed -n "414,565p" scripts/docs/check-testing.mjs
sed -n "598,630p" scripts/docs/check-testing.mjs
sed -n "1,50p" docs/lore/timeline.md
sed -n "33,52p" docs/testing/README.md
git show -s --format=fuller dc478db11c6b52c4e50a1d1135f8a4740796418c
