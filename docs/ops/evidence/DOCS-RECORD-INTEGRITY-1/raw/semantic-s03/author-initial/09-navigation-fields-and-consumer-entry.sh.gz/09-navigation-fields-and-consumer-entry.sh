python3 - <<'PY'
import json
c=json.load(open('docs/testing/catalog.json'))
print('catalog root keys',list(c))
entries=c['entries']
sel=[e for e in entries if e['canonical'].startswith('docs/testing/e2e/')]
fields=['id','kind','title','status','phase','engines','owner','provenance','canonical','index','evidence','tags','lastVerified','reviewBy','dependsOn','revision']
print(json.dumps([{k:e[k] for k in fields} for e in sel],ensure_ascii=False,indent=2))
print('selected count',len(sel))
PY
sed -n "1,125p" scripts/docs/generate-testing-index.mjs
rg -n "catalog|indexes|canonical|status|dependsOn|checkTesting|export|process.argv" scripts/docs/check-testing.mjs
