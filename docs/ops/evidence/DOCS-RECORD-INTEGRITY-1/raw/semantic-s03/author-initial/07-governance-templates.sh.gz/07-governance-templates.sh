cat docs/testing/governance.md docs/phase-governance/templates/README.md docs/phase-governance/templates/governance-index-v1.md
