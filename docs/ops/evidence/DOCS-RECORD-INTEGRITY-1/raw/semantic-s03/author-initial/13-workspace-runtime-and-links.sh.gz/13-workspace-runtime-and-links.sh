cat pnpm-workspace.yaml
if test -f .npmrc; then cat .npmrc; fi
command -v pnpm
node --version
pnpm --version
ls -ld node_modules
rg -n "export|validate|process.argv|readFile" scripts/docs/check-document-model.mjs scripts/docs/check-content-review.mjs | head -50
git show-ref --verify refs/heads/codex/docs-semantic-e2e-entry
