python3 - <<'PY'
from pathlib import Path
import json
p=Path('/tmp/type-pal-s03-author-20261018-al36xarv')
print((p/'20-check-docs.json').read_text())
for stream in ['stdout','stderr']:
 lines=(p/('20-check-docs.'+stream)).read_text().splitlines()
 print(stream,'lines',len(lines))
 for line in lines:
  if any(x in line for x in ['# tests ','# pass ','# fail ','# skipped ','# cancelled ','# todo ','docs: ','document model:','testing docs:','phase/lore','content review:','docs/testing/e2e/README.md:']): print(line)
PY
git switch -c codex/docs-semantic-e2e-entry
git add -- docs/testing/e2e/README.md
git diff --cached --check
git diff --cached --stat
