sed -n "1,44p" docs/ops/tasks/DOCS-FULL-TEMPLATE-1.md && rg -n "S03|S02|S01|当前|准入" docs/ops/tasks/DOCS-FULL-TEMPLATE-1.md | tail -55 && sed -n "1520,1635p" docs/ops/tasks/DOCS-FULL-TEMPLATE-1.md
