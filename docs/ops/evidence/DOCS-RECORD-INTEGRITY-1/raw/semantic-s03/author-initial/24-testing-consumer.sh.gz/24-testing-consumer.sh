NODE_PATH=/Users/zhangxu/illegal/type-pal/node_modules pnpm check:testing-docs
