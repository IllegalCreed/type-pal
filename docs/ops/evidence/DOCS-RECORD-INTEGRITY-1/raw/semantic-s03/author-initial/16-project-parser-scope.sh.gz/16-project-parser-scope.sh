sed -n "1,55p" scripts/docs/check.mjs
sed -n "98,143p" scripts/docs/document-model.mjs
cat scripts/docs/markdown.mjs
python3 - <<'PY'
import json
r=json.load(open('docs/phase-governance/templates/registry.json'))
print(list(r))
for t in r['templates']:
 if t['templateId']=='governance-index-v1': print(json.dumps(t,ensure_ascii=False,indent=2))
PY
