import assert from 'node:assert/strict'
import { execFileSync } from 'node:child_process'
import { createHash } from 'node:crypto'
import { existsSync, readFileSync } from 'node:fs'
import { resolve } from 'node:path'
import { pathToFileURL } from 'node:url'
const root = process.cwd()
const { markdownLinks } = await import(pathToFileURL(resolve('scripts/docs/markdown.mjs')))
const { localTarget } = await import(pathToFileURL(resolve('scripts/docs/check.mjs')))
const { checkTemplateBody } = await import(pathToFileURL(resolve('scripts/docs/document-model.mjs')))
const { renderIndexes } = await import(pathToFileURL(resolve('scripts/docs/generate-testing-index.mjs')))
const file = 'docs/testing/e2e/README.md'
const after = readFileSync(file)
const before = readFileSync('/tmp/type-pal-s03-author-20261018-al36xarv/before-readme.md')
const source = execFileSync('git', ['show', 'dc478db11c6b52c4e50a1d1135f8a4740796418c:docs/testing/e2e/README.md'])
const sha = (b) => createHash('sha256').update(b).digest('hex')
const begin = '<!-- original-source-quote:start -->\n'
const end = '<!-- original-source-quote:end -->'
const text = after.toString('utf8')
const quoted = text.split(begin)[1].split(end)[0]
const decodedQuote = Buffer.from(quoted.split(/(?<=\n)/).map((line) => {
  assert.ok(line.startsWith('>'), `non-quote line ${JSON.stringify(line)}`)
  return line.startsWith('> ') ? line.slice(2) : line.slice(1)
}).join(''))
const inverse = decodedQuote.subarray(0, source.length)
const quoteSeparator = decodedQuote.subarray(source.length)
assert.deepEqual(inverse, source)
assert.deepEqual(quoteSeparator, Buffer.from('\n'))
assert.equal(text.slice(text.indexOf(begin)), before.toString('utf8').slice(before.toString('utf8').indexOf(begin)))
console.log(JSON.stringify({ sourceSha: sha(source), beforeSha: sha(before), afterSha: sha(after), sourceLines: source.toString().split('\n').length - 1, afterLines: text.split('\n').length - 1, quoteBytes: inverse.length, decodedQuoteBytes: decodedQuote.length, excludedQuoteSeparatorHex: quoteSeparator.toString('hex'), quoteInverseMatches: true, quoteBlockUnchanged: true }))
const registry = JSON.parse(readFileSync('docs/phase-governance/templates/registry.json'))
const template = registry.types.find((entry) => entry.templateId === 'governance-index-v1')
const structureIssues = checkTemplateBody(text, template)
assert.deepEqual(structureIssues, [])
console.log(JSON.stringify({ check: 'public checkTemplateBody', templateId: template.templateId, templateVersion: template.templateVersion, requiredSections: template.requiredSections, issues: structureIssues, scope: 'structure only; author self-check' }))
const current = text.slice(0, text.indexOf('## 历史与原文保全'))
const links = markdownLinks(text).map((link) => ({ ...link, resolved: localTarget(file, link.target) }))
const missing = links.filter((link) => link.resolved && !existsSync(resolve(root, link.resolved)))
assert.deepEqual(missing, [])
const catalog = JSON.parse(readFileSync('docs/testing/catalog.json'))
const stageEntries = catalog.entries.filter((entry) => entry.kind === 'e2e-stage')
const currentTargets = new Set(markdownLinks(current).map((link) => localTarget(file, link.target)))
const targets = stageEntries.map((entry) => ({ id: entry.id, index: `docs/testing/${entry.index}`, canonical: `docs/testing/${entry.canonical}` }))
assert.equal(targets.length, 6)
for (const stage of targets) for (const target of [stage.index, stage.canonical]) assert.ok(currentTargets.has(target), `${stage.id} missing ${target}`)
const stageView = renderIndexes(catalog)['by-stage.md']
assert.equal(stageView, readFileSync('docs/testing/indexes/by-stage.md', 'utf8'))
console.log(JSON.stringify({ check: 'actual catalog -> renderIndexes -> by-stage and README links', stageTargets: targets, byStageMatchesProducer: true, localLinkCount: links.length, missing, currentLinks: markdownLinks(current) }))
const inbound = []
const files = execFileSync('git', ['ls-files', '-z']).toString().split('\0').filter((path) => path.endsWith('.md'))
for (const candidate of files) {
  for (const link of markdownLinks(readFileSync(candidate, 'utf8'))) {
    if (localTarget(candidate, link.target) === file) inbound.push({ source: candidate, line: link.line, target: link.target })
  }
}
console.log(JSON.stringify({ check: 'mechanical inbound inventory; no semantic claim for all sources', inbound, catalogIndexUsers: catalog.entries.filter((entry) => entry.index === 'e2e/README.md').map((entry) => entry.id) }))
