cat docs/ops/guides/documentation-model.md
