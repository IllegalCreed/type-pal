node /tmp/type-pal-s03-author-20261018-al36xarv/verify-entry-v3.mjs
