from pathlib import Path
import subprocess,json,gzip,hashlib
root=Path.cwd();out=root/'docs/ops/evidence/QUALITY-BATTLE-MAGIC-PARITY-1';base='0e3fc84fe5949f7ca9c3eb87b1d2a284be945f3c';names=['magic-damage.ts','battle-opcodes.ts','actions/magic.ts'];paths=[Path('packages/game/src/core/battle')/n for n in names];originals={str(p):p.read_bytes() for p in paths};spec=Path('packages/game/src/core/battle/__tests__/magic-parity.test.ts').read_bytes();(out/'regression-legal.spec.ts.gz').write_bytes(gzip.compress(spec,mtime=0))
cmd=['pnpm','--filter','@type-pal/game','exec','vitest','run','src/core/battle/__tests__/magic-parity.test.ts','--reporter=default','--reporter=json','--outputFile=/tmp/type-pal-magic-final-red.json']
try:
 for p in paths:p.write_bytes(subprocess.check_output(['git','show',base+':'+str(p)]))
 done=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);raw=done.stdout;report=Path('/tmp/type-pal-magic-final-red.json').read_bytes();v=json.loads(report);failures=[a['fullName'] for f in v['testResults'] for a in f['assertionResults'] if a['status']=='failed']
 (out/'red-legal.raw.gz').write_bytes(gzip.compress(raw,mtime=0));(out/'red-legal.vitest.json.gz').write_bytes(gzip.compress(report,mtime=0))
 row={'command':cmd,'cwd':str(root),'exit':done.returncode,'base':base,'testSha256':hashlib.sha256(spec).hexdigest(),'failed':v['numFailedTests'],'passed':v['numPassedTests'],'runtimeErrorSuites':v.get('numRuntimeErrorTestSuites',0),'failures':failures,'raw':'red-legal.raw.gz','rawSha256':hashlib.sha256(raw).hexdigest(),'rawBytes':len(raw),'oldProductionSha256':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}}
finally:
 for p,s in originals.items():Path(p).write_bytes(s)
row['restoredSha256']={p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in originals};assert all(Path(p).read_bytes()==s for p,s in originals.items());(out/'red-legal.json').write_text(json.dumps(row,ensure_ascii=False,indent=2)+'\n');print(json.dumps(row,ensure_ascii=False));assert done.returncode==1 and v['numFailedTests']==9 and v.get('numRuntimeErrorTestSuites',0)==0
