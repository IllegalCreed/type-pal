from pathlib import Path
import json,gzip,subprocess,hashlib
root=Path.cwd();out=root/'docs/ops/evidence/QUALITY-BATTLE-MAGIC-PARITY-1';prod=Path('packages/game/src/core/battle/battle-system.ts');test=Path('packages/game/src/core/battle/battle-system.glm-next-wave.test.ts');original=prod.read_bytes();current=test.read_bytes();old=subprocess.check_output(['git','show','0e3fc84fe:'+str(test)]);needle="if (state.phase === 'won' || state.phase === 'lost' || state.phase === 'fleed') break";assert original.decode().count(needle)==1
rows=[]
try:
 prod.write_text(original.decode().replace(needle,'void state.phase',1))
 for label,blob in [('h01-old-green',old),('h01-new-red',current)]:
  test.write_bytes(blob);j=Path('/tmp')/(label+'.json');cmd=['pnpm','--filter','@type-pal/game','exec','vitest','run','src/core/battle/battle-system.glm-next-wave.test.ts','-t','敌 A turnStart','--reporter=default','--reporter=json','--outputFile='+str(j)];p=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);raw=p.stdout;v=json.loads(j.read_text());fail=[a for f in v['testResults'] for a in f['assertionResults'] if a['status']=='failed'];(out/(label+'.raw.gz')).write_bytes(gzip.compress(raw,mtime=0));(out/(label+'.vitest.json.gz')).write_bytes(gzip.compress(j.read_bytes(),mtime=0));rows.append({'label':label,'command':cmd,'exit':p.returncode,'failed':v['numFailedTests'],'passed':v['numPassedTests'],'runtimeErrorSuites':v.get('numRuntimeErrorTestSuites',0),'testSha256':hashlib.sha256(blob).hexdigest(),'failureNames':[a['fullName'] for a in fail],'raw':label+'.raw.gz','rawSha256':hashlib.sha256(raw).hexdigest()})
finally:
 prod.write_bytes(original);test.write_bytes(current)
assert rows[0]['exit']==0 and rows[0]['passed']==1 and rows[1]['exit']==1 and rows[1]['failed']==1 and rows[1]['runtimeErrorSuites']==0
v={'scope':'Remove only terminal-result break; old ip2=end oracle remains green, corrected ip3=dialog oracle fails once. Production source restored byte-for-byte.','originalSourceSha256':hashlib.sha256(original).hexdigest(),'restoredSourceSha256':hashlib.sha256(prod.read_bytes()).hexdigest(),'rows':rows};(out/'h01-control.json').write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n');print(json.dumps(v,ensure_ascii=False))
