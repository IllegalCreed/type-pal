# -*- coding: utf-8 -*-
from pathlib import Path
import subprocess,json,hashlib,gzip
root=Path.cwd();out=root/'docs/ops/evidence/QUALITY-BATTLE-MAGIC-PARITY-1';base='0e3fc84fe5949f7ca9c3eb87b1d2a284be945f3c'
full=['packages/game/src/core/battle/magic-damage.ts','packages/game/src/core/battle/battle-opcodes.ts','packages/game/src/core/battle/actions/magic.ts','packages/game/src/core/battle/simulated-magic-target.ts','packages/game/src/core/battle/__tests__/magic-parity.test.ts','packages/game/src/core/battle/__tests__/battle-opcodes.test.ts','packages/game/src/core/battle/actions/throw-item.ts','packages/game/src/core/battle/battle-runtime-context.ts','packages/game/src/__tests__/glm-next-wave/H/harness.ts','packages/game/src/core/rng.ts','packages/game/src/core/battle/formulas.ts','packages/game/src/core/battle/actions/magic.glm-next-wave.test.ts','packages/game/src/core/battle/battle-system.glm-next-wave.test.ts']
rows=[]
for name in full:
 raw=(root/name).read_bytes();previous=subprocess.run(['git','show',base+':'+name],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 rows.append({'path':name,'lines':len(raw.decode().splitlines()),'sha256':hashlib.sha256(raw).hexdigest(),'readBoundary':'Full pre-edit implementation/test text plus own current delta; new files authored and inspected in full. Read evidence is not whole-file acceptance.','baseSha256':hashlib.sha256(previous.stdout).hexdigest() if previous.returncode==0 else None,'baseLines':len(previous.stdout.decode().splitlines()) if previous.returncode==0 else None})
partial=[('packages/game/src/core/game-state.ts',[[1394,1451],[1558,1705]],'Hydration and runtime-to-battle equipment projection ownership'),('packages/game/src/core/event-system.ts',[[957,1045],[2915,2978],[3035,3078]],'BattleCtx and real raw dispatch/caller lifecycle; remaining whole file not reread'),('packages/game/src/core/battle/battle-state.ts',[[1,170],[545,556],[720,918]],'Types, previous target, real constructor and occupied/empty slot lifecycle; not full current reread'),('packages/game/src/core/battle/anim-timeline.ts',[[935,1100],[1720,1775]],'FIRE landing/frame count and enemy cast intro defense pose insertion; not full current reread'),('packages/game/src/core/battle/battle-anim-driver.ts',[[1,164],[200,254]],'Actual declaration frame consumer, timeline progression and pose ownership; not full current reread')]
pr=[]
for name,ranges,why in partial:
 raw=(root/name).read_bytes();assert all(1<=a<=b<=len(raw.decode().splitlines()) for a,b in ranges);pr.append({'path':name,'lines':len(raw.decode().splitlines()),'sha256':hashlib.sha256(raw).hexdigest(),'ranges':ranges,'boundary':why})
prior=json.loads(Path('docs/ops/evidence/QUALITY-PRE94-RETROSPECTIVE-1/3s-battle-system/read-boundaries.json').read_text());inherited=[]
for name in ['packages/game/src/core/battle/battle-system.ts','packages/game/src/core/battle/__tests__/battle-system.test.ts']:
 row=next(x for x in prior['fullReads'] if x['path']==name);before=subprocess.check_output(['git','show',base+':'+name]);assert hashlib.sha256(before).hexdigest()==row['sha256'];inherited.append({'path':name,'baseSha256':row['sha256'],'currentSha256':hashlib.sha256(Path(name).read_bytes()).hexdigest(),'currentLines':len(Path(name).read_text().splitlines()),'priorFullRead':'docs/ops/evidence/QUALITY-PRE94-RETROSPECTIVE-1/3s-battle-system/read-boundaries.json','sameBaseBytesVerified':True,'currentReadRanges':[[1933,1963],[2680,2795],[2800,2973]] if name.endswith('battle-system.ts') else [[1,230],[419,465],[520,650],[3420,3510]],'scope':'Inherited same-session full reading, only current caller/fixture delta reread. Not a new whole-file acceptance.'})
primary=[]
for name,ranges,functions in [('reference/sdlpal/fight.c',[[87,128],[4719,4768],[5300,5400],[2738,2765]],{87:'PAL_BattleSelectAutoTargetFrom(',5301:'PAL_BattleSimulateMagic('}),('reference/sdlpal/script.c',[[1630,1640],[2007,2014]],{})]:
 raw=Path(name).read_bytes();ls=raw.decode().splitlines();assert all(1<=a<=b<=len(ls) for a,b in ranges)
 for n,f in functions.items():assert ls[n-1].strip()==f
 primary.append({'path':name,'lines':len(ls),'sha256':hashlib.sha256(raw).hexdigest(),'ranges':ranges,'verifiedFunctionNames':functions})
v={'base':base,'owner':'Codex single agent','fullReads':rows,'partialReads':pr,'inheritedSameSessionFullReads':inherited,'primary':primary,'phase':'phase1 only','acceptance':'Counter repair only; all eight affected rows review; no new closed file; no full repository gate, coverage, protected fast or browser visual credit'}
(out/'read-boundaries.json').write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
(out/'red-replay.py.gz').write_bytes(gzip.compress(Path('/tmp/type-pal-magic-legal-red.py').read_bytes(),mtime=0))
print('Actual source boundaries/function EOF and inherited same-session read SHA validated.')
