from pathlib import Path
import json,subprocess,hashlib,gzip
base='0e3fc84fe5949f7ca9c3eb87b1d2a284be945f3c';out=Path('docs/ops/evidence/QUALITY-BATTLE-MAGIC-PARITY-1');files=[p for p in Path('docs/phase-governance/reviews').glob('*.json') if subprocess.run(['git','diff','--quiet','--',str(p)]).returncode!=0];checks=[]
for p in files:
 old=json.loads(subprocess.check_output(['git','show',base+':'+str(p)]));new=json.loads(p.read_text());assert list(old)==list(new);assert len(old['entries'])==len(new['entries']);changed=[]
 for a,b in zip(old['entries'],new['entries']):
  if a==b:continue
  assert a['path']==b['path'];changed.append(a['path']);aa=json.loads(json.dumps(a));bb=json.loads(json.dumps(b))
  for x in [aa,bb]:
   x.pop('afterSha256',None);x.pop('reviewedLines',None);x.get('evidence',{}).pop('afterSha256',None)
   for k in ['implementationSha','afterSha256','history']:x.get('revision',{}).pop(k,None)
  assert aa==bb,(str(p),a['path']);assert len(b['revision']['history'])==len(a['revision']['history'])+1;assert all(h in b['revision']['history'] for h in a['revision']['history']);assert hashlib.sha256(Path(b['path']).read_bytes()).hexdigest()==b['afterSha256']
 checks.append({'review':str(p),'onlyScopedEntriesChanged':changed,'nativeConclusionsAndOtherFieldsPreserved':True})
old=json.loads(subprocess.check_output(['git','show',base+':docs/phase-governance/catalog.phase1.json']));new=json.loads(Path('docs/phase-governance/catalog.phase1.json').read_text());assert len(old['entries'])==len(new['entries']);assert [r for r in old['entries'] if r['path']!='docs/phase1/game-mechanics.md']==[r for r in new['entries'] if r['path']!='docs/phase1/game-mechanics.md']
for name in ['red-legal.json','adjacent-clean.json','h01-final.json','docs.json','docs-consumers.json','docs-consumers-final.json','types-current.json','lint.json','ledger.json','diff.json']:
 v=json.loads((out/name).read_text());raw=gzip.decompress((out/v['raw']).read_bytes());assert hashlib.sha256(raw).hexdigest()==v['rawSha256']
v={'base':base,'scope':'Codex separate-process structured integrity self-check, not an independent reviewer or product gate','reviewDeltas':checks,'untouchedOther59Phase1Entries':True,'rawHashesVerified':True};(out/'integrity.json').write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n');print(json.dumps(v,ensure_ascii=False))
