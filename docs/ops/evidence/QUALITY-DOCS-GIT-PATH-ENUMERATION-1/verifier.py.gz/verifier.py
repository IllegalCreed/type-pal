from pathlib import Path
import json,gzip,hashlib,subprocess,copy
root=Path.cwd();p=root/'docs/ops/evidence/QUALITY-DOCS-GIT-PATH-ENUMERATION-1';base='6fde6d86cf9754e441de948c82ac99ebc1f480c8';sha=lambda b:hashlib.sha256(b).hexdigest();git=lambda path:subprocess.check_output(['git','show',base+':'+str(path)]);before=json.loads((p/'before.json').read_text());sourcePaths=[r['path'] for r in before['files']]
for r in before['files']:
 b=gzip.decompress((p/r['snapshot']).read_bytes());assert b==git(r['path']) and sha(b)==r['sha256'] and len(b.splitlines())==r['lines']
old=git(sourcePaths[0]).decode();expected=old.replace("    { cwd: repoRoot, encoding: 'utf8' },","    // Complete checkout paths can exceed Node's default 1MiB; keep a finite IO bound.\n    { cwd: repoRoot, encoding: 'utf8', maxBuffer: 16 * 1024 * 1024 },");assert expected==Path(sourcePaths[0]).read_text()
old=git(sourcePaths[1]).decode();expected=old.replace("execFileSync('git', ['ls-files', '-z'], { cwd: root, encoding: 'utf8' })","execFileSync('git', ['ls-files', '-z'], {\n    cwd: root,\n    encoding: 'utf8',\n    // This is the whole tracked path list, including out-of-scope evidence paths.\n    maxBuffer: 16 * 1024 * 1024,\n  })");assert expected==Path(sourcePaths[1]).read_text()
old=git(sourcePaths[2]).decode().split("test('code-quality inventory",1)[1].strip();new=Path(sourcePaths[2]).read_text().split("test('code-quality inventory",1)[1].split('/** Real Git',1)[0].strip();assert old==new
for r in json.loads((p/'read-boundaries.json').read_text())['rows']:
 b=git(r['path']) if r['path']=='docs/ops/evidence/README.md' else Path(r['path']).read_bytes();assert sha(b)==r['sha256'] and len(b.splitlines())==r['lines'] and gzip.decompress((p/r['snapshot']).read_bytes())==b and r['ranges']==[[1,r['lines']]]
def receipt(r):
 raw=gzip.decompress((p/r['raw']).read_bytes());assert sha(raw)==r['rawSha256'] and len(raw)==r['rawBytes'] and r['fullUncutMergedStdoutStderr'] and r['signal'] is None and r['spawnError'] is None;return raw.decode()
rawPairs=[]
for f in p.glob('*.json'):
 d=json.loads(f.read_text())
 if isinstance(d,dict) and 'raw' in d:
  s=receipt(d);assert d['exit']==(1 if f.name=='red.json' else 0);rawPairs.append({'receipt':f.name,'raw':d['raw'],'sha256':d['rawSha256'],'exit':d['exit']})
red=receipt(json.loads((p/'red.json').read_text()));assert '# pass 1\n' in red and '# fail 2\n' in red and red.count("  name: 'AssertionError'")==2 and '# skipped 0' in red;green=receipt(json.loads((p/'green.json').read_text()));assert '# pass 3\n' in green and '# fail 0\n' in green
c=json.loads((p/'controls.json').read_text());assert c['restored'] and len(c['controls'])==2
for row in c['controls']:
 assert row['sourceSha256']==sha(Path(row['source']).read_bytes()) and row['mutantSha256']==sha(git(row['source']))
 for phase,r in row['runs'].items():
  s=receipt(r);assert r['restored'] and r['sourceRestoredSha256']==row['sourceSha256'] and r['specRestoredSha256']==sha(Path(sourcePaths[2]).read_bytes()) and '# skipped 0' in s and '# cancelled 0' in s and '# todo 0' in s
  expectedSpec=git(sourcePaths[2]) if phase=='old' else Path(sourcePaths[2]).read_bytes();assert r['specSha256']==sha(expectedSpec)
  if phase=='old':assert r['exit']==0 and '# pass 1\n' in s and '# fail 0\n' in s
  else:assert r['exit']==1 and len(r['failedNames'])==1 and row['expectedFailure'] in r['failedNames'][0] and '# pass 2\n' in s and '# fail 1\n' in s and "  name: 'AssertionError'" in s
ledger='docs/ops/audits/code-quality-file-ledger.md';a=git(ledger).decode();b=Path(ledger).read_text();mark='<!-- original-source-fenced:start -->';assert a.split(mark,1)[1]==b.split(mark,1)[1];trial=b.replace('当前已闭合核验：259；已读但待审：92；尚未逐文件核验：2,965；合计未闭合：3,057。','当前已闭合核验：261；已读但待审：89；尚未逐文件核验：2,966；合计未闭合：3,055。');lines=trial.splitlines()
for path in sourcePaths[:2]:
 i=next(i for i,l in enumerate(lines) if l.startswith('| `'+path+'` |'));assert lines[i].split('|')[3].strip()=='review';lines[i]=next(l for l in a.splitlines() if l.startswith('| `'+path+'` |'))
added=[l for l in lines if l.startswith('| `'+sourcePaths[2]+'` |')];assert len(added)==1 and added[0].split('|')[3].strip()=='review';assert '\n'.join(l for l in lines if l not in added)+'\n'==a
chain=json.loads((p/'review-chain.json').read_text());byReview={}
for r in chain['bindings']:byReview.setdefault(r['review'],[]).append(r)
for path,bindings in byReview.items():
 old=json.loads(git(path));cur=json.loads(Path(path).read_text());trial=copy.deepcopy(cur)
 for bound in bindings:
  i=next(i for i,r in enumerate(trial['entries']) if r['path']==bound['target']);r=trial['entries'][i];original=bound['beforeRow'];assert original==next(r for r in old['entries'] if r['path']==bound['target']);assert r['afterSha256']==sha(Path(bound['target']).read_bytes())==bound['currentSha256'] and r['revision']['history'][1:]==original['revision']['history'] and r['revision']['history'][0]['previousAfterSha256']==sha(git(bound['target']));trial['entries'][i]=original
 assert trial==old
for path in ['scripts/docs/terminal-git.mjs','scripts/docs/terminal-codec.test.mjs','scripts/docs/terminal-namespace.mjs','docs/ops/evidence/QUALITY-PRE94-RETROSPECTIVE-1/all-cards.json','docs/ops/evidence/QUALITY-PRE94-RETROSPECTIVE-1/all-cards.md']:assert Path(path).read_bytes()==git(path)
park=Path('/tmp/type-pal-finalization-park-20261018');saved=json.loads((park/'manifest.json').read_text());assert all(sha(gzip.decompress((park/r['saved']).read_bytes()))==r['sha256'] for r in saved['files']) and len(saved['files'])==10 and (park/'moved-0').is_dir() and (park/'moved-1').is_file()
newcard='docs/ops/tasks/QUALITY-DOCS-GIT-PATH-ENUMERATION-1.md';assert '\nStatus: review\n' in Path(newcard).read_text();index='docs/ops/tasks/index.md';oldLines=git(index).decode().splitlines();lines=Path(index).read_text().splitlines();added=[l for l in lines if l not in oldLines];assert len(added)==1 and 'QUALITY-DOCS-GIT-PATH-ENUMERATION-1' in added[0] and '| review |' in added[0] and [l for l in lines if l not in added]==oldLines
allowed={*sourcePaths,ledger,'docs/ops/board.md','docs/ops/evidence/README.md','docs/ops/tasks/QUALITY-PRE94-RETROSPECTIVE-1.md',index,newcard,*byReview};changed=set(subprocess.check_output(['git','diff','--name-only',base],text=True).splitlines());assert changed==allowed-{newcard};assert all(s==newcard or s.startswith(str(p.relative_to(root))+'/') for s in subprocess.check_output(['git','ls-files','--others','--exclude-standard'],text=True).splitlines());subprocess.run(['git','diff','--check'],check=True)
(p/'verification.json').write_text(json.dumps({'base':base,'scope':'Three-code-file Git enumeration prerequisite, literal two-option source delta, real red/green and two strict full-file controls; no product or unified closeout','rawPairs':rawPairs,'onlyTwoMaxBufferOptionsAndCommentsChanged':True,'allOriginalInventoryAssertionsExact':True,'terminalNamespace4MiBAndItsTestsUnchanged':True,'twoRealBusinessRedToGreen':True,'controls':2,'oldSpecsEachPassed':1,'newSpecsEachPassed':2,'specifiedAssertionErrorsEach':1,'allOtherNativeReviewObjectsExact':True,'oldLedgerRowsAndHistoricalFenceExact':True,'pre94QueueExact':True,'newClosed':0,'tracked':3316,'closed':259,'review':92,'pending':2965,'savedFinalization10HashesIntact':True,'allowedChanges':sorted(allowed)},ensure_ascii=False,indent=2)+'\n');(p/'verifier.py.gz').write_bytes(gzip.compress(Path('/tmp/type-pal-enumeration-verify.py').read_bytes(),mtime=0));print('Tool source/raw/control/ledger/review bindings and saved10 WIP hashes verified; no new closure.')
