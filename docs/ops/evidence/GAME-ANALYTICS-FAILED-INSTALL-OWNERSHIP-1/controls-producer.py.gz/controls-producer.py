from pathlib import Path
import datetime,gzip,hashlib,json,shutil,subprocess,tempfile
root=Path.cwd();out=root/'docs/ops/evidence/GAME-ANALYTICS-FAILED-INSTALL-OWNERSHIP-1';before=json.loads((out/'before.json').read_text());sources=[r['path'] for r in before['files'] if r['path'].endswith('.ts')];spec='packages/game/src/analytics/google-analytics.install-failure.test.ts';current={s:Path(s).read_bytes() for s in sources+[spec]};sha=lambda b:hashlib.sha256(b).hexdigest();tmp=Path(tempfile.mkdtemp(prefix='type-pal-ga-failure-controls-'));rows=[]
def once(s,a,b):
 assert s.count(a)==1,(a,s.count(a));return s.replace(a,b)
old={r['path']:gzip.decompress((out/r['snapshot']).read_bytes()) for r in before['files'] if r['path'] in sources}
page=current[sources[0]].decode();page=once(page,'  let unsubscribePage: (() => void) | undefined\n  try {\n    unsubscribePage = options.subscribePage?.(sendPageView)','  const unsubscribePage = options.subscribePage?.(sendPageView)\n  try {')
ui=once(current[sources[1]].decode(),'    ui.destroy()\n    throw error','    throw error')
variants=[('old-source-final-spec',old,5,None),('page-subscribe-outside-transaction',{**{s:current[s] for s in sources},sources[0]:page.encode()},1,'page subscription failure'),('ui-rollback-removed',{**{s:current[s] for s in sources},sources[1]:ui.encode()},1,'installer rolls back'),('restored-current',{s:current[s] for s in sources},0,None)]
try:
 for label,bodies,expectedFailed,needle in variants:
  report=tmp/(label+'.json');cmd=['pnpm','--filter','@type-pal/game','exec','vitest','run',spec.removeprefix('packages/game/'),'--reporter=verbose','--reporter=json','--outputFile.json='+str(report)];started=datetime.datetime.now(datetime.timezone.utc).isoformat();record={'id':label,'expectedFailed':expectedFailed,'expectedFailureNameContains':needle,'sourceSha256':{s:sha(b) for s,b in bodies.items()},'specSha256':sha(current[spec]),'command':cmd,'cwd':str(root),'startedAt':started};rows.append(record)
  try:
   for path,body in bodies.items():Path(path).write_bytes(body)
   for i,(path,body) in enumerate(bodies.items()):(out/(label+'.source'+str(i)+'.ts.gz')).write_bytes(gzip.compress(body,mtime=0))
   process=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);raw=process.stdout;(out/(label+'.raw.gz')).write_bytes(gzip.compress(raw,mtime=0));native=report.read_bytes() if report.exists() else b'';(out/(label+'.vitest.json.gz')).write_bytes(gzip.compress(native,mtime=0));record.update(completedAt=datetime.datetime.now(datetime.timezone.utc).isoformat(),exit=process.returncode,signal=-process.returncode if process.returncode<0 else None,spawnError=None,raw=label+'.raw.gz',rawBytes=len(raw),rawSha256=sha(raw),fullUncutMergedStdoutStderr=True,nativeReport=label+'.vitest.json.gz',nativeSha256=sha(native));d=json.loads(native);cases=[{'file':f['name'],'fullName':a['fullName'],'status':a['status'],'failureMessages':a['failureMessages']} for f in d['testResults'] for a in f['assertionResults']];record['cases']=cases
   assert len(d['testResults'])==1 and len(cases)==5 and d['numTotalTests']==5 and d['numPendingTests']==d['numTodoTests']==0
   bad=[a for a in cases if a['status']=='failed'];assert len(bad)==expectedFailed and d['numPassedTests']==5-expectedFailed and process.returncode==int(expectedFailed>0)
   assert all(a['status'] in ['passed','failed'] for a in cases) and all(a['failureMessages'] and all('AssertionError:' in m for m in a['failureMessages']) for a in bad)
   if needle:assert needle in bad[0]['fullName']
   assert 'stderr |' not in raw.decode() and 'Unhandled Error' not in raw.decode()
  finally:
   for path,body in current.items():Path(path).write_bytes(body)
   record['restoredSha256']={s:sha(Path(s).read_bytes()) for s in current};record['restoredByteExact']=all(Path(s).read_bytes()==b for s,b in current.items())
  print(label+': '+str(5-expectedFailed)+' passed/'+str(expectedFailed)+' business failures; restored',flush=True)
finally:
 for path,body in current.items():Path(path).write_bytes(body)
 shutil.rmtree(tmp)
 summary={'base':before['base'],'scope':'Current final spec unfiltered; old-source replay is five-error red reconfirmation, two single-failure controls, then restored5 green. Not original chronological red; original red-final proves pre-edit failures.','rows':rows,'tempDirectory':str(tmp),'tempDirectoryRemoved':not tmp.exists(),'restoredByteExact':all(Path(s).read_bytes()==b for s,b in current.items())};(out/'controls.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n');(out/'controls-producer.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
assert len(rows)==4 and summary['restoredByteExact']
