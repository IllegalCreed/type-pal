from pathlib import Path
import gzip,hashlib,json,subprocess
root=Path.cwd();p=Path('docs/ops/evidence/GAME-ANALYTICS-FAILED-INSTALL-OWNERSHIP-1');base='31a6769e7d6cd0e3c02669e3827beb38e818ed4e'
def sha(b):return hashlib.sha256(b).hexdigest()
def write(n,d):(p/n).write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
def once(path,a,b):
 f=Path(path);s=f.read_text();assert s.count(a)==1,(path,a);f.write_text(s.replace(a,b))
f=Path('/tmp/type-pal-ga-failure-module-final-20261018.json');b=f.read_bytes();native=json.loads(b);assert native['numPassedTests']==30 and native['numFailedTests']==0;(p/'module-final.vitest.json.gz').write_bytes(gzip.compress(b,mtime=0));f.unlink()
paths=['packages/game/src/analytics/google-analytics.ts','packages/game/src/analytics/install-analytics.ts','packages/game/src/analytics/google-analytics.install-failure.test.ts','packages/game/src/analytics/google-analytics.test.ts','packages/game/src/analytics/google-analytics.boundaries.test.ts','packages/game/src/analytics/google-analytics.test-fixtures.ts','packages/game/src/analytics/install-analytics.test.ts','packages/game/src/analytics/analytics-consent.ts','packages/game/src/analytics/analytics-consent-ui.ts','packages/game/src/analytics/analytics-consent-ui.test.ts','packages/game/src/main.ts']
rows=[]
for path in paths:
 b=Path(path).read_bytes();h=sha(b);n=len(b.decode().splitlines());name=h[:12]+'-'+Path(path).name+'.read.gz';(p/name).write_bytes(gzip.compress(b,mtime=0));rows.append({'path':path,'sha256':h,'lines':n,'ranges':[[1,n]],'fullRead':True,'snapshot':name})
write('read-boundaries.json',{'base':base,'owner':'Codex single agent','scope':'Named implementations, new regression, adjacent tests, shared host and real installer/main/consent/UI were read completely. Other executed consent tests retain earlier read evidence, not newly accepted here.','rows':rows})
write('gates.json',{'base':base,'status':'Source fix and formal failures/green/native/browser recorded; docs/lint/ledger pending','rows':[{'label':'module-final','receipt':'module-final.json','files':7,'direct':5,'adjacent':25,'passed':30,'nativeReport':'module-final.vitest.json.gz','nativeReportSha256':sha(gzip.decompress((p/'module-final.vitest.json.gz').read_bytes())),'diagnostics':{'stderrBlocks':0,'errors':0,'warnings':0,'infos':0}},{'label':'typecheck-final','receipt':'typecheck-final.json','diagnostics':{'errors':0,'warnings':0,'infos':0}},{'label':'browser','receipt':'browser.json','diagnostics':{'consoleErrorsWarnings':0},'scope':'Native browser diagnostic document with actual modules, owned SDK port and inert existing tag; no real GA or whole-game smoke claim'}],'tracked':3317,'closed':253,'review':99,'pending':2965,'newClosed':0,'newTestReview':1,'pre94':{'partial':55,'pending':28,'accept':0},'productExecutionChanged':True,'publicInterfaceChanged':False,'mainMerged':False,'mergeAllowed':False,'reuseDocsTools':{'commit':'37e2cd7c9a54b29766a87d17ffed90e4dae465dd','receipt':'../QUALITY-DOCS-GIT-PATH-ENUMERATION-1/docs.json','toolsPassed':125,'scope':'Exact same docs-tool/test source; only actual five consumer replay here, not rerun complete check:docs'},'notRun':['whole repository check','official coverage ratchet','protected fast','full game package test','real Google SDK/network','whole game bootstrap smoke','E2E']})
write('test-contracts.json',{'base':base,'owner':'Codex single agent','authorization':'User2026-10-18 explicitly chose A: failed installation rolls back listeners and privacy controls; refresh page to retry. No general telemetry change.','cases':[{'axis':'SDK js/config failures','legalPort':'Existing external gtag function throws synchronously at each initialization command','oracle':'same Error object; both acquired releases once; native consent regrant and page event cannot call recovered SDK','dedupe':'Existing URL rejection test catches URL only. Both commands are distinct partial-initialization boundaries.'},{'axis':'page source subscription fails','legalPort':'Optional public subscribePage throws before returning release handle','oracle':'earlier acquired consent subscription releases; no SDK command on later native consent grant','dedupe':'No existing initialization partial-acquisition test.'},{'axis':'initial readPage fails','legalPort':'readPage throws after js/config returned','oracle':'same Error object and two acquired subscriptions released; preexisting SDK identity/commands preserved; no post-failure SDK call','limit':'SDK/global/script side effects already performed are not claimed reversible; no subscriber-installed-then-throws rollback can be guaranteed without returned handle.'},{'axis':'actual installation/UI failure','legalPort':'Real installer, persisted granted choice, native UI/consent/window with owned inert Document and throwing SDK','oracle':'same Error object, root removed, saved choice preserved, unrelated button responds, later consent does not collect','dedupe':'Composition layer needed: direct GA tests cannot establish installer UI ownership.'}],'isolation':{'host':'Existing fully-read useGoogleAnalyticsTestHost restores SDK descriptors/owned Document; native consent handler cleanup only after assertions, preventing red-candidate leaks from crossing tests','storage':'Only exact analytics consent key saved/restored, no localStorage.clear in new spec','spy':'Native addEventListener call-through used only to recover red-candidate leaked handles after assertions; no product mock or cast','otherFiles':'Existing15 core/installer and10 consent/UI tests unchanged'},'changes':['two implementation lifecycle blocks','one new formal test file'], 'notChanged':['baseline','retirement registry','lint/typecheck rules','save/schema/assets','public interfaces','normal payload/dedupe/privacy consent policies']})
(p/'README.md').write_text('''# GA失败安装资源回滚（用户A裁决）

Status: recorded
Owner: Codex（单Agent实施/核证，不冒充第三方）
Date: 2026-10-18
Base: `31a6769e7d6cd0e3c02669e3827beb38e818ed4e`
Branch: `codex/code-quality-3y`

## 授权、合同和读取

[任务卡](../../tasks/GAME-ANALYTICS-FAILED-INSTALL-OWNERSHIP-1.md)用户明确选A：“失败即撤销本次监听和隐私控件，刷新页面后重试”。这是原pre94 3z发现的真实失败安装ownership修复；3w只读核验已暂停，没有混入结算改动。Google SDK命令合同与项目自己的错误/重试策略分开；本功能无SDLPal机制或二阶段对应。真实main启动catch、installer→consent/UI→GA、两源和专测/共享host均全文核读，见[当前边界](read-boundaries.json)与[基点字节](before.json)。旧OPS-GA4当前历史wrapper只提供可选能力不阻塞启动/consent意图，不授新产品范围。

## 问题和窄修

旧startGoogleAnalytics先取得consent/page释放函数，再apply初始授权；js/config或readPage异常导致没有stop句柄却留下订阅，安装器也没有撤销已装UI。现GA创建者在page订阅与初次apply阶段捕获错误、释放已取得的两个订阅再抛回；installer只撤自己创建的UI，原错误交main既有可选扩展隔离。正常授权、URL清洗、pathname去重、SDK脚本error重试及公共签名不改。只有两个实现与一个新正式测试；没有纯重构混批、规则/ignore新增、baseline/退役/schema/save/资产变化。

回滚范围是尚未返回controller的安装。已有SDK命令不可撤销，不清共享gtag/dataLayer、既有脚本或别的Owner资源；本片不把任意unsubscribe回调自身抛错、订阅源先注册后抛却不交句柄，或安装已返回后事件回调异常认证为已解决。生产consent释放是已全文核读的原生removeEventListener。没有实现B的同页自动重装/完整初始化重试状态机。

## 先红后绿和判别力

原正式4文件在产品修改前15绿/5指定业务AssertionError，0skip/pending/unhandled；第一版消息比较红件保留，随后错误对象identity加强的red-final仍15/5，且冻结了修前两源SHA/最终红测字节，见[先红记录](red-before-fix.json)。五个新case分别核js/config、page订阅失败、初次readPage失败及installer UI组合层；每层先核同一错误对象，再核真实释放和后续native事件静默，不用核心mock。完整raw/native保留。

首轮typecheck在新测试spy的显式泛型上报TS2344，原件保留为失败；改为实际spy类型推断和闭包恢复，没有cast/ignore/放宽规则。产品执行未随该测试修正改变；[当前精确spec回放](controls.json)只替换两旧源，五业务红再次成立，明确不是原时间顺序的第一次红。两个额外变异（page订阅移出事务、删除installer UI回滚）各完整5例4绿1指定AssertionError；不是从五个正式失败里筛单红。每次源/测字节finally恢复，自有临时目录精准清理。

最终7文件30绿（5新直接/25相邻），全case身份与原15保持；game typecheck最终零诊断。旧15/5/更早30绿raw与失败TC原件不改写成最终候选，实际结果见[gates](gates.json)和[合同/排重](test-contracts.json)。

## 实际功能验证

[browser原件](browser.json)：本地6005用actual installer/consent/UI模块和显式抛错/记录型SDK端口，无真实Google网络。失败页观察errorIdentity=true、无controller、privacyRoots=0，恢复SDK后deny/grant仍0命令；隔离进入按钮仍可点击。实际reload后返回controller、1root、js/config/page_view各一次，隐私按钮可打开真实面板。此入口是诊断宿主页，不是完整游戏启动或真实GA采集验收。错误/告警console空。自有cleanup按钮撤root、fixture源码恢复原consent key及probe session keys；AX保留的savedChoice/hasController是旧快照值，不冒充清理后实时值。截图留ignored artifacts，raw AX压缩入证据，临时HTML和自有server/tab已移除/关闭。

## 账本与剩余

两个原源继续review，新测试仅review；0新增closed，3317 tracked /253 closed /99 review /2965 pending。pre94仍55partial/28pending/0accept，83对象与原历史卡SHA不改。本卡review等待统一门；不是专项完成。全仓check、official coverage ratchet、protected fast按用户成本要求留大任务窗口，不为这三文件重跑；docs125工具源码不变复用37e原件，本片仅实跑五消费者。未合main；下一步回3w结算实现/专测，随后94前其余卡，94–102/editor后置。无下一位Agent提示词。
''')
card=Path('docs/ops/tasks/GAME-ANALYTICS-FAILED-INSTALL-OWNERSHIP-1.md')
card.write_text('''# GAME-ANALYTICS-FAILED-INSTALL-OWNERSHIP-1 — GA安装失败后的订阅所有权

Status: review
Owner: Codex
Phase: phase1 project analytics extension
Capability: optional analytics / initialization ownership
Coding Owner: Codex（用户A裁决，三文件窄修）
Reviewer: Codex（自身源码与反例核证，不冒充第三方）
Visual Verification Timing: dev-functional（本地诊断宿主已实跑；非实网GA/完整游戏）
Branch: codex/code-quality-3y

## 目标

安装在返回controller前失败，应由创建者撤已取得的监听和本次隐私UI，保留原错误供main隔离；本次停用，刷新后重新安装。用户2026-10-18已明确批准A，不重复请求。

## 范围

build allowed有限白名单为google-analytics.ts、install-analytics.ts、新正式google-analytics.install-failure.test.ts。只修失败ownership；正常GA采集范围/ID/URL白名单/去重/同意策略、脚本资源error重试、UI布局、公共接口、schema/save/资产/二阶段冻结。3w本轮仅只读，没有改动。

## 前提真值门

| 维度 | 证据与停止线 |
|---|---|
| primary | OPS-GA4现已历史保留的可选扩展/失败不阻启动意图；本轮用户A为重试产品真值。Google命令API不为项目异常策略背书。 |
| 第一阶段 | 真实main.ts:9–15捕获可选安装异常；GA先取得订阅再apply初始授权，旧错误导致无返回句柄却继续响应重授；安装器先装UI。基点完整源/5正式业务失败和原早期probe分别保全。 |
| 二阶段 | N/A：无Reforge/editor/content或SDLPal机制对应。 |
| 目标 | GA构造器撤本次已取得的订阅；installer撤本次UI；同一错误对象传播至原启动catch。正常合同不扩张。 |

### 反证与替代解释

真实gtag通常只排队，不能声称Google实网SDK已观测抛错。本例是公开可注入外部函数端口的同步异常；正式runner与原生浏览器用实际SUT/native事件/Storage和独占Document/记录型SDK。后续命令只在再次明确授权后出现，原缺陷是无owner订阅，不是未经同意发送。若旧源相同输入不泄漏，counter应撤回；本轮精确最终spec回放仍5业务红。

## 用户裁决与准入

用户原话：“A：失败即撤销本次监听和隐私控件，刷新页面后重试（推荐，改动较小）”。Codex premise verified/design agree/build allowed，单Owner/同3y隔离树；先正式失败回归再实现。B（保留可重试controller/同页重试状态机）不实施。原probe冻结4b86b04b7与历史draft不替代此新准入。

## 上下文锚点

- [父卡](QUALITY-PRE94-RETROSPECTIVE-1.md)、[本轮完整证据](../evidence/GAME-ANALYTICS-FAILED-INSTALL-OWNERSHIP-1/README.md)。
- [旧3z probe](../evidence/QUALITY-PRE94-RETROSPECTIVE-1/3z-google-analytics/initialization-probe.json)和源/native/raw为当时未修观察；本次不改旧原件。
- [旧OPS-GA4](../archive/tasks/done/OPS-GA4-consent-pageviews.md)仅设计来源，不恢复固定三签/历史部署信用。

## 验收条件

1. 正式修前js/config/page订阅/初次readPage/真实installer UI失败为精确业务红，错误对象不替换。
2. 释放已取得的监听、UI撤销、已保存选择与不相关DOM保留；失败后native重授/页面事件不再触发本次SDK。
3. 正常现有合同与同意/UI相邻、TC/静态零诊断；全仓/coverage/protected留大任务收尾。
4. 本地浏览器失败及刷新重试功能实跑，不向真实property发送测试采集。

## Draft: 设计与风险

事务边界从已取得consent释放句柄开始，page订阅与初次apply位于try内；异常撤已取得的consent/page，再抛回。installer另撤自己UI。共享SDK/global/脚本不是本次独占资源，不清；已执行SDK命令不可逆，不宣称完整撤销外部副作用。任意外部unsubscribe自身抛错、订阅源已注册却抛且不交句柄、已返回controller后的事件回调错误未据本卡认证。

## Build: 实现与自测

产品只改上述两生命周期块。修前4文件15绿/5指定AssertionError；先红源/spec/native SHA保存后再修，随后7文件30绿。TC首版测试spy泛型有TS2344，改真实类型推断闭包恢复，未cast/ignore；最终TC零诊断。最终spec以两旧源回放仍5红；两单针各4绿1指定红，全部源/测恢复字节，自有临时目录清理。无纯重构夹带、baseline/退役/规则或生成物修改。

## Review: 审查与返工

三文件全文及main/真实UI/consent/共享host核读。既有25相邻测试未改，无弱化/skip。30绿仅本slice执行，三个文件继续review，0新增closed；83卡55partial/28pending/0accept不变。实际docs/lint/ledger以本轮gates为准。统一check/ratchet/protected未跑，review不等于整卡done或允许合main。

## 用户验收

A产品方向已批准。本地浏览器诊断宿主实际看到失败后无控件/无后续命令，刷新后controller/隐私设置可用；真实模块执行，SDK是显式记录端口。不是Google网络/完整游戏启动验收；无需用户重复技术步骤。

## 交接日志

- 2026-10-18早期：冻结4b86b04b7，旧12绿+真实install清理单红，未改产品，开draft等待裁决；原件留3z。
- 2026-10-18本轮：用户A到达；暂停3w只读，先正式五红再窄修，7文件30绿/TC最终零诊断/两单针与本地浏览器通过。三代码路径review，新测试库存+1；3317/253closed/99review/2965pending。main/其它Owner未写，统一门仍待。

## 下一位Agent提示词

无下一位Agent提示词，Codex单Agent继续；本卡窄功能证据有效但全仓门未收口，随后回pre94 3w settlement，不把本次修复当专项完成。
''')
ledger=Path('docs/ops/audits/code-quality-file-ledger.md');s=ledger.read_text();s=s.replace('当前 tracked 清单：3,316。','当前 tracked 清单：3,317。',1).replace('当前已闭合核验：253；已读但待审：98；尚未逐文件核验：2,965；合计未闭合：3,063。','当前已闭合核验：253；已读但待审：99；尚未逐文件核验：2,965；合计未闭合：3,064。',1)
lines=s.splitlines();targets={'packages/game/src/analytics/google-analytics.ts':('147行当前/139行原源全文；真实install/main/consent与用户A','初次安装失败回滚已取得两订阅，五先红后绿/两针；正常合同不改，仍review'),'packages/game/src/analytics/install-analytics.ts':('64行当前/57行原源全文；main可选catch、实际UI和GA创建者','失败撤本次UI并保留原错误；本地刷新重试已实跑，统一门待，不关闭')};seen=[]
for i,line in enumerate(lines):
 for path,(ev,note) in targets.items():
  if line.startswith('| `'+path+'`') and path not in seen:
   lines[i]='| `'+path+'` | product | review | [GA失败回滚](../evidence/GAME-ANALYTICS-FAILED-INSTALL-OWNERSHIP-1/README.md)；'+ev+' | '+note+' |';seen.append(path)
assert len(seen)==2
idx=next(i for i,l in enumerate(lines) if l.startswith('| `scripts/quality/code-quality-inventory.test.mjs`'))
lines.insert(idx+1,'| `packages/game/src/analytics/google-analytics.install-failure.test.ts` | test | review | [GA失败回滚](../evidence/GAME-ANALYTICS-FAILED-INSTALL-OWNERSHIP-1/README.md)；160行全文，真实native ports/安装器/存储/自有宿主 | 五合法错误边界/原Error身份/停止后事件静默；30相邻及两单针，0新增closed |')
ledger.write_text('\n'.join(lines)+'\n')
f=Path('docs/ops/board.md');s=f.read_text();line=next(l for l in s.splitlines() if l.startswith('| GAME-ANALYTICS-FAILED-INSTALL-OWNERSHIP-1 |'));s=s.replace(line,'| GAME-ANALYTICS-FAILED-INSTALL-OWNERSHIP-1 | [GA失败安装归属](tasks/GAME-ANALYTICS-FAILED-INSTALL-OWNERSHIP-1.md) | review | Codex / A窄修已测，待统一门 | 五先红后绿、30相邻/两单针；失败撤监听UI、刷新重试已本地实跑，0关闭 |');f.write_text(s)
f=Path('docs/ops/evidence/README.md');s=f.read_text();anchor='## 当前证据目录（逐目录入口）\n';assert s.count(anchor)==1;s=s.replace(anchor,anchor+'\n- [GAME-ANALYTICS-FAILED-INSTALL-OWNERSHIP-1](GAME-ANALYTICS-FAILED-INSTALL-OWNERSHIP-1/README.md)\n',1);f.write_text(s)
f=Path('docs/ops/tasks/QUALITY-PRE94-RETROSPECTIVE-1.md')
with f.open('a') as out:out.write('\n### 2026-10-18 GA失败安装用户A裁决后窄修\n\n用户明确批准失败撤监听/隐私控件、刷新重试；3w本轮只读暂停，无结算改动。两个生命周期源+一正式失败测试，先15绿5指定红再修，最终7文件30绿/TC零诊断/两单针、原源回放五红及本地浏览器失败/刷新链。原probe和早期TC测试泛型失败原件保留，不改历史raw。三路径review，新增测试库存1；3317/253closed/99review/2965pending，0新增关闭，83卡55partial/28pending/0accept及原83对象不改。详见[GA回滚](../evidence/GAME-ANALYTICS-FAILED-INSTALL-OWNERSHIP-1/README.md)。共享SDK不清，外部清理自身抛错等未签收；全仓/coverage/protected留大任务收尾、不合main，下一步回3w结算，94–102/editor后置；无下一位Agent提示词。\n')
f=Path('docs/ops/evidence/QUALITY-PRE94-RETROSPECTIVE-1/README.md')
with f.open('a') as out:out.write('\n最新[GA失败安装A修复](../GAME-ANALYTICS-FAILED-INSTALL-OWNERSHIP-1/README.md)：用户批准失败撤监听/UI、刷新重试；五先红后绿、30相邻/两单针/TC及本地浏览器已核。两个源与新增失败测试仍review，3317/253/99/2965，0新关闭；83卡55/28/0accept不变。3w仅只读后暂停，下一步继续结算切片；统一门未跑不合main。\n')
index=subprocess.check_output(['node','scripts/docs/check.mjs','--print-task-index']);Path('docs/ops/tasks/index.md').write_bytes(index)
(p/'docs-producer.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0));(p/'capture-producer.py.gz').write_bytes(gzip.compress(Path('/tmp/type-pal-ga-failure-capture.py').read_bytes(),mtime=0));print('Current sources and approved task reviewed; one new test review, no new closures; index regenerated.')
