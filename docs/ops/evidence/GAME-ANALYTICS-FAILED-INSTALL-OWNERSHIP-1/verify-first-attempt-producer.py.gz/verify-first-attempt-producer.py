from pathlib import Path
import collections,difflib,gzip,hashlib,json,re,subprocess
p=Path('docs/ops/evidence/GAME-ANALYTICS-FAILED-INSTALL-OWNERSHIP-1');base='31a6769e7d6cd0e3c02669e3827beb38e818ed4e'
def sha(b):return hashlib.sha256(b).hexdigest()
def load(n):return json.loads((p/n).read_text())
def unpack(n):return gzip.decompress((p/n).read_bytes())
def blob(path):return subprocess.check_output(['git','show',base+':'+str(path)])
def receipt(r):
 b=unpack(r['raw']);assert sha(b)==r['rawSha256'] and len(b)==r['rawBytes']
 assert r['signal'] is None and r['spawnError'] is None and r['fullUncutMergedStdoutStderr']
 return b
before=load('before.json');assert before['base']==base
for r in before['files']:
 b=unpack(r['snapshot']);assert b==blob(r['path']) and sha(b)==r['sha256'] and len(b.decode().splitlines())==r['lines']
for r in load('read-boundaries.json')['rows']:
 b=Path(r['path']).read_bytes();n=len(b.decode().splitlines());assert sha(b)==r['sha256'] and n==r['lines'] and unpack(r['snapshot'])==b and r['fullRead'] and r['ranges']==[[1,n]]
spec='packages/game/src/analytics/google-analytics.install-failure.test.ts';sources=[r['path'] for r in before['files'] if r['path'].endswith('.ts')]
for r in before['files']:
 if r['path'] in sources:
  # Public types and entry signatures before their function bodies unchanged.
  old=unpack(r['snapshot']).decode();new=Path(r['path']).read_text()
  function='export function startGoogleAnalytics' if 'google-analytics.ts' in r['path'] else 'export function installTypePalAnalytics'
  assert old.split(function)[0]==new.split(function)[0]

red=load('red-before-fix.json');d=json.loads(unpack('red-final.vitest.json.gz'))
assert sha(unpack('red-final.spec.ts.gz'))==red['finalSpecSha256'] and sha(unpack('red-final.vitest.json.gz'))==red['nativeSha256']
assert d['numPassedTests']==15 and d['numFailedTests']==5 and d['numPendingTests']==d['numTodoTests']==0
assert red['sourceSha256']=={s:sha(blob(s)) for s in sources}
for f in d['testResults']:
 for a in f['assertionResults']:
  assert a['status'] in ['passed','failed']
  if a['status']=='failed':assert f['name'].endswith(spec) and a['failureMessages'] and all('AssertionError:' in m for m in a['failureMessages'])

controls=load('controls.json');assert len(controls['rows'])==4 and controls['restoredByteExact'] and controls['tempDirectoryRemoved'] and not Path(controls['tempDirectory']).exists()
for r in controls['rows']:
 raw=receipt(r);native=unpack(r['nativeReport']);assert sha(native)==r['nativeSha256'];d=json.loads(native)
 assert d['numTotalTests']==5 and d['numFailedTests']==r['expectedFailed'] and d['numPassedTests']==5-r['expectedFailed'] and d['numPendingTests']==d['numTodoTests']==0
 assert len(d['testResults'])==1 and d['testResults'][0]['name'].endswith(spec)
 assert r['exit']==int(r['expectedFailed']>0) and d['success']==(r['expectedFailed']==0)
 cases=[{'file':f['name'],'fullName':a['fullName'],'status':a['status'],'failureMessages':a['failureMessages']} for f in d['testResults'] for a in f['assertionResults']];assert cases==r['cases']
 bad=[a for a in cases if a['status']=='failed'];assert all(a['status'] in ['passed','failed'] for a in cases)
 assert all(a['failureMessages'] and all('AssertionError:' in m for m in a['failureMessages']) for a in bad)
 if r['expectedFailureNameContains']:assert len(bad)==1 and r['expectedFailureNameContains'] in bad[0]['fullName']
 assert not re.search(rb'(stderr \||Unhandled Error|Unhandled Rejection)',raw)
 assert r['restoredByteExact'] and r['specSha256']==sha(Path(spec).read_bytes())
 assert r['restoredSha256']=={s:sha(Path(s).read_bytes()) for s in sources+[spec]}
 for i,s in enumerate(sources):assert sha(unpack(r['id']+'.source'+str(i)+'.ts.gz'))==r['sourceSha256'][s]
 report=next(c.split('=',1)[1] for c in r['command'] if c.startswith('--outputFile.json='));assert not Path(report).exists()

for f in p.glob('*.json'):
 d=json.loads(f.read_text())
 if isinstance(d,dict) and 'rawBytes' in d:receipt(d)
for name in ['module-final','typecheck-final','docs-consumers','ledger','lint']:
 r=load(name+'.json');raw=receipt(r);assert r['exit']==0
 assert not re.search(rb'(stderr \||Warning:|Unhandled Error|Unhandled Rejection|error TS\d)',raw),name
assert load('typecheck.json')['exit']==2 and b'TS2344' in receipt(load('typecheck.json'))
native=json.loads(unpack('module-final.vitest.json.gz'));assert native['success'] and native['numPassedTests']==native['numTotalTests']==30 and native['numFailedTests']==native['numPendingTests']==native['numTodoTests']==0 and len(native['testResults'])==7
assert all(a['status']=='passed' for f in native['testResults'] for a in f['assertionResults'])
current=next(f for f in native['testResults'] if f['name'].endswith(spec))['assertionResults'];assert len(current)==5
assert [a['fullName'] for a in current]==[a['fullName'] for a in controls['rows'][0]['cases']]
redNative=json.loads(unpack('red-final.vitest.json.gz'))
for f in redNative['testResults']:
 if not f['name'].endswith(spec):
  g=next(g for g in native['testResults'] if g['name']==f['name']);assert [a['fullName'] for a in g['assertionResults']]==[a['fullName'] for a in f['assertionResults']]
assert '0 errors / 0 warnings / 0 infos' in receipt(load('lint.json')).decode()
assert '3317 files; 253 closed / 99 review / 2965 pending' in receipt(load('ledger.json')).decode()

browser=load('browser.json');assert browser['consoleErrorsWarnings']==0 and load('browser-console.json')==[]
for r in browser['stages']:
 b=unpack(r['snapshot']);assert sha(b)==r['sha256'] and len(b)==r['bytes']
beforeAx=unpack('browser-before.ax.txt.gz').decode();afterAx=unpack('browser-refresh.ax.txt.gz').decode()
assert all(t in beforeAx for t in ['"errorIdentity": true','"hasController": false','"privacyRoots": 0','"commands": []'])
assert '"entered": 1' in unpack('browser-button.ax.txt.gz').decode()
assert all(t in afterAx for t in ['"stage": "after-refresh"','"hasController": true','"privacyRoots": 1','"page_view"'])
assert '可选访问统计' in unpack('browser-privacy.ax.txt.gz').decode() and '验证已清理' in unpack('browser-cleanup.ax.txt.gz').decode()
fixture=load('browser-fixture.json');assert not Path(fixture['ownedPath']).exists() and browser['fixtureOwnedFileRemoved']
assert sha(unpack('browser-fixture.html.gz'))==fixture['sha256'] and sha(unpack('browser-fixture-cleanup.html.gz'))==fixture['cleanupRevisionSha256']
for r in browser['screenshots']:assert sha(Path(r['path']).read_bytes())==r['sha256']

ledger=Path('docs/ops/audits/code-quality-file-ledger.md');diff=list(difflib.ndiff(blob(ledger).decode().splitlines(),ledger.read_text().splitlines()));removed=[l[2:] for l in diff if l.startswith('- ')];added=[l[2:] for l in diff if l.startswith('+ ')]
assert len(removed)==4 and len(added)==5
for s in sources:
 assert sum(l.startswith('| `'+s+'`') and '| review |' in l for l in removed)==1
 assert sum(l.startswith('| `'+s+'`') and '| review |' in l for l in added)==1
assert sum(l.startswith('| `'+spec+'`') and '| review |' in l for l in added)==1
queue=Path('docs/ops/evidence/QUALITY-PRE94-RETROSPECTIVE-1/all-cards.json');assert queue.read_bytes()==blob(queue)
assert json.loads(queue.read_text())['currentReviewCounts']=={'partial':55,'pending':28}
chain=load('review-chain.json');assert len(chain['bindings'])==8;byreview=collections.defaultdict(list)
for r in chain['bindings']:
 b=Path(r['target']).read_bytes();assert r['currentSha256']==sha(b) and r['lines']==len(b.decode().splitlines()) and r['previousAfterSha256']==sha(blob(r['target']));byreview[r['review']].append(r['target'])
for path,targets in byreview.items():
 old=json.loads(blob(path));new=json.loads(Path(path).read_text());assert {k:v for k,v in old.items() if k!='entries'}=={k:v for k,v in new.items() if k!='entries'}
 for a,b in zip(old['entries'],new['entries']):
  if a['path'] not in targets:assert a==b
  else:
   assert b['afterSha256']==sha(Path(a['path']).read_bytes()) and b['revision']['history'][1:]==a['revision']['history'] and b['revision']['history'][0]['revision']==base
   def stable(row):
    row=json.loads(json.dumps(row))
    for k in ['afterSha256','reviewedLines']:row.pop(k,None)
    for k in ['history','afterSha256','implementationSha']:row.get('revision',{}).pop(k,None)
    if isinstance(row.get('evidence'),dict):
     for k in ['lineCount','afterSha256']:row['evidence'].pop(k,None)
    return row
   assert stable(a)==stable(b)
for path in ['scripts','docs/testing/catalog.json','packages/game/src/main.ts','packages/game/src/analytics/google-analytics.test-fixtures.ts','packages/game/src/core/battle','docs/ops/evidence/QUALITY-PRE94-RETROSPECTIVE-1/3z-google-analytics']:
 assert not subprocess.check_output(['git','diff',base,'--',path]),path
allowed=set(sources+[spec])|{'docs/ops/board.md','docs/ops/tasks/index.md','docs/ops/evidence/README.md',str(ledger),'docs/ops/tasks/GAME-ANALYTICS-FAILED-INSTALL-OWNERSHIP-1.md','docs/ops/tasks/QUALITY-PRE94-RETROSPECTIVE-1.md','docs/ops/evidence/QUALITY-PRE94-RETROSPECTIVE-1/README.md'}|set(byreview)
assert set(subprocess.check_output(['git','diff',base,'--name-only']).decode().splitlines())==allowed
assert all(f.startswith(str(p)+'/') for f in subprocess.check_output(['git','ls-files','--others','--exclude-standard']).decode().splitlines())
assert subprocess.check_output(['git','branch','--show-current']).decode().strip()=='codex/code-quality-3y'
print(json.dumps({'status':'pass','scope':'Approved A failed-install rollback only; no unified/whole-file closure','sources':2,'newSpecCases':5,'chronologicalRedPassed':15,'chronologicalRedFailed':5,'finalPassed':30,'adjacent':25,'singleFailureControls':2,'rawNativeAndRestores':'verified','browser':'owned diagnostic native UI; no real GA/whole game claim','tracked':3317,'closed':253,'review':99,'pending':2965,'newClosed':0,'pre94':'55partial/28pending/0accept unchanged','reviewBindings':8},ensure_ascii=False))
