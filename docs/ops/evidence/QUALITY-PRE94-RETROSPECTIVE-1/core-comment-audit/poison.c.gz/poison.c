#include <stdint.h>
#include <stdio.h>
typedef uint16_t WORD; typedef int16_t SHORT; typedef int BOOL;
typedef struct { WORD wPoisonID,wPoisonScript; } POISONSTATUS;
static struct { struct { WORD wPlayerRole; } rgParty[1]; WORD wMaxPartyMemberIndex; POISONSTATUS rgPoisonStatus[16][1]; struct { struct { struct { WORD wPoisonLevel; } poison; } rgObject[3]; } g; } data, *gpGlobals=&data;
#define MAX_POISONS 16
int main(void) { int i,j; WORD wPlayerRole=2;data.rgParty[0].wPlayerRole=2;data.rgPoisonStatus[0][0]=(POISONSTATUS){1,8};data.rgPoisonStatus[1][0]=(POISONSTATUS){2,9};data.g.rgObject[1].poison.wPoisonLevel=99;data.g.rgObject[2].poison.wPoisonLevel=1;

      //
      // Remove all poisons leveled 99
      //
      for (i = 0; i <= (short)gpGlobals->wMaxPartyMemberIndex; i++)
      {
         if (gpGlobals->rgParty[i].wPlayerRole == wPlayerRole)
         {
            wPlayerRole = i;
            break;
         }
      }

      if (i <= (short)gpGlobals->wMaxPartyMemberIndex)
      {
         j = 0;

         for (i = 0; i < MAX_POISONS; i++)
         {
            WORD w = gpGlobals->rgPoisonStatus[i][wPlayerRole].wPoisonID;

            if (w == 0)
            {
               break;
            }

            if (gpGlobals->g.rgObject[w].poison.wPoisonLevel < 99)
            {
               gpGlobals->rgPoisonStatus[j][wPlayerRole] =
                  gpGlobals->rgPoisonStatus[i][wPlayerRole];
               j++;
            }
         }

         while (j < MAX_POISONS)
         {
            gpGlobals->rgPoisonStatus[j][wPlayerRole].wPoisonID = 0;
            gpGlobals->rgPoisonStatus[j][wPlayerRole].wPoisonScript = 0;
            j++;
         }
      }
   printf("[");int n=0;for(i=0;i<16;i++){POISONSTATUS p=data.rgPoisonStatus[i][0];if(p.wPoisonID)printf("%s[%d,%u,%u]",n++?",":"",i,p.wPoisonID,p.wPoisonScript);}puts("]");return 0;}
