# -*- coding: utf-8 -*-
from pathlib import Path
import datetime,gzip,hashlib,json,subprocess,tempfile,shutil
root=Path.cwd();out=root/'docs/ops/evidence/QUALITY-PRE94-RETROSPECTIVE-1/core-comment-audit';out.mkdir(exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest();fight=(root/'reference/sdlpal/fight.c').read_text();glob=(root/'reference/sdlpal/global.c').read_text(); battle=(root/'reference/sdlpal/battle.h').read_text()
def body_after(text,needle):
 start=text.index('{',text.index(needle));depth=1;i=start+1
 while depth:
  depth+=(text[i]=='{')-(text[i]=='}');i+=1
 return text[start+1:i-1],start+1,i-1
sort='\n'.join(fight.splitlines()[1573:1585])+'\n';assert sort.count('for (')==2 and '(SHORT)' in sort
wear,start,end=body_after(glob,'else if (wEquipPart == kBodyPartWear)');assert 'j = 0;' in wear and 'if (w == 0)' in wear
struct='typedef '+battle[battle.index('struct tagACTIONQUEUE'):battle.index('} ACTIONQUEUE;')+len('} ACTIONQUEUE;')]
prefix='#include <stdint.h>\n#include <stdio.h>\ntypedef uint16_t WORD; typedef int16_t SHORT; typedef int BOOL;\n'
cqueue=prefix+struct+'\n#define MAX_ACTIONQUEUE_ITEMS 13\nstatic struct { ACTIONQUEUE ActionQueue[MAX_ACTIONQUEUE_ITEMS]; } g_Battle;\nint main(void) { int i,j;\nfor(i=0;i<13;i++){g_Battle.ActionQueue[i].wIndex=0xffff;g_Battle.ActionQueue[i].wDexterity=0xffff;}\ng_Battle.ActionQueue[0]=(ACTIONQUEUE){1,30,0,0};g_Battle.ActionQueue[1]=(ACTIONQUEUE){1,30,1,0};g_Battle.ActionQueue[2]=(ACTIONQUEUE){0,100,0,0};\n'+sort+'printf("[");for(i=0;i<3;i++){ACTIONQUEUE q=g_Battle.ActionQueue[i];printf("%s[\\"%s\\",%u,%u]",i?",":"",q.fIsEnemy?"enemy":"player",q.wIndex,q.wDexterity);}puts("]");return 0;}\n'
ctox=prefix+'''typedef struct { WORD wPoisonID,wPoisonScript; } POISONSTATUS;
static struct { struct { WORD wPlayerRole; } rgParty[1]; WORD wMaxPartyMemberIndex; POISONSTATUS rgPoisonStatus[16][1]; struct { struct { struct { WORD wPoisonLevel; } poison; } rgObject[3]; } g; } data, *gpGlobals=&data;
#define MAX_POISONS 16
int main(void) { int i,j; WORD wPlayerRole=2;data.rgParty[0].wPlayerRole=2;data.rgPoisonStatus[0][0]=(POISONSTATUS){1,8};data.rgPoisonStatus[1][0]=(POISONSTATUS){2,9};data.g.rgObject[1].poison.wPoisonLevel=99;data.g.rgObject[2].poison.wPoisonLevel=1;
'''+wear+'''printf("[");int n=0;for(i=0;i<16;i++){POISONSTATUS p=data.rgPoisonStatus[i][0];if(p.wPoisonID)printf("%s[%d,%u,%u]",n++?",":"",i,p.wPoisonID,p.wPoisonScript);}puts("]");return 0;}
'''
queue_ts=f"import {{ buildActionQueue }} from {json.dumps(str(root/'packages/game/src/core/battle/turn-queue.ts'))};\nconsole.log(JSON.stringify(buildActionQueue({{players:[{{idx:0,dex:100}}],enemies:[{{idx:0,dex:30,dualMove:false}},{{idx:1,dex:30,dualMove:false}}]}}).map(q=>[q.isEnemy?'enemy':'player',q.idx,q.dex])));\n"
poison_ts=f"import {{ createInitialGameState }} from {json.dumps(str(root/'packages/game/src/core/game-state.ts'))};\nimport {{ setObjectPoisons, removePoisonLevel99 }} from {json.dumps(str(root/'packages/game/src/core/player-poison-state.ts'))};\nconst gs=createInitialGameState({{x:160,y:160,facing:'right'}});gs.partyMembers=[2];gs.rgPoisonStatus={{'0_0':{{wPoisonID:1,wPoisonScript:8}},'1_0':{{wPoisonID:2,wPoisonScript:9}}}};setObjectPoisons([{{id:1,level:99,color:0,playerScript:8,enemyScript:0}},{{id:2,level:1,color:0,playerScript:9,enemyScript:0}}]);removePoisonLevel99(gs,2);console.log(JSON.stringify(Object.entries(gs.rgPoisonStatus).filter(([,p])=>p.wPoisonID!==0).map(([key,p])=>[Number(key.split('_')[0]),p.wPoisonID,p.wPoisonScript])));\n"
rows=[];tmp=Path(tempfile.mkdtemp(prefix='type-pal-pre94-primary-counter-'))
def run(label,cmd):
 started=datetime.datetime.now(datetime.timezone.utc).isoformat();p=subprocess.run(cmd,cwd=root,stdout=subprocess.PIPE,stderr=subprocess.PIPE);raw=p.stdout+b'\n[stderr]\n'+p.stderr
 (out/(label+'.raw.gz')).write_bytes(gzip.compress(raw,mtime=0));r={'label':label,'command':cmd,'cwd':str(root),'startedAt':started,'completedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit':p.returncode,'signal':-p.returncode if p.returncode<0 else None,'spawnError':None,'stdout':p.stdout.decode(),'stderr':p.stderr.decode(),'raw':label+'.raw.gz','rawSha256':sha(raw),'rawBytes':len(raw),'fullUncutStdoutAndStderr':True};rows.append(r);assert p.returncode==0 and not p.stderr,(label,r);return p.stdout.decode()
try:
 for name,c,ts in [('queue',cqueue,queue_ts),('poison',ctox,poison_ts)]:
  cp=tmp/(name+'.c');tp=tmp/(name+'.mts');exe=tmp/(name+'-probe');cp.write_text(c);tp.write_text(ts)
  (out/(name+'.c.gz')).write_bytes(gzip.compress(cp.read_bytes(),mtime=0));(out/(name+'.mts.gz')).write_bytes(gzip.compress(tp.read_bytes(),mtime=0))
  run(name+'-compile',['/usr/bin/clang','-std=c99','-Wall','-Wextra','-Werror',str(cp),'-o',str(exe)])
  native=json.loads(run(name+'-c',[str(exe)]));current=json.loads(run(name+'-ts',['pnpm','exec','tsx',str(tp)]));assert native!=current
  print(name,json.dumps({'exactCFragment':native,'currentTsPublicLeaf':current}),flush=True)
finally:
 shutil.rmtree(tmp)
 evidence={'base':subprocess.check_output(['git','rev-parse','HEAD']).decode().strip(),'scope':'Native compiled exact C body fragments in minimal typed contexts vs actual TS public leaves. Not a native full SDLPal executable or browser/gameplay run. No product edits.','fragments':[{'path':'reference/sdlpal/fight.c','sourceSha256':sha(fight.encode()),'range':[1574,1585],'fragmentSha256':sha(sort.encode())},{'path':'reference/sdlpal/global.c','sourceSha256':sha(glob.encode()),'range':[glob[:start].count('\n')+1,glob[:end].count('\n')+1],'fragmentSha256':sha(wear.encode())}],'queuePadding':'13 native slots (3+5*2); unfilled WORD0xffff fields sorted as SHORT -1, filtered only after native sort for display','legalDomain':'Positive ordinary dex30/100; one player/two nondual enemies. Poison typed catalog positive ids1/2, level99/1, compact two occupied slots for party[2]; no native asset identity or completed gameplay claim.','rows':rows,'ownedTemporaryRoot':str(tmp),'temporaryRootRemoved':not tmp.exists()};(out/'primary-counters.json').write_text(json.dumps(evidence,ensure_ascii=False,indent=2)+'\n')
