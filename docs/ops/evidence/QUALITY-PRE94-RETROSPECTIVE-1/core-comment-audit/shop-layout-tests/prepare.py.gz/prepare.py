# coding: utf-8
from pathlib import Path
import hashlib,gzip,json,subprocess
base='206b18563e07569414f4ec90f08597c5b8ac66de';p=Path('docs/ops/evidence/QUALITY-PRE94-RETROSPECTIVE-1/core-comment-audit/shop-layout-tests');p.mkdir()
files=['packages/game/src/present/menu/draw-shop.ts','packages/game/src/present/menu/draw-shop.glm-phase1-leaves.test.ts','packages/game/src/present/menu/draw-menu.glm-phase1-leaves.test.ts','packages/game/src/present/menu/shop-preview-pixels.grok-r1.test.ts'];rows=[]
for path in files:
 raw=Path(path).read_bytes();assert raw==subprocess.check_output(['git','show',base+':'+path]);sha=hashlib.sha256(raw).hexdigest();name=sha[:12]+'.'+Path(path).name+'.before.gz';(p/name).write_bytes(gzip.compress(raw,mtime=0));rows.append({'path':path,'sha256':sha,'lines':len(raw.splitlines()),'readRanges':[[1,len(raw.splitlines())]],'snapshot':name})
assert len({r['snapshot'] for r in rows})==len(rows)
(p/'before.json').write_text(json.dumps({'base':base,'owner':'Codex single agent','files':rows,'scope':'Four current files fully read; source edits only comments, tests bounded to legal inputs and distinguishing oracles. No full-file closure.'},ensure_ascii=False,indent=2)+'\n')
f=Path('docs/ops/tasks/QUALITY-PRE94-RETROSPECTIVE-1.md');f.write_text(f.read_text()+'''\n## 2026-10-18 商店布局与宿主测试有限准入\n\nCodex premise verified / design agree / build allowed：206b18563基点，3y同树单Owner；全文draw-shop.ts、draw-shop leaves、draw-menu leaves、shop-preview pixels四文件。只改买/卖布局事实注释及三测试的合法输入/必要oracle/排重，不改绘制逻辑、共享fixture、配置、baseline、交易或公开接口。draw-menu全文与present入口、menu-driver真实buy/sell、core买卖/栈/库存状态和SDLPal Buy/Sell/ItemSelect callback已核。\n\n当前counter：L12所谓跨队装备只给role0一件，不能区分只计首人；非卖品承诺无售价却未断言数字。L09空grid强造confirm，未证明全屏grid/图标/noDesc/overlay装配，缺catalog三菜单复用不完整state。G07-B06强造买不起confirm，B12同一物品同时占两部位且所有role equipableBy=false。改为公开构造与合法转换、party[4,1]同手部槽/非队员哨兵；保留库存缺省的独立边界。\n\n先记录原22例正式runner结果，再做旧绿新指定单红的隔离反控；正式恢复与相邻/typecheck、注释去除后JS/TS一致。四源/测试保持review，不因当前jsdom能跑canvas就恢复旧文件信用；历史node环境失败不擦除。全仓check/official ratchet/protected仅大窗口收尾。无产品/形态选择，故不新增用户审批或103+。\n''')
# Full logs on disk, small tail in tool response; no piped command truncation.
s=Path('/tmp/type-pal-projection-capture.py').read_text().replace('core-comment-audit/runtime-projection-comments','core-comment-audit/shop-layout-tests').replace("print(raw.decode()[-7000:])","print(raw.decode()[-1600:])");Path('/tmp/type-pal-shop-capture.py').write_text(s)
print('Four snapshots and bounded authorization recorded.')
