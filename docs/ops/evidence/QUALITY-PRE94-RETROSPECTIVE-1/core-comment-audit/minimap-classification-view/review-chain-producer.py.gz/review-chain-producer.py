from pathlib import Path
import json,hashlib,subprocess,gzip
base='987bdddac38ea3e95d84a3b82dcdeb1ba314556c';prefix=Path('docs/phase-governance/reviews');out=Path('docs/ops/evidence/QUALITY-PRE94-RETROSPECTIVE-1/core-comment-audit/minimap-classification-view')
targets={'20261016-historical-cards-d.json':['docs/ops/audits/code-quality-file-ledger.md'],'20261017-r93-phase-governance-artifacts.json':[str(prefix/'20261016-historical-cards-d.json')],'20261017-r94-final-machine-artifacts.json':[str(prefix/'20261017-r93-phase-governance-artifacts.json')]}
for fn,paths in targets.items():
 p=prefix/fn;lines=p.read_text().splitlines()
 for target in paths:
  pi=next(i for i,l in enumerate(lines) if l==f'      "path": "{target}",');st=next(i for i in range(pi,-1,-1) if lines[i]=='    {');en=next(i for i in range(pi+1,len(lines)) if lines[i] in ['    },','    }']);hi=next(i for i in range(st,en) if lines[i]=='        "history": [');blob=Path(target).read_bytes();cur=hashlib.sha256(blob).hexdigest();old=hashlib.sha256(subprocess.check_output(['git','show',base+':'+target])).hexdigest();assert cur!=old
  item={'revision':base,'date':'2026-10-18','action':'Strengthen finite minimap view/classification and real widget shortcut oracles','previousAfterSha256':old,'scope':'Only three live ledger evidence cells remain review; statuses/counts/frozen history exact. Two source comments only, main14 cases strengthened, leaves6 retained plus2 public keyboard/canvas contracts. Five full-file old-green/current-specified-single-AssertionError controls; restored22 direct/36 adjacent and game typecheck do not grant whole-file/native/visual/unified acceptance.83cards51partial/32pending/0accept unchanged; board and all-card queue untouched. No baseline/retirement/schema/assets/save/API changes. Original native verdict/history retained.','evidence':str(out/'README.md'),'notRun':['whole-repository check','official coverage ratchet','protected fast','browser visual','E2E']}
  block=['          '+l for l in json.dumps(item,ensure_ascii=False,indent=2).splitlines()];block[-1]+=',';lines[hi+1:hi+1]=block;en+=len(block)
  for i in range(st,en):
   if lines[i].startswith('      "afterSha256": '):lines[i]=f'      "afterSha256": "{cur}",'
   elif lines[i].startswith('        "implementationSha": '):lines[i]=f'        "implementationSha": "{cur}",'
   elif lines[i].startswith('        "afterSha256": '):lines[i]=f'        "afterSha256": "{cur}",'
   elif lines[i].startswith('      "reviewedLines": '):lines[i]=f'      "reviewedLines": "1-{len(blob.decode().splitlines())}",'
 p.write_text('\n'.join(lines)+'\n');subprocess.run(['pnpm','exec','biome','format','--write',str(p)],check=True,stdout=subprocess.PIPE)
(out/'review-chain-producer.py.gz').write_bytes(gzip.compress(Path('/tmp/type-pal-mm2-chain.py').read_bytes(),mtime=0));print('Only ledger D → R93 → R94 current bindings updated; board binding and all-card queue unchanged.')
