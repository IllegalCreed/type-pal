from pathlib import Path
import gzip

def once(s,a,b):
 assert s.count(a)==1,(a,s.count(a));return s.replace(a,b)
f=Path('packages/game/src/tools/minimap.ts');s=f.read_text();s=once(s,'// count >= 0 = 给道具(sdlpal count==0 → 给 1 个,global.c:1094;**绝大多数地图宝物就是 count=0**);负=扣除不算。','// 具名count>=0归作宝物,0按inventory helper给1(global.c:1094-1097);静态分类不执行脚本。');s=once(s('// dummy') if False else s,'// 0x1F operand[0]=itemId(remove 是 0x20)','// raw 0x1F此处只看itemId,未检查signed数量;0x20另作移除');f.write_text(s)
f=Path('packages/game/src/tools/minimap.test.ts');s=f.read_text();a=s.index("describe('computeView', () => {");z=s.index('\nconst cmds =',a)
s=s[:a]+'''describe('computeView', () => {
  it('视野>=全图 → 全图(sx=sy=0,sw=BASE_PX)', () => {
    expect(computeView(2080, 1024, 1024)).toEqual({ sx: 0, sy: 0, sw: 640 })
  })
  it('缩放档以主角为中心(960 世界px → 1/3 框),clamp 在底图内', () => {
    // 640/2080=4/13;中心(1040,1040)*4/13=(320,320),半宽1920/13。
    const v = computeView(960, 1024, 1024)
    expect(v.sw).toBeCloseTo(3840 / 13, 6)
    expect(v.sx).toBeCloseTo(2240 / 13, 6)
    expect(v.sy).toBeCloseTo(2240 / 13, 6)
    // 独立的y中心输入,避免x/y被错用时因对称夹具互相掩盖。
    const offset = computeView(960, 1024, 512)
    expect(offset.sx).toBeCloseTo(2240 / 13, 6)
    expect(offset.sy).toBeCloseTo(192 / 13, 6)
    expect(offset.sw).toBeCloseTo(3840 / 13, 6)
  })
  it('主角在边角 → clamp 不越界(sx>=0, sx+sw<=BASE_PX)', () => {
    const near = computeView(640, 0, 0)
    expect(near.sx).toBe(0)
    expect(near.sy).toBe(0)
    expect(near.sw).toBeCloseTo(2560 / 13, 6)
    const far = computeView(640, 2048, 2048)
    expect(far.sx).toBeCloseTo(5760 / 13, 6)
    expect(far.sy).toBeCloseTo(5760 / 13, 6)
    expect(far.sw).toBeCloseTo(2560 / 13, 6)
    expect(far.sx + far.sw).toBeCloseTo(640, 6)
    expect(far.sy + far.sw).toBeCloseTo(640, 6)
  })
})
''' + s[z:]
s=once(s,"    expect(classifyTrigger(cmds(give(1), teleport(), end()), { L_0: 0 }, 'L_0').kind).toBe('item')", "    for (const commands of [cmds(give(1), teleport(), end()), cmds(teleport(), give(1), end())]) {\n      expect(classifyTrigger(commands, { L_0: 0 }, 'L_0').kind).toBe('item')\n    }")
s=once(s,"count=0 → item(sdlpal count==0 给 1 个;**绝大多数地图宝物 count=0**,如木鞋)","count=0仍归item(库存helper将0按1处理;不代表原盘道具名称)")
f.write_text(s)
f=Path('packages/game/src/tools/minimap.glm-phase1-leaves.test.ts');s=f.read_text();s=once(s,' * 六例保持:原重复worldToThumb例替换成底图裁剪。控制器只证开关读写与Image loading/failed ownership,\n * 不把getter当widget可见性或坏zoom的验收。每例释放自有rAF/监听/DOM/全局与偏好。',' * 原六例加两例真实widget快捷键:用实际canvas绘制调用核缩放/两端钳制与输入焦点/关闭守卫。\n * getter仍只证开关读写;不冒充完整可见性/坏持久zoom验收。每例释放自有rAF/监听/DOM/全局与偏好。')
pos=s.index("  it('底图 URL 已 resolve")
s=s[:pos]+'''  it('widget快捷键按四档裁剪真实canvas,两端钳制后仍保持边界档', () => {
    setCurrentMapNum(1)
    const gs = createInitialGameState({ x: 1024, y: 1024, facing: 'down' })
    const ctl = createController({ getGs: () => gs, getMapThumbnail: async () => null })
    ctl.setWidgetEnabled(true)
    const canvas = document.querySelector<HTMLCanvasElement>('#tp-minimap-widget canvas')!
    expect(canvas.width).toBe(180)
    expect(canvas.height).toBe(180)
    const rect = vi.spyOn(canvas.getContext('2d')!, 'strokeRect') // 穿透真实canvas绘制
    try {
      const press = (code: string, index: number, expected: readonly number[]): void => {
        rect.mockClear()
        window.dispatchEvent(new KeyboardEvent('keydown', { code }))
        expect(localStorage.getItem('tp-minimap-zoom')).toBe(String(index))
        expect(rect).toHaveBeenCalledTimes(1)
        const actual = rect.mock.calls[0]!
        expected.forEach((value, i) => expect(actual[i]).toBeCloseTo(value, 6))
      }
      // 180px画布;默认960→640。相机=主角-(160,112),白框世界宽高320×200。
      press('Equal', 3, [45, 58.5, 90, 56.25])
      press('Equal', 3, [45, 58.5, 90, 56.25])
      press('Minus', 2, [60, 69, 60, 37.5])
      press('Minus', 1, [67.5, 74.25, 45, 28.125])
      press('Minus', 0, [990 / 13, 1044 / 13, 360 / 13, 225 / 13])
      press('Minus', 0, [990 / 13, 1044 / 13, 360 / 13, 225 / 13])
    } finally {
      rect.mockRestore()
    }
  })

  it('widget关闭或焦点在INPUT/TEXTAREA时,快捷键不改缩放也不重绘', () => {
    setCurrentMapNum(1)
    const gs = createInitialGameState({ x: 1024, y: 1024, facing: 'down' })
    const ctl = createController({ getGs: () => gs, getMapThumbnail: async () => null })
    ctl.setWidgetEnabled(true)
    const canvas = document.querySelector<HTMLCanvasElement>('#tp-minimap-widget canvas')!
    const rect = vi.spyOn(canvas.getContext('2d')!, 'strokeRect')
    try {
      for (const tag of ['input', 'textarea']) {
        const input = document.createElement(tag)
        document.body.appendChild(input)
        input.dispatchEvent(new KeyboardEvent('keydown', { code: 'Equal', bubbles: true }))
        expect(localStorage.getItem('tp-minimap-zoom')).toBeNull()
        expect(rect).not.toHaveBeenCalled()
      }
      ctl.setWidgetEnabled(false)
      window.dispatchEvent(new KeyboardEvent('keydown', { code: 'Equal' }))
      expect(localStorage.getItem('tp-minimap-zoom')).toBeNull()
      expect(rect).not.toHaveBeenCalled()
    } finally {
      rect.mockRestore()
    }
  })

''' +s[pos:];f.write_text(s)
p=Path('docs/ops/evidence/QUALITY-PRE94-RETROSPECTIVE-1/core-comment-audit/minimap-classification-view');(p/'edit-producer.py.gz').write_bytes(gzip.compress(Path('/tmp/type-pal-mm2-edit.py').read_bytes(),mtime=0))
