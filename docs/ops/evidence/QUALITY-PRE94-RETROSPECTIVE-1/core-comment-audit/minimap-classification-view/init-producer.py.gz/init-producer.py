from pathlib import Path
import subprocess,json,gzip,hashlib,struct,collections
root=Path.cwd();assert str(root)=='/Users/zhangxu/.codex/worktrees/quality-3y-closeout/type-pal'
base=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert base=='987bdddac38ea3e95d84a3b82dcdeb1ba314556c'
assert subprocess.check_output(['git','status','--porcelain'],text=True)==''
p=root/'docs/ops/evidence/QUALITY-PRE94-RETROSPECTIVE-1/core-comment-audit/minimap-classification-view';p.mkdir()
files=[]
for path in ['packages/game/src/tools/minimap.ts','packages/game/src/tools/minimap.test.ts','packages/game/src/tools/minimap.glm-phase1-leaves.test.ts']:
 b=(root/path).read_bytes();digest=hashlib.sha256(b).hexdigest();name=digest[:12]+'-'+Path(path).name+'.before.gz';(p/name).write_bytes(gzip.compress(b,mtime=0));files.append({'path':path,'sha256':digest,'lines':len(b.splitlines()),'snapshot':name,'readRanges':[[1,len(b.splitlines())]]})
(p/'before.json').write_text(json.dumps({'base':base,'owner':'Codex single agent','files':files},ensure_ascii=False,indent=2)+'\n')
rawPath=Path('/Users/zhangxu/illegal/type-pal/data/raw/SSS.MKF');b=rawPath.read_bytes();first=struct.unpack_from('<I',b)[0];assert first%4==0;off=struct.unpack_from('<'+'I'*(first//4),b);assert len(off)==6 and off[0]==first and all(a<=z<=len(b) for a,z in zip(off,off[1:]));code=b[off[4]:off[5]];assert len(code)%8==0
rows=[{'ip':i//8,'itemId':w[1],'quantityU16':w[2],'quantityS16':w[2] if w[2]<32768 else w[2]-65536} for i in range(0,len(code),8) if (w:=struct.unpack_from('<4H',code,i))[0]==31]
(p/'raw-quantity-audit.json').write_text(json.dumps({'producer':'init-producer.py.gz','raw':str(rawPath),'rawSha256':hashlib.sha256(b).hexdigest(),'bytes':len(b),'chunkOffsets':off,'scriptCount':len(code)//8,'addItemInstructions':len(rows),'quantityCounts':dict(collections.Counter(r['quantityU16'] for r in rows)),'signedNegative': [r for r in rows if r['quantityS16']<0],'scope':'All 0x1F instructions in this raw SSS snapshot, not specifically map treasures, runtime reachability or original EXE observations. Raw source is read-only; no asset extraction or generated output written.'},ensure_ascii=False,indent=2)+'\n')
task=root/'docs/ops/tasks/QUALITY-PRE94-RETROSPECTIVE-1.md';task.write_text(task.read_text()+'''\n### 2026-10-18 minimap分类与缩放测试准入\n\nCodex premise verified/design agree/build allowed：本批仅minimap.ts事实注释、既有minimap.test.ts和minimap.glm-phase1-leaves.test.ts的oracle/合法夹具/键盘宿主补强，单一Owner Codex，沿用3y隔离树。三文件全文及公开controller/computeView/classifier出口、正式GameState与Command、真实tools/bootstrap与C库存语义已核。原C无此小地图UI；不改实现、产品分类、seam、资产、save/schema或公共接口。raw/具名数量域差异只读，不把无原盘负数量的潜在问题写成当前剧情缺陷。证据落core-comment-audit/minimap-classification-view；定向/相邻、必要typecheck和静态门，完整check/official coverage/protected留大任务收尾。\n''')
(p/'init-producer.py.gz').write_bytes(gzip.compress(Path('/tmp/type-pal-mm2-init.py').read_bytes(),mtime=0))
print('Bounded three-file snapshots and read-only raw quantity audit saved; test/comment-only admission recorded.')
