from pathlib import Path
import json,gzip,hashlib,subprocess,tempfile,shutil,datetime
root=Path.cwd();out=root/'docs/ops/evidence/QUALITY-PRE94-RETROSPECTIVE-1/core-comment-audit/minimap-classification-view';sha=lambda b:hashlib.sha256(b).hexdigest();before=json.loads((out/'before.json').read_text());oldspec={r['path']:gzip.decompress((out/r['snapshot']).read_bytes()) for r in before['files']};source='packages/game/src/tools/minimap.ts';main='packages/game/src/tools/minimap.test.ts';leaves='packages/game/src/tools/minimap.glm-phase1-leaves.test.ts'
def once(s,a,b):
 assert s.count(a)==1,(a,s.count(a));return s.replace(a,b)
controls=[
 ('view-y-uses-x',source,main,14,14,'缩放档以主角为中心',lambda s:once(s,'const [pcx, pcy] = worldToThumb(cx, cy)','const [pcx, pcy] = worldToThumb(cx, cx)')),
 ('view-upper-clamp-missing',source,main,14,14,'主角在边角',lambda s:once(s,'Math.min(BASE_PX - sw / 2, c)','c')),
 ('teleport-returns-before-later-item',source,main,14,14,'item 优先于 teleport',lambda s:once(s,"if (c.op === 'loadScene') teleport = true","if (c.op === 'loadScene') return { kind: 'teleport' }")),
 ('equal-shortcut-no-zoom',source,leaves,6,8,'widget快捷键按四档裁剪真实canvas',lambda s:once(s,"else if (e.code === 'Equal') setZoom(widgetZoom + 1)","else if (e.code === 'Equal') setZoom(widgetZoom)")),
 ('input-focus-guard-missing',source,leaves,6,8,'widget关闭或焦点在INPUT/TEXTAREA',lambda s:once(s,"if (tag === 'INPUT' || tag === 'TEXTAREA') return","if (tag === 'BUTTON') return")),
]
current={r['path']:(root/r['path']).read_bytes() for r in before['files']};tmp=Path(tempfile.mkdtemp(prefix='type-pal-mm2-controls-'));results=[]
try:
 for label,src,spec,oldN,newN,target,mutate in controls:
  mutant=mutate(current[src].decode()).encode();assert mutant!=current[src];(out/(label+'.mutant.gz')).write_bytes(gzip.compress(mutant,mtime=0));row={'id':label,'source':src,'spec':spec,'sourceSha256':sha(current[src]),'mutantSha256':sha(mutant),'expectedNewFailureNameContains':target,'expectedOldCount':oldN,'expectedCurrentCount':newN,'runs':{}}
  for phase,body in [('old',oldspec[spec]),('current',current[spec])]:
   report=tmp/(label+'.'+phase+'.json');cmd=['pnpm','--filter','@type-pal/game','exec','vitest','run',spec.removeprefix('packages/game/'),'--reporter=verbose','--reporter=json','--outputFile.json='+str(report)];started=datetime.datetime.now(datetime.timezone.utc).isoformat();n=oldN if phase=='old' else newN
   try:
    (root/src).write_bytes(mutant);(root/spec).write_bytes(body);proc=subprocess.run(cmd,cwd=root,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);raw=proc.stdout;(out/(label+'.'+phase+'.raw.gz')).write_bytes(gzip.compress(raw,mtime=0));native=report.read_bytes() if report.exists() else b''
    if native:(out/(label+'.'+phase+'.vitest.json.gz')).write_bytes(gzip.compress(native,mtime=0))
    record={'command':cmd,'cwd':str(root),'startedAt':started,'completedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit':proc.returncode,'signal':-proc.returncode if proc.returncode<0 else None,'spawnError':None,'raw':label+'.'+phase+'.raw.gz','rawBytes':len(raw),'rawSha256':sha(raw),'fullUncutMergedStdoutStderr':True,'specSha256':sha(body),'nativeReport':label+'.'+phase+'.vitest.json.gz','nativeSha256':sha(native)};row['runs'][phase]=record
    assert native;data=json.loads(native);cases=[a for f in data['testResults'] for a in f['assertionResults']];failed=[a for a in cases if a['status']=='failed'];record.update({'passed':data['numPassedTests'],'failed':data['numFailedTests'],'pending':data['numPendingTests'],'cases':[{'file':f['name'],'fullName':a['fullName'],'status':a['status']} for f in data['testResults'] for a in f['assertionResults']]})
    assert len(cases)==n and data['numPendingTests']==0 and not data.get('unhandledErrors',[]) and all(a['status'] in ['passed','failed'] for a in cases)
    assert 'stderr |' not in raw.decode()
    if phase=='old':assert proc.returncode==0 and not failed and data['numPassedTests']==n
    else:
     assert proc.returncode==1 and len(failed)==1 and data['numPassedTests']==n-1 and target in failed[0]['fullName'] and failed[0]['failureMessages'] and all('AssertionError' in m for m in failed[0]['failureMessages']);record['failureMessages']=failed[0]['failureMessages']
   finally:
    (root/src).write_bytes(current[src]);(root/spec).write_bytes(current[spec]);record=row['runs'].get(phase)
    if record:record.update({'sourceRestoredSha256':sha((root/src).read_bytes()),'specRestoredSha256':sha((root/spec).read_bytes()),'sourceRestoredByteForByte':(root/src).read_bytes()==current[src],'specRestoredByteForByte':(root/spec).read_bytes()==current[spec]})
  results.append(row);print(label+': old'+str(oldN)+' passed; current'+str(newN-1)+' passed/1 specified AssertionError',flush=True)
finally:
 for path,body in current.items():(root/path).write_bytes(body)
 shutil.rmtree(tmp);summary={'base':before['base'],'owner':'Codex single agent','scope':'Whole unfiltered old/current file per mutant. Three strengthen existing main contracts; two independently new public widget contracts. No native gameplay/visual acceptance.','controls':results,'tempDirectory':str(tmp),'tempDirectoryRemoved':not tmp.exists(),'restored':all((root/k).read_bytes()==v for k,v in current.items())};(out/'controls.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n');(out/'controls-producer.py.gz').write_bytes(gzip.compress(Path('/tmp/type-pal-mm2-controls.py').read_bytes(),mtime=0))
assert len(results)==len(controls) and summary['restored']
