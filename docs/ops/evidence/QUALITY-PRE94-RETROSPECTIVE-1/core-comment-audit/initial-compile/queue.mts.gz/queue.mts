import { buildActionQueue } from "/Users/zhangxu/.codex/worktrees/quality-3y-closeout/type-pal/packages/game/src/core/battle/turn-queue.ts";
console.log(JSON.stringify(buildActionQueue({players:[{idx:0,dex:100}],enemies:[{idx:0,dex:30,dualMove:false},{idx:1,dex:30,dualMove:false}]}).map(q=>[q.isEnemy?'enemy':'player',q.idx,q.dex])));
