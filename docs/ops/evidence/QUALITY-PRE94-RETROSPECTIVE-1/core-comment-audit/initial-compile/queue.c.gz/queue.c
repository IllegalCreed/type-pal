#include <stdint.h>
#include <stdio.h>
typedef uint16_t WORD; typedef int16_t SHORT; typedef int BOOL;
typedef struct tagACTIONQUEUE
{
   BOOL       fIsEnemy;
   WORD       wDexterity;
   WORD       wIndex;
   BOOL       fIsSecond;
} ACTIONQUEUE;
#define MAX_ACTIONQUEUE_ITEMS 13
static struct { ACTIONQUEUE ActionQueue[MAX_ACTIONQUEUE_ITEMS]; } g_Battle;
int main(void) { int i,j;
for(i=0;i<13;i++){g_Battle.ActionQueue[i].wIndex=0xffff;g_Battle.ActionQueue[i].wDexterity=0xffff;}
g_Battle.ActionQueue[0]=(ACTIONQUEUE){1,30,0,0};g_Battle.ActionQueue[1]=(ACTIONQUEUE){1,30,1,0};g_Battle.ActionQueue[2]=(ACTIONQUEUE){0,100,0,0};
            for (i = 0; i < MAX_ACTIONQUEUE_ITEMS; i++)
            {
               for (j = i; j < MAX_ACTIONQUEUE_ITEMS; j++)
               {
                  if ((SHORT)g_Battle.ActionQueue[i].wDexterity < (SHORT)g_Battle.ActionQueue[j].wDexterity)
                  {
                     ACTIONQUEUE t = g_Battle.ActionQueue[i];
                     g_Battle.ActionQueue[i] = g_Battle.ActionQueue[j];
                     g_Battle.ActionQueue[j] = t;
                  }
               }
printf("[");for(i=0;i<3;i++){ACTIONQUEUE q=g_Battle.ActionQueue[i];printf("%s[\"%s\",%u,%u]",i?",":"",q.fIsEnemy?"enemy":"player",q.wIndex,q.wDexterity);}puts("]");return 0;}
