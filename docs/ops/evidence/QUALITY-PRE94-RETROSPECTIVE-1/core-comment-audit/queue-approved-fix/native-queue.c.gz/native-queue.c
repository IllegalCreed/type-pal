#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
typedef uint16_t WORD;typedef int16_t SHORT;typedef struct { int fIsEnemy;WORD wDexterity,wIndex;int fIsSecond; } ACTIONQUEUE;
#define MAX_ACTIONQUEUE_ITEMS 13
static struct { ACTIONQUEUE ActionQueue[13]; } g_Battle;
int main(int argc,char **argv){int i,j;if((argc-1)%4||argc>53)return 2;for(i=0;i<13;i++){g_Battle.ActionQueue[i].wIndex=0xffff;g_Battle.ActionQueue[i].wDexterity=0xffff;}for(i=0;i<(argc-1)/4;i++){int a=1+i*4;g_Battle.ActionQueue[i]=(ACTIONQUEUE){atoi(argv[a]),(WORD)strtoul(argv[a+2],0,10),(WORD)atoi(argv[a+1]),atoi(argv[a+3])};}
            for (i = 0; i < MAX_ACTIONQUEUE_ITEMS; i++)
            {
               for (j = i; j < MAX_ACTIONQUEUE_ITEMS; j++)
               {
                  if ((SHORT)g_Battle.ActionQueue[i].wDexterity < (SHORT)g_Battle.ActionQueue[j].wDexterity)
                  {
                     ACTIONQUEUE t = g_Battle.ActionQueue[i];
                     g_Battle.ActionQueue[i] = g_Battle.ActionQueue[j];
                     g_Battle.ActionQueue[j] = t;
                  }
               }
            }
puts("[");int n=0;for(i=0;i<13;i++){ACTIONQUEUE q=g_Battle.ActionQueue[i];if(q.wDexterity==0xffff)break;printf("%s[%d,%u,%u,%d]",n++?",":"",q.fIsEnemy,q.wIndex,q.wDexterity,q.fIsSecond);}puts("]");return 0;}
