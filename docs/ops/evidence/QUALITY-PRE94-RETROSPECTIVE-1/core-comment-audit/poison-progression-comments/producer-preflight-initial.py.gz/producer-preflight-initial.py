# -*- coding: utf-8 -*-
from pathlib import Path
import json,gzip,hashlib,re
root=Path.cwd();p=Path('docs/ops/evidence/QUALITY-PRE94-RETROSPECTIVE-1/core-comment-audit/poison-progression-comments');base='27358f9d9e3ab65d777b7864fcc936638ed9373a'
for label in ['direct','adjacent']:
 raw=Path('/tmp/type-pal-poison-progression-'+label+'.json').read_bytes();d=json.loads(raw);assert d['numFailedTests']==0 and d['numPendingTests']==0
 (p/(label+'.vitest.json.gz')).write_bytes(gzip.compress(raw,mtime=0))
for name,src in [('control.py.gz','/tmp/type-pal-poison-progression-control.py'),('capture.py.gz','/tmp/type-pal-poison-progression-capture.py'),('emit-proof.cjs.gz','/tmp/type-pal-poison-progression-emit.cjs')]:
 (p/name).write_bytes(gzip.compress(Path(src).read_bytes(),mtime=0))
meta=json.loads((p/'before.json').read_text());full=meta['files']+[{'path':'packages/game/src/core/dependency-ownership.test.ts'},{'path':'packages/game/src/__tests__/glm-next-wave/H/harness.ts'},{'path':'packages/game/src/core/rng.ts'},{'path':'packages/game/vitest.config.ts'}]
for row in full:
 blob=Path(row['path']).read_bytes();row.clear();row.update({'path':nextpath}) if False else None
# Rebuild without mutating source before metadata.
paths=[x['path'] for x in json.loads((p/'before.json').read_text())['files']]+['packages/game/src/core/dependency-ownership.test.ts','packages/game/src/__tests__/glm-next-wave/H/harness.ts','packages/game/src/core/rng.ts','packages/game/vitest.config.ts']
full=[]
for path in paths:
 raw=Path(path).read_bytes();full.append({'path':path,'sha256':hashlib.sha256(raw).hexdigest(),'lines':len(raw.splitlines()),'scope':'Full base text plus own delta where modified; no whole-file semantic closure.'})
 (p/(Path(path).name+'.current.gz')).write_bytes(gzip.compress(raw,mtime=0))
partial={
 'reference/sdlpal/global.c':[[1330,1745],[2080,2145],[2330,2409]],
 'reference/sdlpal/battle.c':[[1055,1190],[1220,1335]],
 'reference/sdlpal/palcommon.h':[[70,90]],
 'packages/game/src/core/game-state.ts':[[520,595],[1060,1080],[1394,1453],[1555,1695]],
 'packages/game/src/core/battle/battle-settlement.ts':[[100,175]],
 'packages/game/src/core/equipment-state.ts':[[370,395]],
 'packages/game/src/core/event-opcode-player.ts':[[195,265],[360,430]],
 'packages/game/src/core/battle/battle-finalization.ts':[[1,65]],
 'packages/game/src/core/battle/battle-opcodes.ts':[[550,640]],
 'packages/game/src/core/event-system.ts':[[4288,4320]],
 'packages/game/src/shell/bootstrap.ts':[[1248,1275]],
 'packages/shared/src/tables.ts':[[465,625]],
 'docs/phase1/game-mechanics.md':[[106,235],[1255,1304],[1333,1364],[1486,1501],[1529,1566]],
 'docs/phase1/engineering-notes.md':[[107,125]],
}
rows=[]
for path,ranges in partial.items():
 raw=Path(path).read_bytes();n=len(raw.splitlines());assert all(1<=a<=z<=n for a,z in ranges),path
 rows.append({'path':path,'sha256':hashlib.sha256(raw).hexdigest(),'ranges':ranges,'scope':'Only these primary/type/caller/lifecycle ranges, including combined contiguous reads; no full file or original-game execution claim.'})
(p/'read-boundaries.json').write_text(json.dumps({'base':base,'fullReads':full,'partialReads':rows,'newClosed':0,'limitations':['Primary C/phase1 documentation, not full SDLPal/native/original asset gameplay.','Adjacent tests are execution regression only, no new semantic review/closure credit.','Poison holes/compaction only recorded; no product build allowed.']},ensure_ascii=False,indent=2)+'\n')
old='D11×M5:升级写 runtime → 投影 → 下一场战斗吃升级后属性(整链闭环)';new='D11×M5:升级写runtime → 公开battle roles投影读取升级结果'
(p/'test-title-mapping.json').write_text(json.dumps({'file':'packages/game/src/core/battle/__tests__/battle-levelup.test.ts','scope':'One title narrowed to actually executed projection, no test-count change; no protected baseline/retirement payload edited or official identity gate run in this slice.','old':old,'current':new,'describe':'battleWonLevelUp —— D11 战斗胜利升级'},ensure_ascii=False,indent=2)+'\n')
# Canonical ledger only; immutable fenced source stays byte-identical.
f=Path('docs/ops/audits/code-quality-file-ledger.md');s=f.read_text();live,history=s.split('<!-- original-source-fenced:start -->',1)
assert '当前已闭合核验：278；已读但待审：63' in live
live=live.replace('当前已闭合核验：278；已读但待审：63；尚未逐文件核验：2,974；合计未闭合：3,037。','当前已闭合核验：275；已读但待审：66；尚未逐文件核验：2,974；合计未闭合：3,040。')
rowspec={
 'packages/game/src/core/battle/battle-progression.ts':('product','源全文/真实settlement caller/原C；错锚与随机算法信用勘误，非执行变化','主升级999 cap与隐藏无该cap分清；有限定向/反控不能闭合全部数值域/统一门，旧源关闭转review'),
 'packages/game/src/core/battle/battle-progression.glm-next-wave.test.ts':('test','全文与真实H工厂/原C CHECK_HIDDEN_EXP；5合同数保持','旧额外RNG消费变异5绿→新4绿1指定AssertionError；只证明两池与主6/隐藏2抽，不冒称七池全序'),
 'packages/game/src/core/battle/__tests__/battle-levelup.test.ts':('test','全文/公开projectRuntimeToBattleRoles/typed makeHRole；11合同数保持','移除as any as核心夹具、收窄未开战的标题；未复算原盘真值表/其它数值极端域，旧整文件信用撤回'),
 'packages/game/src/core/player-poison-state.ts':('product','全文/真实装备与opcode caller/原C；CureKind及Wear/首空槽注释勘误','非压缩/全槽去重差异保持review，GAME-PLAYER-POISON-SLOT-COMPACTION-1只读；未改状态、schema或接口'),
}
lines=live.splitlines()
for path,(kind,evidence,reason) in rowspec.items():
 matches=[i for i,line in enumerate(lines) if line.startswith('| `'+path+'` |')];assert len(matches)==1,path
 lines[matches[0]]=f'| `{path}` | {kind} | review | [毒/升级注释与夹具](../evidence/QUALITY-PRE94-RETROSPECTIVE-1/core-comment-audit/poison-progression-comments/README.md)；{evidence} | {reason} |'
f.write_text('\n'.join(lines)+'\n\n<!-- original-source-fenced:start -->'+history)
# Current slice supersedes only unsupported current claims; preserve prior report exact bytes.
f=Path('docs/ops/evidence/QUALITY-PRE94-RETROSPECTIVE-1/3x-battle-progression/README.md');(p/'3x-README.before.gz').write_bytes(gzip.compress(f.read_bytes(),mtime=0))
f.write_text('''# CODE3x battle progression 当前复审切片

2026-10-18 当前结论：3x仍partial，整文件信用撤回review。前轮“未发现direct实现defect”只保留已核普通数值路径；“无弱断言/所有夹具合法/完整开战闭环”不能成立：levelup投影夹具缺字段而用as any as隐藏，H02额外RNG消费变异旧5例仍绿。旧报告完整字节保存在[本次附件](../core-comment-audit/poison-progression-comments/3x-README.before.gz)，旧207绿仅是当时回归观察，不认证当前语义或统一门。

本次重新全文核battle-progression、H02、levelup，按PAL_BattleWon/PAL_PlayerLevelUp/真实settlement caller核主升级999 cap、隐藏不套此cap、主6抽/隐藏2抽和HP/MP回满顺序。修正STAT_LIMIT2393–2401、MAX_LEVELS/palcommon.h与global.c真实EOF2409；写回余exp与PAL_PlayerLevelUp自身清零不同，PRNG算法也不同于SDLPal，不能声称同种子同序。

生产仅注释，removeComments编译JS字节与27358f9d9基点一致。levelup复用完整typed角色工厂，只执行公开投影，不声称真实开下一场；H02头注只保留Health→Magic两池信用，主升级回满例明确8个合法抽样并核完整调用参数序列。额外一抽的同一变异旧5绿→新4绿1指定业务AssertionError，恢复SHA一致；两文件仍5/11例，无新增弱测试或退役。

本片27定向（含11所有权相邻）与16真实结算/装备/opcode相邻全绿无stderr，game typecheck通过。完整原件/读边界、当前门、身份映射与限制见[毒/升级有限返工](../core-comment-audit/poison-progression-comments/README.md)。C WORD极端数值、全部七池判别力、原盘表重算、真正开战/演出与统一check/coverage/protected仍未验，不关闭文件；前轮C源越界原件也继续保留于53 receipt-audit。
''')
# Record connected sparse-list observation without promoting it to a new verified gameplay defect.
f=Path('docs/ops/tasks/GAME-PLAYER-POISON-SLOT-COMPACTION-1.md');s=f.read_text();s+='''\n## 2026-10-18 只读补充：首空槽与现有测试的证据边界\n\n全文重读玩家毒helper，核PAL_AddPoisonForPlayer/两类Cure与装备/opcode生产caller：C施毒只在首空槽之前检查同毒，TS先扫全部16槽去重；CureByKind本身只清零可留下孔洞，因此不能把稀疏域差异只归于Wear。当前只按源码记录这两个控制流，不把它称作已跑通的真实物品/毒tick/存读链。helper注释已显式分开TS行为与C；正ID/原盘catalog/孔洞后的入口脚本与tick顺序仍待完整核证。\n\n现有dependency-ownership专测直接断言卸Wear后低毒仍在slot1，验证的是当前TS跨入口ownership，不能据其全绿认证SDL压缩等价。本批保持该测试与产品行为；0新批准，不实现压缩、去重策略、队伍键或save/upgrader。有限注释/夹具返工证据见[本片](../evidence/QUALITY-PRE94-RETROSPECTIVE-1/core-comment-audit/poison-progression-comments/README.md)。\n''';f.write_text(s)
# Board actually needs a progress correction, no task status/index change.
f=Path('docs/ops/board.md');s=f.read_text();old='三机制窄修/六簿记已核，十注释/两UI差异继续；旧门rework，未合main';new='队列/三机制窄修已测；四组注释已修，余六组/两UI差异继续；旧门rework，未合main';assert old in s;s=s.replace(old,new);f.write_text(s)
f=Path('docs/ops/tasks/QUALITY-PRE94-RETROSPECTIVE-1.md');s=f.read_text();s+='''\n### 2026-10-18 毒/升级注释与夹具当前结果\n\n四文件有限批：CureKind、Wear/首空槽与升级MAX_LEVELS/STAT_LIMIT/EOF/余exp/RNG说明已更正，两实现removeComments JS字节与27358基点一致。旧投影例改完整typed工厂，标题仅写实际公开投影；H02纠正“七池”、dwExp200与“主6+隐藏1/7值”错注，主6+隐藏2的8抽逐参数核验。相同多耗一抽变异旧5绿→新4绿1指定AssertionError、0skip/runtime额外失败，源finally恢复；恢复27定向+16相邻绿、无stderr，game typecheck通过。\n\n不因少量绿恢复整文件信用：升级源/两测试旧closed→review，poison保持review；3315 tracked/275closed/66review/2974pending，0新closed，83卡50partial/33pending/0accept。毒全槽去重/首空槽差异补回原draft卡，只读不实现；原盘表重算、全部七池测试、C WORD数值极端、真正开战/视觉和统一门待续。四组审计注释现已处理，余六组/冗余算术/两UI继续，94–102/editor在后。\n\n完整原件见[本片](../evidence/QUALITY-PRE94-RETROSPECTIVE-1/core-comment-audit/poison-progression-comments/README.md)。官方coverage/protected与全仓check按用户成本要求留大任务收尾，本片未跑，不合main；无下一位Agent提示词，Codex单Agent继续。\n''';f.write_text(s)
(p/'gates.json').write_text(json.dumps({'base':base,'scope':'Two comment-only implementations and two focused tests; no executable product change','direct':{'files':3,'passed':27,'diagnostics':0,'receipt':'direct.json','scope':'Modified16 plus11 existing ownership regression; unchanged ownership source only read, no new semantic acceptance.'},'adjacent':{'files':3,'passed':16,'diagnostics':0,'receipt':'adjacent.json','scope':'Regression only, not new full-file review.'},'control':{'oldPassed':5,'currentPassed':4,'currentBusinessAssertionErrors':1,'pending':0,'sourceRestoredByteForByte':True,'receipts':['control-old.json','control-current.json'],'scope':'One extra RNG consumption at hidden-refill, same executable production algorithm before/current comments. Not a new product bug.'},'emitIdentity':{'files':2,'byteIdentical':True,'receipts':['emit-identity.json','emit-identity-run.json']},'typecheck':{'exit':0,'diagnostics':0,'receipt':'typecheck.json'},'docs':{'status':'pending','receipt':'docs.json'},'lint':{'status':'pending','receipt':'lint.json'},'ledger':{'status':'pending','receipt':'ledger.json'},'diff':{'status':'pending','receipt':'diff.json'},'newClosed':0,'reopened':3,'notRun':['whole-repository check','official coverage ratchet','protected fast','native SDLPal execution','original-asset gameplay','browser visual','E2E'],'notRunReason':'User batches expensive whole-repo/coverage gates at large closeout; this finite slice makes no product behavior change. No baseline/retirement payload/rule changes.','remaining':['Six annotation groups and formulas arithmetic proof','Poison sparse-list/compaction product decision and actual catalog/tick lifecycle','Unverified original-table and extreme numeric domains','Remaining seven-pool discrimination','One test-title protected identity migration at actual closeout','Unified zero diagnostics and merge']},ensure_ascii=False,indent=2)+'\n')
(p/'README.md').write_text('''# pre94毒/升级：源码注释与测试判别力返工

Status: recorded
Owner: Codex（单Agent；作者修复/反控，不冒充第三方）
Date: 2026-10-18
Base: `27358f9d9e3ab65d777b7864fcc936638ed9373a`
Branch: `codex/code-quality-3y`

## 证据身份与范围

id: QUALITY-PRE94-RETROSPECTIVE-1 / poison-progression-comments；schemaVersion:1；status:recorded。当前准入和交接见[父卡](../../../../tasks/QUALITY-PRE94-RETROSPECTIVE-1.md)，机制停止线见[毒槽卡](../../../../tasks/GAME-PLAYER-POISON-SLOT-COMPACTION-1.md)。[逐文件读边界](read-boundaries.json)只证明实际列出的完整/部分阅读；不把相邻测试绿、SHA相同或“没有any”当整文件通过。

## 实际读取与primary/caller

全文核两源/两直接测试、dependency-ownership、H工厂、rng与Vitest配置。两源的真实生产入口为settlement先写回runtime再升级、event/battle opcode施毒/解毒、卸Wear清装备毒、battle-finalization战后阈值3清毒与bootstrap注入毒表。公开出口仍由event-system/battle-system导出。原C实际核PAL_BattleWon、PAL_PlayerLevelUp/STAT_LIMIT、AddMagic、玩家毒增删查和Wear分支；不是完整SDLPal或原版游戏实跑。

注释修正：CureByKind真实global.c1520–1564；AddPoison范围1459–1517；Wear明确TS不压缩/全16槽、C遇首空槽并前移；CureByLevel不许伪称无条件跳过level99。升级MAX_LEVELS源为palcommon.h82；STAT_LIMIT2393–2401，LevelUp到真实EOF2409；PAL_BattleWon保存余数与LevelUp自身清零分开。本项目mulberry32与SDL LCG不同，只核范围/顺序而非同seed同序。两生产实现removeComments JS输出字节与基点相同，原始/当前源及编译producer保留。

## 测试合法性、oracle与反控

levelup投影例的as any as PlayerRole缺失头像/精灵/音效等必填字段；改复用现有完整typed makeHRole，静态roles显式PlayerRoles类型，保持原有数值oracle。原例未startBattle，只调公开投影，标题勘误并保存[test-title映射](test-title-mapping.json)，不为维持身份保留虚假闭环声明；未编辑baseline/退役payload，官方身份门留大窗口。

H02五例分别核越界等级防御、隐藏无999 cap、Health→Magic两池、无主升级不回满、主升级隐藏涨点后回满；不冒称七池全序或正常生产会生成level120。多池dwExp应100非200。最后一例实际主6抽+隐藏2抽，旧七值的recordingRng回退1遮住次数；现明确八值并断言完整范围序列。该断言与同次主/隐藏升级后的回满合同配对，不拆重复smoke。

同一额外一抽变异先使旧五例5绿，新五例4绿1指定业务AssertionError；没有过滤、skip/pending或collection/runtime替身红，两个完整原生Vitest JSON/raw、command/cwd/exit/signal/source/spec/mutant hash及finally恢复SHA见control-old/current。恢复后改动两测仍5+11=16条，另11条跨入口所有权回归，共27定向；结算/装备/opcode三个相邻文件16条只计回归。完整输出无stderr/act/环境/unhandled诊断。没有新增删除测试、降低断言或修改runner；其余五池次序、原盘表复算与全部极端输入仍未接受。

## 发现、限制与后续

毒去重的TS全槽扫描与C首空槽前缀不是同一合同，CureKind可留孔洞，现只源码记录并回写已有draft卡。dependency-ownership的slot1低毒断言保护当前TS稀疏ownership，不能证明SDL压缩等价；该测试/产品保持。装备/原盘catalog/毒tick与save因果仍待，不改压缩/去重策略、状态键或schema/upgrader。

升级源与两直接测试旧整文件关闭信用转review，poison保持review，0新增closed；旧3x“无弱断言/夹具全合法/完整开战链”撤回，旧报告字节另存，旧207绿不推广。新账本以ledger.json为准，83卡仍50partial/33pending/0accept。完成四组注释，剩余六组和两UI差异优先，94–102/editor随后。

## 验证与交接

当前命令/退出码/完整未裁剪raw/hash见gates.json及配对附件。game typecheck通过；完整docs/lint/ledger/diff门待本片收尾实际回执，不以pending字段当通过。全仓check、official coverage ratchet、protected fast按用户成本纪律未运行；无新产品行为或界面、资源生成、schema/save/public接口改动。未合main，不宣布统一门或专项完成。无下一位Agent提示词，Codex单Agent继续上述明确范围。
''')
print('Four-file current evidence, scoped ledger/board/task corrections written; old fenced history untouched.')
