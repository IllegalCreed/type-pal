# -*- coding: utf-8 -*-
from pathlib import Path
import json,gzip,hashlib,re,subprocess,collections
p=Path('docs/ops/evidence/QUALITY-PRE94-RETROSPECTIVE-1/core-comment-audit/poison-progression-comments');base='27358f9d9e3ab65d777b7864fcc936638ed9373a';sha=lambda b:hashlib.sha256(b).hexdigest()
for row in json.loads((p/'before.json').read_text())['files']:
 raw=gzip.decompress((p/row['snapshot']).read_bytes());assert sha(raw)==row['sha256'] and len(raw.splitlines())==row['lines'];assert raw==subprocess.check_output(['git','show',base+':'+row['path']])
d=json.loads((p/'read-boundaries.json').read_text())
for row in d['fullReads']:
 raw=Path(row['path']).read_bytes();assert sha(raw)==row['sha256'] and len(raw.splitlines())==row['lines'],row['path']
for row in d['partialReads']:
 raw=Path(row['path']).read_bytes();assert sha(raw)==row['sha256'];assert all(1<=a<=z<=len(raw.splitlines()) for a,z in row['ranges']),row['path']
pairs=[]
def scan(x):
 if isinstance(x,list):
  for v in x:scan(v)
 elif isinstance(x,dict):
  if isinstance(x.get('raw'),str) and 'rawSha256' in x:
   raw=gzip.decompress((p/x['raw']).read_bytes());assert sha(raw)==x['rawSha256'];assert len(raw)==x['rawBytes'];pairs.append(x['raw'])
  for v in x.values():scan(v)
for f in p.glob('*.json'):scan(json.loads(f.read_text()))
for label,passed,failed in [('control-old',5,0),('control-current',4,1),('direct',27,0),('adjacent',16,0)]:
 data=json.loads(gzip.decompress((p/(label+'.vitest.json.gz')).read_bytes()));cases=[a for r in data['testResults'] for a in r['assertionResults']];bad=[a for a in cases if a['status']=='failed'];assert data['numPassedTests']==passed and data['numFailedTests']==failed and len(cases)==passed+failed;assert not any(a['status'] in ('skipped','pending','todo') for a in cases)
 assert not data.get('unhandledErrors',[])
 if failed:assert len(bad)==1 and '主升级成立 → 隐藏涨点后' in bad[0]['fullName'] and all('AssertionError' in s for s in bad[0]['failureMessages'])
 if label.startswith('control'):
  r=json.loads((p/(label+'.json')).read_text());assert r['sourceSha256']==r['restoredSourceSha256'] and r['sourceRestoredByteForByte'];assert r['exit']==(1 if failed else 0)
 else:
  raw=gzip.decompress((p/(label+'.raw.gz')).read_bytes()).decode();assert not re.search(r'^stderr \||not wrapped in act|not configured to support act|Unhandled Errors|Unhandled Rejection|Uncaught Exception',raw,re.M|re.I)
for row in json.loads((p/'emit-identity.json').read_text())['rows']:assert sha(Path(row['path']).read_bytes())==row['currentSha256'] and row['byteIdentical']
# Frozen historical ledger bytes and all unchanged catalog objects are actually equal.
marker='<!-- original-source-fenced:start -->';path='docs/ops/audits/code-quality-file-ledger.md';old=subprocess.check_output(['git','show',base+':'+path]).decode();cur=Path(path).read_text();assert old.split(marker,1)[1]==cur.split(marker,1)[1]
old=json.loads(gzip.decompress((p/'catalog.before.gz').read_bytes()));cur=json.loads(Path('docs/testing/catalog.json').read_text());assert len(old['entries'])==len(cur['entries'])==18
idx=next(i for i,e in enumerate(old['entries']) if e['id']=='phase1-dependency-ownership');a=cur['entries'][idx];b=old['entries'][idx]
assert a['lastVerified']==b['lastVerified'] and a['reviewBy']==b['reviewBy'] and a['status']==b['status']
patched=json.loads(json.dumps(a));r=next(r for r in patched['sourceRefs'] if r['path']=='packages/game/src/core/player-poison-state.ts');r['sha256']=next(r for r in b['sourceRefs'] if r['path']=='packages/game/src/core/player-poison-state.ts')['sha256'];patched['revision']['history'].pop(0);assert patched==b
cur['entries'][idx]=b;assert cur==old
old=json.loads(gzip.decompress((p/'dependency-evidence.before.gz').read_bytes()));cur=json.loads(Path('docs/testing/domains/phase1-runtime/dependencies/dependency-ownership/evidence.json').read_text());r=next(r for r in cur['sourceRefs'] if r['path']=='packages/game/src/core/player-poison-state.ts');r['sha256']=next(r for r in old['sourceRefs'] if r['path']=='packages/game/src/core/player-poison-state.ts')['sha256'];cur['history'].pop(0);cur['findings'].pop();assert cur==old
cohort=json.loads(Path('docs/ops/evidence/QUALITY-PRE94-RETROSPECTIVE-1/all-cards.json').read_text());counts=dict(collections.Counter(c['currentReview'] for c in cohort['cards']));assert len(cohort['cards'])==83 and counts=={'partial':50,'pending':33} and not any(c['currentAcceptance'] for c in cohort['cards'])
source=Path('reference/sdlpal/global.c').read_text().splitlines();assert 'PAL_CurePoisonByKind(' in source[1519] and 'PAL_AddPoisonForPlayer(' in source[1458] and 'PAL_PlayerLevelUp(' in source[2346] and '#define STAT_LIMIT' in source[2392];assert len(source)==2409
print(json.dumps({'rawPairsVerified':len(pairs),'readBoundaryHashesAndActualRanges':'matched','beforeSources':'exact27358 Git blobs','currentTests':{'direct':27,'adjacent':16,'newControl':'4passed/1specifiedAssertionError','oldControl':'5passed'},'catalog':'Only selected sourceRef/history changed, other17 objects/status/dates unchanged','pairedEvidence':'Only intended sourceRef/history/finding delta; candidate/versions/runtime flags unchanged','ledgerHistoricalBytes':'exact','cohort':{'total':83,**counts,'accept':0}},ensure_ascii=False))
