# -*- coding: utf-8 -*-
from pathlib import Path
import json,hashlib,subprocess
base='27358f9d9e3ab65d777b7864fcc936638ed9373a';prefix=Path('docs/phase-governance/reviews');evidence='docs/ops/evidence/QUALITY-PRE94-RETROSPECTIVE-1/core-comment-audit/poison-progression-comments/README.md'
def update(fn,paths):
 p=prefix/fn;lines=p.read_text().splitlines()
 for target in paths:
  matches=[i for i,l in enumerate(lines) if l==f'      "path": "{target}",'];assert len(matches)==1,(fn,target);pi=matches[0];st=next(i for i in range(pi,-1,-1) if lines[i]=='    {');en=next(i for i in range(pi+1,len(lines)) if lines[i] in ['    },','    }']);hi=next(i for i in range(st,en) if lines[i]=='        "history": [');blob=Path(target).read_bytes();cur=hashlib.sha256(blob).hexdigest();old=hashlib.sha256(subprocess.check_output(['git','show',base+':'+target])).hexdigest()
  item={'revision':base,'date':'2026-10-18','action':'Finite poison/progression comment/test repair and dependent sourceRef maintenance','previousAfterSha256':old,'scope':'Only the named current source/document delta and incoming bindings. Catalog maintenance selects phase1-dependency-ownership only; other17 entry objects, lastVerified/status/versions/candidate and old D1 runtime/needle fields unchanged. Poison implementation JS unchanged; current11 ownership tests are only finite regression. Three old file closures reopened; no new product/native/SCC/browser/coverage or whole-document acceptance. Original native verdicts/history preserved.','evidence':evidence,'notRun':['original D1 audit/needles','whole-repository check','official coverage ratchet','protected fast','browser visual','E2E']}
  # Only our still-uncommitted C maintenance may be replaced; never duplicate it or edit older history.
  if lines[hi+1]=='          {':
   he=next(i for i in range(hi+2,en) if lines[i] in ['          },','          }']);prior=json.loads('\n'.join(lines[hi+1:he+1]).rstrip(','))
   if prior.get('revision')==base and prior.get('evidence')==evidence:
    del lines[hi+1:he+1];en-=he-hi
  block=['          '+l for l in json.dumps(item,ensure_ascii=False,indent=2).splitlines()];block[-1]+=',';lines[hi+1:hi+1]=block;en+=len(block)
  for i in range(st,en):
   if lines[i].startswith('      "afterSha256": '):lines[i]=f'      "afterSha256": "{cur}",'
   elif lines[i].startswith('        "implementationSha": '):lines[i]=f'        "implementationSha": "{cur}",'
   elif lines[i].startswith('        "afterSha256": '):lines[i]=f'        "afterSha256": "{cur}",'
   elif lines[i].startswith('      "reviewedLines": '):lines[i]=f'      "reviewedLines": "1-{len(blob.decode().splitlines())}",'
 p.write_text('\n'.join(lines)+'\n');json.loads(p.read_text());subprocess.run(['pnpm','exec','biome','format','--write',str(p)],check=True,stdout=subprocess.PIPE)
update('20261015-catalog-pilot-batch.json',['docs/testing/catalog.json','docs/testing/domains/phase1-runtime/dependencies/dependency-ownership/report.md'])
update('20261015-domain-pairs-and-archive-cards.json',['docs/testing/domains/phase1-runtime/dependencies/dependency-ownership/evidence.json'])
update('20261017-r93-phase-governance-artifacts.json',[str(prefix/'20261015-catalog-pilot-batch.json'),str(prefix/'20261015-domain-pairs-and-archive-cards.json')])
update('20261017-r94-final-machine-artifacts.json',[str(prefix/'20261017-r93-phase-governance-artifacts.json')])
print('Two exact publication reviews and their R93/R94 incoming rows rebound; historical bindings and native findings retained.')
