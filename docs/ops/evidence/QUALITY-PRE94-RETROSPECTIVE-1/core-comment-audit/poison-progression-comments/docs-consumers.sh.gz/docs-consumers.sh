set -e
node scripts/docs/check.mjs
node scripts/docs/check-document-model.mjs
pnpm check:testing-docs
node scripts/docs/check-phase-lore-governance.mjs
node scripts/docs/check-content-review.mjs --strict
