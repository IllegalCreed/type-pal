# coding: utf-8
from pathlib import Path

def once(s,a,b):
 assert s.count(a)==1,(a,s.count(a));return s.replace(a,b)
f=Path('packages/game/src/core/battle/__tests__/formulas.test.ts');s=f.read_text()
s=once(s,' * 公式测试 —— D29 + D30 数值忠诚度。手算输入 → 期望输出,\n * 与 sdlpal `fight.c` 行号一一对照。具体 1:1 数值由 T23 baseline 跑 sdlpal harness 校验。',' * 公式叶合同:手算小值及当前 TS 截断边界,不代替真实 caller 或全数值域 SDLPal 验证。\n * 五灵使用对敌生产除数1;已知 FLOAT/WORD 差异见 GAME-MAGIC-NUMERIC-ASSIGNMENT-1。')
s=once(s,"  it('SHORT cast 行为(大值溢出有限数,不抛)', () => {","  it('当前 TS 截取16位:65535输入得到-2,不声称C越界浮点转换等价', () => {")
s=once(s,'    expect(Number.isFinite(result)).toBe(true)\n','')
s=s.replace('resistMult: 10,','resistMult: 1,')
s=s.replace('multiplier = 10 - 0/10 = 10','multiplier = 10 - 0/1 = 10')
s=once(s,"  it('高 elemental resistance (50) → 低伤害'","  it('敌方 elemental resistance=5,生产除数1 → 伤害80'")
s=once(s,'multiplier = 10 - 50/10 = 5','multiplier = 10 - 5/1 = 5');s=once(s,'wind: 50','wind: 5')
s=once(s,"  it('满 elemental resistance (100) → 免疫,damage = 0'","  it('敌方 elemental resistance=10,生产除数1 → 免疫'")
s=once(s,'multiplier = 10 - 100/10 = 0','multiplier = 10 - 10/1 = 0');s=once(s,'wind: 100','wind: 10')
# Both zero-resistance comments already replaced.
s=once(s,"  it('rngFactor 1.1 ≥ 1.0 (放大 magStr → 不减伤)'","  it('caller可达倍率1.05与1.0分别得到52与50'")
s=once(s,'rngFactor: 1.1,','rngFactor: 1.05,');s=once(s,'    expect(higher).toBeGreaterThanOrEqual(base)\n','')
s=once(s,'    // higher: magStr=trunc(110)=110, calcBase=trunc(220+0.5)=220; /4=55','    // next=0.5时倍率1.05:magStr=105,calcBase=210;整数除4=52')
s=once(s,'expect(higher).toBe(55)','expect(higher).toBe(52)')
s=once(s,'    // 给 thunder (索引 1) 一个高 resist,只有 elem=2 受影响\n    const resThunder = { ...ZERO_ELEM, thunder: 100 }\n    expect(make(2, resThunder)).toBe(0)\n    expect(make(1, resThunder)).toBe(160) // wind 不受 thunder resist 影响\n    expect(make(5, resThunder)).toBe(160) // earth 不受影响','    // 共同入元素前为80;不同抗性使五个索引各有独立结果,可辨别水/火互换。\n    // 80 * (10-res) / 5;场效0。输入与生产对敌抗性/除数口径一致。\n    const res = { wind: 0, thunder: 2, water: 4, fire: 6, earth: 8 }\n    expect([1, 2, 3, 4, 5].map((elemental) => make(elemental, res))).toEqual([\n      160, 128, 96, 64, 32,\n    ])')
f.write_text(s)
print('3 selected files edited: 2 comments-only, 1 existing 28-case test quality delta')
