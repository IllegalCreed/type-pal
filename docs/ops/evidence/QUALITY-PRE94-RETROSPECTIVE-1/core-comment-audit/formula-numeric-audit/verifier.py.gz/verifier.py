from pathlib import Path
import json,gzip,hashlib,subprocess,copy
root=Path.cwd();p=root/'docs/ops/evidence/QUALITY-PRE94-RETROSPECTIVE-1/core-comment-audit/formula-numeric-audit';base='8dabfd49976f818364d451635f155af08a41b9a9';sha=lambda b:hashlib.sha256(b).hexdigest();meta=json.loads((p/'before.json').read_text());read=json.loads((p/'read-boundaries.json').read_text())
for r in meta['files']:
 b=gzip.decompress((p/r['snapshot']).read_bytes());assert sha(b)==r['sha256'] and len(b.splitlines())==r['lines'];assert b==subprocess.check_output(['git','show',base+':'+r['path']])
for r in read['fullReads']+read['partialReads']:
 b=Path(r['path']).read_bytes();assert sha(b)==r['sha256'] and len(b.splitlines())==r['lines'];assert all(1<=a<=z<=r['lines'] for a,z in r['ranges'])
 if 'snapshot' in r:assert gzip.decompress((p/r['snapshot']).read_bytes())==b
c=json.loads((p/'controls.json').read_text());assert len(c['controls'])==2 and c['restored'] and c['tempDirectoryRemoved'];pairs=[]
for r in c['controls']:
 assert sha(Path(r['source']).read_bytes())==r['sourceSha256'];assert sha(gzip.decompress((p/(r['id']+'.mutant.gz')).read_bytes()))==r['mutantSha256']
 for phase,d in r['runs'].items():
  raw=gzip.decompress((p/d['raw']).read_bytes());assert sha(raw)==d['rawSha256'] and len(raw)==d['rawBytes'] and d['fullUncutMergedStdoutStderr'];native=json.loads(gzip.decompress((p/d['nativeReport']).read_bytes()));assert d['passed']==(28 if phase=='old' else 27) and d['failed']==(0 if phase=='old' else 1) and d['pending']==0;assert d['sourceRestoredByteForByte'] and d['specRestoredByteForByte'];assert d['sourceRestoredSha256']==r['sourceSha256'];assert d['specRestoredSha256']==sha(Path(r['spec']).read_bytes());assert native['numPassedTests']==d['passed'] and native['numFailedTests']==d['failed'] and not native.get('unhandledErrors',[]);assert len(d['cases'])==28
 pairs.append({'id':r['id'],'oldPassed':28,'currentPassed':27,'currentSpecifiedAssertionError':1,'restored':True})
for r in json.loads((p/'emit-identity.json').read_text())['rows']:
 assert r['byteIdentical'] and r['parsedTypeScriptWithoutCommentsIdentical'] and r['currentSha256']==sha(Path(r['path']).read_bytes())
rawPairs=[]
for f in sorted(p.glob('*.json')):
 d=json.loads(f.read_text());rs=([d] if 'raw' in d else [])+d.get('runs',[])
 if isinstance(rs,dict):continue
 for r in rs:
  raw=gzip.decompress((p/r['raw']).read_bytes());assert len(raw)==r['rawBytes'] and sha(raw)==r['rawSha256'] and r['fullUncutMergedStdoutStderr'];assert r['exit']==0,(f,r['exit']);rawPairs.append({'receipt':f.name,'raw':r['raw'],'sha256':sha(raw)})
for f in ['numeric-counter.json','mapping-oracle.json','poison-oracle.json']:
 d=json.loads((p/f).read_text());assert d['tempRemoved']
x=json.loads((p/'numeric-counter.json').read_text());assert x['base']==base
native=[json.loads(s) for s in gzip.decompress((p/'native-O0.raw.gz').read_bytes()).decode().splitlines()];assert [r['damage'] for r in native[:3]]==[80,161,161] and native[-1]['randomFloat']==11;assert gzip.decompress((p/'native-O0.raw.gz').read_bytes())==gzip.decompress((p/'native-O2.raw.gz').read_bytes())
for r in x['bounds']:
 b=Path(r['path']).read_bytes();assert sha(b)==r['sha256'];assert all(1<=a<=z<=len(b.splitlines()) for a,z in r['ranges'])
for f in ['typescript.raw.gz','caller-lifecycle.raw.gz']:
 d=json.loads(gzip.decompress((p/f).read_bytes()));assert d['leaf']==d['quarter']==160 and d['result']==[{'enemyIdx':0,'damage':160,'hpBefore':9000,'hpAfter':8840}] and d['sameOneDraw'] and d['oneDrawState']==1831809862
# Only the declared existing paths plus the new risk card/evidence may differ.
allowed={'docs/ops/board.md','docs/ops/audits/code-quality-file-ledger.md','docs/ops/tasks/index.md','docs/ops/tasks/QUALITY-PRE94-RETROSPECTIVE-1.md','docs/ops/evidence/QUALITY-PRE94-RETROSPECTIVE-1/3m-formulas-magic/README.md','docs/ops/evidence/QUALITY-PRE94-RETROSPECTIVE-1/core-comment-audit/README.md',*[r['path'] for r in meta['files']],*[str(Path('docs/phase-governance/reviews')/n) for n in ['20261004-semantic-current-batch.json','20261016-historical-cards-d.json','20261017-r93-phase-governance-artifacts.json','20261017-r94-final-machine-artifacts.json']]};changed=set(subprocess.check_output(['git','diff','--name-only',base],text=True).splitlines());assert changed==allowed,(changed-allowed,allowed-changed)
extra=subprocess.check_output(['git','ls-files','--others','--exclude-standard'],text=True).splitlines();assert all(s.startswith(str(p.relative_to(root))+'/') or s=='docs/ops/tasks/GAME-MAGIC-NUMERIC-ASSIGNMENT-1.md' for s in extra),extra
f='docs/ops/audits/code-quality-file-ledger.md';a=subprocess.check_output(['git','show',base+':'+f]).decode();b=Path(f).read_text();mark='<!-- original-source-fenced:start -->';assert a.split(mark,1)[1]==b.split(mark,1)[1];old={line.split('|')[1].strip():line.split('|')[3].strip() for line in a.split(mark)[0].splitlines() if line.startswith('| `')};new={line.split('|')[1].strip():line.split('|')[3].strip() for line in b.split(mark)[0].splitlines() if line.startswith('| `')};delta={k:(v,new[k]) for k,v in old.items() if v!=new[k]};assert len(delta)==2 and all(v==('已验证','review') for v in delta.values()),delta
assert gzip.decompress((p/'3m-report.before.gz').read_bytes())==subprocess.check_output(['git','show',base+':docs/ops/evidence/QUALITY-PRE94-RETROSPECTIVE-1/3m-formulas-magic/README.md'])
assert not any(s.startswith(('scripts/coverage/','docs/testing/')) or 'retirement' in s.lower() for s in changed)
subprocess.run(['git','diff','--check'],check=True)
(p/'verification.json').write_text(json.dumps({'base':base,'owner':'Codex single agent','scope':'Exact declared source/read/raw/mutation/ledger/current-review delta verification; not whole-file/native gameplay/official unified acceptance','rawPairs':rawPairs,'controlPairs':pairs,'beforeSnapshotsMatchGit':True,'allReadShaAndBoundariesMatch':True,'twoSourceCommentOnlyProofsMatch':True,'ledgerStatusDelta':delta,'historicalLedgerFenceExact':True,'noBaselineRetirementOrTestingCatalogChanges':True,'allowedTrackedChanges':sorted(allowed),'newClosed':0},ensure_ascii=False,indent=2)+'\n');print('Scoped source/read/raw/control/ledger checks passed; only 2 historical closures revoked, no new closure.')
