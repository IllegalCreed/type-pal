# coding: utf-8
from pathlib import Path
import subprocess,json,gzip,hashlib,re
p=Path('docs/ops/evidence/QUALITY-PRE94-RETROSPECTIVE-1/core-comment-audit/formula-numeric-audit');base='8dabfd49976f818364d451635f155af08a41b9a9';sha=lambda b:hashlib.sha256(b).hexdigest();before=json.loads((p/'before.json').read_text());controls=json.loads((p/'controls.json').read_text());assert len(controls['controls'])==2 and controls['restored'] and controls['tempDirectoryRemoved']
for r in controls['controls']:assert sha(Path(r['source']).read_bytes())==r['sourceSha256'] and sha(Path(r['spec']).read_bytes())==r['runs']['current']['specSha256']
full=[r['path'] for r in before['files']]+['packages/game/src/core/rng.ts','packages/game/src/__tests__/glm-next-wave/H/harness.ts']
partial={
'reference/sdlpal/fight.c':[[130,390]],
'reference/sdlpal/util.c':[[165,280]],
'reference/sdlpal/common.h':[[131,162]],
'reference/sdlpal/util.h':[[69,88]],
'reference/sdlpal/global.c':[[1830,1868]],
'packages/game/src/core/battle/battle-system.ts':[[729,763]],
'packages/game/src/core/game-state.ts':[[1390,1455],[1571,1606],[1645,1678],[1875,1960]],
'packages/game/src/core/battle/battle-state.ts':[[785,916]],
'docs/phase1/game-mechanics.md':[[250,334],[855,890]],
'docs/phase1/engineering-notes.md':[[107,125]],
}
rows=[]
for path in full:
 b=Path(path).read_bytes();n=len(b.splitlines());row={'path':path,'sha256':sha(b),'lines':n,'ranges':[[1,n]],'scope':'Full implementation/test read; caller ranges below; not whole-file quality acceptance.'}
 if path in [r['path'] for r in before['files']]:
  name=sha(b)[:12]+'-'+Path(path).name+'.current.gz';(p/name).write_bytes(gzip.compress(b,mtime=0));row['snapshot']=name
 rows.append(row)
for path,ranges in partial.items():
 n=len(Path(path).read_bytes().splitlines());assert all(1<=a<=b<=n for a,b in ranges),(path,n,ranges)
(p/'read-boundaries.json').write_text(json.dumps({'base':base,'fullReads':rows,'partialReads':[{'path':path,'lines':len(Path(path).read_bytes().splitlines()),'sha256':sha(Path(path).read_bytes()),'ranges':ranges,'scope':'Only these primary/caller/type ranges; no whole-file acceptance.'} for path,ranges in partial.items()],'newClosed':0,'limits':['C bodies compiled in minimal typed context with selected lrand sample, not full SDLPal/original executable.','Real TS public caller and SeedableRng, no same-seed cross-PRNG claim; synthetic typed role/enemy/field, not original asset identity.','Numerical change remains unapproved; no formula execution change.','rng.ts adjacent rangeFloat alignment comment remains inaccurate about C endpoints; only read here, no new quality closure.','asShort is an internal reuse candidate; no new module/export until domains and ownership are fully checked.','Extreme WORD/SHORT domains, other FLOAT coefficient accuracy, field permutations and original visual/E2E remain pending.','Protected test title identity changes recorded, official identity/coverage/protected gates deferred to large task closeout.']},ensure_ascii=False,indent=2)+'\n')
# Preserve exact test rename mapping; no baseline relaxation.
r=controls['controls'][0];old=r['runs']['old']['cases'];new=r['runs']['current']['cases'];assert len(old)==len(new)==28;changes=[{'old':a['fullName'],'current':b['fullName'],'reason':'Correct actual test scope/input/oracle; same contract slot, stronger exact assertions or explicit TS-only extreme domain.'} for a,b in zip(old,new) if a['fullName']!=b['fullName']];assert len(changes)==4
(p/'test-title-mappings.json').write_text(json.dumps({'file':r['spec'],'base':base,'testCountBefore':28,'testCountCurrent':28,'mappings':changes,'baselineEdited':False,'officialProtectedIdentityGate':'not run; reconcile exact identities at large-task closeout without count/coverage weakening'},ensure_ascii=False,indent=2)+'\n')
# Live ledger only, historical fenced rows byte-preserved.
f=Path('docs/ops/audits/code-quality-file-ledger.md');live,history=f.read_text().split('<!-- original-source-fenced:start -->',1);old='当前已闭合核验：269；已读但待审：73；尚未逐文件核验：2,973；合计未闭合：3,046。';assert live.count(old)==1;live=live.replace(old,'当前已闭合核验：267；已读但待审：75；尚未逐文件核验：2,973；合计未闭合：3,048。');lines=live.splitlines();link='[公式数值/注释与测试返工](../evidence/QUALITY-PRE94-RETROSPECTIVE-1/core-comment-audit/formula-numeric-audit/README.md)'
reasons={
 'packages/game/src/core/battle/formulas.ts':('product','源全文/原C FLOAT与WORD中间赋值/真实caller；1:1和玩家等级坏注撤回','正常域TS160/C161直接counter另开GAME-MAGIC-NUMERIC-ASSIGNMENT-1；执行未改、旧关闭转review'),
 'packages/game/src/core/battle/magic-damage.ts':('product','源全文/真实公开GS hydrate→projection→createBattleState→applyMagicDamage与真实SeedableRng','随机半开与C端点分清、抗性倍率[0,5]及投影前提订正；去注释TS/JS不变，既有review保持'),
 'packages/game/src/core/battle/__tests__/formulas.test.ts':('test','全文；28例保持，生产除数1/合法倍率1.05、五灵独立oracle与非零毒抗','两枚各旧28绿→新27绿1指定AssertionError；C O0/O2矩阵/毒抗oracle；原全数值域信用撤回review'),
}
for path,(kind,ev,why) in reasons.items():
 ix=[i for i,l in enumerate(lines) if l.startswith('| `'+path+'` |')];assert len(ix)==1,path;lines[ix[0]]=f'| `{path}` | {kind} | review | {link}；{ev} | {why} |'
f.write_text('\n'.join(lines)+'\n\n<!-- original-source-fenced:start -->'+history)
f=Path('docs/ops/board.md');s=f.read_text();a='六组注释已修，余四组/算术风险/两UI差异继续';assert s.count(a)==1;s=s.replace(a,'七组注释已修，余三组/数值风险/两UI差异继续');anchor='| GAME-PLAYER-POISON-SLOT-COMPACTION-1 |';i=s.index('\n',s.index(anchor));s=s[:i+1]+'| GAME-MAGIC-NUMERIC-ASSIGNMENT-1 | [第一阶段法术数值赋值](tasks/GAME-MAGIC-NUMERIC-ASSIGNMENT-1.md) | draft | Codex / 已复现160/161，等裁决再改数值 | 原C O0/O2与真实TS/PRNG/caller；不改随机算法、次数或接口 |\n'+s[i+1:];f.write_text(s)
f=Path('docs/ops/evidence/QUALITY-PRE94-RETROSPECTIVE-1/3m-formulas-magic/README.md');(p/'3m-report.before.gz').write_bytes(gzip.compress(f.read_bytes(),mtime=0));f.write_text('''# CODE3m formulas / magic-damage 当前复审切片

2026-10-18 当前结论：3m保持partial，0整卡accept。旧README的“整数步骤与C一致/未发现直接缺陷/fixture窄as any不改变输入”不能作为当前整文件关闭依据；旧222绿只保留原执行范围。原文完整字节保存在当前数值返工片的3m-report.before.gz，不重写历史为已通过。

此前漏报的上次选靶、0x66裸武术、非伤害敌法术预掷由[三机制返工](../../QUALITY-BATTLE-MAGIC-PARITY-1/README.md)独立修复并先红后绿；它们不覆盖本轮新发现的FLOAT/WORD中间赋值差异。magic-damage/battle-opcodes仍review。

[当前公式数值/注释与测试返工](../core-comment-audit/formula-numeric-audit/README.md)全文核formulas、magic-damage和既有28例公式测试，核真实GS hydrate/projection/createBattleState/applyMagicDamage及SeedableRng。原C O0/O2正常域扣161，而TS真实caller扣160；[风险卡](../../../tasks/GAME-MAGIC-NUMERIC-ASSIGNMENT-1.md)等待用户裁决，未改执行，也没有用删除*10/10冒充修复。两旧关闭转review，无新closed。

当前只修错注和原测试判别力：玩家身法无等级项、必填抗性除数1/20、TS半开与C含端点、玩家抗性倍率[0,5]及投影前提；去注释TS/JS同字节。五灵五个独立值、非零毒抗、合法倍率1.05，删除2条被精确值蕴含断言，28例保持。两枚各旧28绿→新27绿1指定业务AssertionError；原C独立oracle可复算，完整原件随片保存。

恢复后定向2文件51绿、相邻6文件293绿与必要game typecheck；具体诊断/文档/lint见本片最终回执。全仓check、official coverage ratchet、protected fast留完整大任务收尾。越界WORD/SHORT、其它float系数/场效全排列、原盘与视觉/E2E、整文件/整卡仍未接受，不将小值手算或包绿扩成完整1:1。
''')
f=Path('docs/ops/evidence/QUALITY-PRE94-RETROSPECTIVE-1/core-comment-audit/README.md');f.write_text(f.read_text()+'''\n当前[公式数值/注释与测试返工](formula-numeric-audit/README.md)补第七组注释，仍余尺寸/快捷键/ColorFade及两UI与毒列表风险。正常法术TS160/C161另开draft风险卡并请求用户裁决；只修注释、加强既有28例，两旧关闭撤回review，数值实现冻结。\n''')
f=Path('docs/ops/tasks/QUALITY-PRE94-RETROSPECTIVE-1.md');f.write_text(f.read_text()+'''\n### 2026-10-18 CODE3m公式数值与测试当前结果\n\n有限白名单仅formulas.ts与magic-damage.ts事实注释、既有formulas.test.ts判别力；由父卡低风险注释/测试准入推进，产品数值不在本片build范围。全文核三文件与RNG/H工厂，真实hydrate/projection/createBattleState/applyMagicDamage及C FLOAT/WORD赋值；clang O0/O2正常域161，真实TS/SeedableRng(244049)扣160/HP8840，一次抽样状态一致。开GAME-MAGIC-NUMERIC-ASSIGNMENT-1只读draft卡请求裁决，未收到回复前不改公式，不以删除*10/10代替修复。\n\n第七组错注已修：玩家身法无level、抗性除数1/20、TS半开与C含端点、抗性倍率[0,5]及投影前提；parsedTS/去注释JS均同字节。原测试28例保持，五灵五个独立值与非零毒抗、合法1.05倍率；删除被精确值蕴含的finite/单调两断言。两反控各旧28绿→新27绿1指定AssertionError，源/测finally字节恢复；C原函数给相同矩阵/毒抗/中点oracle。51定向/293相邻与game typecheck零诊断，文档与lint以本片原件为准。\n\nformulas源/测两旧关闭转review，magic-damage原review保持；267closed/75review/2973pending（提交前机器复核），83卡50partial/33pending/0accept不变。尚余三组注释、毒列表/新数值/两UI风险、极端WORD与其它FLOAT系数等，不能因小值绿关闭。rng.ts的rangeFloat“对齐SDL”端点说明及asShort复用仅只读登记，未扩写实现/公开出口。4个测试标题映射保留，protected身份/coverage基准待大任务统一收尾。证据见[本片](../evidence/QUALITY-PRE94-RETROSPECTIVE-1/core-comment-audit/formula-numeric-audit/README.md)；不跑昂贵全仓check/official coverage/protected，不合main。无下一位Agent提示词，Codex继续pre94。\n''')
f=Path('docs/ops/tasks/GAME-MAGIC-NUMERIC-ASSIGNMENT-1.md');s=f.read_text().replace('## 目标与范围\n\n','## 目标\n\n核清第一阶段法术数值与SDLPal的已复现分叉，按裁决确定有限修复。\n\n## 范围\n\n').replace('## 直接证据与上下文锚点','## 直接证据');s=s.replace('## 验收条件','## 上下文锚点\n\nAGENTS/CLAUDE第一阶段保真与停线原则、docs/phase1/engineering-notes.md数值对拍边界、game-mechanics.md伤害公式与身法真值，以及父卡CODE3m本片原件。源码锚点为formulas.calcMagicDamage、magic-damage.applyMagicDamage、util.RandomFloat与fight.PAL_CalcMagicDamage；不重新引入兼容/upgrader。\n\n## 验收条件');f.write_text(s)
(p/'README.md').write_text('''# pre94 公式数值、事实注释与既有测试判别力返工

Status: recorded
Owner: Codex（单Agent，自身源码核证，不冒充第三方）
Date: 2026-10-18
Base: `8dabfd49976f818364d451635f155af08a41b9a9`
Branch: `codex/code-quality-3y`

## 身份、准入与实际读取

id: QUALITY-PRE94-RETROSPECTIVE-1 / formula-numeric-audit；schemaVersion:1；status:recorded。授权与交接见[父卡](../../../../tasks/QUALITY-PRE94-RETROSPECTIVE-1.md)，[数值风险卡](../../../../tasks/GAME-MAGIC-NUMERIC-ASSIGNMENT-1.md)仅draft只读、等待用户裁决，数值执行不在本片build。三选定源/测全文，实际RNG/H工厂全文及primary/caller分段由[read-boundaries](read-boundaries.json)给出；未把grep命中或相邻绿算全文验收。旧3m原README完整gzip保留，当前正文撤回过度信用。

## Primary、caller与新停止线

原C util.RandomFloat、fight.PAL_CalcBaseDamage/PAL_CalcMagicDamage原函数体按真实边界提取，common.h的WORD/SHORT/FLOAT宽度以static_assert约束，最小typed globals和指定lrand样本。clang O0/O2均-Wall/-Wextra/-Werror零诊断、输出相同。真实TS公开GS创建→hydrate→projection→createBattleState→applyMagicDamage，使用实际SeedableRng(244049)并核下一state，仅typed角色/敌人/战场工厂，未stub RNG/伤害。

灵力240、有效防御30、基础伤50、无元素、HP9000：实际TS扣160/余8840，C原函数使用邻近归一化样本或四分之一样本扣161；TS叶倍率1.025也为160。C float32写回WORD再整数除10与TS连续double最后截断不能宣称等价。C INT_MAX端点RandomFloat=11，TS生产倍率[1,1.1)；两边不同PRNG，不声称同seed序列或完整原版EXE/原盘实跑。删除*10/10在本反例仍得到245，不是修复。[numeric-counter](numeric-counter.json)保留命令/完整raw/程序/SHA/临时清理；这是可感知差异证据，不是修复绿灯。

## 三文件问题与有限改动

- formulas.ts：撤销1:1大包票、玩家等级项和抗性默认10；分清TS/C端点与赋值、SHORT越界域；只修注释，未删算式。
- magic-damage.ts：原注“抗性倍率永>=5”错误，在公开投影[0,100]前提下实际[0,5]；旧行号改函数锚，RNG说明分清TS与C。敌伤害JSDoc原错贴rollAutoDefend，归回实际函数；AoE先掷后判HP及结果HP字段说明纠正。执行与类型结构均不变，见[去注释双重证明](emit-identity.json)。
- formulas.test.ts：原“五灵”仅测1/2/5且多零，换成同生产除数1与五个独立值；毒抗全零恒辨不出漏读，改非零毒抗5/元素抗8/场效10，必须给80；1.1端点换next=0.5可达1.05/52。删除finite和单调两条被精确值蕴含断言，28例保持。65535→-2仅当前TS截取合同，不承诺C越界浮点转换。

独立手算与原C O0/O2给五灵[160,128,96,64,32]、毒抗80与中点52；[matrix](mapping-oracle.json)、[poison](poison-oracle.json)附完整程序/raw。用例不从被测TS函数生成期望。两反控（水/火抗性互换、漏毒抗）各完整未过滤旧28绿→新27绿1指定业务AssertionError，0skip/pending/unhandled；source/spec/mutant/全量nativeJSON及finally恢复SHA见[controls](controls.json)。未以现有错误伤害160为期望加产品回归，数值修复先红留获准后。

## 门与证据限制

完整未裁剪stdout/stderr gzip与独立命令回执保留，最终[gates](gates.json)汇总实际诊断。恢复后51直接、293相邻与game typecheck；只有本次三源/测审查信用，未读相邻不关闭。文档check125与所有消费者、lint-zero和ledger以最终回执实际结果为准。全仓check、官方coverage ratchet、protected fast按用户成本规则留大任务收尾，未运行、不授统一门/合并信用。4个标题变化映射另存[test identities](test-title-mappings.json)，未改baseline或退役账。

两个原closed转review，magic-damage原review保持；267closed/75review/2973pending，0新增closed，83卡50partial/33pending/0accept。三组其它坏注、两UI差异、毒列表与本次数值风险继续；其它FLOAT系数/WORD极端域、field permutations、原盘/视觉/E2E均pending。rng.ts另有rangeFloat“对齐SDL”的端点错注，只读登记；asShort重复是复用候选，先核域和owner，未借提取引新公共接口。

## 交接与下一步

同一3y分支有限提交推送，fetch确认0behind后保留待审；未合main。数值裁决未到时继续尺寸/快捷键/ColorFade的独立核验；获准后另卡先红后修、行为另提交。初次本地编辑脚本因零抗性注释命中两处而中止，测试文件尚未写入；随后仅执行测试段并完成本回执验证，不当作产品失败或反控证据。
''')
for name,path in [('edit-comments.py.gz','/tmp/type-pal-formula-edit.py'),('edit-tests.py.gz','/tmp/type-pal-formula-edit-test.py'),('capture.py.gz','/tmp/type-pal-formula-capture.py'),('numeric-counter-producer.py.gz','/tmp/type-pal-formula-counter.py'),('mapping-oracle-producer.py.gz','/tmp/type-pal-formula-oracle.py'),('poison-oracle-producer.py.gz','/tmp/type-pal-formula-poison-oracle.py'),('controls-producer.py.gz','/tmp/type-pal-formula-controls.py'),('emit-proof.cjs.gz','/tmp/type-pal-formula-emit.cjs')]:
 (p/name).write_bytes(gzip.compress(Path(path).read_bytes(),mtime=0))
print('Bounded current docs/ledger/status updates prepared; no historical source table or baseline changed.')
