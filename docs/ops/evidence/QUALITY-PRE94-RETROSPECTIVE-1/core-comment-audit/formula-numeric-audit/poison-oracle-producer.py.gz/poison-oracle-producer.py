from pathlib import Path
import json,gzip,hashlib,tempfile,shutil,subprocess,datetime
out=Path('docs/ops/evidence/QUALITY-PRE94-RETROSPECTIVE-1/core-comment-audit/formula-numeric-audit');original=gzip.decompress((out/'native-counter.c.gz').read_bytes()).decode();prefix=original[:original.index('int main(void)')]
main='''int main(void) {
 Magic magics[1]={{50,6}};
 Field fields[1]={{{10,10,10,10,10}}};
 WORD resistance[5]={8,8,8,8,8};
 gpGlobals->g.lprgMagic=magics; gpGlobals->g.lprgBattleField=fields;
 sample=0; calls=0;
 SHORT damage=PAL_CalcMagicDamage(100,50,resistance,5,1,1);
 printf("poison %d %d\\n",damage,calls);
 return 0;
}
''';source=(prefix+main).encode();(out/'poison-oracle.c.gz').write_bytes(gzip.compress(source,mtime=0));tmp=Path(tempfile.mkdtemp(prefix='type-pal-formula-map-'));rows=[]
def run(label,cmd):
 started=datetime.datetime.now(datetime.timezone.utc).isoformat();p=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);raw=p.stdout;(out/(label+'.raw.gz')).write_bytes(gzip.compress(raw,mtime=0));rows.append({'label':label,'command':[str(x) for x in cmd],'cwd':str(Path.cwd()),'startedAt':started,'completedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit':p.returncode,'signal':-p.returncode if p.returncode<0 else None,'spawnError':None,'raw':label+'.raw.gz','rawBytes':len(raw),'rawSha256':hashlib.sha256(raw).hexdigest(),'fullUncutMergedStdoutStderr':True});assert p.returncode==0,raw.decode();return raw
try:
 (tmp/'map.c').write_bytes(source)
 for opt in ['O0','O2']:
  exe=tmp/opt;run('poison-compile-'+opt,['clang','-std=c11','-'+opt,'-Wall','-Wextra','-Werror','-ffp-contract=off',str(tmp/'map.c'),'-o',str(exe)]);raw=run('poison-native-'+opt,[str(exe)]);assert raw==b'poison 80 1\n'
finally:
 shutil.rmtree(tmp);(out/'poison-oracle.json').write_text(json.dumps({'scope':'Same extracted C functions and typed minimal context as numeric-counter.json; one independent hand/native oracle for the existing poison-resistance leaf case. Not full gameplay.','sourceSha256':hashlib.sha256(source).hexdigest(),'runs':rows,'tempDirectory':str(tmp),'tempRemoved':not tmp.exists()},indent=2)+'\n')
print('native O0/O2 poison80 with distinct elemental resistance/field; zero compiler diagnostics')
