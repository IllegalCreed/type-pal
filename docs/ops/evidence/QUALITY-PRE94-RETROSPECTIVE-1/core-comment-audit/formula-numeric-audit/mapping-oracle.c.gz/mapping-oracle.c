#include <stdint.h>
#include <stdio.h>
#include <limits.h>
typedef uint16_t WORD;
typedef int16_t SHORT;
typedef float FLOAT;
#define NUM_MAGIC_ELEMENTAL 5
_Static_assert(sizeof(WORD)==2 && sizeof(SHORT)==2 && sizeof(FLOAT)==4, "SDL numeric widths");
static int sample;
static int calls;
static int lrand(void) { calls++; return sample; }
float
RandomFloat(
   float from,
   float to
)
/*++
  Purpose:

    This function returns a random floating-point number between (and including) the starting
    and ending values passed by parameters from and to.

  Parameters:

    from - the starting value.

    to - the ending value.

  Return value:

    The generated random number.

--*/
{
   if (to <= from)
      return from;

   return from + (float)lrand() / (INT_MAX / (to - from));
}
typedef struct { WORD wBaseDamage; WORD wElemental; } Magic;
typedef struct { int16_t rgsMagicEffect[5]; } Field;
typedef struct { struct { WORD wMagicNumber; } magic; } Object;
typedef struct { struct { Object rgObject[2]; Magic *lprgMagic; Field *lprgBattleField; } g; WORD wNumBattleField; } Globals;
static Globals storage;
static Globals *gpGlobals=&storage;
static SHORT
PAL_CalcBaseDamage(
   WORD        wAttackStrength,
   WORD        wDefense
)
/*++
  Purpose:

    Calculate the base damage value of attacking.

  Parameters:

    [IN]  wAttackStrength - attack strength of attacker.

    [IN]  wDefense - defense value of inflictor.

  Return value:

    The base damage value of the attacking.

--*/
{
   SHORT            sDamage;

   //
   // Formula courtesy of palxex and shenyanduxing
   //
   if (wAttackStrength > wDefense)
   {
      sDamage = (SHORT)(wAttackStrength * 2 - wDefense * 1.6 + 0.5);
   }
   else if (wAttackStrength > wDefense * 0.6)
   {
      sDamage = (SHORT)(wAttackStrength - wDefense * 0.6 + 0.5);
   }
   else
   {
      sDamage = 0;
   }

   return sDamage;
}
static SHORT
PAL_CalcMagicDamage(
   WORD             wMagicStrength,
   WORD             wDefense,
   const WORD       rgwElementalResistance[NUM_MAGIC_ELEMENTAL],
   WORD             wPoisonResistance,
   WORD             wResistanceMultiplier,
   WORD             wMagicID
)
/*++
   Purpose:

     Calculate the damage of magic.

   Parameters:

     [IN]  wMagicStrength - magic strength of attacker.

     [IN]  wDefense - defense value of victim.

     [IN]  rgwElementalResistance - victim's resistance to the elemental magics.

     [IN]  wPoisonResistance - victim's resistance to poison.

     [IN]  wResistanceMultiplier - multiplier of resistance value.

     [IN]  wMagicID - object ID of the magic.

   Return value:

     The damage value of the magic attack.

--*/
{
   SHORT           sDamage;
   WORD            wElem;

   wMagicID = gpGlobals->g.rgObject[wMagicID].magic.wMagicNumber;

   //
   // Formula courtesy of palxex and shenyanduxing
   //
   wMagicStrength *= RandomFloat(10, 11);
   wMagicStrength /= 10;

   sDamage = PAL_CalcBaseDamage(wMagicStrength, wDefense);
   sDamage /= 4;

   sDamage += gpGlobals->g.lprgMagic[wMagicID].wBaseDamage;

   if (gpGlobals->g.lprgMagic[wMagicID].wElemental != 0)
   {
      wElem = gpGlobals->g.lprgMagic[wMagicID].wElemental;

      if (wElem > NUM_MAGIC_ELEMENTAL)
      {
         sDamage *= 10 - ((FLOAT)wPoisonResistance / wResistanceMultiplier);
      }
      else if (wElem == 0)
      {
         sDamage *= 5;
      }
      else
      {
         sDamage *= 10 - ((FLOAT)rgwElementalResistance[wElem - 1] / wResistanceMultiplier);
      }

      sDamage /= 5;

      if (wElem <= NUM_MAGIC_ELEMENTAL)
      {
         sDamage *= 10 + gpGlobals->g.lprgBattleField[gpGlobals->wNumBattleField].rgsMagicEffect[wElem - 1];
         sDamage /= 10;
      }
   }

   return sDamage;
}
int main(void) {
 Magic magics[1]={{50,1}};
 Field fields[1]={{{0,0,0,0,0}}};
 WORD resistance[5]={0,2,4,6,8};
 gpGlobals->g.lprgMagic=magics; gpGlobals->g.lprgBattleField=fields;
 for (int i=1;i<=5;i++) {
   sample=0; calls=0; magics[0].wElemental=(WORD)i;
   SHORT damage=PAL_CalcMagicDamage(100,50,resistance,0,1,1);
   printf("%d %d %d\n",i,damage,calls);
 }
 magics[0].wElemental=0;magics[0].wBaseDamage=0;sample=INT_MAX/2;
 printf("midpoint %d\n",PAL_CalcMagicDamage(100,0,resistance,0,1,1));
 return 0;
}
