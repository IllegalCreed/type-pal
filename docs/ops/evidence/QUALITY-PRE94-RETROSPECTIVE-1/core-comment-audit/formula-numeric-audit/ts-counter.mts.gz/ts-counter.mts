import { calcMagicDamage } from "/Users/zhangxu/.codex/worktrees/quality-3y-closeout/type-pal/packages/game/src/core/battle/formulas.ts"
import { applyMagicDamage } from "/Users/zhangxu/.codex/worktrees/quality-3y-closeout/type-pal/packages/game/src/core/battle/magic-damage.ts"
import { createSeedableRng } from "/Users/zhangxu/.codex/worktrees/quality-3y-closeout/type-pal/packages/game/src/core/rng.ts"
import { createInitialGameState, hydratePlayerRolesRuntime, projectRuntimeToBattleRoles } from "/Users/zhangxu/.codex/worktrees/quality-3y-closeout/type-pal/packages/game/src/core/game-state.ts"
import { createBattleState } from "/Users/zhangxu/.codex/worktrees/quality-3y-closeout/type-pal/packages/game/src/core/battle/battle-state.ts"
import { makeHRole, makeHEnemy, makeHField } from "/Users/zhangxu/.codex/worktrees/quality-3y-closeout/type-pal/packages/game/src/__tests__/glm-next-wave/H/harness.ts"
const zero={wind:0,thunder:0,water:0,fire:0,earth:0};
const seed=244049;
const sampleRng=createSeedableRng(seed), r=sampleRng.next(), factor=1+r*0.1;
const rng=createSeedableRng(seed);
const gs=createInitialGameState({x:0,y:0,facing:'down'});gs.partyMembers=[0];
const staticRoles={roles:[makeHRole(0,{magicStrength:240})]};
hydratePlayerRolesRuntime(gs.PlayerRolesRuntime,staticRoles);
const roles=projectRuntimeToBattleRoles(gs.PlayerRolesRuntime,staticRoles,gs.rgEquipmentEffect);
const state=createBattleState({gs,playerRoles:roles,enemies:[makeHEnemy({level:1,defense:2})],field:makeHField(),isBoss:false,rng});
const result=applyMagicDamage({state,target:0,magStr:roles.roles[0]!.magicStrength,magicData:{baseDamage:50,elemental:0},minDamage:1});
const leaf=calcMagicDamage({magStr:240,def:30,elemRes:zero,poisonRes:0,resistMult:1,magicData:{baseDamage:50,elemental:0},fieldEffect:zero,rngFactor:factor});
const quarter=calcMagicDamage({magStr:240,def:30,elemRes:zero,poisonRes:0,resistMult:1,magicData:{baseDamage:50,elemental:0},fieldEffect:zero,rngFactor:1.025});
console.log(JSON.stringify({seed,r,factor,leaf,quarter,result,oneDrawState:rng.getState(),expectedOneDrawState:sampleRng.getState(),sameOneDraw:rng.getState()===sampleRng.getState(),sourceExpressionMag:Math.trunc(240*factor*10/10),simplifiedMag:Math.trunc(240*factor),scope:'Actual public GS hydrate/projection/createBattleState/applyMagicDamage and seeded RNG; not a full game/asset run.'}));
