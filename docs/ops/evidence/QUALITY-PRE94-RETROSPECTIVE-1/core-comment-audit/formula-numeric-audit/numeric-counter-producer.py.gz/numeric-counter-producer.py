# coding: utf-8
from pathlib import Path
import subprocess,json,gzip,hashlib,tempfile,shutil,datetime,re
root=Path.cwd();out=root/'docs/ops/evidence/QUALITY-PRE94-RETROSPECTIVE-1/core-comment-audit/formula-numeric-audit';out.mkdir();sha=lambda b:hashlib.sha256(b).hexdigest();tmp=Path(tempfile.mkdtemp(prefix='type-pal-formula-numeric-'));runs=[];bounds=[]
def extract(path,name):
 raw=(root/path).read_bytes();text=raw.decode();m=re.search(r'(?m)^'+re.escape(name)+r'\(',text);assert m,name;start=text.rfind('\n',0,text.rfind('\n',0,m.start()))+1;brace=text.index('{',m.end());depth=0;end=None
 for i in range(brace,len(text)):
  if text[i]=='{':depth+=1
  if text[i]=='}':
   depth-=1
   if depth==0:end=i+1;break
 assert end;body=text[start:end]+'\n';bounds.append({'path':path,'function':name,'sha256':sha(raw),'ranges':[[text[:start].count('\n')+1,text[:end].count('\n')+1]],'bodySha256':sha(body.encode())});return body
random=extract('reference/sdlpal/util.c','RandomFloat');base=extract('reference/sdlpal/fight.c','PAL_CalcBaseDamage');magic=extract('reference/sdlpal/fight.c','PAL_CalcMagicDamage')
prefix='''#include <stdint.h>
#include <stdio.h>
#include <limits.h>
typedef uint16_t WORD;
typedef int16_t SHORT;
typedef float FLOAT;
#define NUM_MAGIC_ELEMENTAL 5
_Static_assert(sizeof(WORD)==2 && sizeof(SHORT)==2 && sizeof(FLOAT)==4, "SDL numeric widths");
static int sample;
static int calls;
static int lrand(void) { calls++; return sample; }
'''
context='''typedef struct { WORD wBaseDamage; WORD wElemental; } Magic;
typedef struct { int16_t rgsMagicEffect[5]; } Field;
typedef struct { struct { WORD wMagicNumber; } magic; } Object;
typedef struct { struct { Object rgObject[2]; Magic *lprgMagic; Field *lprgBattleField; } g; WORD wNumBattleField; } Globals;
static Globals storage;
static Globals *gpGlobals=&storage;
'''
main='''int main(void) {
 Magic magics[1]={{0,0}};
 Field fields[1]={{{0,0,0,0,0}}};
 WORD resistance[5]={0,0,0,0,0};
 gpGlobals->g.lprgMagic=magics; gpGlobals->g.lprgBattleField=fields;
 const int samples[3]={0,536870912,536870765};
 const WORD strength[3]={100,240,240};
 const WORD defense[3]={50,30,30};
 for (int i=0;i<3;i++) {
   sample=samples[i]; calls=0; magics[0].wBaseDamage=50;
   const SHORT damage=PAL_CalcMagicDamage(strength[i],defense[i],resistance,0,1,1);
   const int count=calls;
   const float raw=RandomFloat(10,11);
   printf("{\\"case\\":%d,\\"sample\\":%d,\\"rawFloat\\":%.9g,\\"magStr\\":%u,\\"def\\":%u,\\"damage\\":%d,\\"drawCalls\\":%d}\\n",i,samples[i],raw,strength[i],defense[i],damage,count);
 }
 sample=INT_MAX;
 printf("{\\"endpointSample\\":%d,\\"randomFloat\\":%.9g}\\n",INT_MAX,RandomFloat(10,11));
 return 0;
}
'''
c=prefix+random+context+base+magic+main;(tmp/'counter.c').write_text(c);(out/'native-counter.c.gz').write_bytes(gzip.compress(c.encode(),mtime=0))
def run(label,cmd,cwd=root):
 started=datetime.datetime.now(datetime.timezone.utc).isoformat();p=subprocess.run(cmd,cwd=cwd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);raw=p.stdout;(out/(label+'.raw.gz')).write_bytes(gzip.compress(raw,mtime=0));row={'label':label,'command':[str(x) for x in cmd],'cwd':str(cwd),'startedAt':started,'completedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit':p.returncode,'signal':-p.returncode if p.returncode<0 else None,'spawnError':None,'raw':label+'.raw.gz','rawBytes':len(raw),'rawSha256':sha(raw),'fullUncutMergedStdoutStderr':True};runs.append(row);assert p.returncode==0,(label,raw.decode());return raw
try:
 native=[]
 for opt in ['O0','O2']:
  binary=tmp/('counter-'+opt);run('compile-'+opt,['clang','-std=c11','-'+opt,'-Wall','-Wextra','-Werror','-ffp-contract=off',str(tmp/'counter.c'),'-o',str(binary)]);raw=run('native-'+opt,[str(binary)]);native.append([json.loads(x) for x in raw.decode().splitlines()])
 assert native[0]==native[1];assert [x['damage'] for x in native[0][0:3]]==[80,161,161] and native[0][-1]['randomFloat']==11
 imports={
 'formulas':str(root/'packages/game/src/core/battle/formulas.ts'),
 'magic':str(root/'packages/game/src/core/battle/magic-damage.ts'),
 'rng':str(root/'packages/game/src/core/rng.ts'),
 'gs':str(root/'packages/game/src/core/game-state.ts'),
 'state':str(root/'packages/game/src/core/battle/battle-state.ts'),
 'fixtures':str(root/'packages/game/src/__tests__/glm-next-wave/H/harness.ts'),
 }
 ts='\n'.join(['import { calcMagicDamage } from '+json.dumps(imports['formulas']), 'import { applyMagicDamage } from '+json.dumps(imports['magic']), 'import { createSeedableRng } from '+json.dumps(imports['rng']), 'import { createInitialGameState, hydratePlayerRolesRuntime, projectRuntimeToBattleRoles } from '+json.dumps(imports['gs']), 'import { createBattleState } from '+json.dumps(imports['state']), 'import { makeHRole, makeHEnemy, makeHField } from '+json.dumps(imports['fixtures'])])+'''
const zero={wind:0,thunder:0,water:0,fire:0,earth:0};
const seed=244049;
const sampleRng=createSeedableRng(seed), r=sampleRng.next(), factor=1+r*0.1;
const rng=createSeedableRng(seed);
const gs=createInitialGameState({x:0,y:0,facing:'down'});gs.partyMembers=[0];
const staticRoles={roles:[makeHRole(0,{magicStrength:240})]};
hydratePlayerRolesRuntime(gs.PlayerRolesRuntime,staticRoles);
const roles=projectRuntimeToBattleRoles(gs.PlayerRolesRuntime,staticRoles,gs.rgEquipmentEffect);
const state=createBattleState({gs,playerRoles:roles,enemies:[makeHEnemy({level:1,defense:2})],field:makeHField(),isBoss:false,rng});
const result=applyMagicDamage({state,target:0,magStr:roles.roles[0]!.magicStrength,magicData:{baseDamage:50,elemental:0},minDamage:1});
const leaf=calcMagicDamage({magStr:240,def:30,elemRes:zero,poisonRes:0,resistMult:1,magicData:{baseDamage:50,elemental:0},fieldEffect:zero,rngFactor:factor});
const quarter=calcMagicDamage({magStr:240,def:30,elemRes:zero,poisonRes:0,resistMult:1,magicData:{baseDamage:50,elemental:0},fieldEffect:zero,rngFactor:1.025});
console.log(JSON.stringify({seed,r,factor,leaf,quarter,result,oneDrawState:rng.getState(),expectedOneDrawState:sampleRng.getState(),sameOneDraw:rng.getState()===sampleRng.getState(),sourceExpressionMag:Math.trunc(240*factor*10/10),simplifiedMag:Math.trunc(240*factor),scope:'Actual public GS hydrate/projection/createBattleState/applyMagicDamage and seeded RNG; not a full game/asset run.'}));
''';(tmp/'counter.mts').write_text(ts);(out/'ts-counter.mts.gz').write_bytes(gzip.compress(ts.encode(),mtime=0));raw=run('typescript',['pnpm','exec','tsx',str(tmp/'counter.mts')]);data=json.loads(raw.decode().splitlines()[-1]);assert data['leaf']==data['quarter']==160 and data['result'][0]['damage']==160 and data['result'][0]['hpAfter']==8840 and data['sameOneDraw'];print(json.dumps({'native':native[0],'typescript':data},ensure_ascii=False),flush=True)
finally:
 shutil.rmtree(tmp);d={'base':'8dabfd49976f818364d451635f155af08a41b9a9','owner':'Codex single agent','bounds':bounds,'nativeSourceSha256':sha(c.encode()),'runs':runs,'tempDirectory':str(tmp),'tempRemoved':not tmp.exists(),'scope':'Original C bodies with minimal typed globals and one normalized lrand sample stub, actual public TS caller and real SeedableRng. Not full SDLPal/pal.exe/native asset parity, and no same-seed cross-RNG claim.'};(out/'numeric-counter.json').write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
