import subprocess,json,sys
commands=[['node','scripts/docs/check.mjs'],['node','scripts/docs/check-document-model.mjs'],['node','scripts/docs/check-testing.mjs'],['node','scripts/docs/check-phase-lore-governance.mjs'],['node','scripts/docs/check-content-review.mjs','--strict']]
for command in commands:
 print(json.dumps({'command':command,'scope':'Final consumer replay; unchanged docs-tool125 test source already passed earlier this batch'}),flush=True)
 p=subprocess.run(command)
 if p.returncode:sys.exit(p.returncode)
