# coding: utf-8
from pathlib import Path

def once(s,a,b):
 assert s.count(a)==1,(a,s.count(a));return s.replace(a,b)
changes={}
f=Path('packages/game/src/tools/minimap.ts');s=f.read_text();s=once(s,'//   底图复用 renderMapThumbnail(64×128 地图 → 96×96 缩略图,见 bootstrap);叠加主角/NPC/宝物','//   底图经 bootstrap renderSceneThumbnail 取640×640图(标准64×128地图),另叠加主角/NPC/宝物')
s=once(s,'//   bufW=(64+1)*32=2080,camera=(-16,-16),降采样到 BASE_PX 宽。BASE_PX 用较高分辨率\n//   (高于 dev 96)→ 场景 tab 近 1:1 不糊、widget 放大裁剪也清晰。','//   bufW=(64+1)*32=2080,camera=(-16,-16),输出 BASE_PX 宽;开发picker另用96px。\n//   场景tab/widget的显示尺寸、DPR与视野裁剪共同决定最终缩放,不保证每档都是降采样。')
s=once(s,'export const BASE_PX = 640 // 底图渲染分辨率(px;= worldToThumb 值域 + bootstrap getMapThumbnail outW)。高→各缩放档皆降采样=清晰','export const BASE_PX = 640 // 底图坐标基准(px),与bootstrap getMapThumbnail的输出宽度一致')
s=once(s,'/** 世界像素 → 底图像素(0..BASE_PX)。 */','/** 世界像素按缩略图相机偏移/比例映射;出界输入不钳到图内。 */')
s=once(s,' * item 优先(先命中即返回)。仅线性流(不跟 goto/call),~95% 覆盖。',' * item 优先(先命中即返回)。仅线性扫最多400条,不跟 goto/call;是工具标记启发式,没有覆盖率保证。')
s=once(s,'/** present.ts:456 绘制可见性:sState 隐藏(0/负)或 sVanishTime>0 → 不在图上。 */','/** 本图可见性:sState为0/负或sVanishTime>0时过滤;缺省sState按可见处理。 */')
s=once(s,'  //   npcs 数组时引用变,正好在新 npcs 就绪时重算。scene 内 npc 移动不换数组引用 → kinds(按 triggerLabel)不变,不必重算。','  //   npcs数组时引用变即重算;同数组内移动不重算。该缓存也不监听原地triggerLabel/脚本表变化,不是实时脚本解释器。')
s=once(s,'      // backing 按 DPR 放大(retina 清晰;640 底图够用),CSS 仍 sizePx;drawMinimap 用 canvas.width=backing。','      // backing按DPR(上限2)配置,CSS仍sizePx;drawMinimap按backing绘制,不保证裁剪区只缩不放。');changes[f]=s
f=Path('packages/game/src/tools/tools-panel.ts');s=f.read_text();s=once(s,'  /** 小地图底图:mapNum → 96×96 PNG dataURL(复用 bootstrap renderMapThumbnail 缓存);省略 → 无底图。 */','  /** 小地图底图:标准地图640×640 PNG dataURL,经bootstrap renderSceneThumbnail缓存;省略则无底图。 */')
s=once(s,' * 战斗态轻量签名:进/出战斗(mode)、每回合 HP/MP/状态/中毒/敌死亡 变化即变。',' * 战斗态轻量签名:只拼接下方选定字段,不是完整状态checksum。\n * HP/MP读持久runtime、毒读数量;同数量换毒或其它未拼接字段不保证立即刷新。');changes[f]=s
f=Path('packages/game/src/shell/bootstrap.ts');s=f.read_text();s=once(s,'// 这里显式 cast —— dev/fixtures/battle-fixtures.json 的 schema 由 BattleFixture 定义,运行时合法。','// 这里仅提供静态类型视图,cast本身不校验JSON的运行时合法性。')
s=once(s,'// 同模式 cast —— scene-jumps.json schema 由 SceneJump 定义。','// scene-jumps使用同一静态视图方式,不在此增加运行时校验。')
s=once(s,' *   playSplashFallback FBP chunk 3/4 + 仙鹤 + 标题 RLE + palette 渐变 200 行 port)',' *   playSplashFallback FBP chunk 0x26/0x27 + 仙鹤 + 标题 RLE + palette渐变)')
s=once(s,'  // 正常启动:OpeningMenu 选 new-game → playOpeningAvi() stub → startNewGameFromPrimary 装载完整','  // 正常启动:OpeningMenu选new-game → playOpeningAvi(Win95播3.mp4,DOS直接返回) → 装载完整')
a=s.index('  // M3.5 T17:per-scene lazy fetcher');z=s.index("  const BASE = '/extracted'",a);s=s[:a]+'''  // 按scene懒载scene/events/tilemap,并行补该场景的tileset RLE blob与缺失sprite RLE blob。
  // tileImagesBySceneId随SceneAssetsCache淘汰;NPC帧存closure map,由presentCtx共享。
  // SceneAssets.palette当前复用启动palette,不是按scene另取;屏幕色表由palette/fade脚本管理。
'''+s[z:]
s=once(s,'  //   fetchSceneTileImages 复刻同模式,写进 by-sceneId map(cache,首屏 / 已 fetch 跳过)。','  //   fetchSceneTileImages写进by-sceneId map(首屏/已fetch跳过)。') if '  //   fetchSceneTileImages 复刻同模式,写进 by-sceneId map(cache,首屏 / 已 fetch 跳过)。' in s else s
s=once(s,'   * 5. palette / eventCommands:首屏保留(留 M5)','   * 5. 此处同步scene-system的commands/labelMap;屏幕palette不覆盖,basePalette由loadSceneCommon更新')
s=once(s,'  // ── dev 场景缩略图(setupDevPanel.renderSceneThumbnail)─────────────────────────\n  // 把整张 map tilemap(≤64×128 → ~2080×2080 px)渲染到离屏大 framebuffer,再降采样成 96px PNG dataURL。\n  // **按 mapNum 缓存**(同 map 多场景共享缩略图);解码的 tile 位图渲染完即弃(只留 dataURL),不写\n  // gameplay 的 tileImagesBySceneId / sceneAssetsCache(LRU 16),避免污染正在玩的场景缓存。\n  // 并发限 2 + 同 map dedup —— 防 IntersectionObserver 一次滚入多卡片时 N×数百 tile PNG 同时 fetch。','  // ── dev picker与生产小地图共用的离屏缩略图──────────────────────────────────\n  // 标准64×128地图先画2080×2080 framebuffer;picker默认输出宽96,小地图caller传640。\n  // 按mapNum/outW缓存和dedup,并发上限2;本地解码tileset blob,成功后只留dataURL。\n  // 不写gameplay的tileImagesBySceneId/sceneAssetsCache,不在此接入seam repair。')
s=once(s,'    // 大 canvas(putImageData 全分辨率)→ 降采样小 canvas → dataURL。用首屏 palette(与 dev jump 渲染同源)。','    // full canvas→按outW等比缩放→dataURL。显式override优先,否则用启动palette,不读取实时gs.palette。')
s=once(s,'    outW: number = THUMB_OUT_W, // dev picker 用默认 96;小地图传 256(高清)','    outW: number = THUMB_OUT_W, // dev picker默认96;生产小地图caller传640')
s=once(s,'    const cacheKey = `${map}_${outW}` // 不同分辨率分开缓存(dev 96 / 小地图 256 不串)','    const cacheKey = `${map}_${outW}` // 同地图按输出宽度分开缓存(picker96/小地图640)')
s=once(s,'    // 小地图底图:复用 renderSceneThumbnail,出 640px 高清(= minimap BASE_PX;各缩放档皆降采样=清晰)。\n    //   "地图发黑" 真因是 getCurrentMapNum stale 停在 map 0 梦境(已修),非 palette。','    // 小地图输出宽640,与minimap BASE_PX一致;标准地图高也为640。\n    // 显示缩放由minimap的DPR/裁剪决定;色表与seam边界仍以CODE57为准。')
s=once(s,'  setupSpeedrunHotkeys() // 速通计时器快捷键(F10 重置 / F8 切覆盖层),仅启用时生效','  setupSpeedrunHotkeys() // 启用计时器后:F8暂停/恢复,F4重置本局,F2切覆盖层')
s=once(s,'  //   sprite(非预载,按需 fetch sprite/{id}.json + 帧 PNG)→ 跑 400 帧 cutscene。modal,suspendRaf。','  //   sprite(非预载,按需加载sprite/{id}.rle blob)→跑400帧cutscene。modal,suspendRaf。')
s=once(s,'   * **未做(非视觉/已记)**:音乐(M6 音频系统)、ShowFBP(76) 的 MGO effectSprite 0x27b 叠加(Phase 留)、\n   *   WaitForKey(原版等键,这里连续观看用短延时)。','   * 下方已接setMus配乐、effectSprite 0x27b叠加与waitForKey;这不代替完整原版演出/视觉验收。')
s=once(s,'  // ts 端:T18/T19 trademark + splash + 3.avi 留后续 task;T17 只接 OpeningMenu 本体 + AVI hook stub。','  // 当前启动序列见showTrademarkAndSplash;new-game的Win95路径由playOpeningAvi实播3.mp4。')
changes[f]=s
for f,s in changes.items():f.write_text(s)
print('3 source files: comments only; no schema/save/asset/interface or UI behavior edits')
