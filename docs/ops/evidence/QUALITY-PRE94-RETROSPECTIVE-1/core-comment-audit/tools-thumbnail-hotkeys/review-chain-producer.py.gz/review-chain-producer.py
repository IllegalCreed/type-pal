# -*- coding: utf-8 -*-
from pathlib import Path
import json,hashlib,subprocess
base='5d55e2c49a1eb517d4bd51b2814df840dd49052a';prefix=Path('docs/phase-governance/reviews')
targets={
 '20261004-semantic-current-batch.json':['docs/ops/board.md'],
 '20261016-historical-cards-d.json':['docs/ops/audits/code-quality-file-ledger.md'],
}
def update(fn,paths):
 p=prefix/fn;lines=p.read_text().splitlines()
 for target in paths:
  pi=next(i for i,l in enumerate(lines) if l==f'      "path": "{target}",');st=next(i for i in range(pi,-1,-1) if lines[i]=='    {');en=next(i for i in range(pi+1,len(lines)) if lines[i] in ['    },','    }']);hi=next(i for i in range(st,en) if lines[i]=='        "history": [');blob=Path(target).read_bytes();cur=hashlib.sha256(blob).hexdigest();old=hashlib.sha256(subprocess.check_output(['git','show',base+':'+target])).hexdigest()
  item={'revision':base,'date':'2026-10-18','action':'Correct pre94 thumbnail/hotkey comments and L18 independent canvas and host ownership oracles','previousAfterSha256':old,'scope':'Only one board progress row, five selected live ledger entries and incoming bindings. Three implementations comments-only and one existing6-case test file. Four historical closures revoked; bootstrap previously unlisted pending becomes review; no new closure. CODE57 finite source/helper evidence becomes partial,51/32/0accept; its scopeConfirmed=false and visual/seam stop remain. Three old-green/new-specified-single-red controls,6/50 regressions do not grant whole-file/native/UI/coverage acceptance. Original native verdict/history retained; no baseline/retirement edits.','evidence':'docs/ops/evidence/QUALITY-PRE94-RETROSPECTIVE-1/core-comment-audit/tools-thumbnail-hotkeys/README.md','notRun':['whole-repository check','official coverage ratchet','protected fast','browser visual','E2E']}
  block=['          '+l for l in json.dumps(item,ensure_ascii=False,indent=2).splitlines()];block[-1]+=',';lines[hi+1:hi+1]=block;en+=len(block)
  for i in range(st,en):
   if lines[i].startswith('      "afterSha256": '):lines[i]=f'      "afterSha256": "{cur}",'
   elif lines[i].startswith('        "implementationSha": '):lines[i]=f'        "implementationSha": "{cur}",'
   elif lines[i].startswith('        "afterSha256": '):lines[i]=f'        "afterSha256": "{cur}",'
   elif lines[i].startswith('      "reviewedLines": '):lines[i]=f'      "reviewedLines": "1-{len(blob.decode().splitlines())}",'
 p.write_text('\n'.join(lines)+'\n')
 subprocess.run(['pnpm','exec','biome','format','--write',str(p)],check=True,stdout=subprocess.PIPE)
for fn,paths in targets.items():update(fn,paths)
update('20261017-r93-phase-governance-artifacts.json',[str(prefix/fn) for fn in targets])
update('20261017-r94-final-machine-artifacts.json',[str(prefix/'20261017-r93-phase-governance-artifacts.json')])
print('Four scoped review records updated; original verdict/history payloads preserved.')
