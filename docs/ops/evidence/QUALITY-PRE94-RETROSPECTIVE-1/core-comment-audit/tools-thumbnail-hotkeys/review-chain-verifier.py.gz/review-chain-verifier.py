# coding: utf-8
from pathlib import Path
import json,copy,hashlib,subprocess
p=Path('docs/ops/evidence/QUALITY-PRE94-RETROSPECTIVE-1/core-comment-audit/tools-thumbnail-hotkeys');base='5d55e2c49a1eb517d4bd51b2814df840dd49052a';prefix=Path('docs/phase-governance/reviews');mapping={
'20261004-semantic-current-batch.json':['docs/ops/board.md'],
'20261016-historical-cards-d.json':['docs/ops/audits/code-quality-file-ledger.md'],
'20261017-r93-phase-governance-artifacts.json':[str(prefix/'20261004-semantic-current-batch.json'),str(prefix/'20261016-historical-cards-d.json')],
'20261017-r94-final-machine-artifacts.json':[str(prefix/'20261017-r93-phase-governance-artifacts.json')]};report=[]
for name,targets in mapping.items():
 f=prefix/name;old=json.loads(subprocess.check_output(['git','show',base+':'+str(f)]));cur=json.loads(f.read_text());trial=copy.deepcopy(cur)
 for target in targets:
  a=next(r for r in old['entries'] if r['path']==target);b=next(r for r in trial['entries'] if r['path']==target);current=hashlib.sha256(Path(target).read_bytes()).hexdigest();assert b['afterSha256']==current;assert b['revision']['history'][0]['revision']==base and b['revision']['history'][1:]==a['revision']['history'];assert b['revision']['history'][0]['previousAfterSha256']==hashlib.sha256(subprocess.check_output(['git','show',base+':'+target])).hexdigest()
  for key in ['afterSha256','reviewedLines']:b[key]=a[key]
  for key in ['afterSha256','implementationSha']:
   if key in b['revision']:assert b['revision'][key]==current;b['revision'][key]=a['revision'][key]
  if isinstance(b.get('evidence'),dict) and 'afterSha256' in b['evidence']:
   assert b['evidence']['afterSha256']==current;b['evidence']['afterSha256']=a['evidence']['afterSha256']
  b['revision']['history'].pop(0)
 assert trial==old,name
 report.append({'review':str(f),'changedCurrentTargets':targets,'allOtherObjectsAndNativeVerdictsExact':True,'historicalRevisionChainExact':True,'allowedCurrentBindings':['entry.afterSha256','entry.revision.implementationSha','entry.evidence.afterSha256 where present','entry.reviewedLines'],'addedHistory':'One bounded delta entry at revision.history[0]'})
(p/'review-bindings-verification.json').write_text(json.dumps({'base':base,'scope':'Only four current records, no blanket hash refresh or whole-document semantic credit','records':report},ensure_ascii=False,indent=2)+'\n')
print('Four exact review bindings checked; all other objects/native verdicts/history retained.')
