# -*- coding: utf-8 -*-
from pathlib import Path
import json,hashlib,subprocess
base='9cc4b3fd4f4c6754cf2f727890c7f228b0b8e4f2';prefix=Path('docs/phase-governance/reviews')
targets={
 '20261004-semantic-current-batch.json':['docs/ops/board.md'],
 '20261016-historical-cards-d.json':['docs/ops/audits/code-quality-file-ledger.md'],
}
def update(fn,paths):
 p=prefix/fn;lines=p.read_text().splitlines()
 for target in paths:
  pi=next(i for i,l in enumerate(lines) if l==f'      "path": "{target}",');st=next(i for i in range(pi,-1,-1) if lines[i]=='    {');en=next(i for i in range(pi+1,len(lines)) if lines[i] in ['    },','    }']);hi=next(i for i in range(st,en) if lines[i]=='        "history": [');blob=Path(target).read_bytes();cur=hashlib.sha256(blob).hexdigest();old=hashlib.sha256(subprocess.check_output(['git','show',base+':'+target])).hexdigest()
  item={'revision':base,'date':'2026-10-18','action':'Correct pre94 ColorFade domain comments and strengthen existing palette test discrimination','previousAfterSha256':old,'scope':'Only one board progress row, two selected live ledger rows and incoming bindings. One implementation comments-only and one existing17-case test file; two old closures to review, no new closure. Four old-green/new-specified-single-red controls and17/86 regressions do not grant whole-file/native/UI/coverage acceptance. C normal4-grid vs TS expanded color distinction documented; no numerical or asset behavior change. Original native verdict/history retained; no baseline/retirement edits.','evidence':'docs/ops/evidence/QUALITY-PRE94-RETROSPECTIVE-1/core-comment-audit/palette-approach-tests/README.md','notRun':['whole-repository check','official coverage ratchet','protected fast','browser visual','E2E']}
  block=['          '+l for l in json.dumps(item,ensure_ascii=False,indent=2).splitlines()];block[-1]+=',';lines[hi+1:hi+1]=block;en+=len(block)
  for i in range(st,en):
   if lines[i].startswith('      "afterSha256": '):lines[i]=f'      "afterSha256": "{cur}",'
   elif lines[i].startswith('        "implementationSha": '):lines[i]=f'        "implementationSha": "{cur}",'
   elif lines[i].startswith('        "afterSha256": '):lines[i]=f'        "afterSha256": "{cur}",'
   elif lines[i].startswith('      "reviewedLines": '):lines[i]=f'      "reviewedLines": "1-{len(blob.decode().splitlines())}",'
 p.write_text('\n'.join(lines)+'\n')
 subprocess.run(['pnpm','exec','biome','format','--write',str(p)],check=True,stdout=subprocess.PIPE)
for fn,paths in targets.items():update(fn,paths)
update('20261017-r93-phase-governance-artifacts.json',[str(prefix/fn) for fn in targets])
update('20261017-r94-final-machine-artifacts.json',[str(prefix/'20261017-r93-phase-governance-artifacts.json')])
print('Four scoped review records updated; original verdict/history payloads preserved.')
