# coding: utf-8
from pathlib import Path
import json,gzip,hashlib,subprocess,tempfile,shutil,datetime
root=Path.cwd();out=root/'docs/ops/evidence/QUALITY-PRE94-RETROSPECTIVE-1/core-comment-audit/palette-approach-tests';sha=lambda b:hashlib.sha256(b).hexdigest();before=json.loads((out/'before.json').read_text());oldspec={r['path']:gzip.decompress((out/r['snapshot']).read_bytes()) for r in before['files']};source='packages/game/src/core/palette-fade.ts';spec='packages/game/src/core/palette-fade.test.ts'

def once(s,a,b):
 assert s.count(a)==1,(a,s.count(a));return s.replace(a,b)

def approach(s,fn):
 a=s.index('    const maxDelta = pf.increment');return s[:a]+fn(s[a:])
controls=[
 ('black-row-alias',source,spec,17,'blackColors:256',lambda s:once(s,'return Array.from({ length: 256 }, () => [0, 0, 0] as RGB)','return new Array<RGB>(256).fill([0, 0, 0])')),
 ('colorfade-nongrid-unclamped-loop',source,spec,17,'!fFrom:',lambda s:once(s,'moveToward(s[0], t[0], maxDelta),','pf.increment === 4 ? (() => { let value = s[0]; for (let k = 0; k < Math.floor(progress * pf.steps); k++) { if (value < t[0]) value += 4; else if (value > t[0]) value -= 4; } return value })() : moveToward(s[0], t[0], maxDelta),')),
 ('colorfade-rising-red-frozen',source,spec,17,'fFrom:纯色',lambda s:once(s,'moveToward(s[0], t[0], maxDelta),','pf.increment === 4 && s[0] < t[0] ? s[0] : moveToward(s[0], t[0], maxDelta),')),
 ('approach-accumulates-working-colors',source,spec,17,'fFrom:纯色',lambda s:approach(s,lambda x:once(x,'const s = pf.startColors[j]!','const s = colors[j]!'))),
]
allPaths={r['path'] for r in before['files']};current={s:(root/s).read_bytes() for s in allPaths};tmp=Path(tempfile.mkdtemp(prefix='type-pal-palette-controls-'));results=[]
try:
 for label,source,spec,n,target,mutate in controls:
  mutant=mutate(current[source].decode()).encode();assert mutant!=current[source];(out/(label+'.mutant.gz')).write_bytes(gzip.compress(mutant,mtime=0));row={'id':label,'source':source,'spec':spec,'sourceSha256':sha(current[source]),'mutantSha256':sha(mutant),'expectedNewFailureNameContains':target,'runs':{}}
  for phase,body in [('old',oldspec[spec]),('current',current[spec])]:
   rawfile=out/(label+'.'+phase+'.raw.gz');report=tmp/(label+'.'+phase+'.json');cmd=['pnpm','--filter','@type-pal/game','exec','vitest','run',spec.removeprefix('packages/game/'),'--reporter=verbose','--reporter=json','--outputFile.json='+str(report)];started=datetime.datetime.now(datetime.timezone.utc).isoformat()
   try:
    (root/source).write_bytes(mutant);(root/spec).write_bytes(body);proc=subprocess.run(cmd,cwd=root,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);raw=proc.stdout;rawfile.write_bytes(gzip.compress(raw,mtime=0));native=report.read_bytes() if report.exists() else b''
    if native:(out/(label+'.'+phase+'.vitest.json.gz')).write_bytes(gzip.compress(native,mtime=0))
    record={'command':cmd,'cwd':str(root),'startedAt':started,'completedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit':proc.returncode,'signal':-proc.returncode if proc.returncode<0 else None,'spawnError':None,'raw':rawfile.name,'rawBytes':len(raw),'rawSha256':sha(raw),'fullUncutMergedStdoutStderr':True,'specSha256':sha(body),'nativeReport':label+'.'+phase+'.vitest.json.gz'};row['runs'][phase]=record
    assert native,'native report missing';data=json.loads(native);cases=[a for f in data['testResults'] for a in f['assertionResults']];failed=[a for a in cases if a['status']=='failed'];record.update({'passed':data['numPassedTests'],'failed':data['numFailedTests'],'pending':data['numPendingTests'],'cases':[{'file':f['name'],'fullName':a['fullName'],'status':a['status']} for f in data['testResults'] for a in f['assertionResults']]})
    assert len(cases)==n and data['numPendingTests']==0 and not data.get('unhandledErrors',[]);assert all(a['status'] in ['passed','failed'] for a in cases)
    if phase=='old':assert proc.returncode==0 and not failed and data['numPassedTests']==n
    else:assert proc.returncode==1 and len(failed)==1 and data['numPassedTests']==n-1 and target in failed[0]['fullName'] and all('AssertionError' in m for m in failed[0]['failureMessages']);record['failureMessages']=failed[0]['failureMessages']
   finally:
    (root/source).write_bytes(current[source]);(root/spec).write_bytes(current[spec]);record=row['runs'].get(phase)
    if record:record.update({'sourceRestoredSha256':sha((root/source).read_bytes()),'specRestoredSha256':sha((root/spec).read_bytes()),'sourceRestoredByteForByte':(root/source).read_bytes()==current[source],'specRestoredByteForByte':(root/spec).read_bytes()==current[spec]})
  results.append(row);print(label+': old'+str(n)+' green; current'+str(n-1)+' green /1 specified AssertionError',flush=True)
finally:
 for path,body in current.items():(root/path).write_bytes(body)
 shutil.rmtree(tmp);summary={'base':before['base'],'owner':'Codex single agent','scope':'Each mutant runs one whole unfiltered old/current file. This is source mutation discrimination, not native game or UI acceptance.','controls':results,'tempDirectory':str(tmp),'tempDirectoryRemoved':not tmp.exists(),'restored':all((root/k).read_bytes()==v for k,v in current.items())};(out/'controls.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
assert len(results)==len(controls) and summary['restored']
