#include <stdint.h>
#include <stdio.h>
#include <string.h>
typedef int INT;
typedef int BOOL;
typedef uint8_t BYTE;
#define VOID void
#define PAL_LARGE
#define FALSE 0
#define TRUE 1
typedef struct { BYTE r,g,b,a; } SDL_Color;
static SDL_Color palette[256];
static struct { INT wNumPalette; BOOL fNightPalette; } storage;
#define gpGlobals (&storage)
static int emitted;
static SDL_Color *PAL_GetPalette(INT p,BOOL n) { (void)p;(void)n;return palette; }
static void UTIL_Delay(INT delay) { (void)delay; }
static void VIDEO_SetPalette(SDL_Color *p) {
 if(emitted++) printf(",");
 printf("[");
 for(int i=0;i<256;i++) {if(i)printf(",");printf("[%u,%u,%u]",p[i].r,p[i].g,p[i].b);}
 printf("]");
}
VOID
PAL_ColorFade(
   INT        iDelay,
   BYTE       bColor,
   BOOL       fFrom
)
/*++
  Purpose:

    Fade the palette from/to the specified color.

  Parameters:

    [IN]  iDelay - the delay time of each step.

    [IN]  bColor - the color to fade from/to.

    [IN]  fFrom - if TRUE then fade from bColor, else fade to bColor.

  Return value:

    None.

--*/
{
   SDL_Color       *palette;
   PAL_LARGE SDL_Color        newpalette[256];
   int              i, j;

   memset(newpalette, 0xff, sizeof(SDL_Color)*255);

   palette = PAL_GetPalette(gpGlobals->wNumPalette, gpGlobals->fNightPalette);

   iDelay *= 10;
   if (iDelay == 0)
   {
      iDelay = 10;
   }

   if (fFrom)
   {
      for (i = 0; i < 256; i++)
      {
         newpalette[i] = palette[bColor];
      }

      for (i = 0; i < 64; i++)
      {
         for (j = 0; j < 256; j++)
         {
            if (newpalette[j].r > palette[j].r)
            {
               newpalette[j].r -= 4;
            }
            else if (newpalette[j].r < palette[j].r)
            {
               newpalette[j].r += 4;
            }

            if (newpalette[j].g > palette[j].g)
            {
               newpalette[j].g -= 4;
            }
            else if (newpalette[j].g < palette[j].g)
            {
               newpalette[j].g += 4;
            }

            if (newpalette[j].b > palette[j].b)
            {
               newpalette[j].b -= 4;
            }
            else if (newpalette[j].b < palette[j].b)
            {
               newpalette[j].b += 4;
            }
         }

         VIDEO_SetPalette(newpalette);
         UTIL_Delay(iDelay);
      }

      VIDEO_SetPalette(palette);
   }
   else
   {
      memcpy(newpalette, palette, sizeof(newpalette));

      for (i = 0; i < 64; i++)
      {
         for (j = 0; j < 256; j++)
         {
            if (newpalette[j].r > palette[bColor].r)
            {
               newpalette[j].r -= 4;
            }
            else if (newpalette[j].r < palette[bColor].r)
            {
               newpalette[j].r += 4;
            }

            if (newpalette[j].g > palette[bColor].g)
            {
               newpalette[j].g -= 4;
            }
            else if (newpalette[j].g < palette[bColor].g)
            {
               newpalette[j].g += 4;
            }

            if (newpalette[j].b > palette[bColor].b)
            {
               newpalette[j].b -= 4;
            }
            else if (newpalette[j].b < palette[bColor].b)
            {
               newpalette[j].b += 4;
            }
         }

         VIDEO_SetPalette(newpalette);
         UTIL_Delay(iDelay);
      }

      for (i = 0; i < 256; i++)
      {
         newpalette[i] = palette[bColor];
      }

      VIDEO_SetPalette(newpalette);
   }
}
int main(void) {
 printf("[");
 for(int c=0;c<3;c++) {
  if(c)printf(",");
  for(int i=0;i<256;i++)palette[i]=(c==2?(SDL_Color){101,81,40,0}:(SDL_Color){100,20,40,0});
  palette[7]=(c==2?(SDL_Color){40,101,40,0}:(SDL_Color){20,100,40,0});
  emitted=0;printf("{\"case\":%d,\"frames\":[",c);PAL_ColorFade(1,7,c==1);printf("]}");
 }
 printf("]\n");return 0;
}
