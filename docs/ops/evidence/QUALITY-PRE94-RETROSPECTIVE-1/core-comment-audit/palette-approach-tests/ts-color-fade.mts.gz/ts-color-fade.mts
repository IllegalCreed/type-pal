import { buildColorFade,blackColors,stepPaletteFade,finalizePaletteFade } from "/Users/zhangxu/.codex/worktrees/quality-3y-closeout/type-pal/packages/game/src/core/palette-fade.ts";
import {decodePalette} from "/Users/zhangxu/.codex/worktrees/quality-3y-closeout/type-pal/packages/pal-extract/src/resources/palette.ts";
const fill=(c:[number,number,number]):[number,number,number][]=>Array.from({length:256},()=>[c[0],c[1],c[2]]);
const series=(base:[number,number,number][],from:boolean)=>{const pf=buildColorFade(base,7,from,6400,0),colors=blackColors(),frames=[];for(let k=1;k<=64;k++){stepPaletteFade(colors,pf,k*100);frames.push(structuredClone(colors));}finalizePaletteFade(colors,pf);frames.push(structuredClone(colors));return frames;};
const grid=fill([100,20,40]);grid[7]=[20,100,40];
const raw=new Uint8Array(768);for(let i=0;i<256;i++)raw.set([25,20,10],i*3);raw.set([10,25,10],7*3);const decoded=decodePalette(raw).colors;
console.log(JSON.stringify({gridForward:series(grid,false),gridReverse:series(grid,true),decodedForward:series(decoded,false),decoded:[decoded[0],decoded[7]],rawGrid:[[100,80,40],[40,100,40]],scope:'Actual decodePalette and game helpers; synthetic legal768-byte input, no asset generation or original EXE run.'}));
