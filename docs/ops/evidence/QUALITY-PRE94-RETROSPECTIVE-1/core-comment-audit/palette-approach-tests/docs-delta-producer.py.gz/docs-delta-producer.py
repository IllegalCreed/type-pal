from pathlib import Path
import json,gzip,hashlib,subprocess
p=Path('docs/ops/evidence/QUALITY-PRE94-RETROSPECTIVE-1/core-comment-audit/palette-approach-tests');base='9cc4b3fd4f4c6754cf2f727890c7f228b0b8e4f2';sha=lambda b:hashlib.sha256(b).hexdigest();m=json.loads((p/'before.json').read_text());c=json.loads((p/'controls.json').read_text());controlBase=gzip.decompress((p/'controls-source-base.gz').read_bytes());assert len(c['controls'])==4 and c['restored'] and c['tempDirectoryRemoved']
for r in c['controls']:assert r['sourceSha256']==sha(controlBase) and r['runs']['current']['specSha256']==sha(Path(r['spec']).read_bytes())
full=[x['path'] for x in m['files']]+['packages/pal-extract/src/resources/palette.ts','docs/ops/archive/tasks/done/CODE-QUALITY-3n-game-core-fade-identity-catalog.md'];partial={'reference/sdlpal/palette.c':[[55,104],[456,667]],'packages/game/src/core/event-system.ts':[[605,650],[1525,1563],[2535,2549],[2599,2615],[3529,3540]],'packages/game/src/present/present.ts':[[195,246]]};rows=[]
for path in full:
 b=Path(path).read_bytes();row={'path':path,'sha256':sha(b),'lines':len(b.splitlines()),'ranges':[[1,len(b.splitlines())]],'scope':'Full read; no whole-file acceptance inferred from reading.'}
 if path in [x['path'] for x in m['files']]:
  name=sha(b)[:12]+'-'+Path(path).name+'.current.gz';(p/name).write_bytes(gzip.compress(b,mtime=0));row['snapshot']=name
 rows.append(row)
for path,ranges in partial.items():assert all(1<=a<=b<=len(Path(path).read_bytes().splitlines()) for a,b in ranges)
(p/'read-boundaries.json').write_text(json.dumps({'base':base,'fullReads':rows,'partialReads':[{'path':path,'sha256':sha(Path(path).read_bytes()),'lines':len(Path(path).read_bytes().splitlines()),'ranges':ranges,'scope':'Only these primary/caller/lifecycle ranges, not whole-file closure.'} for path,ranges in partial.items()],'newClosed':0,'limits':['C PAL_GetPalette grid established by source shifts; compiled ColorFade uses synthetic typed palette/video/delay stubs, not full asset/EXE execution.','Same-grid comparison is two concrete forward/reverse palettes,65 submissions each, not full color-domain/visual parity.','Artificial non-grid C input is outside PAL_GetPalette normal domain and does not prove a production C defect.','TS palette uses actual decodePalette of legal768-byte synthetic6bit data, no generated files written.','Source after controls only removes a stale PAL_GetPalette99-104 anchor; control base gzip and two parsed TS/JS identity comparisons preserve exact temporal scope.','All other fade math, invalid durations/cursor cancellation, real asset/E2E/visual and unified gates remain unaccepted.']},ensure_ascii=False,indent=2)+'\n')
r=c['controls'][0];changes=[{'old':a['fullName'],'current':b['fullName'],'reason':'Maximum valid RGB boundary is not evidence that removing an unreachable clamp changes behavior.'} for a,b in zip(r['runs']['old']['cases'],r['runs']['current']['cases']) if a['fullName']!=b['fullName']];assert len(changes)==1;(p/'test-title-mappings.json').write_text(json.dumps({'file':r['spec'],'base':base,'before':17,'current':17,'mappings':changes,'baselineEdited':False,'officialProtectedIdentityGate':'not run; exact mapping retained for large-task reconciliation'},ensure_ascii=False,indent=2)+'\n')
f=Path('docs/ops/audits/code-quality-file-ledger.md');live,hist=f.read_text().split('<!-- original-source-fenced:start -->',1);old='当前已闭合核验：267；已读但待审：75；尚未逐文件核验：2,973；合计未闭合：3,048。';assert live.count(old)==1;live=live.replace(old,'当前已闭合核验：265；已读但待审：77；尚未逐文件核验：2,973；合计未闭合：3,050。');lines=live.splitlines();link='[ColorFade输入域/测试返工](../evidence/QUALITY-PRE94-RETROSPECTIVE-1/core-comment-audit/palette-approach-tests/README.md)'
for path,kind,ev,why in [('packages/game/src/core/palette-fade.ts','product','328行原源全文、C正常4网格/实际提取器8位展开、event/present所有权分段','任意8位等价与视觉1:1错注撤回；C有限64步再补终值，原C人工非网格往返不当正常域缺陷；仅注释变化，旧关闭转review'),('packages/game/src/core/palette-fade.test.ts','test','235行原测全文；17例保持、行/快照独立、非网格钳制与正反通道/重复重绘','四枚各旧17绿→新16绿1指定AssertionError；恢复17/相邻86绿，精确输入域与C/TS分开；不授整文件关闭')]:
 ix=[i for i,l in enumerate(lines) if l.startswith('| `'+path+'` |')];assert len(ix)==1;lines[ix[0]]=f'| `{path}` | {kind} | review | {link}；{ev} | {why} |'
# Preserve the exact historical fence and existing separator whitespace.
f.write_text('\n'.join(lines)+'\n<!-- original-source-fenced:start -->'+hist)
f=Path('docs/ops/board.md');s=f.read_text();a='七组注释已修，余三组/数值风险/两UI差异继续';assert s.count(a)==1;f.write_text(s.replace(a,'八组注释已修，余两组/数值风险/两UI差异继续'))
f=Path('docs/ops/evidence/QUALITY-PRE94-RETROSPECTIVE-1/3n-fade-identity-catalog/README.md');(p/'3n-report.before.gz').write_bytes(gzip.compress(f.read_bytes(),mtime=0));s=f.read_text();notice='''> 2026-10-18 当前更正：palette源/测旧整文件关闭转review。ColorFade原C无钳制，但PAL_GetPalette产生4倍数网格、64步后补终值；“任意8位步进等价/视觉1:1”源注不能成立，人工非网格C往返也不证明正常原版缺陷。见[输入域与测试返工](../core-comment-audit/palette-approach-tests/README.md)。本次不改产品执行；此前PaletteFade `/31` 修复证据仍按原有限范围保留，其它三个helper不被本次重新签收。\n\n''';title,rest=s.split('\n',1);s=title+'\n\n'+notice+rest.lstrip('\n');s=s.replace('原 80→80 中点 oracle','原 0→80 中点 oracle');f.write_text(s)
f=Path('docs/ops/evidence/QUALITY-PRE94-RETROSPECTIVE-1/core-comment-audit/README.md');f.write_text(f.read_text()+'''\n当前[ColorFade输入域与测试返工](palette-approach-tests/README.md)补第八组注释，余尺寸/快捷键两组。原C完整函数正反同网格65次提交与TS一致；人工非网格仅64步往返后补终值，不能登记原版正常域缺陷。两旧关闭转review，17例保持、四旧绿新单红；数值风险与两UI差异继续。\n''')
f=Path('docs/ops/tasks/QUALITY-PRE94-RETROSPECTIVE-1.md');f.write_text(f.read_text()+'''\n### 2026-10-18 CODE3n ColorFade输入域与原17例返工\n\n本有限白名单为palette-fade.ts事实注释及palette-fade.test.ts原例补强，由父卡低风险准入推进。全文核两文件与真实palette提取器，读event cursor/cursorless构造、waiting与present收尾caller、原C GetPalette/ColorFade/FadeToRed。原C完整ColorFade以typed最小上下文O0/O2捕获65次完整256色提交，两个同网格正反palette与真实TS步骤一致；C正常getPalette v<<2保持4倍数，人工非网格输入才往返且64步后补终值，不把它当真实原版“永久振荡”缺陷。真实decodePalette的合法6位合成768字节给101/81/40等展开值，TS饱和合同与C字节域分清；未改提取器、生成物、时间/色值执行或公开接口。\n\n第八组错注修正：连续lerp/任意8位等价/视觉1:1、夜色“未提取”与错误GetPalette99–104锚撤回，收尾SceneFade63/64例外说清。原17例保持，black行/新快照独立、ColorFade非网格/上升下降/同时间重绘不累积补强；最大RGB255测试撤销“能辨clamp删除”夸大标题。四反控各完整旧17绿→新16绿1指定业务AssertionError；恢复17、相邻3文件86和typecheck零诊断。控制后仅修一处source引用，控制基点gzip及两轮parsedTS/JS同一证明保留，未重跑无关测试。\n\n两旧关闭转review、0新增closed；265closed/77review/2973pending（提交前机器核），83卡50partial/33pending/0accept不变。全部逐文件/primary/caller/oracle及原始日志见[本片](../evidence/QUALITY-PRE94-RETROSPECTIVE-1/core-comment-audit/palette-approach-tests/README.md)；未授全色域/视觉/原盘/完整机制信用。docs/lint看最终回执，全仓check、官方coverage/protected仍留大任务收尾，不合main。下一范围尺寸/快捷键；其它数值/毒列表/两UI风险继续，法术160/161裁决仍pending。无下一位Agent提示词。\n''')
(p/'README.md').write_text('''# pre94 ColorFade输入域与既有测试判别力返工

Status: recorded
Owner: Codex（单Agent，自身源码核证，不冒充第三方）
Date: 2026-10-18
Base: `9cc4b3fd4f4c6754cf2f727890c7f228b0b8e4f2`
Branch: `codex/code-quality-3y`

## 身份、范围与读取

id: QUALITY-PRE94-RETROSPECTIVE-1 / palette-approach-tests；schemaVersion:1；status:recorded。[父卡](../../../../tasks/QUALITY-PRE94-RETROSPECTIVE-1.md)低风险注释/测试准入，2文件全文：palette-fade.ts原328行及原测235行；实际提取器与历史3n卡全文，event/present生产caller分段见[读取边界](read-boundaries.json)。只本片两文件补证，不将旁读/执行变为相邻整文件验收。旧3n报告字节gzip保留，当前信用已收窄。

## Primary与反证边界

原C ColorFade直接±4，正常PAL_GetPalette用v<<2，任意两个通道差为4倍数：每步到目标距离减4，0..252至多63步，无越过或BYTE环绕。64步后另提交终值。因此“任意8位moveToward都等价”错误，“原版永久振荡”也不能从非网格人工输入推出；只确立这个有限域和结构事实。

[原C完整函数回执](native-oracle.json)按真实body边界提取，typed SDL_Color与最小globals、合成palette源及video/delay stub，clang O0/O2 -Wall/-Wextra/-Werror均零诊断、结果相同。两组方向各65次**完整256色RGB**提交，与实际TS同网格helper步骤1..64+finalize逐字相同；非全数值域或原EXE/视觉验收。C被人工喂101→40时末两步41/37、随后补40，只有64步内往返，不当正常原版缺陷。

真实pal-extract decodePalette吃合法768字节6位合成palette，把25/20/10展开成101/81/40；TS已有饱和收敛给40/101/40。此输入是TS生产域，不是C正常getPalette字节域。跨包调用只在隔离取证程序，不增加game产品/测试依赖、不生成/改写资产。保持现有行为，未提出色值/时间/asset pipeline改造。

## 两文件问题与测试质量

源码仅修事实注释：离散量化而非连续lerp；ColorFade等价域与FadeToRed显式clamp区分；撤销“视觉1:1”、夜色未提取说法、GetPalette99–104错误锚；说明SceneFade-in终值例外。源语法/JS完全未变，见[两基点证明](emit-identity.json)：Git基点及控制基点各对最终源作parsed TS与去注释JS相同验证。控制之后只去掉一处错误行号，控制源gzip保存，不为注释再次跑整组测试。

原测试17例保持，未加万能新例：blackColors补行与跨调用独立；ColorFade现有两方向补上升/下降/不变通道、中间帧、非网格饱和与同时间重绘快照ownership。RGB最大255输入仅验证边界公式，不能辨别删除不可达clamp，标题已更正，[唯一标题映射](test-title-mappings.json)保留，未改baseline/退役账。

四精确反控见[controls](controls.json)：行别名、ColorFade非网格仿C无clamp循环、上升红通道冻结、错误从工作色表累积；各完整未过滤旧17绿→新16绿1指定业务AssertionError，0skip/pending/unhandled，完整source/spec/mutant/nativeJSON/raw/restore SHA与finally清理。源SHA按controls-source-base.gz定位；最终源差一处引用勘误，AST双证明确。测试不直接构造被测算法来生成oracle：小值手算与原C/真实提取器完整对照相互核证。

## 门、状态与未决

实际结果及诊断见[gates](gates.json)，完整未裁剪raw gzip与独立命令回执随片；17恢复、86相邻、game typecheck零诊断。docs125/全部消费者、lint和ledger以最终回执为准。全仓check、official coverage ratchet、protected fast、视觉/E2E未运行，按用户成本规则留完整大任务窗口，不授统一门或main合并信用。

两个原closed转review，0新增closed；265closed/77review/2973pending，83卡50partial/33pending/0accept。整色域、其它fade数学、invalid delay、资源库存/视觉和完整异步生命周期仍未接受；共享moveToward提取未证多个owner同域必要，不为“复用”加新接口。第八组注释已处理，尺寸/快捷键继续；法术160/161与毒列表、两UI风险按原卡留待裁决/核证。

## 交接与下一步

同一3y治理分支提交推送，fetch确认0behind；未合main。下一有限范围核minimap/tools-panel/bootstrap尺寸与真实speedrun hotkey。无下一位Agent提示词，Codex单Agent继续94前全部复审。
''')
for name,path in [('edit-producer.py.gz','/tmp/type-pal-palette-edit.py'),('native-producer.py.gz','/tmp/type-pal-palette-native.py'),('capture.py.gz','/tmp/type-pal-palette-capture.py'),('controls-producer.py.gz','/tmp/type-pal-palette-controls.py'),('emit-proof.cjs.gz','/tmp/type-pal-palette-emit.cjs')]: (p/name).write_bytes(gzip.compress(Path(path).read_bytes(),mtime=0))
print('Two live ledger closures revoked; current docs bound to finite palette slice, no historical fence or baseline edits.')
