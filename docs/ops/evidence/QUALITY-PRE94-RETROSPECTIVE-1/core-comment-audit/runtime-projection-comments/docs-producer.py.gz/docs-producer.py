# coding: utf-8
from pathlib import Path
import json,gzip,hashlib,re
p=Path('docs/ops/evidence/QUALITY-PRE94-RETROSPECTIVE-1/core-comment-audit/runtime-projection-comments');base=json.loads((p/'before.json').read_text())['base'];before=json.loads((p/'before.json').read_text());sha=lambda b:hashlib.sha256(b).hexdigest()
partial={
 'packages/game/src/shell/bootstrap.ts':[[1170,1242]],
 'packages/game/src/core/menu/menu-driver.ts':[[135,174]],
 'packages/game/src/core/equipment-state.ts':[[1,269],[305,339],[345,391]],
 'packages/game/src/core/equip-effect.ts':[[1,75]],
 'packages/game/src/core/event-opcode-player.ts':[[116,147],[175,221],[240,307]],
 'packages/game/src/core/event-system.ts':[[3085,3116]],
 'packages/game/src/core/battle/battle-opcodes.ts':[[640,705],[838,884]],
 'packages/game/src/core/game-state.test.ts':[[641,850]],
 'packages/game/src/core/battle/__tests__/battle-state.test.ts':[[1,105],[155,205]],
 'reference/sdlpal/fight.c':[[87,128],[1085,1158],[1385,1445],[1631,1673],[1728,1752]],
 'reference/sdlpal/battle.c':[[600,744],[1730,1839]],
 'reference/sdlpal/video.c':[[1043,1135]],
 'reference/sdlpal/global.c':[[1736,2098],[2168,2345]],
 'reference/sdlpal/script.c':[[1362,1378]],
 'docs/phase1/game-mechanics.md':[[1486,1503],[1558,1578]],
 'docs/phase1/engineering-notes.md':[[107,125]],
}
full=[r['path'] for r in before['files']]+['packages/game/src/core/battle/battle-runtime-context.ts','packages/game/src/core/battle/battle-finalization.ts','packages/game/src/core/battle/actions/attack.glm-next-wave.test.ts','packages/game/vitest.config.ts','docs/ops/evidence/QUALITY-PRE94-RETROSPECTIVE-1/3s-battle-system/README.md','docs/ops/evidence/QUALITY-PRE94-RETROSPECTIVE-1/3v-battle-actions/README.md']
rows=[]
for path,ranges in partial.items():
 b=Path(path).read_bytes();assert all(1<=a<=z<=len(b.splitlines()) for a,z in ranges),path;rows.append({'path':path,'sha256':sha(b),'lines':len(b.splitlines()),'ranges':ranges,'scope':'Only listed caller/type/primary/oracle ranges; not full-file semantic acceptance.'})
# Check exact selected source hashes before publishing any evidence.
identity=json.loads((p/'emit-identity.json').read_text());assert len(identity['rows'])==4
for r in identity['rows']:assert r['currentSha256']==sha(Path(r['path']).read_bytes())
fullrows=[]
for path in full:
 b=Path(path).read_bytes();n=Path(path).name+'.current.gz';(p/n).write_bytes(gzip.compress(b,mtime=0));fullrows.append({'path':path,'sha256':sha(b),'lines':len(b.splitlines()),'snapshot':n,'scope':'Full text read; modified implementation read at base plus entire own comment delta. No whole-file acceptance.'})
(p/'read-boundaries.json').write_text(json.dumps({'base':base,'owner':'Codex single agent','fullReads':fullrows,'partialReads':rows,'newClosed':0,'limitations':['Four selected implementations fully read; partial production caller/primary ranges remain bounded.','SDLPal source reading is not pal.exe execution, browser, E2E or visual acceptance.','GameState spec has legacy double cast and stale comments; execution green is not quality acceptance.','All-HP0+Puppet loss and hidden stash migration hypotheses rejected after primary reading.','Equipment rebuild order/WORD extreme domains remain unproven, no behavior fix authorized here.']},ensure_ascii=False,indent=2)+'\n')
for label in ['direct','adjacent']:
 raw=Path('/tmp/type-pal-projection-'+label+'.json').read_bytes();d=json.loads(raw);assert d['numFailedTests']==d['numPendingTests']==0;(p/(label+'.vitest.json.gz')).write_bytes(gzip.compress(raw,mtime=0))
for name,path in [('capture.py.gz','/tmp/type-pal-projection-capture.py'),('emit-proof.cjs.gz','/tmp/type-pal-projection-emit.cjs'),('prepare.py.gz','/tmp/type-pal-projection-prepare.py')]: (p/name).write_bytes(gzip.compress(Path(path).read_bytes(),mtime=0))
# Limited source/closure credit correction, preserving original fenced ledger bytes.
f=Path('docs/ops/audits/code-quality-file-ledger.md');original=f.read_text();live,history=original.split('<!-- original-source-fenced:start -->',1);live=live.replace('当前已闭合核验：275；已读但待审：66；尚未逐文件核验：2,974；合计未闭合：3,040。','当前已闭合核验：272；已读但待审：70；尚未逐文件核验：2,973；合计未闭合：3,043。');lines=live.splitlines();link='[投影与宿主错注](../evidence/QUALITY-PRE94-RETROSPECTIVE-1/core-comment-audit/runtime-projection-comments/README.md)'
reasons={
 'packages/game/src/core/battle/actions/attack.ts':('614行全文；真实投影/原Cgetter，撤销失效行号','只更正投影ownership注释，JS/TS语法不变；数值极端、整个action测试/统一门仍待，旧源关闭转review'),
 'packages/game/src/core/battle/battle-system.ts':('3141行全文及bootstrap/effect/状态/cleanup caller；自动评分/选靶/入场/队列错注已修','删除虚假快照/音效时序等价信用，186例只回归；生命周期其余轴/视觉/统一门仍待，旧源关闭转review'),
 'packages/game/src/core/battle/battle-state.ts':('918行全文；rgPlayerStatus真实写入/seed/cleanup与原C','状态不限装备、Confirm记忆、顶层fade不推进游标错注已修；14例只回归，旧整文件关闭转review'),
}
for path,(ev,why) in reasons.items():
 ids=[i for i,l in enumerate(lines) if l.startswith('| `'+path+'` |')];assert len(ids)==1,path;lines[ids[0]]=f'| `{path}` | product | review | {link}；{ev} | {why} |'
path='packages/game/src/core/game-state.ts';assert not any(l.startswith('| `'+path+'` |') for l in lines);at=next(i for i,l in enumerate(lines) if l.startswith('| `packages/game/src/core/battle/battle-state.ts` |'));lines.insert(at,f'| `{path}` | product | review | {link}；2111行全文及公开投影/HPMP回写、实际caller/原C | 裸基础值/effect快照/状态ownership错注更正，无执行或schema变化；其余场景/存档/异步字段与旧测试强转继续待核 |')
f.write_text('\n'.join(lines)+'\n\n<!-- original-source-fenced:start -->'+history)
# Add explicit current counter notices without rewriting old excerpts.
for sub,title in [('3s-battle-system','宿主'),('3v-battle-actions','attack')]:
 f=Path('docs/ops/evidence/QUALITY-PRE94-RETROSPECTIVE-1')/sub/'README.md';b=f.read_bytes();(p/(sub+'-README.before.gz')).write_bytes(gzip.compress(b,mtime=0));s=b.decode();head,tail=s.split('\n',1);s=head+'\n\n> 2026-10-18 当前注释counter：本轮全文补审发现'+title+'的投影、状态或生命周期说明与实际caller不符；原整文件关闭信用转review。原有限数值结果不据此否定，也不扩成“全部注释/测试合法/全生命周期等价”。仅事实错注已修、执行代码不变；详见[投影/宿主返工](../core-comment-audit/runtime-projection-comments/README.md)。\n'+tail;f.write_text(s)
f=Path('docs/ops/board.md');s=f.read_text();old='四组注释已修，余六组/两UI差异继续';assert s.count(old)==1;s=s.replace(old,'五组注释已修，余五组/算术风险/两UI差异继续');f.write_text(s)
f=Path('docs/ops/tasks/QUALITY-PRE94-RETROSPECTIVE-1.md');f.write_text(f.read_text()+'''\n### 2026-10-18 runtime投影注释当前结果\n\n四源事实错注已修：runtime裸值与装备effect分开，投影是快照、HPMP单向回写不叫严格逆；普通大世界状态同样seed。宿主纠正自动法术随机评分、Confirm记忆、0槽保留、入场VIDEO_SwitchScreen和动作/fade游标归属，音效只描述当前caller、不再超卖时序等价；错贴performAction头移回所属函数。去注释后的parsed TypeScript和JS字节均与bcec7f0fe一致，零产品行为变化。\n\n75定向+199相邻恢复绿、game typecheck通过，完整raw零stderr/act/环境/unhandled；未改任何测试。裸scanner不理解模板重扫导致一次验证器假报，改用TS parser/printer后两种输出一致，原失败保留，不计业务反控。game-state.test旧双强转/造型静态错注本次只登记后续，绿色不换整文件验收。\n\n三旧源码关闭转review，GameState从pending转review；0新增closed，机器账本待最终实测。83卡仍50partial/33pending/0accept；五组审计注释已修，余draw-shop/formulas/尺寸/快捷键/ColorFade、冗余算术与两UI差异继续。完整[原件](../evidence/QUALITY-PRE94-RETROSPECTIVE-1/core-comment-audit/runtime-projection-comments/README.md)。全仓check/official coverage ratchet/protected按用户大窗口成本要求未跑，统一门rework，未合main，94–102/editor仍在pre94之后。\n''')
(p/'README.md').write_text('''# pre94 runtime投影与战斗宿主事实注释\n\nStatus: recorded\nOwner: Codex（单Agent，自身核证，不冒充独立第三方）\nDate: 2026-10-18\nBase: `bcec7f0fe1ecac8612c8d83374e4882f2c8f8f0a`\nBranch: `codex/code-quality-3y`\n\n## 证据身份与准入\n\nid: QUALITY-PRE94-RETROSPECTIVE-1 / runtime-projection-comments；schemaVersion:1；status:recorded。准入和交接见[父卡](../../../../tasks/QUALITY-PRE94-RETROSPECTIVE-1.md)。只改四源注释，无测试/行为/API/schema/save/生成物修改；商店与其余pre94仍待，不扩大103+。源全文、caller/primary实际区间与SHA见[读边界](read-boundaries.json)；不是grep命中即全文。\n\n## 逐文件发现与修复\n\n- attack.ts：全文614行；攻击用开战投影的有效武术，纠正失效game-state:1279锚，避免把等级敌方项重复加给队员。其余action/极端WORD并未据本片重新接受。\n- battle-system.ts：全文3141行；纠正过时1282锚、0槽保留、资源stash owner、自动法术参数实为0..range随机评分非MP阈值、Confirm记忆非hover、动作完成先推进游标/fade暂停下一动作。入场对应PAL_StartBattle→PAL_BattleMain→VIDEO_SwitchScreen(5)换屏360ms一段，不包括此前200ms delay；不能称完整演出等价。音效sweep有动作收尾和毒后两个caller，不固定称回合初/仅回合末，不承诺C时序完全等价。\n- game-state.ts：全文2111行；runtime武术是裸基础值，装备与Extra另存；造型也可变。投影是含回退/钳制/覆盖的对象快照，HP/MP边界回写不是完整逆函数；无第三参的menuRoles不合装备。更正“只建stat行”“合击待P2”和“状态表只存装备buff”等旧说明。\n- battle-state.ts：全文918行；状态seed同时带普通和装备状态，fade字段纠正顶层driver和游标归属，目标记忆说明对应Confirm；工厂说明移到真实函数上。其余类型/API、状态或布局边界保持review。\n\n## Primary、caller与oracle\n\n真实bootstrap注入projectRuntimeToBattleRoles(runtime,static,effect)；menuRoles只传前两参，不能合并描述。equipment-state数值getter与row writer、event-system 0x19/0x1A resync、battle-opcodes 0x30 Extra刷新、outside-battle 0x2D、createBattleState seed与finalizeBattleCleanup清<=999状态组成当前ownership链。参考SDLPal global.c的属性getter/覆盖与状态函数，fight.c的自动选靶/终态，uibattle.c自动选法术评分，battle.c入场与战末cleanup，video.c换屏。SDLPal仅源证据，不冒充原版EXE运行；原盘装备数据和全部调用时序仍未接受。\n\n全HP0+Puppet的新缺陷假设已排除：C该分支仅清fOnlyPuppet，未清fEnded，仍判负；只修坏注释。runtime-context仍存隐藏字段，不能伪称已迁到WeakMap。装备重建时序等猜测没有真实反例，不写成已验证缺陷或直接实现。\n\n## 测试与可执行不变证据\n\n四源TS parser/printer去注释输出一致，同时removeComments JS字节一致（emit-identity.json），类型/表达式未变。裸scanner首版未按parser上下文重扫模板，误把带注释的大片正文当模板token，emit-preflight退出1；不是生产失败或有效业务反控。原raw保留，后用parser/JS两条对照，未改runner/规则消诊断。\n\n定向2文件75例（GameState61、BattleState14），相邻3文件199例（宿主186、attack2、ownership11）；原生Vitest JSON/raw全部保存，0失败/skip/pending，完整输出无stderr块/act/环境/unhandled诊断。现有GameState投影测试用了as any as PlayerRole且有旧造型注释，本片只读相关区间，不能凭61绿接受其整文件；未写新弱测试或为覆盖率堆量。最后两项注释微调未重复跑测试，以初/末编译同字节证明执行候选一致。\n\n## 状态、门与限制\n\n0新增closed；三旧源码closure撤回review，GameState原pending只提升review；83卡仍50partial/33pending/0accept。机器计数及docs/lint/diff最终结果以gates.json为准，尚未运行的门不登记通过。全仓check、official coverage ratchet、protected fast、浏览器/视觉/E2E均未运行，留大任务收尾；未合main，统一门仍rework。\n\n五组审计注释已处理；下一组draw-shop全屏装配，之后formulas半开区间/冗余算术、640尺寸与快捷键、ColorFade；draw-equip单人rows/draw-inventory阴影及毒列表因果继续只读。旧fixture也列后续，不把4源注释修正当整个pre94完成。\n''')
print('Four source current findings and bounded evidence written; no new closures, original ledger fence retained.')
