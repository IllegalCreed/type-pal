# coding: utf-8
from pathlib import Path
import json,gzip,hashlib,re,subprocess,collections
p=Path('docs/ops/evidence/QUALITY-PRE94-RETROSPECTIVE-1/core-comment-audit/runtime-projection-comments');base='bcec7f0fe1ecac8612c8d83374e4882f2c8f8f0a';sha=lambda b:hashlib.sha256(b).hexdigest()
for r in json.loads((p/'before.json').read_text())['files']:
 raw=gzip.decompress((p/r['snapshot']).read_bytes());assert raw==subprocess.check_output(['git','show',base+':'+r['path']]);assert sha(raw)==r['sha256'] and len(raw.splitlines())==r['lines'];assert r['readRanges']==[[1,r['lines']]]
d=json.loads((p/'read-boundaries.json').read_text())
for r in d['fullReads']:
 raw=Path(r['path']).read_bytes();assert sha(raw)==r['sha256'] and len(raw.splitlines())==r['lines'],r['path'];assert gzip.decompress((p/r['snapshot']).read_bytes())==raw
for r in d['partialReads']:
 raw=Path(r['path']).read_bytes();assert sha(raw)==r['sha256'] and len(raw.splitlines())==r['lines'];assert all(1<=a<=z<=r['lines'] for a,z in r['ranges']),r['path']
pairs=[]
def scan(x):
 if isinstance(x,list):
  for v in x:scan(v)
 elif isinstance(x,dict):
  if isinstance(x.get('raw'),str) and 'rawSha256' in x:
   raw=gzip.decompress((p/x['raw']).read_bytes());assert sha(raw)==x['rawSha256'] and len(raw)==x['rawBytes'];pairs.append(x['raw'])
  for v in x.values():scan(v)
for f in p.glob('*.json'):scan(json.loads(f.read_text()))
counts={}
for label,passed,files in [('direct',75,2),('adjacent',199,3)]:
 d=json.loads(gzip.decompress((p/(label+'.vitest.json.gz')).read_bytes()));cases=[a for r in d['testResults'] for a in r['assertionResults']];assert len(d['testResults'])==files and len(cases)==d['numPassedTests']==passed;assert d['numFailedTests']==d['numPendingTests']==0 and not d.get('unhandledErrors',[]);assert all(a['status']=='passed' for a in cases);raw=gzip.decompress((p/(label+'.raw.gz')).read_bytes()).decode();assert not re.search(r'^stderr\s*\||not wrapped in act|not configured to support act|Unhandled Errors|Unhandled Rejection|Uncaught Exception|Not implemented:',raw,re.M|re.I);counts[label]={'files':files,'passed':passed,'stderrBlocks':0,'act':0,'environment':0,'unhandled':0}
for r in json.loads((p/'emit-identity.json').read_text())['rows']:assert r['currentSha256']==sha(Path(r['path']).read_bytes()) and r['byteIdentical'] and r['parsedTypeScriptWithoutCommentsIdentical']
marker='<!-- original-source-fenced:start -->';path='docs/ops/audits/code-quality-file-ledger.md';old=subprocess.check_output(['git','show',base+':'+path]).decode();cur=Path(path).read_text();assert old.split(marker,1)[1]==cur.split(marker,1)[1]
# Only three old current source rows reopened, plus GameState newly read as review.
def ledger(s):return {m.group(1):m.group(2).strip() for l in s.split(marker,1)[0].splitlines() if (m:=re.match(r'^\| `([^`]+)` \| [^|]+ \| ([^|]+) \|',l))}
a,b=ledger(old),ledger(cur);changed={k:(a.get(k),b.get(k)) for k in set(a)|set(b) if a.get(k)!=b.get(k)};expected={r['path']:('已验证','review') for r in json.loads((p/'before.json').read_text())['files'] if r['path']!='packages/game/src/core/game-state.ts'};expected['packages/game/src/core/game-state.ts']=(None,'review');assert changed==expected,changed
assert Path('docs/testing/catalog.json').read_bytes()==subprocess.check_output(['git','show',base+':docs/testing/catalog.json'])
cohort=json.loads(Path('docs/ops/evidence/QUALITY-PRE94-RETROSPECTIVE-1/all-cards.json').read_text());counts83=dict(collections.Counter(c['currentReview'] for c in cohort['cards']));assert len(cohort['cards'])==83 and counts83=={'partial':50,'pending':33} and not any(c['currentAcceptance'] for c in cohort['cards'])
# No tests, public types, baseline/retirement or settings changed. AST/JS proof covers source syntax.
changedPaths=subprocess.check_output(['git','diff','--name-only']).decode().splitlines();sourcePaths=[x for x in changedPaths if x.startswith(('packages/','scripts/'))];assert set(sourcePaths)=={r['path'] for r in json.loads((p/'before.json').read_text())['files']}
print(json.dumps({'rawPairsVerified':len(pairs),'beforeSources':'Exact bcec7 Git blobs; four full implementation reads','currentReadBoundaries':'SHA, lines, actual ranges and full snapshots match','runtimeRegression':counts,'syntaxAndJS':'Both unchanged beyond comments','ledgerChanges':changed,'ledgerHistoricalBytes':'Exact','testingCatalog':'Byte-identical','cohort':{'total':83,**counts83,'accept':0},'newClosures':0},ensure_ascii=False))
