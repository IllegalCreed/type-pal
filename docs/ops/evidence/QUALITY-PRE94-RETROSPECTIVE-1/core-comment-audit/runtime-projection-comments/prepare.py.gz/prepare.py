# coding: utf-8
from pathlib import Path
import json,gzip,hashlib,subprocess
p=Path('docs/ops/evidence/QUALITY-PRE94-RETROSPECTIVE-1/core-comment-audit/runtime-projection-comments');p.mkdir()
d=json.loads(Path('/tmp/type-pal-projection-read-progress.json').read_text());base=d['base'];files=[]
for r in d['rows']:
 raw=Path(r['path']).read_bytes();assert hashlib.sha256(raw).hexdigest()==r['sha256'];assert raw==subprocess.check_output(['git','show',base+':'+r['path']]);name=Path(r['path']).name+'.before.gz';(p/name).write_bytes(gzip.compress(raw,mtime=0));files.append(dict(r,snapshot=name))
(p/'before.json').write_text(json.dumps({'base':base,'files':files,'scope':'Full implementation read; no full-file acceptance. All edits limited to comments.'},ensure_ascii=False,indent=2)+'\n')
# Scope recorded before implementation edits. It does not predeclare gate results.
f=Path('docs/ops/tasks/QUALITY-PRE94-RETROSPECTIVE-1.md');f.write_text(f.read_text()+'''\n## 2026-10-18 runtime投影注释有限准入\n\nCodex premise verified / design agree / build allowed：bcec7f0fe基点，同一3y树单Owner，完整读取attack.ts 614行、battle-system.ts 3141行、game-state.ts 2111行、battle-state.ts 918行。白名单仅这四源的事实注释；生产bootstrap投影、装备effective getter/0x30刷新、outside-battle 0x2D、开战seed与终态cleanup均已按实际边界核读，SDLPal getter/选靶/自动选法术/入场函数/状态设置清除逐项对照。纠正runtime裸值、快照与HP/MP回写边界，状态表不限装备，自动目标Confirm记忆、随机评分与动作游标hold错注。\n\n不改变可执行逻辑、schema/save/UI/公开类型接口，不借此处理装备重建时序等未有反例的假设。all-HP0+Puppet不是新机制counter：C仅改fOnlyPuppet未清fEnded，照样判负；hidden runtime stash仍在，不能宣称已迁到WeakMap。原假设明确排除。计划四源removeComments编译字节对照、已有定向/相邻回归与game typecheck；全仓check/official ratchet/protected仍留大任务收尾。注释信用与整文件验收分开，未知继续review，不扩大103+或94–102优先级。\n''')
f=Path('docs/ops/evidence/QUALITY-PRE94-RETROSPECTIVE-1/core-comment-audit/README.md');f.write_text(f.read_text()+'\n后续[runtime投影与战斗宿主注释](runtime-projection-comments/README.md)核四源、真实写入/消费与原C，只更正事实注释；门与状态以该片回执为准，不恢复旧统一门信用。\n')
print('Four source snapshots and comment-only build scope recorded.')
