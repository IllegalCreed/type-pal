# -*- coding: utf-8 -*-
from pathlib import Path
import gzip,hashlib,json,subprocess
out=Path('docs/ops/evidence/QUALITY-PRE94-RETROSPECTIVE-1/supplementary-audit');sha=lambda b:hashlib.sha256(b).hexdigest();c=json.loads((out/'controls-current.json').read_text())
assert c['sourceRestored'] and c['specRestored'] and len(c['rows'])==14
for r in c['rows']:
 raw=gzip.decompress((out/r['raw']).read_bytes());assert sha(raw)==r['rawSha256']
 assert r['runtimeErrorSuites']==0 and r['signal'] is None and r['spawnError'] is None
 if r['version']=='old':assert r['passed']==8 and r['failed']==0 and r['exit']==0
 else:assert r['passed']==0 and r['failed']==1 and r['exit']==1 and len(r['failureMessages'])==1 and 'AssertionError' in r['failureMessages'][0]
spec=Path('packages/game/src/core/save/__tests__/api.test.ts');api=Path('packages/game/src/core/save/api.ts');assert sha(spec.read_bytes())==c['restoredSpecSha256'];assert sha(api.read_bytes())==c['restoredSourceSha256'];assert api.read_bytes()==subprocess.check_output(['git','show','HEAD:'+str(api)])
assert gzip.decompress((out/'api-before.test.ts.gz').read_bytes())==subprocess.check_output(['git','show','2daed1bb7:'+str(spec)])
for r in json.loads((out/'read-boundaries.json').read_text())['fullReads']:
 b=Path(r['path']).read_bytes();assert sha(b)==r['sha256'] and len(b.decode().splitlines())==r['lines'],r['path']
for label in ['direct-current','typecheck-current','docs','lint','ledger']:
 r=json.loads((out/(label+'.json')).read_text());raw=gzip.decompress((out/(label+'.raw.gz')).read_bytes());assert r['exit']==0 and r['signal'] is None and r['spawnError'] is None and len(raw)==r['rawBytes'] and sha(raw)==r['rawSha256']
v=json.loads(gzip.decompress((out/'direct-current.vitest.json.gz').read_bytes()));assert v['numPassedTests']==41 and v['numFailedTests']==0 and v.get('numRuntimeErrorTestSuites',0)==0
assert subprocess.check_output(['git','diff','--name-only','--','packages','scripts']).decode().splitlines()==[str(spec)]
print('PASS: exact final seven old-green/new-business-red mutation pairs, restored source/spec, original old spec, all named read SHA/line bounds, full native raw hashes and current41 green; only api.test changes in packages/scripts. Hash verification grants no broader semantic acceptance.')
