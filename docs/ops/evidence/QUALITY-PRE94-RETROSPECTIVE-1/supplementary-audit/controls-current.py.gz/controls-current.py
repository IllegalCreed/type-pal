# -*- coding: utf-8 -*-
from pathlib import Path
import datetime,gzip,hashlib,json,subprocess
root=Path.cwd(); out=root/'docs/ops/evidence/QUALITY-PRE94-RETROSPECTIVE-1/supplementary-audit'
prod=Path('packages/game/src/core/save/api.ts'); spec=Path('packages/game/src/core/save/__tests__/api.test.ts')
original=prod.read_bytes(); current=spec.read_bytes(); old=gzip.decompress((out/'api-before.test.ts.gz').read_bytes())
needle='return entry ? deepClone(entry.gs) : null'; assert original.decode().count(needle)==1
mutations=[(name, f'if (!entry) return null\n    const loaded = deepClone(entry.gs)\n    {assignment}\n    return loaded','round-trip preserves gameplay fields') for name,assignment in [('scene','loaded.wNumScene = 0'),('saved-times','loaded.wSavedTimes = 0'),('hp','loaded.PlayerRolesRuntime.rgwHP[0] = 0'),('level','loaded.PlayerRolesRuntime.rgwLevel[1] = 0'),('inventory','loaded.inventory = []')]]
mutations += [('read-alias','return entry ? entry.gs : null','loadSlot returns an independent snapshot'),('read-shallow','return entry ? { ...entry.gs } : null','loadSlot returns an independent snapshot')]
sha=lambda b:hashlib.sha256(b).hexdigest(); rows=[]
(out/'api-production-before.ts.gz').write_bytes(gzip.compress(original,mtime=0))
try:
 for name,replacement,selection in mutations:
  mutant=original.decode().replace(needle,replacement).encode(); prod.write_bytes(mutant)
  for version,blob in [('old',old),('new',current)]:
   spec.write_bytes(blob); label=f'current-control-{name}-{version}'; report=Path('/tmp')/(label+'.json')
   cmd=['pnpm','--filter','@type-pal/game','exec','vitest','run','src/core/save/__tests__/api.test.ts','--maxWorkers=1','--reporter=default','--reporter=json','--outputFile='+str(report)]
   if version=='new':cmd += ['-t',selection]
   started=datetime.datetime.now(datetime.timezone.utc).isoformat(); p=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT); raw=p.stdout; v=json.loads(report.read_text()); failed=[a for f in v['testResults'] for a in f['assertionResults'] if a['status']=='failed']
   (out/(label+'.raw.gz')).write_bytes(gzip.compress(raw,mtime=0)); (out/(label+'.vitest.json.gz')).write_bytes(gzip.compress(report.read_bytes(),mtime=0))
   rows.append({'id':name,'version':version,'command':cmd,'cwd':str(root),'startedAt':started,'completedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit':p.returncode,'signal':-p.returncode if p.returncode<0 else None,'spawnError':None,'sourceSha256':sha(original),'mutantSha256':sha(mutant),'specSha256':sha(blob),'replace':{'before':needle,'after':replacement},'passed':v['numPassedTests'],'failed':v['numFailedTests'],'runtimeErrorSuites':v.get('numRuntimeErrorTestSuites',0),'fullNames':[{'file':f['name'],'name':a['fullName'],'status':a['status']} for f in v['testResults'] for a in f['assertionResults']],'failureMessages':[m for a in failed for m in a.get('failureMessages',[])],'raw':label+'.raw.gz','rawBytes':len(raw),'rawSha256':sha(raw),'fullUncutMergedStdoutStderr':True})
   if version=='old':assert p.returncode==0 and v['numPassedTests']==8 and v['numFailedTests']==0
   else:assert p.returncode==1 and len(failed)==1 and v['numFailedTests']==1 and v.get('numRuntimeErrorTestSuites',0)==0 and any('AssertionError' in m for a in failed for m in a.get('failureMessages',[]))
   print(label, v['numPassedTests'],v['numFailedTests'],flush=True)
finally:
 prod.write_bytes(original);spec.write_bytes(current)
 proof={'base':subprocess.check_output(['git','rev-parse','HEAD']).decode().strip(),'scope':'Seven precise mutations: old eight-test spec remains green; new selected business contract fails exactly once. No production repair claimed. New filtered runs mark eight unselected tests pending; they receive no control credit.','sourceRestored':sha(prod.read_bytes())==sha(original),'specRestored':sha(spec.read_bytes())==sha(current),'originalSourceSha256':sha(original),'restoredSourceSha256':sha(prod.read_bytes()),'originalSpecSha256':sha(current),'restoredSpecSha256':sha(spec.read_bytes()),'rows':rows};(out/'controls-current.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n')
print('restored production and final spec byte-for-byte',flush=True)
