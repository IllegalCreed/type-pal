from pathlib import Path
import json,hashlib,subprocess,gzip
base='4b86b04b790eb6b83f93a10f4ac07102c608b39b';prefix=Path('docs/phase-governance/reviews');out=Path('docs/ops/evidence/QUALITY-PRE94-RETROSPECTIVE-1/3z-google-analytics')
targets={'20261004-semantic-current-batch.json':['docs/ops/board.md','docs/ops/tasks/index.md'],'20261016-historical-cards-d.json':['docs/ops/audits/code-quality-file-ledger.md'],'20261017-r93-phase-governance-artifacts.json':[str(prefix/'20261004-semantic-current-batch.json'),str(prefix/'20261016-historical-cards-d.json')],'20261017-r94-final-machine-artifacts.json':[str(prefix/'20261017-r93-phase-governance-artifacts.json')]}
for fn,paths in targets.items():
 p=prefix/fn;lines=p.read_text().splitlines()
 for target in paths:
  pi=next(i for i,l in enumerate(lines) if l==f'      "path": "{target}",');st=next(i for i in range(pi,-1,-1) if lines[i]=='    {');en=next(i for i in range(pi+1,len(lines)) if lines[i] in ['    },','    }']);hi=next(i for i in range(st,en) if lines[i]=='        "history": [');blob=Path(target).read_bytes();cur=hashlib.sha256(blob).hexdigest();old=hashlib.sha256(subprocess.check_output(['git','show',base+':'+target])).hexdigest();assert cur!=old
  item={'revision':base,'date':'2026-10-18','action':'Review GA implementation and tests with shared owned host; record failed-install risk','previousAfterSha256':old,'scope':'Three unlisted pending GA paths and one new test fixture are review only, zero closure. Execution unchanged beyond one catch-scope comment; main8 to9/H05 remains4 with exact assertion transfers, five whole-file old-green/new-specific-AssertionError controls, outer-owner isolation old8-green/1-red to current10-green, formal13direct/12adjacent and typecheck. Actual failed-install ownership counter is a separate draft and awaits user choice; no product build allowed. Only CODE3z pending to partial;83cards53partial/30pending/0accept, scopeConfirmed=false. Bounded board progress/new draft row, generated index adds its one task. No baseline/retirement/schema/save/API/assets or historical native verdict changes.','evidence':str(out/'README.md'),'notRun':['whole-repository check','official coverage ratchet','protected fast','browser visual','E2E']}
  block=['          '+l for l in json.dumps(item,ensure_ascii=False,indent=2).splitlines()];block[-1]+=',';lines[hi+1:hi+1]=block;en+=len(block)
  for i in range(st,en):
   if lines[i].startswith('      "afterSha256": '):lines[i]=f'      "afterSha256": "{cur}",'
   elif lines[i].startswith('        "implementationSha": '):lines[i]=f'        "implementationSha": "{cur}",'
   elif lines[i].startswith('        "afterSha256": '):lines[i]=f'        "afterSha256": "{cur}",'
   elif lines[i].startswith('      "reviewedLines": '):lines[i]=f'      "reviewedLines": "1-{len(blob.decode().splitlines())}",'
 p.write_text('\n'.join(lines)+'\n');subprocess.run(['pnpm','exec','biome','format','--write',str(p)],check=True,stdout=subprocess.PIPE)
(out/'review-chain-producer.py.gz').write_bytes(gzip.compress(Path('/tmp/type-pal-ga-chain.py').read_bytes(),mtime=0));print('Four bounded current board/ledger incoming bindings updated; original native verdict/history unchanged.')
