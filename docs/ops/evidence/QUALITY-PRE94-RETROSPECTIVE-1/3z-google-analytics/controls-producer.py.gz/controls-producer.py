from pathlib import Path
import json,gzip,hashlib,subprocess,tempfile,shutil,datetime
root=Path.cwd();out=root/'docs/ops/evidence/QUALITY-PRE94-RETROSPECTIVE-1/3z-google-analytics';sha=lambda b:hashlib.sha256(b).hexdigest();before=json.loads((out/'before.json').read_text());oldspec={r['path']:gzip.decompress((out/r['snapshot']).read_bytes()) for r in before['files']};source='packages/game/src/analytics/google-analytics.ts';main='packages/game/src/analytics/google-analytics.test.ts';leaves='packages/game/src/analytics/google-analytics.boundaries.test.ts'
def once(s,a,b):
 assert s.count(a)==1,(a,s.count(a));return s.replace(a,b)
controls=[
 ('automatic-page-view',main,8,9,'内建gtag采用arguments队列',lambda s:once(s,'send_page_view: false','send_page_view: true')),
 ('page-unsubscribe-missing',main,8,9,'stop后同意与页面两订阅',lambda s:once(s,'    unsubscribePage()','    void unsubscribePage')),
 ('reload-resets-command-state',main,8,9,'标签加载失败后可重试',lambda s:once(s,'        script.remove()','        script.remove()\n        initialized = false')),
 ('utm-term-leak',leaves,4,4,'UTM 64保留',lambda s:once(s,"['source', 'medium', 'campaign', 'content']","['source', 'medium', 'campaign', 'content', 'term']")),
 ('id-six-rejected',leaves,4,4,'项目ID格式归一化',lambda s:once(s,'{6,20}','{7,20}')),
]
current={r['path']:(root/r['path']).read_bytes() for r in before['files']};tmp=Path(tempfile.mkdtemp(prefix='type-pal-ga-controls-'));results=[]
try:
 for label,spec,oldN,newN,target,mutate in controls:
  mutant=mutate(current[source].decode()).encode();assert mutant!=current[source];(out/(label+'.mutant.gz')).write_bytes(gzip.compress(mutant,mtime=0));row={'id':label,'source':source,'spec':spec,'sourceSha256':sha(current[source]),'mutantSha256':sha(mutant),'expectedNewFailureNameContains':target,'expectedOldCount':oldN,'expectedCurrentCount':newN,'runs':{}}
  for phase,body in [('old',oldspec[spec]),('current',current[spec])]:
   report=tmp/(label+'.'+phase+'.json');cmd=['pnpm','--filter','@type-pal/game','exec','vitest','run',spec.removeprefix('packages/game/'),'--reporter=verbose','--reporter=json','--outputFile.json='+str(report)];started=datetime.datetime.now(datetime.timezone.utc).isoformat();n=oldN if phase=='old' else newN
   try:
    (root/source).write_bytes(mutant);(root/spec).write_bytes(body);proc=subprocess.run(cmd,cwd=root,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);raw=proc.stdout;(out/(label+'.'+phase+'.raw.gz')).write_bytes(gzip.compress(raw,mtime=0));native=report.read_bytes() if report.exists() else b''
    if native:(out/(label+'.'+phase+'.vitest.json.gz')).write_bytes(gzip.compress(native,mtime=0))
    record={'command':cmd,'cwd':str(root),'startedAt':started,'completedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit':proc.returncode,'signal':-proc.returncode if proc.returncode<0 else None,'spawnError':None,'raw':label+'.'+phase+'.raw.gz','rawBytes':len(raw),'rawSha256':sha(raw),'fullUncutMergedStdoutStderr':True,'specSha256':sha(body),'nativeReport':label+'.'+phase+'.vitest.json.gz','nativeSha256':sha(native)};row['runs'][phase]=record
    assert native;data=json.loads(native);cases=[a for f in data['testResults'] for a in f['assertionResults']];failed=[a for a in cases if a['status']=='failed'];record.update({'passed':data['numPassedTests'],'failed':data['numFailedTests'],'pending':data['numPendingTests'],'cases':[{'file':f['name'],'fullName':a['fullName'],'status':a['status']} for f in data['testResults'] for a in f['assertionResults']]})
    assert len(cases)==n and data['numPendingTests']==0 and not data.get('unhandledErrors',[]) and all(a['status'] in ['passed','failed'] for a in cases)
    assert 'stderr |' not in raw.decode()
    if phase=='old':assert proc.returncode==0 and not failed and data['numPassedTests']==n
    else:
     assert proc.returncode==1 and len(failed)==1 and data['numPassedTests']==n-1 and target in failed[0]['fullName'] and failed[0]['failureMessages'] and all('AssertionError' in m for m in failed[0]['failureMessages']);record['failureMessages']=failed[0]['failureMessages']
   finally:
    (root/source).write_bytes(current[source]);(root/spec).write_bytes(current[spec]);record=row['runs'].get(phase)
    if record:record.update({'sourceRestoredSha256':sha((root/source).read_bytes()),'specRestoredSha256':sha((root/spec).read_bytes()),'sourceRestoredByteForByte':(root/source).read_bytes()==current[source],'specRestoredByteForByte':(root/spec).read_bytes()==current[spec]})
  results.append(row);print(label+': old'+str(oldN)+' passed; current'+str(newN-1)+' passed/1 specified AssertionError',flush=True)
finally:
 for path,body in current.items():(root/path).write_bytes(body)
 shutil.rmtree(tmp);summary={'base':before['base'],'owner':'Codex single agent','scope':'Whole unfiltered old/current test file per one source mutant. No SDK network or visual acceptance.','controls':results,'tempDirectory':str(tmp),'tempDirectoryRemoved':not tmp.exists(),'restored':all((root/k).read_bytes()==v for k,v in current.items())};(out/'controls.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n');(out/'controls-producer.py.gz').write_bytes(gzip.compress(Path('/tmp/type-pal-ga-controls.py').read_bytes(),mtime=0))
assert len(results)==len(controls) and summary['restored']
