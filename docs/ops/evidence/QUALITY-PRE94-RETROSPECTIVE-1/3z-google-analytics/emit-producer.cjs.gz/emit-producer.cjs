const fs = require('node:fs')
const zlib = require('node:zlib')
const crypto = require('node:crypto')
const ts = require('node:module').createRequire(process.cwd() + '/package.json')('typescript')
const p = 'docs/ops/evidence/QUALITY-PRE94-RETROSPECTIVE-1/3z-google-analytics/'
const meta = JSON.parse(fs.readFileSync(p + 'before.json'))
const digest = data => crypto.createHash('sha256').update(data).digest('hex')
const rows = meta.files.slice(0, 1).map(row => {
  const before = zlib.gunzipSync(fs.readFileSync(p + row.snapshot))
  const current = fs.readFileSync(row.path)
  if (digest(before) !== row.sha256) throw new Error('before snapshot hash mismatch: ' + row.path)
  const emit = source => ts.transpileModule(source.toString(), { fileName: row.path, compilerOptions: { module: ts.ModuleKind.ESNext, target: ts.ScriptTarget.ES2022, removeComments: true, newLine: ts.NewLineKind.LineFeed } }).outputText
  const printTypeScript = source => ts.createPrinter({ removeComments: true, newLine: ts.NewLineKind.LineFeed }).printFile(ts.createSourceFile(row.path, source.toString(), ts.ScriptTarget.Latest, true, ts.ScriptKind.TS))
  if (printTypeScript(before) !== printTypeScript(current)) throw new Error('Parsed TypeScript changed beyond comments: ' + row.path)
  const oldEmit = emit(before)
  const newEmit = emit(current)
  if (oldEmit !== newEmit) throw new Error('JavaScript bytes changed: ' + row.path)
  return { path: row.path, beforeSha256: digest(before), currentSha256: digest(current), removeCommentsJavaScriptSha256: digest(newEmit), byteIdentical: true, parsedTypeScriptWithoutCommentsIdentical: true }
})
fs.writeFileSync(p + 'emit-identity.json', JSON.stringify({ typescript: ts.version, scope: 'Only google-analytics.ts implementation, same transpile options; not native/gameplay/whole-file acceptance', rows }, null, 2) + '\n')
console.log(JSON.stringify({ files: rows.length, byteIdentical: rows.every(row => row.byteIdentical) }))
