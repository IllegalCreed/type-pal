from pathlib import Path
import tempfile,subprocess,json,gzip,hashlib,shutil,datetime
root=Path.cwd();out=root/'docs/ops/evidence/QUALITY-PRE94-RETROSPECTIVE-1/3z-google-analytics';tmp=Path(tempfile.mkdtemp(prefix='ga-init-review-',dir=root/'packages/game/src/analytics'));src=tmp/'initialization.probe.test.ts';report=tmp/'native.json';sha=lambda b:hashlib.sha256(b).hexdigest();before={str(p):sha(p.read_bytes()) for p in [root/'packages/game/src/analytics/google-analytics.ts',root/'packages/game/src/analytics/install-analytics.ts',root/'packages/game/src/analytics/analytics-consent.ts']}
body="""import { expect, it, vi } from 'vitest'
import { installTypePalAnalytics } from '../install-analytics.js'
import { writeAnalyticsConsent } from '../analytics-consent.js'

it('failed analytics installation leaves no consent reaction after SDK recovers', () => {
  const key = 'type-pal.analytics-consent.v1'
  const original = localStorage.getItem(key)
  const names = ['gtag', 'dataLayer', 'ga-disable-G-9Q2XJV7NJ6']
  const descriptors = names.map((name) => [name, Object.getOwnPropertyDescriptor(window, name)] as const)
  const doc = document.implementation.createHTMLDocument('owned probe')
  const listeners = vi.spyOn(window, 'addEventListener')
  const failure = new Error('owned SDK initialization failure')
  try {
    localStorage.setItem(key, 'granted')
    for (const name of names) Reflect.deleteProperty(window, name)
    Object.defineProperty(window, 'gtag', { configurable: true, writable: true, value: () => { throw failure } })
    let caught: unknown
    try { installTypePalAnalytics({ enabled: true, window, document: doc, navigator: {} }) }
    catch (error) { caught = error }
    expect(caught).toBe(failure)
    const recoveredGtag = vi.fn()
    Object.defineProperty(window, 'gtag', { configurable: true, writable: true, value: recoveredGtag })
    expect(writeAnalyticsConsent('denied')).toBe(true)
    expect(writeAnalyticsConsent('granted')).toBe(true)
    expect(recoveredGtag).not.toHaveBeenCalled()
  } finally {
    for (const [type, listener, options] of listeners.mock.calls) window.removeEventListener(type, listener, options)
    listeners.mockRestore()
    doc.head.replaceChildren(); doc.body.replaceChildren()
    for (const [name, descriptor] of descriptors) {
      if (descriptor) Object.defineProperty(window, name, descriptor)
      else Reflect.deleteProperty(window, name)
    }
    if (original === null) localStorage.removeItem(key)
    else localStorage.setItem(key, original)
  }
})
"""
src.write_text(body);(out/'initialization-probe.test.ts.gz').write_bytes(gzip.compress(body.encode(),mtime=0));cmd=['pnpm','--filter','@type-pal/game','exec','vitest','run','src/analytics/google-analytics.test.ts','src/analytics/google-analytics.boundaries.test.ts',str(src.relative_to(root/'packages/game')),'--reporter=verbose','--reporter=json','--outputFile.json='+str(report)];started=datetime.datetime.now(datetime.timezone.utc).isoformat();result={}
try:
 proc=subprocess.run(cmd,cwd=root,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);raw=proc.stdout;(out/'initialization-probe.raw.gz').write_bytes(gzip.compress(raw,mtime=0));native=report.read_bytes();(out/'initialization-probe.vitest.json.gz').write_bytes(gzip.compress(native,mtime=0));d=json.loads(native);failed=[a for f in d['testResults'] for a in f['assertionResults'] if a['status']=='failed'];result={'command':cmd,'cwd':str(root),'startedAt':started,'completedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit':proc.returncode,'signal':-proc.returncode if proc.returncode<0 else None,'spawnError':None,'raw':'initialization-probe.raw.gz','rawBytes':len(raw),'rawSha256':sha(raw),'fullUncutMergedStdoutStderr':True,'nativeReport':'initialization-probe.vitest.json.gz','nativeSha256':sha(native),'passed':d['numPassedTests'],'failed':d['numFailedTests'],'pending':d['numPendingTests'],'cases':[{'file':f['name'],'fullName':a['fullName'],'status':a['status']} for f in d['testResults'] for a in f['assertionResults']]};assert proc.returncode==1 and d['numPassedTests']==12 and d['numFailedTests']==1 and d['numPendingTests']==0 and not d.get('unhandledErrors',[]) and len(failed)==1 and failed[0]['fullName']=='failed analytics installation leaves no consent reaction after SDK recovers' and all('AssertionError' in m for m in failed[0]['failureMessages']);result['failureMessages']=failed[0]['failureMessages'];print('Actual install/Storage/window consent path: old12 passed; one specified cleanup AssertionError. No product source edits.');print(failed[0]['failureMessages'][0][:1100])
finally:
 shutil.rmtree(tmp);result.update({'productSourcesSha256':before,'productSourcesByteExact':all(sha(Path(path).read_bytes())==value for path,value in before.items()),'temporaryTree':str(tmp),'temporaryTreeRemoved':not tmp.exists(),'scope':'Read-only lifecycle counter: owned throwing SDK port, actual install and consent APIs, inert Document. No real Google endpoint, no product fix approval.'});(out/'initialization-probe.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');(out/'probe-producer.py.gz').write_bytes(gzip.compress(Path('/tmp/type-pal-ga-probe.py').read_bytes(),mtime=0))
