from pathlib import Path
import gzip
f=Path('packages/game/src/analytics/google-analytics.ts');s=f.read_text();old='// Analytics 是可选能力，任何异常都不得影响游戏启动、输入或渲染。';assert s.count(old)==1;s=s.replace(old,'// 此处只隔离URL/发送阶段异常；初始initialize/readPage不在本catch内，见安装失败ownership卡。');f.write_text(s)
Path('packages/game/src/analytics/google-analytics.test-fixtures.ts').write_text('''import { afterEach, beforeEach } from 'vitest'
import type { AnalyticsConsent } from './analytics-consent.js'
import { type AnalyticsPage, startGoogleAnalytics } from './google-analytics.js'

export interface GoogleAnalyticsHarnessOptions {
  enabled?: boolean
  measurementId?: string
  consent?: AnalyticsConsent
  page?: AnalyticsPage
  subscribePage?: boolean
}

function sdkKeys(): string[] {
  return [
    'dataLayer',
    'gtag',
    ...Object.getOwnPropertyNames(window).filter((key) => key.startsWith('ga-disable-')),
  ]
}

function isCommand(value: unknown): value is ArrayLike<unknown> {
  return (
    value !== null &&
    typeof value === 'object' &&
    'length' in value &&
    typeof value.length === 'number' &&
    Number.isInteger(value.length) &&
    value.length >= 0 &&
    value.length <= 16
  )
}

/**
 * Only the SDK globals, public event-source ports and an owned inert Document are fixture state.
 * The real controller runs; scripts are DOM artifacts, not downloaded SDK/network evidence.
 * Test-facing stop always calls the actual stop; host cleanup cannot hide a failed unsubscribe
 * from assertions made before afterEach. Finally releases remaining owned ports/descriptors.
 */
export function useGoogleAnalyticsTestHost() {
  let doc = document.implementation.createHTMLDocument('GA test host')
  const saved = new Map<string, PropertyDescriptor | undefined>()
  const stops = new Set<() => void>()
  const releases = new Set<() => void>()
  beforeEach(() => {
    saved.clear()
    for (const key of sdkKeys()) {
      saved.set(key, Object.getOwnPropertyDescriptor(window, key))
      Reflect.deleteProperty(window, key)
    }
    doc = document.implementation.createHTMLDocument('GA test host')
  })
  afterEach(() => {
    try {
      for (const stop of stops) stop()
    } finally {
      for (const release of releases) release()
      doc.head.replaceChildren()
      doc.body.replaceChildren()
      for (const key of sdkKeys()) Reflect.deleteProperty(window, key)
      for (const [key, descriptor] of saved) {
        if (descriptor) Object.defineProperty(window, key, descriptor)
      }
      stops.clear()
      releases.clear()
      saved.clear()
    }
  })

  const entries = (): unknown[] => {
    const value: unknown = Reflect.get(window, 'dataLayer')
    return Array.isArray(value) ? value : []
  }
  const commands = (): unknown[][] =>
    entries().map((entry) => (isCommand(entry) ? Array.from(entry) : [entry]))

  return {
    get document(): Document {
      return doc
    },
    entries,
    commands,
    events: (): unknown[][] =>
      commands().filter((entry) => entry[0] === 'event' && entry[1] === 'page_view'),
    readProperty: (name: string): unknown => Reflect.get(window, name),
    setGtag(gtag: (...args: unknown[]) => void): void {
      Object.defineProperty(window, 'gtag', { configurable: true, writable: true, value: gtag })
    },
    create(options: GoogleAnalyticsHarnessOptions = {}) {
      let consent: AnalyticsConsent = options.consent ?? 'unset'
      let page: AnalyticsPage = options.page ?? {
        path: '/?utm_source=DEV&scene=75&pos=1,2&facing=3&give=999#battle',
        title: '仙剑奇侠传 · type-pal',
      }
      let onConsent: ((next: AnalyticsConsent) => void) | undefined
      let onPage: ((next: AnalyticsPage) => void) | undefined
      const releaseConsent = (): void => { onConsent = undefined }
      const releasePage = (): void => { onPage = undefined }
      releases.add(releaseConsent)
      releases.add(releasePage)
      const actualStop = startGoogleAnalytics({
        enabled: options.enabled ?? true,
        measurementId: options.measurementId ?? 'G-TEST12345',
        window,
        document: doc,
        readConsent: () => consent,
        subscribeConsent: (listener) => {
          onConsent = listener
          return releaseConsent
        },
        readPage: () => page,
        ...(options.subscribePage === false ? {} : {
          subscribePage: (listener: (next: AnalyticsPage) => void) => {
            onPage = listener
            return releasePage
          },
        }),
      })
      let stoppedByTest = false
      stops.add(() => { if (!stoppedByTest) actualStop() })
      return {
        stop(): void {
          actualStop()
          stoppedByTest = true
        },
        grant(): void { consent = 'granted'; onConsent?.(consent) },
        deny(): void { consent = 'denied'; onConsent?.(consent) },
        navigate(next: AnalyticsPage): void { page = next; onPage?.(page) },
      }
    },
  }
}
''')
Path('packages/game/src/analytics/google-analytics.test.ts').write_text('''import { describe, expect, it, vi } from 'vitest'
import { sanitizePageViewUrl } from './google-analytics.js'
import { useGoogleAnalyticsTestHost } from './google-analytics.test-fixtures.js'

const host = useGoogleAnalyticsTestHost()

describe('minimal Google Analytics page view', () => {
  it('非生产或 Measurement ID 非法时零副作用', () => {
    host.create({ enabled: false, consent: 'granted' })
    host.create({ measurementId: 'invalid', consent: 'granted' })
    expect(host.document.querySelector('script[data-ga4-measurement-id]')).toBeNull()
    expect(host.readProperty('dataLayer')).toBeUndefined()
    expect(host.readProperty('gtag')).toBeUndefined()
  })

  it('unset/denied 不加载；granted 只加载并记录当前页一次', () => {
    const harness = host.create()
    expect(host.document.querySelector('script[data-ga4-measurement-id]')).toBeNull()
    expect(host.entries()).toEqual([])
    harness.deny()
    expect(host.document.querySelector('script[data-ga4-measurement-id]')).toBeNull()
    expect(host.entries()).toEqual([])
    harness.grant()
    harness.grant()
    expect(host.document.querySelectorAll('script[data-ga4-measurement-id]')).toHaveLength(1)
    expect(host.events()).toEqual([['event', 'page_view', {
      page_path: '/',
      page_location: 'http://localhost:3000/?utm_source=dev',
      page_title: '仙剑奇侠传 · type-pal',
    }]])
  })

  it('P1: 只保留 pathname 与合法 UTM，丢弃所有游戏参数和 hash', () => {
    expect(sanitizePageViewUrl(
      '/play?utm_source=DEV&utm_medium=Video&utm_campaign=PAL-Launch&utm_content=Intro&scene=75&pos=1,2&facing=3&give=999#battle',
      'https://pal.illegalscreed.cn',
    )).toBe('https://pal.illegalscreed.cn/play?utm_source=dev&utm_medium=video&utm_campaign=pal-launch&utm_content=intro')
  })

  it('G1/P3: 同 pathname 去重、场景事件不计页、撤回后停发', () => {
    const harness = host.create({ consent: 'granted' })
    expect(host.events()).toHaveLength(1)
    window.dispatchEvent(new CustomEvent('typepal:scene-change', { detail: 75 }))
    expect(host.events()).toHaveLength(1)
    harness.navigate({ path: '/?scene=80', title: 'scene 80' })
    expect(host.events()).toHaveLength(1)
    harness.navigate({ path: '/manual', title: 'manual' })
    expect(host.events()).toHaveLength(2)
    expect(host.events()[1]?.[2]).toEqual({
      page_path: '/manual', page_location: 'http://localhost:3000/manual', page_title: 'manual',
    })
    harness.deny()
    harness.navigate({ path: '/privacy', title: 'privacy' })
    expect(host.events()).toHaveLength(2)
  })

  it('URL解析失败后仍可处理后续合法页面', () => {
    const harness = host.create({ consent: 'granted', page: { path: 'https://[invalid', title: 'invalid' } })
    expect(host.events()).toHaveLength(0)
    expect(() => harness.navigate({ path: '/manual', title: 'manual' })).not.toThrow()
    expect(host.events()).toHaveLength(1)
    // SDK初始化异常不由此例证明,另见失败安装ownership反例。
  })

  it('复用既有 gtag 与 script，不重复注入', () => {
    const script = host.document.createElement('script')
    script.dataset.ga4MeasurementId = 'G-TEST12345'
    host.document.head.append(script)
    const gtag = vi.fn()
    host.setGtag(gtag)
    host.create({ consent: 'granted' })
    expect(host.document.querySelectorAll('script[data-ga4-measurement-id]')).toHaveLength(1)
    expect(host.document.querySelector('script[data-ga4-measurement-id]')).toBe(script)
    expect(host.readProperty('gtag')).toBe(gtag)
    expect(gtag).toHaveBeenCalledWith('event', 'page_view', {
      page_path: '/', page_location: 'http://localhost:3000/?utm_source=dev', page_title: '仙剑奇侠传 · type-pal',
    })
  })

  it('标签加载失败后可重试且不重复排队当前页', () => {
    const harness = host.create()
    harness.grant()
    const failedScript = host.document.querySelector<HTMLScriptElement>('script[data-ga4-measurement-id]')!
    expect(failedScript).not.toBeNull()
    failedScript.dispatchEvent(new Event('error'))
    expect(host.document.querySelectorAll('script[data-ga4-measurement-id]')).toHaveLength(0)
    harness.grant()
    const retryScript = host.document.querySelector<HTMLScriptElement>('script[data-ga4-measurement-id]')
    expect(retryScript).not.toBe(failedScript)
    expect(host.document.querySelectorAll('script[data-ga4-measurement-id]')).toHaveLength(1)
    expect(host.events()).toHaveLength(1)
    expect(host.commands().map((command) => command[0])).toEqual(['js', 'config', 'event'])
  })

  it('内建gtag采用arguments队列并关闭自动page_view', () => {
    host.create({ consent: 'granted' })
    const entries = host.entries()
    expect(entries).toHaveLength(3)
    for (const entry of entries) expect(Object.prototype.toString.call(entry)).toBe('[object Arguments]')
    const commands = host.commands()
    expect(commands[0]?.[0]).toBe('js')
    expect(commands[0]?.[1]).toBeInstanceOf(Date)
    expect(commands[1]?.slice(0, 2)).toEqual(['config', 'G-TEST12345'])
    expect(commands[1]?.[2]).toEqual(expect.objectContaining({ send_page_view: false }))
  })

  it('stop后同意与页面两订阅均不再触发', () => {
    const harness = host.create({ consent: 'granted' })
    expect(host.events()).toHaveLength(1)
    harness.stop()
    harness.navigate({ path: '/after-stop', title: 'after' })
    expect(host.events()).toHaveLength(1)
    harness.deny()
    harness.grant()
    expect(host.events()).toHaveLength(1)
  })
})
''')
Path('packages/game/src/analytics/google-analytics.boundaries.test.ts').write_text('''/**
 * H05:项目ID格式与UTM边界、无page订阅的重授/stop、disable属性。
 * 大写UTM归一而非丢弃;不把fetch替身当script资源的网络拦截。
 * 使用共享自有Document/SDK属性/订阅宿主,真实SUT执行;不接真实Google端点。
 */
import { describe, expect, it } from 'vitest'
import { sanitizePageViewUrl } from './google-analytics.js'
import { type GoogleAnalyticsHarnessOptions, useGoogleAnalyticsTestHost } from './google-analytics.test-fixtures.js'

const host = useGoogleAnalyticsTestHost()
const create = (options: GoogleAnalyticsHarnessOptions = {}) => host.create({
  page: { path: '/play?utm_source=alpha', title: 't' }, ...options,
})

describe('H05 边界', () => {
  it('项目ID格式归一化:小写、6/20字符接受,5/21字符拒绝', () => {
    const lower = create({ measurementId: 'g-test12345' })
    lower.grant()
    expect(host.events()).toHaveLength(1)
    lower.stop()
    lower.stop()
    for (const id of ['G-AAAAAA', `G-${'A'.repeat(20)}`]) {
      const before = host.events().length
      const harness = create({ measurementId: id })
      harness.grant()
      expect(host.events()).toHaveLength(before + 1)
      expect(host.commands().filter((command) => command[0] === 'config').at(-1)?.[1]).toBe(id)
      harness.stop()
    }
    const before = host.events().length
    for (const id of ['G-AAAAA', `G-${'A'.repeat(21)}`]) {
      const harness = create({ measurementId: id })
      harness.grant()
      expect(host.events()).toHaveLength(before)
      expect(host.readProperty(`ga-disable-${id}`)).toBeUndefined()
      harness.stop()
    }
    expect(host.document.head.querySelectorAll('script')).toHaveLength(1)
  })

  it('UTM 64保留/65丢弃,前导减号拒绝,大写归一且不扩展白名单', () => {
    const ok64 = 'a'.repeat(64)
    const long65 = 'a'.repeat(65)
    const parsed = new URL(sanitizePageViewUrl(
      `/p?utm_source=${ok64}&utm_medium=${long65}&utm_campaign=-lead&utm_content=Up&utm_term=private&scene=9&pos=1,2`,
      'https://play.example.com',
    ))
    expect(parsed.origin).toBe('https://play.example.com')
    expect(parsed.pathname).toBe('/p')
    expect(Object.fromEntries(parsed.searchParams)).toEqual({ utm_source: ok64, utm_content: 'up' })
  })

  it('不传 subscribePage：grant 发当前页一次；deny 停发且清 lastPath；regrant 同页可再发；stop 后零回调', () => {
    const harness = create({ subscribePage: false })
    harness.grant()
    expect(host.events()).toHaveLength(1)
    harness.deny()
    harness.grant()
    expect(host.events()).toHaveLength(2)
    harness.deny()
    harness.stop()
    harness.grant()
    expect(host.events()).toHaveLength(2)
  })

  it('disable 键随同意翻转：granted=false、denied=true', () => {
    const harness = create({ measurementId: 'G-TEST12345' })
    harness.grant()
    expect(host.readProperty('ga-disable-G-TEST12345')).toBe(false)
    harness.deny()
    expect(host.readProperty('ga-disable-G-TEST12345')).toBe(true)
    harness.stop()
  })
})
''')
p=Path('docs/ops/evidence/QUALITY-PRE94-RETROSPECTIVE-1/3z-google-analytics');(p/'edit-producer.py.gz').write_bytes(gzip.compress(Path('/tmp/type-pal-ga-edit.py').read_bytes(),mtime=0))
