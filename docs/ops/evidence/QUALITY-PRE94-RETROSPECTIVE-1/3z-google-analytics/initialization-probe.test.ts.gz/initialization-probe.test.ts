import { expect, it, vi } from 'vitest'
import { installTypePalAnalytics } from '../install-analytics.js'
import { writeAnalyticsConsent } from '../analytics-consent.js'

it('failed analytics installation leaves no consent reaction after SDK recovers', () => {
  const key = 'type-pal.analytics-consent.v1'
  const original = localStorage.getItem(key)
  const names = ['gtag', 'dataLayer', 'ga-disable-G-9Q2XJV7NJ6']
  const descriptors = names.map((name) => [name, Object.getOwnPropertyDescriptor(window, name)] as const)
  const doc = document.implementation.createHTMLDocument('owned probe')
  const listeners = vi.spyOn(window, 'addEventListener')
  const failure = new Error('owned SDK initialization failure')
  try {
    localStorage.setItem(key, 'granted')
    for (const name of names) Reflect.deleteProperty(window, name)
    Object.defineProperty(window, 'gtag', { configurable: true, writable: true, value: () => { throw failure } })
    let caught: unknown
    try { installTypePalAnalytics({ enabled: true, window, document: doc, navigator: {} }) }
    catch (error) { caught = error }
    expect(caught).toBe(failure)
    const recoveredGtag = vi.fn()
    Object.defineProperty(window, 'gtag', { configurable: true, writable: true, value: recoveredGtag })
    expect(writeAnalyticsConsent('denied')).toBe(true)
    expect(writeAnalyticsConsent('granted')).toBe(true)
    expect(recoveredGtag).not.toHaveBeenCalled()
  } finally {
    for (const [type, listener, options] of listeners.mock.calls) window.removeEventListener(type, listener, options)
    listeners.mockRestore()
    doc.head.replaceChildren(); doc.body.replaceChildren()
    for (const [name, descriptor] of descriptors) {
      if (descriptor) Object.defineProperty(window, name, descriptor)
      else Reflect.deleteProperty(window, name)
    }
    if (original === null) localStorage.removeItem(key)
    else localStorage.setItem(key, original)
  }
})
