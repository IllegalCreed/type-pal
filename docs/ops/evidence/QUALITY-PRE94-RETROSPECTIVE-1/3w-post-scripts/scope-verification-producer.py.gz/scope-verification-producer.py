from pathlib import Path
import json,gzip,hashlib,subprocess,collections,copy,re
p=Path('docs/ops/evidence/QUALITY-PRE94-RETROSPECTIVE-1/3w-post-scripts');base='599d35717d8a5213802f76535eb14ba187f709e5';sha=lambda b:hashlib.sha256(b).hexdigest();load=lambda n:json.loads((p/n).read_text());uz=lambda n:gzip.decompress((p/n).read_bytes());blob=lambda s:subprocess.check_output(['git','show',base+':'+s])
for f in p.rglob('*.json'):
 d=json.loads(f.read_text())
 if isinstance(d,dict) and 'rawBytes' in d:
  raw=gzip.decompress((f.parent/d['raw']).read_bytes());assert len(raw)==d['rawBytes'] and sha(raw)==d['rawSha256']
for r in load('read-boundaries.json')['rows']:
 raw=Path(r['path']).read_bytes();assert raw==uz(r['snapshot']) and sha(raw)==r['sha256'] and len(raw.decode().splitlines())==r['lines'];assert all(1<=a<=b<=r['lines'] for a,b in r['ranges'])
formal=json.loads(uz('module-final.vitest.json.gz'));assert formal['numTotalTests']==formal['numPassedTests']==237 and formal['numFailedTests']==formal['numPendingTests']==formal['numTodoTests']==0 and len(formal['testResults'])==8
c=load('controls.json');assert len(c['controls'])==6 and c['temporaryRootsRemoved'] and c['canonicalSourcesUnchanged']
for file in c['runs']:
 x=load(file);assert not Path(x['temporaryRoot']).exists()
for r in c['controls']:
 assert Path(r['source']).read_bytes()==blob(r['source']) and sha(uz(r['id']+'.mutant.gz'))==r['mutantSha256']
 for phase,v in r['runs'].items():
  raw=uz(v['raw']);assert sha(raw)==v['rawSha256'] and len(raw)==v['rawBytes'];d=json.loads(uz(v['nativeReport']));assert sha(uz(v['nativeReport']))==v['nativeSha256'];n=r['expectedOldCount'] if phase=='old' else r['expectedCurrentCount'];bad=[a for f in d['testResults'] for a in f['assertionResults'] if a['status']=='failed'];assert d['numTotalTests']==n and d['numPendingTests']==d['numTodoTests']==0 and not d.get('unhandledErrors',[]);assert v['mirrorRestoredByteForByte'] and v['canonicalSourcesUnchanged']
  if phase=='old':assert v['exit']==0 and not bad and d['numPassedTests']==n
  else:
   assert v['exit']==1 and len(bad)==1 and d['numPassedTests']==n-1 and r['expectedNewFailureNameContains'] in bad[0]['fullName'] and all('AssertionError:' in x for x in bad[0]['failureMessages']);expect=next(f for f in formal['testResults'] if f['name'].endswith(r['spec']));assert [a['fullName'] for f in d['testResults'] for a in f['assertionResults']]==[a['fullName'] for a in expect['assertionResults']]
  assert not re.search(rb'(stderr \||Unhandled Error|Unhandled Rejection)',raw)
for n in ['module-final','typecheck-final','docs-consumers','ledger','lint']:
 r=load(n+'.json');raw=uz(r['raw']);assert r['exit']==0 and r['signal'] is None and r['spawnError'] is None and not re.search(rb'(stderr \||Warning:|Unhandled Error|Unhandled Rejection|error TS\d)',raw)
assert b'0 errors / 0 warnings / 0 infos; complete report' in uz('lint.raw.gz')
assert b'3318 files; 251 closed / 102 review / 2965 pending' in uz('ledger.raw.gz')
queue='docs/ops/evidence/QUALITY-PRE94-RETROSPECTIVE-1/all-cards.json';old=json.loads(blob(queue));cur=json.loads(Path(queue).read_text());next(r for r in old['cards'] if r['id']=='3w')['evidence']=str(p/'README.md');assert cur==old and collections.Counter(r['currentReview'] for r in cur['cards'])=={'partial':55,'pending':28} and not any(r['currentAcceptance'] for r in cur['cards'])
for path in sorted({r['review'] for r in load('review-chain.json')['bindings']}):
 old=json.loads(blob(path));current=json.loads(Path(path).read_text());rebuilt=copy.deepcopy(current)
 for binding in [r for r in load('review-chain.json')['bindings'] if r['review']==path]:
  before=next(r for r in old['entries'] if r['path']==binding['target']);after=next(r for r in current['entries'] if r['path']==binding['target']);assert after['afterSha256']==sha(Path(binding['target']).read_bytes());assert after['revision']['history'][1:]==before['revision']['history'];restored=copy.deepcopy(after);restored['afterSha256']=before['afterSha256'];restored['reviewedLines']=before['reviewedLines'];restored['revision']['history']=before['revision']['history']
  for k in ['implementationSha','afterSha256']:
   if k in before['revision']:restored['revision'][k]=before['revision'][k]
  if isinstance(before.get('evidence'),dict):
   for k in ['afterSha256','lineCount']:
    if k in before['evidence']:restored['evidence'][k]=before['evidence'][k]
  assert restored==before;rebuilt['entries'][rebuilt['entries'].index(after)]=before
 assert rebuilt==old
assert not subprocess.check_output(['git','diff','37e2cd7c9a54b29766a87d17ffed90e4dae465dd','--','scripts/docs/'])
assert subprocess.check_output(['git','branch','--show-current'],text=True).strip()=='codex/code-quality-3y';subprocess.run(['git','diff','--check'],check=True)
print('PASS: six old-green/current-single-business-failure controls, temporary mirrors removed, exact raw/native/input hashes and case identities; final237+TC+five consumers+zero lint+ledger;83 statuses and bounded five metadata bindings. Product sources unchanged.')
