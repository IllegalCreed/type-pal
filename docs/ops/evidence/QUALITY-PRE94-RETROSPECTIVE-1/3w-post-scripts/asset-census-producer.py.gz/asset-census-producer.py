from pathlib import Path
import json,gzip,hashlib,struct,collections,subprocess
p=Path('docs/ops/evidence/QUALITY-PRE94-RETROSPECTIVE-1/3w-post-scripts');root=Path('/Users/zhangxu/illegal/type-pal/data');sha=lambda b:hashlib.sha256(b).hexdigest();raw=(root/'raw/SSS.MKF').read_bytes();header=struct.unpack_from('<I',raw)[0];assert header%4==0;offsets=struct.unpack_from('<'+'I'*(header//4),raw);assert offsets[0]==header and offsets[-1]==len(raw) and list(offsets)==sorted(offsets)
objects=raw[offsets[2]:offsets[3]];bytecode=raw[offsets[4]:offsets[5]];assert len(objects)%14==0 and len(bytecode)%8==0
resourceBytes=(root/'extracted/data/enemy-objects.json').read_bytes();eventBytes=(root/'extracted/events/all.json').read_bytes();resources=json.loads(resourceBytes);commands=json.loads(eventBytes)['segments'][0]['commands'];assert len(resources)==153 and len(commands)==len(bytecode)//8;groups=collections.defaultdict(list)
for e in resources:
 words=struct.unpack_from('<7H',objects,e['objectIndex']*14);assert [e[k] for k in ['enemyId','resistanceToSorcery','scriptOnTurnStart','scriptOnBattleEnd','scriptOnReady']]==list(words[:5])
 if e['scriptOnBattleEnd']:groups[e['scriptOnBattleEnd']].append({'objectIndex':e['objectIndex'],'enemyId':e['enemyId'],'name':e['_name'],'objectRawHex':objects[e['objectIndex']*14:(e['objectIndex']+1)*14].hex()})
ends=[]
for entry,es in sorted(groups.items()):
 body=[]
 for ip in range(entry,entry+12):
  words=struct.unpack_from('<4H',bytecode,ip*8);c=commands[ip];body.append({'ip':ip,'rawWords':list(words),'rawHex':bytecode[ip*8:(ip+1)*8].hex(),'command':c});assert words[0] in [0,6,0x1f,0x3e,0xffff],(ip,words)
  if words[0]==0:assert c['op']=='end';break
  if words[0]==6:assert c['opcode']==6 and c['operands']==list(words[1:]) and words[2]==0
  if words[0]==0x1f:assert c['op']=='giveItem' and [c['itemId'],c['count']]==list(words[1:3])
  if words[0]==0x3e:assert c['op']=='setDialogStyleNarration'
  if words[0]==0xffff:assert c['op']=='showDialog' and c['messageIndex']==words[1]
 else:raise AssertionError('unbounded leaf')
 ends.append({'entry':entry,'objects':es,'instructions':body})
sites={137:[],144:[]}
for ip in range(len(bytecode)//8):
 words=struct.unpack_from('<4H',bytecode,ip*8)
 if words[0] in sites:
  c=commands[ip];assert c['op']=='raw' and c['opcode']==words[0] and c['operands']==list(words[1:]);sites[words[0]].append({'ip':ip,'rawWords':list(words),'command':c})
assert len(groups)==10 and sum(map(len,groups.values()))==15 and len(sites[137])==4 and all(x['rawWords'][1]==0 for x in sites[137]) and len(sites[144])==3 and all(x['rawWords'][3]==0 for x in sites[144])
d={'base':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'scope':'Read-only raw SSS.MKF chunk2/4 cross-check against extracted153 objects/all instructions. No extractor execution/output writes/arbitrary external save/original-runtime claim.','inputs':[{'path':str(root/'raw/SSS.MKF'),'sha256':sha(raw),'bytes':len(raw)},{'path':str(root/'extracted/data/enemy-objects.json'),'sha256':sha(resourceBytes),'bytes':len(resourceBytes)},{'path':str(root/'extracted/events/all.json'),'sha256':sha(eventBytes),'bytes':len(eventBytes)}],'mkfOffsets':list(offsets),'objectsCompared':153,'allInstructionCount':len(commands),'battleEndEntries':ends,'setBattleResultSites':sites[137],'setObjectScriptSites':sites[144],'conclusion':'10 straight leaves/15 owners: giveItem(count0), narration0x3E and optional0x06 jump0. No HP/status writes/calls/other jumps in these leaves. Four0x89 sites terminate(result0), none result3. Three0x90 sites write word2(turnStart), none word3(battleEnd). External saves/debug may differ and are not accepted here.','authoringNote':'Initial interactive census draft assumed narration0x3C and failed at41009 actualopcode62. Corrected to0x3E after raw/C script.c:3419-3428 check; no production issue or product red-first claim.'}
(p/'asset-census.json').write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n');(p/'asset-census-producer.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0));print('Raw/extracted match:153 enemy objects,10 PhaseE entries/15 owners,4 result0 sites,3 turnStart-only0x90 writes.')
