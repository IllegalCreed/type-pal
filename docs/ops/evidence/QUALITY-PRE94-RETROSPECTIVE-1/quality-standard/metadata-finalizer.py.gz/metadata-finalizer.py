from pathlib import Path
import json,hashlib,subprocess,gzip
base='0bc82025928b4fe13dce0f34c3a8696507d04032';p=Path('docs/ops/evidence/QUALITY-PRE94-RETROSPECTIVE-1/quality-standard');sha=lambda b:hashlib.sha256(b).hexdigest();load=lambda f:json.loads(Path(f).read_text());dump=lambda f,d:Path(f).write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n');blob=lambda f:subprocess.check_output(['git','show',base+':'+str(f)]);bindings=load(p/'review-bindings.json')
for path in sorted({r['review'] for r in bindings['rows'] if r['kind']=='content'}):
 d=load(path);old=json.loads(blob(path))
 for b in [r for r in bindings['rows'] if r['review']==path]:
  r=next(r for r in d['entries'] if r['path']==b['target']);prior=next(r for r in old['entries'] if r['path']==b['target']);h=r['revision']['history'][0];assert h['revision']==base
  for field in ['businessOracle','dedupe','truthAnchors','unresolved','nextStep']:h['previous'+field[0].upper()+field[1:]]=prior[field]
  r['businessOracle']={'type':'authorized-document-content-and-real-route-template-consumers','assertions':[r['coreConclusion'],'One canonical cross-phase quality contract; entry/form instructions preserve actual task state and risk boundaries','Current delta does not claim historical byte preservation or independent third-party/product execution acceptance']};r['dedupe']={'result':'Only entry/recording prompts here; complete quality clauses live in docs/ops/code-quality.md','against':['docs/ops/code-quality.md','docs/ops/agent-workflow.md']};r['truthAnchors']=['docs/ops/code-quality.md','AGENTS.md:操作与必读','User 2026-10-18 instruction to persist quality, recheck and contributor responsibilities'];r['unresolved']=['Historical product/coverage/unified gates remain outside this documentation-only integration.'];r['nextStep']='Use canonical quality contract for subsequent development and GLM read-only pilot; independently review code and actual evidence before acceptance.'
 dump(path,d);subprocess.run(['pnpm','exec','biome','format','--write',path],check=True,stdout=subprocess.PIPE)
# Rebind own unpublished incoming rows without adding fictitious review iterations.
for review in ['docs/phase-governance/reviews/20261017-r93-phase-governance-artifacts.json','docs/phase-governance/reviews/20261017-r94-final-machine-artifacts.json']:
 d=load(review)
 for b in [r for r in bindings['rows'] if r['review']==review]:
  r=next(r for r in d['entries'] if r['path']==b['target']);raw=Path(b['target']).read_bytes();h=sha(raw);r['afterSha256']=h;r['reviewedLines']='1-'+str(len(raw.decode().splitlines()))
  for key in ['implementationSha','afterSha256']:
   if key in r['revision']:r['revision'][key]=h
  for key,val in [('afterSha256',h),('lineCount',len(raw.decode().splitlines()))]:
   if key in r['evidence']:r['evidence'][key]=val
  b['afterSha256']=h;b['lines']=len(raw.decode().splitlines())
 dump(review,d);subprocess.run(['pnpm','exec','biome','format','--write',review],check=True,stdout=subprocess.PIPE)
dump(p/'review-bindings.json',bindings);(p/'metadata-finalizer.py.gz').write_bytes(gzip.compress(Path('/tmp/type-pal-quality-norm-finalize.py').read_bytes(),mtime=0))
