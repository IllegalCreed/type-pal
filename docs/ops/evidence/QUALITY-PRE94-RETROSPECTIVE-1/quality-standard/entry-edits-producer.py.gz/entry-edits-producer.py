from pathlib import Path
root=Path.cwd()
def edit(path,a,b):
 f=root/path;s=f.read_text();assert s.count(a)==1,(path,a,s.count(a));f.write_text(s.replace(a,b))
edit('AGENTS.md','| 开始或接手非小改 |','| 开发、修改、重构或审查代码 | [工程代码质量与验收](docs/ops/code-quality.md)、[开发验收流程](docs/ops/agent-workflow.md) | 八维逐文件、按影响范围验证；功能正确与质量合格共同构成完成，交付须可独立复验 |\n| 开始或接手非小改 |')
edit('CLAUDE.md','## 协作规范（两阶段通用）\n','## 协作规范（两阶段通用）\n\n所有新功能、缺陷修复、重构、测试与工具开发均遵守[工程代码质量与验收规范](docs/ops/code-quality.md)；从[AGENTS操作路由](AGENTS.md#操作与必读)进入设计、逐文件审查和独立验收，不以专项任务卡代替长期标准。\n')
edit('docs/ops/README.md','- [现行协作工作流](agent-workflow.md)、[当前任务看板](board.md)。','- [工程代码质量与验收规范](code-quality.md)：两阶段所有开发与审查的八维标准、低成本复验和完成定义。\n- [现行协作工作流](agent-workflow.md)、[当前任务看板](board.md)。')
f=root/'docs/ops/agent-workflow.md';s=f.read_text().replace('Last reviewed: 2026-10-15','Last reviewed: 2026-10-18',1);f.write_text(s)
edit('docs/ops/agent-workflow.md','## 前置条件\n','## 前置条件\n\n所有新功能、缺陷修复、重构、测试和工具开发先读[长期工程质量规范](code-quality.md)，按完整八维开展设计、实现和审查；本页规定推进方式，不维护第二套质量条文。\n')
edit('docs/ops/agent-workflow.md','### 2. 隔离实施与交付\n','### 2. 隔离实施与交付\n\n先核模块职责、状态Owner与依赖，再定文件边界；拆合、重命名和目录重组按[质量规范](code-quality.md#2-定位问题并选择整改)同步caller/出口/测试/文档映射。纯重构与行为修复分提交；必要检查随影响范围安排，全仓check/官方coverage/protected集中在较大稳定窗口。\n')
edit('docs/ops/agent-workflow.md','### 3. 独立复核与集成\n','### 3. 独立复核与集成\n\n逐文件审查[八维结论](code-quality.md#1-逐文件核清八维)，核具体实现和全部变更，不只验收报告或包级全绿。接收[可独立复验交付](code-quality.md#4-交付可独立复验的证据)：先快检候选/附件/原始结果，再按需定向实跑，复核失效或疑点范围；哈希匹配不授语义信用。缺维不升代码审查切片partial，关键未知或重要未修项不关闭文件。\n')
edit('docs/ops/agent-workflow.md','## 完成定义\n','## 完成定义\n\n依[长期质量完成定义](code-quality.md#完成定义)分别核审查完整、整改完成和可集成；功能正确、质量合格、必要质量门实际通过共同构成完成。贡献者负责执行和自验，Codex负责独立核代码、判定与集成，用户保留新产品取舍的决定权；不恢复固定模型席位。\n')
for path,heading in [('docs/ops/templates/TASK-template.md','## 验收条件'),('docs/ops/templates/TASK-lite-template.md','## 验证')]:
 f=root/path;s=f.read_text();needle=heading+'\n';assert s.count(needle)==1
 block='''\n代码任务按[长期工程质量规范](../code-quality.md)填写；非代码任务说明适用范围。下列为记录提示，不预填通过，不改变既有任务状态机。\n\n### 代码质量与低成本复验\n\n- 受审文件/实际全文读域、生产caller、公共出口、相邻类型与生命周期：\n- 逐文件八维结论及具体依据（N/A须解释；可链接同一份完整审查表）：\n  - A正确性与边界；B注释质量；C高内聚低耦合；D可复用：\n  - E测试质量；F可读性；G简洁性；H可测试性：\n- 必改项、可改善结构、未知/保留项及阻断性；模块/路径/测试合同迁移映射：\n- 基点/候选Git身份，相关caller/依赖/测试/工具指纹与证据失效条件：\n- 快速只读复验命令及预期、不能自动验证的语义；必要定向命令及完整原件入口：\n- 实际结果/诊断计数/未跑项与理由；全仓check/官方coverage/protected的大窗口安排：\n- Codex独立代码审查；审查完整/整改完成/可集成分别判定，不以全绿或字段齐全代替：\n'''
 s=s.replace(needle,needle+block);f.write_text(s)
edit('docs/ops/templates/README.md','## 证据与下一步\n','## 证据与下一步\n\n完整/轻量模板的验收提示均接入[长期工程质量规范](../code-quality.md)：逐文件八维结论、问题处置、候选身份与失效条件、快速复验及原始结果。任务卡类型、状态词和必填章节合同保持，纯文档任务按实际范围说明适用性；小改可紧凑引用已有完整记录，不为填表新造专项。\n')
edit('docs/phase-governance/templates/README.md','## 证据与下一步\n','## 证据与下一步\n\n任务卡的验收内容同时受[长期工程质量规范](../../ops/code-quality.md)约束；完整与轻量Ops模板已增加八维及低成本复验填写提示。本次不新增docType、不改task-card-v1状态或requiredSections，内容提示的更新按实际consumer和review验证。\n')
edit('docs/phase-governance/templates/task-card.md','- 测试与证据：','- 代码质量与低成本复验：按[长期规范](../../ops/code-quality.md)逐文件给八维依据、问题处置、候选身份/失效条件、快速复验命令与完整原件；非代码任务说明适用性。\n- 测试与证据：')
# Make current task instruction refer to canonical, preserve previous conversation admission as history.
f=root/'docs/ops/tasks/QUALITY-PRE94-RETROSPECTIVE-1.md';s=f.read_text();a=s.index('## 2026-10-18 用户重申：代码质量是治理主目标');b=s.index('## 当前推进',a)
s=s[:a]+'''## 长期质量标准与当前执行分工\n\n所有文件按[工程代码质量与验收规范](../code-quality.md)的八维和可独立复验要求推进；本卡只保存本轮范围、进度与证据，不另维护质量条文。本轮GLM承担主要全文审查与获准整改，Codex主导分批、风险核定、独立代码验收及集成；首批RLE三文件只读校准尚不获得产品build或关闭信用。历史partial不继承新的八维验收。\n\n'''+s[b:]
s+='''\n### 2026-10-18 项目长期质量规范接入准入\n\n用户明确要求将八维质量、低成本复验与分工固化为后续开发通用规范。Codex单Owner在现3y树build allowed：新ops/code-quality.md为唯一完整条款；AGENTS/CLAUDE路由、agent-workflow、Ops/通用任务模板及导航只做入口/验收接线，必要registry/routing与逐项review同步。只改文档与对应元数据，不改产品/测试/质量工具或存量文件状态；不占用GLM首批RLE只读范围，不触碰另一docs树。完整check:docs、lint-zero、diff和ledger实测后提交推送治理分支；不借规范接入签收任何旧代码或统一集成门。\n''';f.write_text(s)
f=root/'docs/ops/board.md';s=f.read_text();s=s.replace('Codex / 先完成独立审计机制、注释与证据返工','Codex / 固化长期质量标准；GLM首批只读校准');f.write_text(s)
print('Canonical engineering contract and direct development/review/template consumers written; history untouched except current task summary superseded by link.')
