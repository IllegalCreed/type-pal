from pathlib import Path
import json,hashlib,gzip,subprocess,copy,re
root=Path.cwd();p=Path('docs/ops/evidence/QUALITY-PRE94-RETROSPECTIVE-1/quality-standard');base='0bc82025928b4fe13dce0f34c3a8696507d04032';sha=lambda b:hashlib.sha256(b).hexdigest();load=lambda f:json.loads(Path(f).read_text());blob=lambda f:subprocess.check_output(['git','show',base+':'+str(f)]);manifest=load(p/'manifest.json');bindings=load(p/'review-bindings.json')
for r in manifest['files']:
 raw=Path(r['path']).read_bytes();assert sha(raw)==r['afterSha256'] and len(raw.decode().splitlines())==r['lines'],r['path']
 if 'beforeSha256' in r:assert sha(blob(r['path']))==r['beforeSha256']
assert not subprocess.check_output(['git','diff','--name-only',base,'--','packages/','scripts/','docs/ops/audits/code-quality-file-ledger.md'])
q='docs/ops/evidence/QUALITY-PRE94-RETROSPECTIVE-1/all-cards.json';assert Path(q).read_bytes()==blob(q)
# New machine declarations are additive, with no policy/schema/old-entry changes.
f='docs/phase-governance/routing.json';old=json.loads(blob(f));cur=load(f);old['routes'].insert(1,{'operation':'开发、修改、重构或审查代码','required':['docs/ops/code-quality.md','docs/ops/agent-workflow.md']});old['migratedDocuments'].append({'path':'docs/ops/code-quality.md','templateId':'guide-runbook-v1'});assert old==cur
f='docs/phase-governance/document-registry.json';old=json.loads(blob(f));cur=load(f);new=next(x for x in cur['entries'] if x['path']=='docs/ops/code-quality.md');old['entries'].append(new);s=old['summary'];s['total']+=1;s['byPhase']['ops']+=1;s['byType']['guide-runbook']+=1;s['reviewStatus']['content-reviewed']+=1;s['templateCompliance']['template-compliant']+=1;assert old==cur
# Existing required task headings and status spellings are not changed by prompts.
for f in ['docs/ops/templates/TASK-template.md','docs/ops/templates/TASK-lite-template.md','docs/phase-governance/templates/task-card.md']:
 before=blob(f).decode();after=Path(f).read_text();assert re.findall(r'^## .+$',before,re.M)==re.findall(r'^## .+$',after,re.M);assert 'code-quality.md' in after
 for status in ['draft','build','review','done','blocked','rework','cancelled']:assert (status in before)==(status in after)
standard=Path('docs/ops/code-quality.md').read_text();assert re.findall(r'^#### ([A-H]) ',standard,re.M)==list('ABCDEFGH');assert '统一检查器' in standard and '不宣称' in standard
for path in sorted({r['review'] for r in bindings['rows']}):
 before=json.loads(blob(path));after=load(path);rebuilt=copy.deepcopy(after)
 if path.endswith('20261004-semantic-current-batch.json'):
  rows=[r for r in rebuilt['entries'] if r['path']=='docs/ops/code-quality.md'];assert len(rows)==1 and rows[0]['afterSha256']==sha(standard.encode());rebuilt['entries'].remove(rows[0])
 for b in [r for r in bindings['rows'] if r['review']==path]:
  old=next(r for r in before['entries'] if r['path']==b['target']);new=next(r for r in after['entries'] if r['path']==b['target']);body=Path(b['target']).read_bytes();h=sha(body);assert h==b['afterSha256']==new['afterSha256'];assert new['reviewedLines']=='1-'+str(len(body.decode().splitlines()));assert new['revision']['history'][1:]==old['revision']['history'] and new['revision']['currentSha']==old['revision']['currentSha'];assert new['revision']['history'][0]['previousAfterSha256']==old['afterSha256'];restore=copy.deepcopy(new)
  for field in ['afterSha256','reviewedLines','revision']:
   restore[field]=old[field]
  if b['kind']=='content':
   assert new['revision']['history'][0]['previousEvidence']==old['evidence'] and new['revision']['history'][0]['previousCoreConclusion']==old['coreConclusion']
   for field in ['coreConclusion','readMethod','reviewNotes','evidence','candidateSha256','documentStatus','businessOracle','dedupe','truthAnchors','unresolved','nextStep']:
    if field in old:restore[field]=old[field]
    else:restore.pop(field,None)
  else:
   for field in ['afterSha256','lineCount']:
    if field in old['evidence']:restore['evidence'][field]=old['evidence'][field]
  assert restore==old,(path,b['target']);rebuilt['entries'][rebuilt['entries'].index(new)]=old
 assert rebuilt==before,path
for f in p.glob('*.json'):
 d=load(f)
 if 'rawBytes' in d:
  raw=gzip.decompress((p/d['raw']).read_bytes());assert sha(raw)==d['rawSha256'] and len(raw)==d['rawBytes']
for label in ['docs-final','lint','ledger']:
 d=load(p/(label+'.json'));assert d['exit']==0 and d['signal'] is None and d['spawnError'] is None
 raw=gzip.decompress((p/d['raw']).read_bytes());assert not re.search(rb'(Warning:|error TS\d|Unhandled Error|Unhandled Rejection)',raw)
assert b'0 errors / 0 warnings / 0 infos; complete report' in gzip.decompress((p/'lint.raw.gz').read_bytes());assert b'3319 files; 251 closed / 103 review / 2965 pending' in gzip.decompress((p/'ledger.raw.gz').read_bytes())
known={r['path'] for r in manifest['files']};changed=[s.decode() for s in subprocess.check_output(['git','diff','--name-only','-z',base]).split(b'\0') if s];unknown=[s.decode() for s in subprocess.check_output(['git','ls-files','--others','--exclude-standard','-z']).split(b'\0') if s];assert set(changed)<=known and all(s=='docs/ops/code-quality.md' or s.startswith(str(p)+'/') for s in unknown)
assert subprocess.check_output(['git','branch','--show-current'],text=True).strip()=='codex/code-quality-3y';subprocess.run(['git','diff','--check'],check=True)
print('PASS: source/caller entry identities; A-H present (structure only), unchanged task headings/statuses; one additive route and guide registry binding; all unrelated review rows/history preserved; no product/test/tool/ledger/83-card changes. Semantic conclusions remain explicitly author-reviewed, not machine-certified.')
