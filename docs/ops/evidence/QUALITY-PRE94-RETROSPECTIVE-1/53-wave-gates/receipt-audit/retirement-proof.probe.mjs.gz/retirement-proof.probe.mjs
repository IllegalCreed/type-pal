import { readFileSync, writeFileSync } from 'node:fs'
import { execFileSync } from 'node:child_process'
import { createHash } from 'node:crypto'
import { pathToFileURL } from 'node:url'
import assert from 'node:assert/strict'
const root=process.cwd()
const moduleUrl=pathToFileURL(`${root}/scripts/coverage/approved-test-retirements.mjs`).href
const {approvedTestRetirements,isApprovedTestRetirement}=await import(moduleUrl)
const files=['packages/editor/src/ui/SpriteResourceViewer.c03-g03.cursor-r1.test.tsx','packages/editor/src/ui/SpriteUploadWizard.c03-g07.cursor-r1.test.tsx','packages/pal-extract/src/events/annotate.test.ts','packages/pal-extract/src/resources/parsers/ball.glm-runtime-resource.test.ts','packages/shared/src/rle.glm-o.test.ts','packages/shared/src/rng.test.ts']
const hash=bytes=>createHash('sha256').update(bytes).digest('hex')
const original=JSON.parse(execFileSync('git',['show','f544b9b94^:scripts/coverage/baseline.fast.json'],{encoding:'utf8'}))
const generated=JSON.parse(execFileSync('git',['show','f544b9b94:scripts/coverage/baseline.fast.json'],{encoding:'utf8'}))
const entry=(baseline,file)=>Object.values(baseline.packages).flatMap(p=>p.fastTests.fileEntries).find(e=>e.file===file)
const rows=files.map(file=>{
 const approval=approvedTestRetirements.find(e=>e.file===file),previous=entry(original,file),current=entry(generated,file)
 assert(approval&&previous&&current)
 const fileSha256=hash(readFileSync(file))
 const input={removal:{kind:'test-count',value:file,previous:previous.testCount,current:current.testCount},previous,current,fileSha256}
 assert.equal(isApprovedTestRetirement(input),true)
 assert.equal(isApprovedTestRetirement({...input,fileSha256:'different'}),false)
 const addition=execFileSync('git',['log','-1','--format=%H%n%aI%n%s','-S',file,'--','scripts/coverage/approved-test-retirements.mjs'],{encoding:'utf8'}).trim().split('\n')
 return {file,approval,input,exactSnapshotAccepted:true,fileByteDriftRejected:true,additionCommit:addition[0],additionDate:addition[1],additionSubject:addition[2]}
})
const output={command:['node','/tmp/pre94-audit-followup.mjs'],cwd:root,phase:process.argv[2]??'before-comments',scope:'Six exact stored baseline transitions and actual current test bytes; not new runtime/coverage acceptance and not individual user signatures',payloadSha256:hash(JSON.stringify(approvedTestRetirements)),matcherSha256:hash(isApprovedTestRetirement.toString()),baselineSha256:hash(readFileSync('scripts/coverage/baseline.fast.json')),rows}
writeFileSync(`docs/ops/evidence/QUALITY-PRE94-RETROSPECTIVE-1/53-wave-gates/receipt-audit/retirement-proof-${output.phase}.json`,JSON.stringify(output,null,2)+'\n')
console.log(JSON.stringify({phase:output.phase,snapshots:rows.length,payloadSha256:output.payloadSha256,matcherSha256:output.matcherSha256,baselineSha256:output.baselineSha256}))
