from pathlib import Path
from datetime import datetime
import json,gzip,hashlib,subprocess
root=Path.cwd();out=root/'docs/ops/evidence/QUALITY-PRE94-RETROSPECTIVE-1/53-wave-gates/receipt-audit';sha=lambda b:hashlib.sha256(b).hexdigest();old=gzip.decompress((out/'retirements-before-authorization-comments.mjs.gz').read_bytes());new=(root/'scripts/coverage/approved-test-retirements.mjs').read_bytes();code=lambda b:'\n'.join(l for l in b.decode().splitlines() if not l.lstrip().startswith('//')).strip();assert code(old)==code(new)
b=json.loads((out/'retirement-proof-before-comments.json').read_text());a=json.loads((out/'retirement-proof-after-comments.json').read_text())
for k in ['payloadSha256','matcherSha256','baselineSha256']:assert a[k]==b[k]
assert sha((root/'scripts/coverage/baseline.fast.json').read_bytes())==a['baselineSha256']
authority=json.loads((out/'retirement-authorizations.json').read_text());messages={r['id']:r for r in json.loads((out/'authorization-instructions.json').read_text())['instructions']}
for row in authority['rows']:
 assert row['individuallySignedByUser'] is False and row['legacyOpqFiveFileApprovalApplies'] is False
 for k in row['instructionIds']:assert datetime.fromisoformat(messages[k]['timestampUtc'].replace('Z','+00:00'))<datetime.fromisoformat(row['additionDate'])
anchors=json.loads((out/'anchor-corrections.json').read_text())['anchors']
for row in anchors:
 raw=(root/row['source']).read_bytes();lines=raw.decode().splitlines();start,end=row['lines'];assert 1<=start<=end<=len(lines);assert sha(raw)==row['sourceSha256'];assert lines[row['functionNameLine']-1].strip()==row['ownerFunction']+'(';assert sha(('\n'.join(lines[start-1:end])+'\n').encode())==row['rangeSha256']
preserved=[]
for target in ['docs/ops/archive/tasks/done/CODE-QUALITY-3l-game-battle-present.md','docs/ops/archive/tasks/done/CODE-QUALITY-3x-game-battle-progression.md','docs/ops/audits/code-quality-governance.md']:
 previous=subprocess.check_output(['git','show',json.loads((out/'anchor-corrections.json').read_text())['base']+':'+target]).decode();current=(root/target).read_text();assert current.endswith(previous.split('\n',1)[1]);preserved.append(target)
row={'command':['python3','/tmp/verify-audit-followup.py'],'cwd':str(root),'exit':0,'sourceBase':json.loads((out/'anchor-corrections.json').read_text())['base'],'scope':'Separate process data/source reconstruction, Codex self-check; not a third-party review or runtime/coverage acceptance','registryChange':'comments only; original executable text identical','registryBeforeSha256':sha(old),'registryAfterSha256':sha(new),'original30PayloadUnchanged':True,'matcherUnchanged':True,'baselineUnchanged':True,'sixHumanAuthoritiesPredateAdditions':True,'threeCorrectedAnchorRangesInBoundsAndFunctionNamesMatch':True,'historicalBodiesRetained':preserved,'oldWaveFullRawAvailable':False,'oldWaveZeroDiagnosticAcceptance':False}
(out/'verification.json').write_text(json.dumps(row,ensure_ascii=False,indent=2)+'\n');print(json.dumps(row,ensure_ascii=False))
