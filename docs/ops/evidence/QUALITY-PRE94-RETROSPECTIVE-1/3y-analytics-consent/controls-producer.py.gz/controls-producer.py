from pathlib import Path
import json,gzip,hashlib,subprocess,tempfile,shutil,datetime
root=Path.cwd();out=root/'docs/ops/evidence/QUALITY-PRE94-RETROSPECTIVE-1/3y-analytics-consent';sha=lambda b:hashlib.sha256(b).hexdigest();before=json.loads((out/'before.json').read_text());oldspec={r['path']:gzip.decompress((out/r['snapshot']).read_bytes()) for r in before['files']};source='packages/game/src/analytics/analytics-consent.ts';main='packages/game/src/analytics/analytics-consent.test.ts';leaves='packages/game/src/analytics/analytics-consent.boundaries.test.ts'
def once(s,a,b):
 assert s.count(a)==1,(a,s.count(a));return s.replace(a,b)
def publish_before_commit(s):
 first="""  try {
    storage.setItem(ANALYTICS_CONSENT_STORAGE_KEY, consent)
  } catch {
    return false
  }

"""
 start=s.index(first);secondStart=start+len(first);secondEnd=s.index('  return true',secondStart);second=s[secondStart:secondEnd]
 return s[:start]+second+first+s[secondEnd:]

def notify_failed_storage(s):
 start=s.index('export function writeAnalyticsConsent(')
 return s[:start]+once(s[start:],"""  } catch {
    return false
  }""","""  } catch {
    eventTarget?.dispatchEvent(new CustomEvent(ANALYTICS_CONSENT_EVENT, { detail: consent }))
    return false
  }""")

controls=[
 ('publish-before-persistence',source,main,3,3,'默认宿主先持久化选择',publish_before_commit),
 ('dnt-zero-treated-as-signal',source,main,3,3,'DNT/GPC 仅在访客尚未选择',lambda s:once(s,"return navigatorLike?.doNotTrack === '1' || navigatorLike?.globalPrivacyControl === true","return Boolean(navigatorLike?.doNotTrack) || navigatorLike?.globalPrivacyControl === true")),
 ('default-write-host-missing',source,main,3,3,'默认宿主先持久化选择',lambda s:once(s,"storage: Pick<ConsentStorage, 'setItem'> | undefined = getBrowserConsentStorage(),","storage: Pick<ConsentStorage, 'setItem'> | undefined = undefined,")),
 ('notify-after-storage-failure',source,leaves,3,4,'持久化失败返回false且不广播',notify_failed_storage),
 ('browserless-falls-back-to-global-storage',source,leaves,3,4,'拒绝访问localStorage或无window',lambda s:once(s,'if (!browserWindow) return undefined','if (!browserWindow) return localStorage')),
]

current={r['path']:(root/r['path']).read_bytes() for r in before['files']};tmp=Path(tempfile.mkdtemp(prefix='type-pal-consent-controls-'));results=[]
try:
 for label,src,spec,oldN,newN,target,mutate in controls:
  mutant=mutate(current[src].decode()).encode();assert mutant!=current[src];(out/(label+'.mutant.gz')).write_bytes(gzip.compress(mutant,mtime=0));row={'id':label,'source':src,'spec':spec,'sourceSha256':sha(current[src]),'mutantSha256':sha(mutant),'expectedNewFailureNameContains':target,'expectedOldCount':oldN,'expectedCurrentCount':newN,'runs':{}}
  for phase,body in [('old',oldspec[spec]),('current',current[spec])]:
   report=tmp/(label+'.'+phase+'.json');cmd=['pnpm','--filter','@type-pal/game','exec','vitest','run',spec.removeprefix('packages/game/'),'--reporter=verbose','--reporter=json','--outputFile.json='+str(report)];started=datetime.datetime.now(datetime.timezone.utc).isoformat();n=oldN if phase=='old' else newN
   try:
    (root/src).write_bytes(mutant);(root/spec).write_bytes(body);proc=subprocess.run(cmd,cwd=root,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);raw=proc.stdout;(out/(label+'.'+phase+'.raw.gz')).write_bytes(gzip.compress(raw,mtime=0));native=report.read_bytes() if report.exists() else b''
    if native:(out/(label+'.'+phase+'.vitest.json.gz')).write_bytes(gzip.compress(native,mtime=0))
    record={'command':cmd,'cwd':str(root),'startedAt':started,'completedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit':proc.returncode,'signal':-proc.returncode if proc.returncode<0 else None,'spawnError':None,'raw':label+'.'+phase+'.raw.gz','rawBytes':len(raw),'rawSha256':sha(raw),'fullUncutMergedStdoutStderr':True,'specSha256':sha(body),'nativeReport':label+'.'+phase+'.vitest.json.gz','nativeSha256':sha(native)};row['runs'][phase]=record
    assert native;data=json.loads(native);cases=[a for f in data['testResults'] for a in f['assertionResults']];failed=[a for a in cases if a['status']=='failed'];record.update({'passed':data['numPassedTests'],'failed':data['numFailedTests'],'pending':data['numPendingTests'],'cases':[{'file':f['name'],'fullName':a['fullName'],'status':a['status']} for f in data['testResults'] for a in f['assertionResults']]})
    assert len(cases)==n and data['numPendingTests']==0 and not data.get('unhandledErrors',[]) and all(a['status'] in ['passed','failed'] for a in cases)
    assert 'stderr |' not in raw.decode()
    if phase=='old':assert proc.returncode==0 and not failed and data['numPassedTests']==n
    else:
     assert proc.returncode==1 and len(failed)==1 and data['numPassedTests']==n-1 and target in failed[0]['fullName'] and failed[0]['failureMessages'] and all('AssertionError' in m for m in failed[0]['failureMessages']);record['failureMessages']=failed[0]['failureMessages']
   finally:
    (root/src).write_bytes(current[src]);(root/spec).write_bytes(current[spec]);record=row['runs'].get(phase)
    if record:record.update({'sourceRestoredSha256':sha((root/src).read_bytes()),'specRestoredSha256':sha((root/spec).read_bytes()),'sourceRestoredByteForByte':(root/src).read_bytes()==current[src],'specRestoredByteForByte':(root/spec).read_bytes()==current[spec]})
  results.append(row);print(label+': old'+str(oldN)+' passed; current'+str(newN-1)+' passed/1 specified AssertionError',flush=True)
finally:
 for path,body in current.items():(root/path).write_bytes(body)
 shutil.rmtree(tmp);summary={'base':before['base'],'owner':'Codex single agent','scope':'Whole unfiltered old/current file per mutant. Three strengthen main storage/order/signal contracts; two disambiguate missing browser and failed persistence contracts. No real GA endpoint/browser/visual acceptance.','controls':results,'tempDirectory':str(tmp),'tempDirectoryRemoved':not tmp.exists(),'restored':all((root/k).read_bytes()==v for k,v in current.items())};(out/'controls.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n');(out/'controls-producer.py.gz').write_bytes(gzip.compress(Path('/tmp/type-pal-consent-controls.py').read_bytes(),mtime=0))
assert len(results)==len(controls) and summary['restored']
