from pathlib import Path
import json,gzip,hashlib,subprocess
root=Path.cwd();p=root/'docs/ops/evidence/QUALITY-PRE94-RETROSPECTIVE-1/3y-analytics-consent';base='28fcfbe310815bcfd712b2f3da1849e0f4076092';sha=lambda b:hashlib.sha256(b).hexdigest()
f=Path('/tmp/type-pal-consent-module-20261018.json');native=f.read_bytes();d=json.loads(native);assert d['numPassedTests']==24 and d['numFailedTests']==d['numPendingTests']==0 and len(d['testResults'])==6;(p/'module-final.vitest.json.gz').write_bytes(gzip.compress(native,mtime=0));f.unlink()
full=[r['path'] for r in json.loads((p/'before.json').read_text())['files']]+['packages/game/src/analytics/install-analytics.ts','packages/game/src/analytics/analytics-consent-ui.ts','packages/game/src/analytics/google-analytics.ts','packages/game/src/main.ts','packages/game/src/analytics/install-analytics.test.ts','packages/game/src/analytics/analytics-consent-ui.test.ts','packages/game/src/analytics/google-analytics.test.ts','packages/game/src/analytics/google-analytics.boundaries.test.ts','docs/ops/archive/tasks/done/CODE-QUALITY-3y-game-analytics-consent.md','docs/ops/archive/tasks/done/OPS-GA4-consent-pageviews.md','docs/ops/archive/tasks/done/TEST-GAME-HOST-BOUNDARIES-1-privacy-timer.md','docs/ops/tasks/CODE-QUALITY-109-game-analytics-install-review.md'];rows=[]
for path in full:
 b=Path(path).read_bytes();h=sha(b);name=h[:12]+'-'+Path(path).name+'.read.gz';(p/name).write_bytes(gzip.compress(b,mtime=0));rows.append({'path':path,'sha256':h,'lines':len(b.splitlines()),'ranges':[[1,len(b.splitlines())]],'fullRead':True,'snapshot':name,'scope':'Actual current source/caller/oracle/history read only; adjacent files not closed or product-authorized'})
(p/'read-boundaries.json').write_text(json.dumps({'base':base,'rows':rows,'phase':'First-stage project analytics extension; no SDLPal mechanism counterpart, no phase2 changes','primary':'Current typed IO ports and actual native Storage/EventTarget execution; original OPS-GA4 basic-consent scope is historical design provenance, not new authorization or legal advice'},ensure_ascii=False,indent=2)+'\n')
transfer=[
 {'from':'main case1 blocked storage write returns false','to':'H04 persistence-failure case','evidence':'Exact false return retained; add exact key/value/count and native dispatch zero.'},
 {'from':'main case2 granted storage/broadcast and invalid external detail','to':['main default-host commit-before-notify case','H04 unknown external event case'],'evidence':'Granted/denied exact stored state observed inside native callback; duplicate invalid/bogus strings both use the same isStoredConsent membership guard, keep one unknown-detail representative.'},
 {'from':'main case3 DNT/GPC positives and stored granted priority','to':'main case3','evidence':'Retain both pure positives and DNT fallback/granted priority; add false signals, GPC-only fallback, stored denied with/without signals moved from H04.'},
 {'from':'H04 case1 getter exception and throwing getItem; title falsely claimed no window','to':['H04 browser-storage case','main read case'],'evidence':'Typed hostile getter removes as never; actual undefined-window IO branch now executed. Throwing getItem already has identical catch-all branch in main, error message is not inspected.'},
 {'from':'H04 case2 dispatch exception returns true and exact key/value; stored denied priority','to':['H04 broadcast-failure case','main case3'],'evidence':'Native EventTarget with narrowly failing dispatch replaces unknown double cast, same true return and exact committed tuple retained; independent stored-denied contract moved to main.'},
 {'from':'H04 case3 external events, unsubscribe and typeof default-write boolean','to':['H04 external-event case','main default-host case'],'evidence':'Exact granted/unset/unset trace and zero callbacks after unsubscribe retained; typeof boolean replaced by exact true, storage key/value and callback-at-commit result. finally cleanup added.'}]
(p/'assertion-transfers.json').write_text(json.dumps({'base':base,'oldCounts':{'main':3,'boundaries':3},'currentCounts':{'main':3,'boundaries':4},'netTests':1,'policy':'No whole-case retirement or baseline edit; strengthen/split/move the exact storage/order/signal/unknown-event contracts, not a claim of identical test fullNames','transfers':transfer},ensure_ascii=False,indent=2)+'\n')
readme='''# CODE-QUALITY-3y analytics consent当前复审

Status: recorded
Owner: Codex（单Agent，自身源码/测试核证，不冒充第三方）
Date: 2026-10-18
Base: `28fcfbe310815bcfd712b2f3da1849e0f4076092`
Branch: `codex/code-quality-3y`

## 身份、准入与逐文件读取

id: QUALITY-PRE94-RETROSPECTIVE-1 / 3y-analytics-consent；schemaVersion:1；status:recorded。沿用[父卡](../../../tasks/QUALITY-PRE94-RETROSPECTIVE-1.md)低风险注释/测试准入。旧卡CODE-QUALITY-3y与治理分支同名是两个身份；本片非CODE109后续范围扩张。三原文件90/57/71行全文；安装器/两消费端/主入口及四相邻测试、OPS/宿主历史卡全文见[实际边界](read-boundaries.json)。未把旧done或未成功的protected结果继承为当前accept。

## Primary、caller、ownership与实现结论

这是第一阶段项目扩展，SDLPal无此UI/统计功能；不伪造原版依据。OPS-GA4历史basic-consent意图与当前typed端口为项目合同来源，不沿用旧签字/法律断语。main只在页面入口安装并隔离异常；install将真实window/document/storage注入UI和GA，未传subscribePage；当前main未持有installation是页面生命周期，测试须自己destroy。UI选择先write成功才隐藏面板；GA订阅真实consent事件并在非granted时停发，生产消费者使用同一window。无任何游戏状态/存档/输入订阅。

consent源纯读写与事件端口边界清楚，存储缺失/读异常/非法外部stored值归unset，DNT='1'/GPC=true只给无选择者默认denied。存储写失败返回false且不广播；成功写后同步广播，广播异常吞掉且仍true。源码旧“广播异常仍失败关闭”无充分支持，改成只描述已提交且不保证订阅者收通知；[parsedTS/JS证明](emit-identity.json)相同，产品执行未改。未更改隐私策略、GA网络、UI形态、schema/save、资产或公共接口。

## 测试问题、修复与排重

旧主测清空全部localStorage，订阅无finally；H04有as never/unknown双强转、标题称无window却没执行、默认宿主只typeof boolean，混放dispatch失败与stored-denied，读异常/非法事件重复。现两文件只保存/恢复自有持久键；订阅/spy/window模拟精确finally清理。getter的never返回类型是合法拒绝访问IO，直接满足Pick<Window,'localStorage'>；EventTarget保持真实，仅模拟宿主dispatch异常。没有核心mock、强转、ignore/降规则或放宽断言。

主测3例：独立持久键/合法两态/未知或抛错读；默认真实Storage+window的granted/denied写入，listener在通知当场读到提交值；信号真假、DNT与GPC单独fallback、保存的granted/denied均优先。H04从3拆成4例：实际无window/属性拒绝、写失败false且零广播、广播失败true且精确写键值、真实未知事件与unsubscribe后零回调。[逐断言迁移](assertion-transfers.json)保留原有效合同；不同异常文案/无效detail字面值因同一catch-all/二值membership条件归并，不按测试名相似臆断等价。没有整例退役或baseline/测试catalog改动；历史报告与SHA保留。

[五反控](controls.json)全文件未过滤：先通知后持久化、DNT='0'误识别、默认写宿主丢失，各旧主3绿→新主2绿1指定AssertionError；写失败仍通知、无window回退全局storage，各旧H04 3绿→新H04 3绿1指定AssertionError。native完整file×fullName/JSON/raw/command/cwd/exit/signal/spawn和源/测试/mutant SHA、逐轮finally恢复与精确临时树清理均保留。正常恢复7定向+17相邻（6文件24绿）、game typecheck零诊断；jsdom未执行真实Google端点，不以DOM script断言冒充实网/生产采集验收。

## 当前状态、门与限制

三路径此前未在live表登记，按真实tracked库存属于pending；本次只pending→review，不是撤销三个既有关闭。最终机器3315 tracked /261 closed /85 review /2969 pending，0新closed。只CODE-QUALITY-3y从pending→partial；83卡52partial/31pending/0accept，scopeConfirmed=false和currentAcceptance=false保留，其他82对象/历史SHA完全不改。旧历史卡继续原路径/原done时点，不恢复新门。

[门回执](gates.json)保留完整未裁剪gzip原件与实际诊断。全仓check、official coverage ratchet、protected fast按用户成本规则留大任务收尾；本片不跑全包/生产部署/浏览器视觉/E2E，不合main。全仓现有诊断与其它pending并未由本片消除。

未验证仍有跨window/realm与非默认storage注入组合、广播失败时现存GA订阅的端到端一致性、真实存储策略/浏览器/网络行为及完整UI卸载。当前同窗生产caller未发现本片可直接修复的新执行缺陷；未知不当已验证，也不修政策或接口。重复的小型测试自有键hooks暂留各文件owner；更大的宿主复用须先核UI/GA不同全局清理域，不为了抽象扩大白名单。

## 交接与下一批

同一治理分支提交推送、fresh fetch确认0behind；三源/测继续review，不将静态绿数写成整卡accept。下一批CODE-QUALITY-3z：google-analytics.ts与两专测，重点订阅/全局恢复、UTM坏注、异步script生命周期和真实consumer；GA/隐私/网络行为若需改，先专卡裁决。94–102/editor后置，无下一位Agent提示词，Codex继续全部83卡。
'''
(p/'README.md').write_text(readme)
# Add three actual live review records at the end of the first continuously parsed table only.
f=Path('docs/ops/audits/code-quality-file-ledger.md');s=f.read_text();lines=s.splitlines();i=next(i for i,l in enumerate(lines) if l.startswith('| 文件 |'))+2
while lines[i].startswith('|'):i+=1
new=[
'| `packages/game/src/analytics/analytics-consent.ts` | product | review | [pre94 consent复审](../evidence/QUALITY-PRE94-RETROSPECTIVE-1/3y-analytics-consent/README.md)；90行全文，真实main/install/UI/GA与OPS项目合同 | 只修广播失败过强注释，parsedTS/JS相同；跨realm/注入组合和实网端到端未知，不关闭 |',
'| `packages/game/src/analytics/analytics-consent.test.ts` | test | review | [pre94 consent复审](../evidence/QUALITY-PRE94-RETROSPECTIVE-1/3y-analytics-consent/README.md)；57行原测全文，独立持久键/真实默认Storage+window、通知时已提交与信号优先级 | 三旧3绿→新2绿1指定AssertionError；3例保持，按自有键/finally隔离；7定向/17相邻仅有限信用 |',
'| `packages/game/src/analytics/analytics-consent.boundaries.test.ts` | test | review | [pre94 consent复审](../evidence/QUALITY-PRE94-RETROSPECTIVE-1/3y-analytics-consent/README.md)；71行原测全文，typed getter/原生EventTarget、无window与失败零通知 | 两旧3绿→新3绿1指定AssertionError；3→4拆职责，读异常/denied与重复detail逐断言迁主测；零新关闭 |']
lines[i:i]=new;s='\n'.join(lines)+'\n';old='当前已闭合核验：261；已读但待审：82；尚未逐文件核验：2,972；合计未闭合：3,054。';assert s.count(old)==1;s=s.replace(old,'当前已闭合核验：261；已读但待审：85；尚未逐文件核验：2,969；合计未闭合：3,054。');f.write_text(s)
# One queue object, one markdown row, and the current count fields. Historical payloads remain untouched.
f=Path('docs/ops/evidence/QUALITY-PRE94-RETROSPECTIVE-1/all-cards.json');q=json.loads(f.read_text());r=next(r for r in q['cards'] if r['id']=='3y');assert r['currentReview']=='pending' and not r['scopeConfirmed'] and not r['currentAcceptance'];r['currentReview']='partial';r['evidence']=str(p.relative_to(root)/'README.md');q['currentReviewCounts']={'partial':52,'pending':31};f.write_text(json.dumps(q,ensure_ascii=False,indent=2)+'\n')
f=Path('docs/ops/evidence/QUALITY-PRE94-RETROSPECTIVE-1/all-cards.md');s=f.read_text();assert s.count('partial=51，pending=32')==1;s=s.replace('partial=51，pending=32','partial=52，pending=31');lines=s.splitlines();i=next(i for i,l in enumerate(lines) if l.startswith('| [CODE-QUALITY-3y]'));assert '| done | pending |' in lines[i];lines[i]='| [CODE-QUALITY-3y](../../archive/tasks/done/CODE-QUALITY-3y-game-analytics-consent.md) | done | partial | [consent三文件](3y-analytics-consent/README.md)：原生存储/事件和五旧绿新单红，7定向/17相邻；跨realm/实网/统一门仍待 |';f.write_text('\n'.join(lines)+'\n')
f=Path('docs/ops/board.md');s=f.read_text();assert s.count('83卡51partial/32pending/0accept；')==1;s=s.replace('83卡51partial/32pending/0accept；','83卡52partial/31pending/0accept；consent三文件补证；');f.write_text(s)
f=Path('docs/ops/tasks/QUALITY-PRE94-RETROSPECTIVE-1.md');s=f.read_text();assert '当前复审队列已推进为51张partial、32张pending' in s;s=s.replace('当前复审队列已推进为51张partial、32张pending','当前复审队列已推进为52张partial、31张pending',1);s=s.replace('83卡当前全量accept=0、51partial/32pending','83卡当前全量accept=0、52partial/31pending',1);s+='''\n本片交付：三原文件90/57/71行及真实install/UI/GA/main、相邻测试与原OPS/宿主卡已全文核证；源仅校正广播异常不回滚的事实注释。两测去不必要强转、只恢复自有key、订阅/spy/window异常finally清理，旧duplicate/混职责逐断言迁移；主3保持、H04 3→4。五旧全文件3绿→新主2绿1指定AssertionError（三枚）/新H04 3绿1指定AssertionError（两枚），正常7直接/17相邻与game typecheck零诊断。三原未列pending→review，3315/261closed/85review/2969pending，0关闭；只3y pending→partial，83卡52/31/0accept，scopeConfirmed=false保留。详见[consent证据](../evidence/QUALITY-PRE94-RETROSPECTIVE-1/3y-analytics-consent/README.md)；未知跨realm/注入组合与广播失败端到端继续review，不修改隐私/GA网络、UI、save/schema、资源或API。最终docs/lint/ledger看gates，全仓check/coverage/protected仍留大任务收尾、不合main；下一批旧3z GA源/两测试，无下一位Agent提示词。\n''';f.write_text(s)
rows=[]
for label,n in [('baseline',6),('current',7),('module-final',24),('typecheck',None)]:
 r=json.loads((p/(label+'.json')).read_text());assert r['exit']==0;raw=gzip.decompress((p/r['raw']).read_bytes()).decode();assert not any(k in raw for k in ['stderr |','not wrapped in act','Unhandled Errors','Unhandled Rejection','not configured to support act']);row={'label':label,'receipt':label+'.json','exit':0,'diagnostics':{'stderrBlocks':0,'reactAct':0,'environmentWarning':0,'unhandledErrors':0,'unhandledRejection':0}}
 if n is not None:row['passed']=n
 if label=='module-final':row.update(files=6,direct=7,adjacent=17,nativeReport='module-final.vitest.json.gz',nativeReportSha256=sha(native),temporaryNativeReportRemoved=True)
 rows.append(row)
(p/'gates.json').write_text(json.dumps({'base':base,'status':'7direct/17adjacent and game typecheck recorded; final docs/lint/ledger pending','rows':rows,'tracked':3315,'closed':261,'review':85,'pending':2969,'newClosed':0,'cards':{'partial':52,'pending':31,'accept':0},'mergeAllowed':False,'productExecutionChanged':False,'notRun':['whole repository pnpm check','official coverage ratchet','protected fast','full game package test','real Google endpoint','production deployment','browser visual','E2E']},ensure_ascii=False,indent=2)+'\n')
(p/'docs-producer.py.gz').write_bytes(gzip.compress(Path('/tmp/type-pal-consent-docs.py').read_bytes(),mtime=0));(p/'capture.py.gz').write_bytes(gzip.compress(Path('/tmp/type-pal-consent-capture.py').read_bytes(),mtime=0));print('Bounded consent report, assertion transfers, three live review records and one-card queue delta recorded.')
