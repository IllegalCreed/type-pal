from pathlib import Path
import json,hashlib,subprocess,gzip
base='28fcfbe310815bcfd712b2f3da1849e0f4076092';prefix=Path('docs/phase-governance/reviews');out=Path('docs/ops/evidence/QUALITY-PRE94-RETROSPECTIVE-1/3y-analytics-consent')
targets={'20261004-semantic-current-batch.json':['docs/ops/board.md'],'20261016-historical-cards-d.json':['docs/ops/audits/code-quality-file-ledger.md'],'20261017-r93-phase-governance-artifacts.json':[str(prefix/'20261004-semantic-current-batch.json'),str(prefix/'20261016-historical-cards-d.json')],'20261017-r94-final-machine-artifacts.json':[str(prefix/'20261017-r93-phase-governance-artifacts.json')]}
for fn,paths in targets.items():
 p=prefix/fn;lines=p.read_text().splitlines()
 for target in paths:
  pi=next(i for i,l in enumerate(lines) if l==f'      "path": "{target}",');st=next(i for i in range(pi,-1,-1) if lines[i]=='    {');en=next(i for i in range(pi+1,len(lines)) if lines[i] in ['    },','    }']);hi=next(i for i in range(st,en) if lines[i]=='        "history": [');blob=Path(target).read_bytes();cur=hashlib.sha256(blob).hexdigest();old=hashlib.sha256(subprocess.check_output(['git','show',base+':'+target])).hexdigest();assert cur!=old
  item={'revision':base,'date':'2026-10-18','action':'Review three pending consent files and strengthen storage/event host oracles','previousAfterSha256':old,'scope':'Only three previously unlisted pending paths become live review records; no closure. One source factual comment only; two tests main3/H04 3 to main3/H04 4 with exact assertion transfers. Five full-file old3 green/current specified-single-AssertionError controls, restored7 direct/17 adjacent and game typecheck do not grant whole-file/native/real-network/visual/unified acceptance. Only CODE3y pending to partial,83cards52partial/31pending/0accept;scopeConfirmed=false and historical payloads retained. One board progress row and ledger counts updated. No baseline/retirement/schema/assets/save/API changes. Original native verdict/history retained.','evidence':str(out/'README.md'),'notRun':['whole-repository check','official coverage ratchet','protected fast','browser visual','E2E']}
  block=['          '+l for l in json.dumps(item,ensure_ascii=False,indent=2).splitlines()];block[-1]+=',';lines[hi+1:hi+1]=block;en+=len(block)
  for i in range(st,en):
   if lines[i].startswith('      "afterSha256": '):lines[i]=f'      "afterSha256": "{cur}",'
   elif lines[i].startswith('        "implementationSha": '):lines[i]=f'        "implementationSha": "{cur}",'
   elif lines[i].startswith('        "afterSha256": '):lines[i]=f'        "afterSha256": "{cur}",'
   elif lines[i].startswith('      "reviewedLines": '):lines[i]=f'      "reviewedLines": "1-{len(blob.decode().splitlines())}",'
 p.write_text('\n'.join(lines)+'\n');subprocess.run(['pnpm','exec','biome','format','--write',str(p)],check=True,stdout=subprocess.PIPE)
(out/'review-chain-producer.py.gz').write_bytes(gzip.compress(Path('/tmp/type-pal-consent-chain.py').read_bytes(),mtime=0));print('Four bounded current board/ledger incoming bindings updated; original native verdict/history unchanged.')
