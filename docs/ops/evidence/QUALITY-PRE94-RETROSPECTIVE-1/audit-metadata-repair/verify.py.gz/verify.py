# -*- coding: utf-8 -*-
from pathlib import Path
import json,gzip,hashlib,subprocess
root=Path.cwd();parent=Path('docs/ops/evidence/QUALITY-PRE94-RETROSPECTIVE-1');out=parent/'audit-metadata-repair';v=json.loads((out/'corrections.json').read_text());changes=v['changes'];restored=[]
def sha(b):return hashlib.sha256(b).hexdigest()
for row in changes:
 p=Path(row['target'])
 if 'before' in row:
  before=gzip.decompress((out/row['before']).read_bytes());atbase=subprocess.check_output(['git','show',v['base']+':'+str(p)]);assert before==atbase;restored.append({'target':str(p),'originalBytes':len(before),'originalSha256':sha(before),'gzip':row['before']})
 if row['kind']=='battle-c-truncated-sha':
  x=json.loads(p.read_text());r=next(r for r in x['partialReads'] if r['path']=='reference/sdlpal/battle.c');b=Path(r['path']).read_bytes();assert len(row['previousSha256'])==63 and len(r['sha256'])==64 and sha(b)==r['sha256'] and r['sha256'].startswith(row['previousSha256']) and len(b.decode().splitlines())==r['lines']
 if row['kind']=='42-sha-line-pair':
  for r in json.loads(p.read_text())['fullReads']:
   b=Path(r['path']).read_bytes();assert sha(b)==r['sha256'] and len(b.decode().splitlines())==r['lines']
 if row['kind'] in ['3v-canon-range','intro-snapshot-eof']:
  for r in json.loads(p.read_text())['partialReads']:
   if ('game-mechanics.md' in r['path'] and row['kind']=='3v-canon-range') or (r['path']=='reference/sdlpal/battle.c' and row['kind']=='intro-snapshot-eof'):
    b=Path(r['path']).read_bytes();n=len(b.decode().splitlines());assert sha(b)==r['sha256'] and r['lines']==n
    for span in r['ranges']:a,z=map(int,span.split('-'));assert 1<=a<=z<=n
x=json.loads((parent/'55-draw-menu/read-boundaries.json').read_text());assert x['base']==v['base'] and x['historicalReportBase']=='f544b9b94'
for r in x['fullReads']+x['partialReads']:
 b=Path(r['path']).read_bytes();n=len(b.decode().splitlines());assert sha(b)==r['sha256'] and n==r['lines']
 for span in r.get('ranges',[]):a,z=map(int,span.split('-'));assert 1<=a<=z<=n
assert len([r for r in changes if r['kind']=='battle-c-truncated-sha'])==5
assert subprocess.check_output(['git','diff','--name-only',v['base'],'--','packages','scripts'])==b''
proof={'base':v['base'],'scope':'Codex separate-process evidence integrity self-check, no independent reviewer/product acceptance','correctedItems':len(changes),'battleShaCount':5,'beforeAttachmentsReversible':restored,'55RecordIsFreshSupplement':True,'55OldOriginalRecovered':False,'productionAndTestBytesUnchanged':True,'newClosures':0};(out/'verification.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n');print(json.dumps(proof,ensure_ascii=False))
