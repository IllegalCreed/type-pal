import { createInitialGameState } from '/Users/zhangxu/.codex/worktrees/quality-menu-accept-94-95/type-pal/packages/game/src/core/game-state.ts'
import { addPoisonForPlayer, setObjectPoisons } from '/Users/zhangxu/.codex/worktrees/quality-menu-accept-94-95/type-pal/packages/game/src/core/player-poison-state.ts'
const state = createInitialGameState({x:0,y:0,facing:'down'})
state.partyMembers = [2,0]
try {
  setObjectPoisons([{id:100,level:2,color:0,playerScript:0,enemyScript:0}])
  addPoisonForPlayer(state,2,100)
  console.log(JSON.stringify({party:state.partyMembers,role:2,partySlot:state.partyMembers.indexOf(2),actualKeys:Object.keys(state.rgPoisonStatus),actualPoison:state.rgPoisonStatus['0_2'],partyKey:state.rgPoisonStatus['0_0']??null}))
} finally {setObjectPoisons([])}
