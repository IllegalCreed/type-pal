from pathlib import Path
import gzip,hashlib,json,subprocess
p=Path('docs/ops/evidence/QUALITY-PRE94-RETROSPECTIVE-1/3u-state-factory');base='9c2c5eabe143bc81ad8df1c9234aa741b130aabc'
def sha(b):return hashlib.sha256(b).hexdigest()
def write(name,d): (p/name).write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
def once(path,a,b):
 f=Path(path);s=f.read_text();assert s.count(a)==1,(path,a);f.write_text(s.replace(a,b))
raw=Path('/tmp/type-pal-state-module-20261018.json').read_bytes();native=json.loads(raw);assert native['numPassedTests']==283 and native['numFailedTests']==0
(p/'module.vitest.json.gz').write_bytes(gzip.compress(raw,mtime=0));Path('/tmp/type-pal-state-module-20261018.json').unlink()
reads={
 'packages/game/src/core/battle/battle-state.ts':None,
 'packages/game/src/core/battle/__tests__/battle-state.test.ts':None,
 'packages/game/src/core/battle/battle-state.glm-next-wave.test.ts':None,
 'packages/game/src/__tests__/glm-next-wave/H/harness.ts':None,
 'packages/game/src/core/battle/battle-positions.ts':None,
 'packages/game/src/core/battle/turn-queue.ts':[[1,100]],
 'packages/game/src/core/battle/battle-system.ts':[[270,355],[838,844],[895,945],[1938,1975]],
 'packages/game/src/core/battle/battle-opcodes.ts':[[1425,1458]],
 'packages/game/src/core/battle/battle-state-machine.glm-battle.test.ts':[[1,135]],
 'reference/sdlpal/battle.c':[[17,38],[903,945],[1560,1775]],
 'reference/sdlpal/global.h':[[40,62]],
 'reference/sdlpal/fight.c':[[1632,1674]],
 'docs/phase1/game-mechanics.md':[[1480,1595]],
}
rows=[]
for path,ranges in reads.items():
 b=Path(path).read_bytes();h=sha(b);n=len(b.decode().splitlines());name=h[:12]+'-'+Path(path).name+'.read.gz';(p/name).write_bytes(gzip.compress(b,mtime=0));rows.append({'path':path,'sha256':h,'lines':n,'fullRead':ranges is None,'ranges':ranges or [[1,n]],'snapshot':name,'scope':'Actual semantic read ranges; whole gzip is only a byte snapshot. Adjacent test execution does not accept unread tests.'})
write('read-boundaries.json',{'base':base,'owner':'Codex single agent','rows':rows})
old=json.loads(gzip.decompress((p/'baseline.vitest.json.gz').read_bytes()));formal=native
oldcases=[{'file':f['name'].split('/type-pal/')[-1],'fullName':a['fullName']} for f in old['testResults'] for a in f['assertionResults']]
newcases=[{'file':f['name'].split('/type-pal/')[-1],'fullName':a['fullName']} for f in formal['testResults'] for a in f['assertionResults'] if f['name'].endswith(('__tests__/battle-state.test.ts','battle-state.glm-next-wave.test.ts'))]
write('assertion-transfers.json',{'base':base,'oldCounts':{'main':14,'glm':4},'currentCounts':{'main':14,'glm':3},'wholeCasesRetired':2,'newBusinessCases':1,'replacedWeakCases':1,'oldCases':oldcases,'currentCases':newcases,'decisions':[
 {'from':'phase 字段联合 7 种','decision':'retire no-business runtime count','reason':'It counts its own literal array and never invokes SUT. BattlePhase remains production TypeScript contract; no new runtime credit or replacement assertion count. Existing real factory preBattle oracle retained.'},
 {'from':'B-w0.3 status JSON roundtrip','decision':'replace with actual factory status ownership','reason':'Manual writes followed by JSON cannot guard seeding; silence/puppet/bravery/protect/dualAttack are now asserted on factory results, no serialization claim. Live-player puppet remains zero because startBattle revives then clears it; no fake live-puppet fixture.'},
 {'from':'GLM players prevHp/prevMp/scriptPrevHp','decision':'merge into main player snapshot','reason':'All three field oracles retained plus source mutation must not change snapshots. Original GLM MP45 exceeded maxMP40; remaining boot now maxMP60. Conservation mutant removes scriptPrevHp: old whole GLM gets one specific failure and current whole main gets one matching snapshot failure; not an old-green regression needle.'},
 {'from':'D14 two seeded/default fields','decision':'strengthen all nine by role identity','reason':'Party[2,0], distinct legal counters, exact CLASSIC mapping and slow0. Includes ordinary/equipment values; no poison key or phase2 change.'},
 {'from':'GLM placeholder position is defined','decision':'replace irrelevant placeholder layout assertion with real enemy position','reason':'Production render/target logic skips defeated placeholder; real enemy must still use two-slot layout despite null entry. Exact real position now checked against independent literal oracle.'},
 {'from':'enemy health/id zero and identity','decision':'retain and strengthen','reason':'Zero numeric fields/element vector on placeholder from C memset; live enemy shallow identity, maxHealth, prevHp and source/current HP isolation retained. C primitive zero-field parity is not a claim that all unused empty fields have live consumers.'},
 {'from':'97-line duplicate complete role/enemy construction','decision':'reuse existing pure H resource factories','reason':'H222 fully read; only makeHRole/makeHEnemy/makeHField reused. Actual core RNG and ActionQueue builder used, no copied RNG algorithm/core mocks/casts.'}
 ],'authority':{'source':'User-provided AGENTS.md in current session, reaffirming 2026-10-03 test-quality rule','quote':'已证重复、恒真或无业务执行的用例精简，类型合同走typecheck，不计运行时数量','scope':'Only the two named cases and explicit oracle transfers here; no inherited 2026-10-03 OPQ five-file authorization or individual user signature claimed.'},'protectedGateStatus':'Deferred to large closeout: baseline and retirement registry unchanged, identity/count reconciliation still pending; no protected acceptance claimed.'})
write('gates.json',{'base':base,'status':'Module283/typecheck/controls recorded; docs/lint/ledger pending','rows':[{'label':'module','receipt':'module.json','files':7,'passed':283,'direct':17,'adjacent':266,'nativeReport':'module.vitest.json.gz','nativeReportSha256':sha(raw),'diagnostics':{'stderrBlocks':0,'errors':0,'warnings':0,'infos':0}},{'label':'typecheck','receipt':'typecheck.json','exit':0,'diagnostics':{'errors':0,'warnings':0,'infos':0}}],'regressionControls':6,'conservationControl':1,'tracked':3316,'closed':253,'review':98,'pending':2965,'newClosed':0,'reopenedReview':2,'cards':{'partial':55,'pending':28,'accept':0},'mergeAllowed':False,'productExecutionChanged':False,'reuseDocsTools':{'sourceCommit':'37e2cd7c9a54b29766a87d17ffed90e4dae465dd','receipt':'../../QUALITY-DOCS-GIT-PATH-ENUMERATION-1/docs.json','toolsPassed':125,'scope':'Docs tool/test bytes unchanged; this slice runs actual five consumers only, not a new whole check:docs.'},'notRun':['whole repository check','official coverage ratchet','protected fast','full game package','original game runtime','browser visual','E2E']})
(p/'README.md').write_text('''# CODE3u BattleState工厂专测复审

Status: recorded
Owner: Codex（单Agent核读/执行，不冒充第三方）
Date: 2026-10-18
Base: `9c2c5eabe143bc81ad8df1c9234aa741b130aabc`
Branch: `codex/code-quality-3y`

## 范围与证据

按[父卡](../../../tasks/QUALITY-PRE94-RETROSPECTIVE-1.md)低风险准入：实现916行、原主383行/GLM81行全文，现主340行/GLM82行全文；H222和positions93全文。实际读范围、当前SHA与原字节分别见[read-boundaries](read-boundaries.json)、[before](before.json)。原[清理/runtime片](../3u-3w-finalization/README.md)信用继续有限保留；本片不替它关闭Extra可达性。

第一阶段：真实startBattle展开队槽、重跑装备再构造；CLASSIC状态global.h:40–60逐role九槽，C玩家状态直接用持久表，TS显式seed独立视图。battle.c:1598–1720支持零槽保留和敌资源拷贝，:903–945支持人数布局与yOffset；玩家快照实际供battle-system casualty脚本使用，0x64读敌maxHealth，不读玩家scriptPrevHp。机制文档1480–1595的旧全域等价断言不作为本轮全部语义验收；非队员Extra未知仍归既有draft。只证明源码/C参考范围，未运行原版。

## 实际修改、排重和输入

生产battle-state.ts未改，完整字节同基点；没有新产品取舍、公开接口、schema/save、资源或二阶段变化。实现全文读过，但庞大动画/UI类型的全部caller、脚本元数据/极端数值/容量域及所有注释锚尚未全核，继续review。

两测复用已读H的三个纯资源工厂，去重复结构定义；不用H的仿RNG，直接用core RNG。行动队列也取真实buildActionQueue，按真实ActionQueueItem字段；早期17绿候选曾手拼错index/dexterity，代码检查后纠正，旧raw保留、不授typecheck或最终身份信用，见[早期限制](early-candidate-limit.json)。

撤掉只数自写枚举的运行时用例；手写状态再JSON的case改为真正构造/持久数组/下一场视图隔离；GLM三玩家快照断言合并主测并保留源突变后不变，另纠正MP45>maxMP40夹具。九状态按party[2,0]逐role映射，不凭位置猜角色，普通计数和>999好状态都保留；活人傀儡设0，不能拿正式开战会清除的组合冒充可达。空槽旧“坐标非空”改为真正活敌使用包含null的两槽布局；零值统计仅C primitive合同，不扩张为每个空字段都有生产消费。原边界抛错、人数、玩家/敌坐标、yOffset和其它业务断言保留。

[逐项迁移](assertion-transfers.json)：18→17，退两整例（一无业务枚举、一重复快照），增一个真实局部队列ownership例，另替换一弱JSON例。主14保持/GLM4→3；不是按数量或覆盖率取舍。现行测试少而精指令是这两例的适用授权，不借10-03旧OPQ头自批其它退役；baseline/退役registry未动，protected身份/计数协调留大窗口，不能宣称已通过。

## 判别力和实际验证

[六反控](controls.json)均完整未过滤文件：role→party误接、silence读sleep、同持久数组缓存状态视图、共享pendingActions、压掉null布局人数、空槽cash非零。各旧14或4全绿→当前恰一指定业务AssertionError，其余13或2绿；0skip/pending/runtime failure，源/测试/mutant和native/raw字节、身份、finally恢复及自有临时目录清理完整保存。

[快照保全针](snapshot-conservation.json)另计：暂去scriptPrevHp，冻结旧GLM与当前主测均恰一指定快照AssertionError，证明合并没有丢该oracle；不把双红保全冒充旧绿新红反控。正常源逐字节恢复后7文件283绿（17直接/266相邻），game typecheck零诊断。更早17绿raw仅历史；最终看module native。相邻执行不签收其整文件。

## 当前结论与后续

两旧关闭专测重开review；实现原review保持，0新增closed。机器以[实际gates](gates.json)为准：3316 tracked /253 closed /98 review /2965 pending；83卡55partial/28pending/0accept不变，仅3u当前证据指针更新，其余82对象/原历史SHA不改。

完整check/official coverage/protected fast按用户要求留大任务收尾；本片不跑全game、原版/浏览器/E2E，不合main。接下来继续3u剩余factory输入/caller与3w settlement，或40/41未核切片，94–102/editor后置。无下一位Agent提示词，Codex单Agent继续。
''')
ledger='docs/ops/audits/code-quality-file-ledger.md';once(ledger,'当前已闭合核验：255；已读但待审：96；尚未逐文件核验：2,965；合计未闭合：3,061。','当前已闭合核验：253；已读但待审：98；尚未逐文件核验：2,965；合计未闭合：3,063。')
f=Path(ledger);lines=f.read_text().splitlines();inLive=True;targets={'packages/game/src/core/battle/battle-state.ts':('product','916行实现全文；真实startBattle/九状态/快照/坐标与C','实现字节未改；动画/UI类型全caller、元数据与极端域仍待，不关闭'),'packages/game/src/core/battle/__tests__/battle-state.test.ts':('test','383行原测全文，现340行；九状态role/局部owner/资源隔离与typed工厂','枚举无业务撤销，JSON改真实隔离，快照合并保全；六旧绿新单红，整卡未完'),'packages/game/src/core/battle/battle-state.glm-next-wave.test.ts':('test','81行原测全文，现82行；合法MP/零槽与实际活敌layout oracle','快照迁主测有双红保全，4→3排重；旧关闭重开review，0新增关闭')};seen=[]
for i,line in enumerate(lines):
 for path,(kind,evidence,limitation) in targets.items():
  if line.startswith('| `'+path+'`') and path not in seen:
   lines[i]='| `'+path+'` | '+kind+' | review | [state工厂复审](../evidence/QUALITY-PRE94-RETROSPECTIVE-1/3u-state-factory/README.md)；'+evidence+' | '+limitation+' |';seen.append(path)
assert len(seen)==3;f.write_text('\n'.join(lines)+'\n')
once('docs/ops/board.md','清理/runtime四文件补证','state两测补强与排重')
f=Path('docs/ops/evidence/QUALITY-PRE94-RETROSPECTIVE-1/all-cards.json');d=json.loads(f.read_text());row=next(r for r in d['cards'] if r['id']=='3u');assert row['currentReview']=='partial' and not row['currentAcceptance'];row['evidence']=str(p/'README.md');f.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
f=Path('docs/ops/evidence/QUALITY-PRE94-RETROSPECTIVE-1/all-cards.md');s=f.read_text();line=next(l for l in s.splitlines() if '[CODE-QUALITY-3u]' in l);s=s.replace(line,'| [CODE-QUALITY-3u](../../archive/tasks/done/CODE-QUALITY-3u-game-battle-state-runtime.md) | done | partial | [工厂专测](3u-state-factory/README.md)：六针/快照保全，18→17排重；原清理片有限信用保留，元数据/极端域/统一门仍待 |');f.write_text(s)
f=Path('docs/ops/evidence/QUALITY-PRE94-RETROSPECTIVE-1/README.md');s=f.read_text();s=s.replace('2026-10-18 清理/runtime复审；下文数字均按各片原时点','2026-10-18 state复审；下文数字均按各片原时点');s+='\n最新[3u state工厂专测](3u-state-factory/README.md)：两测复用typed资源工厂、九状态role映射/owner隔离/实际活敌layout，六旧绿新单红和迁移快照双红保全；18→17，7文件283绿/TC零诊断。两旧关闭转review、实现原字节保持；3316/253/98/2965，83卡55/28/0accept不变。元数据/极端域及统一门仍待，protected身份/计数协调留大窗口，不合main。\n';f.write_text(s)
f=Path('docs/ops/tasks/QUALITY-PRE94-RETROSPECTIVE-1.md')
with f.open('a') as out:out.write('\n本片交付：两测typed工厂复用，九状态role映射/隔离、HPMP/script快照及零槽活敌layout补强；18→17精简，枚举无业务撤销、GLM快照完整迁主测且有双红保全，六旧绿新指定单红均逐字节恢复。7文件283（17直接/266相邻）及TC零诊断，早期手拼queue字段候选局限原件保留。两旧专测关闭重开review，state实现字节不改；机器3316/253closed/98review/2965pending，83卡55partial/28pending/0accept不变，仅3u证据指针更新；生产/phase2/schema/save/UI无改。详见[state证据](../evidence/QUALITY-PRE94-RETROSPECTIVE-1/3u-state-factory/README.md)。全仓/official coverage/protected仍留大任务窗口，baseline/退役registry未变，身份协调未通过；不合main，后续3u输入/caller或3w/40/41，94–102/editor后置。无下一位Agent提示词。\n')
(p/'docs-producer.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0));print('Two old test closures reopened; queue55/28/0 unchanged; incoming review bindings still pending.')
