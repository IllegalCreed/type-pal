from pathlib import Path
import re,gzip
p=Path('packages/game/src/core/battle/__tests__/battle-state.test.ts');s=p.read_text()
s=s.replace("import { type BattlePhase, createBattleState } from '../battle-state.js'", "import {\n  makeHEnemy,\n  makeHField,\n  makeHRole,\n} from '../../../__tests__/glm-next-wave/H/harness.js'\nimport { createBattleState } from '../battle-state.js'")
a=s.index('function minimalRole(');b=s.index("describe('createBattleState'")
s=s[:a]+'''function minimalRole(id: number): PlayerRole {
  return makeHRole(id, { maxHP: 200, maxMP: 30, hp: 200, mp: 30 })
}

function minimalEnemy(id: number, health = 50): Enemy {
  return makeHEnemy({ id, health })
}

'''+s[b:]
s=s.replace('health shallow copy、roleId 错配抛错、phase 枚举 7 种。','health 隔离、roleId/人数边界、九状态按角色映射与每场局部 ownership。')
s,n=re.subn(r"field: \{\n\s+id: 0,\n\s+screenWave: 0,\n\s+magicEffect: \{ wind: 0, thunder: 0, water: 0, fire: 0, earth: 0 \},\n\s+\},",'field: makeHField(),',s);assert n==13,n
s=s.replace("    expect(state.players[0]?.prevMp).toBe(30)\n", "    expect(state.players[0]?.prevMp).toBe(30)\n    expect(state.players[0]?.scriptPrevHp).toBe(200)\n    role.hp = 9\n    role.mp = 8\n    expect(state.players[0]?.prevHp).toBe(200)\n    expect(state.players[0]?.prevMp).toBe(30)\n    expect(state.players[0]?.scriptPrevHp).toBe(200)\n",1)
s=s.replace('enemies: [minimalEnemy(100, 75)],','enemies: [sourceEnemy],',1)
s=s.replace("  it('enemies prevHp = e.health 拷贝', () => {\n    const gs =", "  it('enemies prevHp = e.health 拷贝', () => {\n    const sourceEnemy = minimalEnemy(100, 75)\n    const gs =",1)
s=s.replace("    expect(state.enemies[0]?.e.health).toBe(75)\n", "    expect(state.enemies[0]?.e.health).toBe(75)\n    const enemy = state.enemies[0]!\n    expect(enemy.objectId).toBe(100) // 未提供对象脚本元数据时的显式fallback合同。\n    expect(enemy.maxHealth).toBe(75)\n    expect(enemy.e).not.toBe(sourceEnemy)\n    enemy.e.health = 25\n    expect(sourceEnemy.health).toBe(75)\n    expect(enemy.prevHp).toBe(75)\n    expect(enemy.maxHealth).toBe(75)\n    sourceEnemy.health = 60\n    expect(enemy.e.health).toBe(25)\n",1)
a=s.index('  // ── D14:');b=s.index("  it('D14:无装备状态",a)
s=s[:a]+'''  // CLASSIC状态按roleId读取；傀儡在正式开战复活路径清零，不伪造活人傀儡输入。
  it('D14:gs.rgPlayerStatus 九槽按角色身份映射，保留普通及装备计数', () => {
    const gs = createInitialGameState({ x: 0, y: 0, facing: 'down' })
    gs.partyMembers = [2, 0]
    gs.rgPlayerStatus[2] = [1, 2, 3, 4, 0, 1000, 999, 32760, 6]
    gs.rgPlayerStatus[0] = [7, 8, 9, 10, 0, 11, 12, 13, 14]
    const state = createBattleState({
      gs,
      playerRoles: { roles: [0, 1, 2].map(minimalRole) },
      enemies: [],
      field: makeHField(),
      isBoss: false,
      rng: createSeedableRng(1),
    })
    expect(state.players.map((p) => p.roleId)).toEqual([2, 0])
    expect(state.players.map((p) => p.status)).toEqual([
      { confused: 1, paralyzed: 2, sleep: 3, silence: 4, puppet: 0,
        bravery: 1000, protect: 999, haste: 32760, dualAttack: 6, slow: 0 },
      { confused: 7, paralyzed: 8, sleep: 9, silence: 10, puppet: 0,
        bravery: 11, protect: 12, haste: 13, dualAttack: 14, slow: 0 },
    ])
  })

'''+s[b:]
s=s.replace("    expect(state.players[0]?.status.dualAttack ?? 0).toBe(0)\n    expect(state.players[0]?.status.sleep).toBe(0)", "    expect(state.players[0]?.status).toEqual({ confused: 0, paralyzed: 0, sleep: 0,\n      silence: 0, puppet: 0, bravery: 0, protect: 0, haste: 0, dualAttack: 0, slow: 0 })")
a=s.index("  it('phase 字段联合 7 种'");b=s.index('  // ── M5.B-w0.2:',a)
s=s[:a]+'''  it('每场pendingActions/prevActions和行动队列独立，不泄漏到下一场', () => {
    const gs = createInitialGameState({ x: 0, y: 0, facing: 'down' })
    gs.partyMembers = [0]
    const input = { gs, playerRoles: { roles: [minimalRole(0)] }, enemies: [],
      field: makeHField(), isBoss: false, rng: createSeedableRng(1) }
    const first = createBattleState(input)
    first.pendingActions.set(0, { type: 'defend', target: 0 })
    first.prevActions?.set(0, { type: 'attack', target: 0 })
    first.actionQueue.push({ isEnemy: false, index: 0, dexterity: 30 })
    const next = createBattleState(input)
    expect(next.pendingActions.size).toBe(0)
    expect(next.prevActions?.size).toBe(0)
    expect(next.actionQueue).toEqual([])
    expect(first.pendingActions.get(0)).toEqual({ type: 'defend', target: 0 })
    expect(first.prevActions?.get(0)).toEqual({ type: 'attack', target: 0 })
    expect(first.actionQueue).toEqual([{ isEnemy: false, index: 0, dexterity: 30 }])
  })

'''+s[b:]
a=s.index("  it('B-w0.3:status field");b=s.index("  it('B-w0.2:partyMembers <=",a)
s=s[:a]+'''  it('战斗状态副本与持久状态及其它队员相互隔离', () => {
    const gs = createInitialGameState({ x: 0, y: 0, facing: 'down' })
    gs.partyMembers = [0, 1]
    gs.rgPlayerStatus[0]![6] = 7
    const state = createBattleState({ gs, playerRoles: { roles: [0, 1].map(minimalRole) },
      enemies: [], field: makeHField(), isBoss: false, rng: createSeedableRng(1) })
    const first = state.players[0]!.status
    const second = state.players[1]!.status
    first.protect = 6
    expect(gs.rgPlayerStatus[0]![6]).toBe(7)
    expect(second.protect).toBe(0)
    gs.rgPlayerStatus[0]![6] = 0
    expect(first.protect).toBe(6)
    second.haste = 3
    expect(first.haste).toBe(0)
    expect(gs.rgPlayerStatus[1]![7]).toBe(0)
  })

'''+s[b:];p.write_text(s)
p=Path('packages/game/src/core/battle/battle-state.glm-next-wave.test.ts');s=p.read_text();s=s.replace('  seededRng,\n','');s=s.replace("import { createInitialGameState } from '../game-state.js'", "import { createInitialGameState } from '../game-state.js'\nimport { createSeedableRng } from '../rng.js'")
s=s.replace(' *  - players scriptPrevHp 战前快照(0x64 类脚本 show-once 判定基线)\n',' *  玩家prevHp/prevMp/scriptPrevHp快照统一在主测核验；0x64读敌maxHealth，不读玩家快照。\n')
s=s.replace('makeHRole(0, { hp: 123, mp: 45 })','makeHRole(0, { hp: 123, mp: 45, maxMP: 60 })')
s=s.replace('rng: seededRng(7),','rng: createSeedableRng(7),\n    enemyPos: { layouts: [[{ x: 160, y: 80 }], [{ x: 120, y: 78 }, { x: 212, y: 88 }]] },')
s=s.replace('    expect(slot.posOriginal).toBeDefined()','    expect(slot.posOriginal).toEqual({ x: 212, y: 88 })\n    expect(slot.pos).toEqual({ x: 212, y: 88 })\n    expect(slot.pos).not.toBe(slot.posOriginal)\n    expect(state.enemies[0]!.posOriginal).toEqual({ x: 120, y: 78 })')
s=s.replace('缺省 false(0x8A 跨战斗持久)','缺省 false(0x8A 脚本flag)')
a=s.index("\n  it('players prevHp/prevMp/scriptPrevHp");s=s[:a]+'\n})\n';p.write_text(s)
e=Path('docs/ops/evidence/QUALITY-PRE94-RETROSPECTIVE-1/3u-state-factory');(e/'edit-producer.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
