from pathlib import Path
import collections,difflib,gzip,hashlib,json,re,subprocess
p=Path('docs/ops/evidence/QUALITY-PRE94-RETROSPECTIVE-1/3u-state-factory');base='9c2c5eabe143bc81ad8df1c9234aa741b130aabc'
def sha(b):return hashlib.sha256(b).hexdigest()
def load(n):return json.loads((p/n).read_text())
def unpack(n):return gzip.decompress((p/n).read_bytes())
def blob(path):return subprocess.check_output(['git','show',base+':'+str(path)])
def receipt(r):
 b=unpack(r['raw']);assert len(b)==r['rawBytes'] and sha(b)==r['rawSha256']
 assert r['fullUncutMergedStdoutStderr'] and r['signal'] is None and r['spawnError'] is None
 return b
before=load('before.json');assert before['base']==base and len(before['files'])==3
for r in before['files']:
 b=unpack(r['snapshot']);assert b==blob(r['path']) and sha(b)==r['sha256'] and len(b.decode().splitlines())==r['lines']
source=before['files'][0]['path'];assert Path(source).read_bytes()==blob(source)
for r in load('read-boundaries.json')['rows']:
 b=Path(r['path']).read_bytes();n=len(b.decode().splitlines());assert sha(b)==r['sha256'] and n==r['lines'] and unpack(r['snapshot'])==b
 assert all(1<=a<=z<=n for a,z in r['ranges'])
 if r['fullRead']:assert r['ranges']==[[1,n]]

controls=load('controls.json');conserved=load('snapshot-conservation.json')
assert len(controls['controls'])==6 and len(conserved['controls'])==1
for document,isConservation in [(controls,False),(conserved,True)]:
 assert document['restored'] and document['tempDirectoryRemoved'] and not Path(document['tempDirectory']).exists()
 for row in document['controls']:
  assert sha(Path(row['source']).read_bytes())==row['sourceSha256']
  assert sha(unpack(row['id']+'.mutant.gz'))==row['mutantSha256']
  for phase,r in row['runs'].items():
   raw=receipt(r);native=unpack(r['nativeReport']);assert sha(native)==r['nativeSha256'];d=json.loads(native)
   spec=r.get('specPath',row['spec']);n=row['expectedOldCount'] if phase=='old' else row['expectedCurrentCount'];failed=isConservation or phase=='current'
   assert len(d['testResults'])==1 and d['testResults'][0]['name'].endswith(spec)
   assert d['numTotalTests']==n and d['numPassedTests']==n-int(failed) and d['numFailedTests']==int(failed)
   assert d['numPendingTests']==d['numTodoTests']==0 and d['success']==(not failed) and r['exit']==int(failed)
   cases=d['testResults'][0]['assertionResults'];bad=[a for a in cases if a['status']=='failed']
   assert len(cases)==n and all(a['status'] in ['passed','failed'] for a in cases)
   assert [{'file':d['testResults'][0]['name'],'fullName':a['fullName'],'status':a['status']} for a in cases]==r['cases']
   if failed:
    target='players prevHp/prevMp/scriptPrevHp' if isConservation and phase=='old' else row['expectedNewFailureNameContains']
    assert len(bad)==1 and target in bad[0]['fullName'] and bad[0]['failureMessages'] and all('AssertionError:' in m for m in bad[0]['failureMessages'])
   expected=blob(spec) if phase=='old' else Path(spec).read_bytes();assert r['specSha256']==sha(expected)
   assert r['sourceRestoredByteForByte'] and r['specRestoredByteForByte']
   assert r['sourceRestoredSha256']==sha(Path(row['source']).read_bytes()) and r['specRestoredSha256']==sha(Path(spec).read_bytes())
   assert not re.search(rb'(stderr \||Unhandled Error|Unhandled Rejection)',raw)
   report=next(c.split('=',1)[1] for c in r['command'] if c.startswith('--outputFile.json='));assert not Path(report).exists()

for f in p.glob('*.json'):
 d=json.loads(f.read_text())
 if isinstance(d,dict) and 'rawBytes' in d:receipt(d)
for name in ['module','typecheck-final','docs-consumers','ledger','lint']:
 r=load(name+'.json');raw=receipt(r);assert r['exit']==0
 assert not re.search(rb'(stderr \||Warning:|Unhandled Error|Unhandled Rejection|error TS\d)',raw),name
d=json.loads(unpack('module.vitest.json.gz'));assert d['success'] and d['numPassedTests']==d['numTotalTests']==283 and d['numFailedTests']==d['numPendingTests']==d['numTodoTests']==0
assert len(d['testResults'])==7
direct=[f for f in d['testResults'] if any(f['name'].endswith(r['path']) for r in before['files'][1:])]
assert len(direct)==2 and sum(len(f['assertionResults']) for f in direct)==17
assert all(a['status']=='passed' for f in d['testResults'] for a in f['assertionResults'])
for row in controls['controls']:
 formal=next(f for f in direct if f['name'].endswith(row['spec']));assert [a['fullName'] for a in formal['assertionResults']]==[a['fullName'] for a in row['runs']['current']['cases']]
baseline=json.loads(unpack('baseline.vitest.json.gz'));assert baseline['numPassedTests']==18 and baseline['success']
t=load('assertion-transfers.json');assert t['wholeCasesRetired']==2 and t['newBusinessCases']==1 and t['oldCounts']=={'main':14,'glm':4} and t['currentCounts']=={'main':14,'glm':3}
assert len(t['oldCases'])==18 and len(t['currentCases'])==17
assert '0 errors / 0 warnings / 0 infos' in receipt(load('lint.json')).decode()
assert '3316 files; 253 closed / 98 review / 2965 pending' in receipt(load('ledger.json')).decode()
ledger=Path('docs/ops/audits/code-quality-file-ledger.md');diff=list(difflib.ndiff(blob(ledger).decode().splitlines(),ledger.read_text().splitlines()));removed=[l[2:] for l in diff if l.startswith('- ')];added=[l[2:] for l in diff if l.startswith('+ ')]
assert len(removed)==len(added)==4
for r in before['files']:
 old=next(l for l in removed if l.startswith('| `'+r['path']+'`'));new=next(l for l in added if l.startswith('| `'+r['path']+'`'))
 assert ('| review |' if r['path']==source else '| 已验证 |') in old and '| review |' in new
queue=Path('docs/ops/evidence/QUALITY-PRE94-RETROSPECTIVE-1/all-cards.json');old=json.loads(blob(queue));new=json.loads(queue.read_text())
assert old['currentReviewCounts']==new['currentReviewCounts']=={'partial':55,'pending':28}
assert {k:v for k,v in old.items() if k!='cards'}=={k:v for k,v in new.items() if k!='cards'}
for a,b in zip(old['cards'],new['cards']):
 if a['id']!='3u':assert a==b
 else:
  assert {k:v for k,v in a.items() if k!='evidence'}=={k:v for k,v in b.items() if k!='evidence'}
  assert b['evidence']==str(p/'README.md') and not b['currentAcceptance'] and not b['scopeConfirmed'] and Path(b['path']).read_bytes()==blob(b['path'])
chain=load('review-chain.json');assert len(chain['bindings'])==5;byreview=collections.defaultdict(list)
for r in chain['bindings']:
 b=Path(r['target']).read_bytes();assert r['currentSha256']==sha(b) and r['lines']==len(b.decode().splitlines()) and r['previousAfterSha256']==sha(blob(r['target']));byreview[r['review']].append(r['target'])
for path,targets in byreview.items():
 old=json.loads(blob(path));new=json.loads(Path(path).read_text());assert {k:v for k,v in old.items() if k!='entries'}=={k:v for k,v in new.items() if k!='entries'}
 for a,b in zip(old['entries'],new['entries']):
  if a['path'] not in targets:assert a==b
  else:assert b['afterSha256']==sha(Path(a['path']).read_bytes()) and b['revision']['history'][1:]==a['revision']['history'] and b['revision']['history'][0]['revision']==base
for path in ['scripts/coverage','scripts/docs','scripts/quality','docs/testing/catalog.json','docs/ops/tasks/index.md','docs/ops/evidence/README.md','packages/game/src/__tests__/glm-next-wave/H/harness.ts','packages/game/src/core/battle/battle-positions.ts','docs/ops/evidence/QUALITY-PRE94-RETROSPECTIVE-1/3u-3w-finalization']:
 assert not subprocess.check_output(['git','diff',base,'--',path]),path
allowed={r['path'] for r in before['files'][1:]}|{str(ledger),'docs/ops/board.md','docs/ops/tasks/QUALITY-PRE94-RETROSPECTIVE-1.md',str(queue),str(queue.with_suffix('.md')),str(queue.parent/'README.md')}|set(byreview)
assert set(subprocess.check_output(['git','diff',base,'--name-only']).decode().splitlines())==allowed
assert all(f.startswith(str(p)+'/') for f in subprocess.check_output(['git','ls-files','--others','--exclude-standard']).decode().splitlines())
assert Path('docs/ops/tasks/QUALITY-PRE94-RETROSPECTIVE-1.md').read_bytes().startswith(blob('docs/ops/tasks/QUALITY-PRE94-RETROSPECTIVE-1.md'))
print(json.dumps({'status':'pass','scope':'Three-file factory review, two spec changes; no whole-card/unified acceptance','implementationByteExact':True,'oldDirect':18,'currentDirect':17,'adjacent':266,'total':283,'regressionControls':6,'snapshotConservationControl':1,'rawNativeAndRestores':'verified','tracked':3316,'closed':253,'review':98,'pending':2965,'newClosed':0,'reopenedReview':2,'partialCards':55,'pendingCards':28,'acceptedCards':0,'reviewBindings':5},ensure_ascii=False))
