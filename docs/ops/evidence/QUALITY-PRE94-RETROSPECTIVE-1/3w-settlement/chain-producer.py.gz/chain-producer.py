from pathlib import Path
import json,subprocess,hashlib,gzip
base='9bc478671044f2dff222581b6326884694e5b9e2';prefix=Path('docs/phase-governance/reviews');p=Path('docs/ops/evidence/QUALITY-PRE94-RETROSPECTIVE-1/3w-settlement');records=[]
targets={'20261004-semantic-current-batch.json':['docs/ops/board.md'],'20261016-historical-cards-d.json':['docs/ops/audits/code-quality-file-ledger.md'],'20261017-r93-phase-governance-artifacts.json':[str(prefix/'20261004-semantic-current-batch.json'),str(prefix/'20261016-historical-cards-d.json')],'20261017-r94-final-machine-artifacts.json':[str(prefix/'20261017-r93-phase-governance-artifacts.json')]}
for name,paths in targets.items():
 f=prefix/name;assert f.read_bytes()==subprocess.check_output(['git','show',base+':'+str(f)]);d=json.loads(f.read_text())
 for path in paths:
  r=next(r for r in d['entries'] if r['path']==path);raw=Path(path).read_bytes();old=subprocess.check_output(['git','show',base+':'+path]);h=hashlib.sha256(raw).hexdigest();assert r['afterSha256']==hashlib.sha256(old).hexdigest()
  r['revision']['history'].insert(0,{'revision':base,'date':'2026-10-18','action':'Bounded CODE3w settlement implementation/comment/test review','previousAfterSha256':r['afterSha256'],'scope':'Selected implementation246→249/spec259→347 lines fully read, caller/primary/dedupe explicit. Only source comments corrected; emitted JS original/control-input/final identical. Tests use loadDefaultGame/projection/startBattle/real RNG/runner/dialog, five contracts migrated into eight cases, no retirement/baseline/rule changes. Six whole old5green/current7green+1specified AssertionError controls, exact restoration. Final7files229=direct8+adjacent221 and game TC. Earlier test-author wrong dialog field1red retained, not product-red evidence. Two old closures reopen review;3317/251closed/101review/2965pending,0newclosed.83cards55partial/28pending/0accept unchanged,only3w evidence pointer. Four incoming review files/five bindings only; other rows/history/native verdicts preserved. No product execution/API/save/schema/assets/phase2 change. Script impact/exception,edge domains,visual and nonparty Extra remain unaccepted.','evidence':str(p/'README.md'),'notRun':['whole repository check','official coverage ratchet','protected fast','original game runtime','E2E','visual']})
  r['afterSha256']=h;r['reviewedLines']='1-'+str(len(raw.decode().splitlines()))
  for k in ['implementationSha','afterSha256']:
   if k in r['revision']:r['revision'][k]=h
  if isinstance(r.get('evidence'),dict):
   if 'afterSha256' in r['evidence']:r['evidence']['afterSha256']=h
   if 'lineCount' in r['evidence']:r['evidence']['lineCount']=len(raw.decode().splitlines())
  records.append({'review':str(f),'target':path,'previousAfterSha256':hashlib.sha256(old).hexdigest(),'currentSha256':h,'lines':len(raw.decode().splitlines())})
 f.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n');subprocess.run(['pnpm','exec','biome','format','--write',str(f)],check=True,stdout=subprocess.PIPE)
(p/'review-chain.json').write_text(json.dumps({'base':base,'bindings':records},ensure_ascii=False,indent=2)+'\n');(p/'chain-producer.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0));print('Four review files/five incoming bindings, no unrelated metadata mutation.')
