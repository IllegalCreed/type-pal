from pathlib import Path
import collections,copy,difflib,gzip,hashlib,json,re,subprocess
root=Path.cwd();p=Path('docs/ops/evidence/QUALITY-PRE94-RETROSPECTIVE-1/3w-settlement');base='9bc478671044f2dff222581b6326884694e5b9e2'
def sha(b):return hashlib.sha256(b).hexdigest()
def load(n):return json.loads((p/n).read_text())
def unzip(n):return gzip.decompress((p/n).read_bytes())
def blob(path):return subprocess.check_output(['git','show',base+':'+str(path)])
def receipt(r):
 b=unzip(r['raw']);assert len(b)==r['rawBytes'] and sha(b)==r['rawSha256'];assert r['fullUncutMergedStdoutStderr'] and r['signal'] is None and r['spawnError'] is None;return b
before=load('before-sources.json');assert before['base']==base and len(before['files'])==2
for r in before['files']:
 b=unzip(r['snapshot']);assert b==blob(r['path']) and sha(b)==r['sha256'] and len(b.decode().splitlines())==r['lines']
source,spec=[r['path'] for r in before['files']]
for r in load('read-boundaries.json')['rows']:
 b=Path(r['path']).read_bytes();n=len(b.decode().splitlines());assert sha(b)==r['sha256'] and n==r['lines'] and unzip(r['snapshot'])==b;assert all(1<=a<=z<=n for a,z in r['ranges'])
 if r['fullRead']:assert r['ranges']==[[1,n]]
assert len(Path(source).read_text().splitlines())==249 and len(Path(spec).read_text().splitlines())==347
sourceInputs={r['path']:unzip(r['snapshot']) for r in load('control-sources.json')['rows']}
for r in load('control-sources.json')['rows']:assert sha(sourceInputs[r['path']])==r['sha256']
identity=load('execution-identity.json');assert identity['equal'] and len(set(identity['emittedHashes']))==1;assert identity['sourceHashes']==[sha(blob(source)),sha(sourceInputs[source]),sha(Path(source).read_bytes())]
# 发射JS再次真实计算,不用仅相信写入的布尔值。
script="""import ts from 'typescript';import{createHash}from'node:crypto';let s='';for await(const b of process.stdin)s+=b;const out=JSON.parse(s).map(x=>createHash('sha256').update(ts.transpileModule(x,{compilerOptions:{target:ts.ScriptTarget.ESNext,module:ts.ModuleKind.ESNext,removeComments:true}}).outputText).digest('hex'));console.log(JSON.stringify(out));"""
actual=json.loads(subprocess.check_output(['node','--input-type=module','-e',script],input=json.dumps([blob(source).decode(),sourceInputs[source].decode(),Path(source).read_text()]).encode()));assert actual==identity['emittedHashes']
controls=load('controls.json');assert len(controls['controls'])==6 and controls['restored'] and controls['tempDirectoryRemoved'] and not Path(controls['tempDirectory']).exists()
formal=json.loads(unzip('module-final.vitest.json.gz'));direct=next(f for f in formal['testResults'] if f['name']==str(root/spec));formalNames=[a['fullName'] for a in direct['assertionResults']]
for row in controls['controls']:
 assert sha(sourceInputs[row['source']])==row['sourceSha256'];assert sha(unzip(row['id']+'.mutant.gz'))==row['mutantSha256']
 for phase,r in row['runs'].items():
  raw=receipt(r);native=unzip(r['nativeReport']);assert sha(native)==r['nativeSha256'];d=json.loads(native);n=5 if phase=='old' else 8;badExpected=phase=='current'
  assert len(d['testResults'])==1 and d['testResults'][0]['name']==str(root/spec);cases=d['testResults'][0]['assertionResults'];bad=[a for a in cases if a['status']=='failed']
  assert len(cases)==d['numTotalTests']==n and d['numPassedTests']==n-int(badExpected) and d['numFailedTests']==int(badExpected) and d['numPendingTests']==d['numTodoTests']==0 and d['success']==(not badExpected) and r['exit']==int(badExpected)
  assert all(a['status'] in ['passed','failed'] for a in cases) and not d.get('unhandledErrors',[])
  assert [{'file':d['testResults'][0]['name'],'fullName':a['fullName'],'status':a['status']} for a in cases]==r['cases']
  if badExpected:
   assert len(bad)==1 and row['expectedNewFailureNameContains'] in bad[0]['fullName'] and bad[0]['failureMessages'] and all('AssertionError:' in m for m in bad[0]['failureMessages']);assert [a['fullName'] for a in cases]==formalNames
  assert r['specSha256']==sha(blob(spec) if phase=='old' else Path(spec).read_bytes())
  assert r['sourceRestoredByteForByte'] and r['specRestoredByteForByte'] and r['sourceRestoredSha256']==sha(sourceInputs[row['source']]) and r['specRestoredSha256']==sha(Path(spec).read_bytes())
  assert not re.search(rb'(stderr \||Unhandled Error|Unhandled Rejection)',raw)
  report=next(c.split('=',1)[1] for c in r['command'] if c.startswith('--outputFile.json='));assert not Path(report).exists()
for path,b in sourceInputs.items():
 if path!=source:assert Path(path).read_bytes()==b==blob(path)
for r in load('native-archives.json')['rows']:
 b=unzip(r['nativeReport']);assert sha(b)==r['sha256'] and r['ownedTempRemoved'] and not Path(r['originalPath']).exists()
 d=json.loads(b)
 if r['label']=='before':assert d['success'] and d['numPassedTests']==5
 elif r['label']=='direct':assert not d['success'] and d['numPassedTests']==7 and d['numFailedTests']==1
 elif r['label']=='direct-corrected':assert d['success'] and d['numPassedTests']==8
 else:assert d['success'] and d['numPassedTests']==229 and len(d['testResults'])==7
assert formal['numTotalTests']==formal['numPassedTests']==229 and formal['numFailedTests']==formal['numPendingTests']==formal['numTodoTests']==0 and not formal.get('unhandledErrors',[]) and len(direct['assertionResults'])==8
for f in formal['testResults']:assert all(a['status']=='passed' for a in f['assertionResults'])
for f in p.glob('*.json'):
 d=json.loads(f.read_text())
 if isinstance(d,dict) and 'rawBytes' in d:receipt(d)
for name in ['module-final','typecheck','docs-consumers','ledger','lint']:
 r=load(name+'.json');raw=receipt(r);assert r['exit']==0;assert not re.search(rb'(stderr \||Warning:|Unhandled Error|Unhandled Rejection|error TS\d)',raw),name
assert b'0 errors / 0 warnings / 0 infos; complete report' in receipt(load('lint.json'))
assert b'3317 files; 251 closed / 101 review / 2965 pending' in receipt(load('ledger.json'))
assert len(load('review-chain.json')['bindings'])==5
for path in sorted({r['review'] for r in load('review-chain.json')['bindings']}):
 original=json.loads(blob(path));current=json.loads(Path(path).read_text());rebuilt=copy.deepcopy(current)
 for bind in [r for r in load('review-chain.json')['bindings'] if r['review']==path]:
  old=next(r for r in original['entries'] if r['path']==bind['target']);new=next(r for r in current['entries'] if r['path']==bind['target']);body=Path(bind['target']).read_bytes();assert new['afterSha256']==bind['currentSha256']==sha(body) and bind['previousAfterSha256']==sha(blob(bind['target'])) and new['reviewedLines']=='1-'+str(len(body.decode().splitlines()));assert len(new['revision']['history'])==len(old['revision']['history'])+1 and new['revision']['history'][1:]==old['revision']['history']
  restored=copy.deepcopy(new);restored['afterSha256']=old['afterSha256'];restored['reviewedLines']=old['reviewedLines'];restored['revision']['history']=old['revision']['history']
  for key in ['implementationSha','afterSha256']:
   if key in old['revision']:restored['revision'][key]=old['revision'][key]
  if isinstance(old.get('evidence'),dict):
   for key in ['afterSha256','lineCount']:
    if key in old['evidence']:restored['evidence'][key]=old['evidence'][key]
  assert restored==old;rebuilt['entries'][rebuilt['entries'].index(new)]=old
 assert rebuilt==original
queue='docs/ops/evidence/QUALITY-PRE94-RETROSPECTIVE-1/all-cards.json';old=json.loads(blob(queue));cur=json.loads(Path(queue).read_text());next(r for r in old['cards'] if r['id']=='3w')['evidence']=str(p/'README.md');assert cur==old and len(cur['cards'])==83 and collections.Counter(r['currentReview'] for r in cur['cards'])=={'partial':55,'pending':28} and not any(r['currentAcceptance'] for r in cur['cards'])
ledger='docs/ops/audits/code-quality-file-ledger.md';old=blob(ledger).decode();cur=Path(ledger).read_text();expected=old.replace('当前已闭合核验：253；已读但待审：99；尚未逐文件核验：2,965；合计未闭合：3,064。','当前已闭合核验：251；已读但待审：101；尚未逐文件核验：2,965；合计未闭合：3,066。')
for path in [source,spec]:
 a=next(s for s in old.splitlines() if s.startswith('| `'+path+'`'));b=next(s for s in cur.splitlines() if s.startswith('| `'+path+'`'));assert '| review |' in b;expected=expected.replace(a,b,1)
assert cur==expected
for path in ['docs/ops/tasks/QUALITY-PRE94-RETROSPECTIVE-1.md','docs/ops/evidence/QUALITY-PRE94-RETROSPECTIVE-1/README.md']:assert Path(path).read_bytes().startswith(blob(path))
assert not subprocess.check_output(['git','diff','37e2cd7c9a54b29766a87d17ffed90e4dae465dd','--','scripts/docs/'])
allowed={source,spec,ledger,queue,'docs/ops/evidence/QUALITY-PRE94-RETROSPECTIVE-1/all-cards.md','docs/ops/evidence/QUALITY-PRE94-RETROSPECTIVE-1/README.md','docs/ops/tasks/QUALITY-PRE94-RETROSPECTIVE-1.md','docs/ops/board.md',*[r['review'] for r in load('review-chain.json')['bindings']]}
changed=[x.decode() for x in subprocess.check_output(['git','diff','--name-only','-z',base]).split(b'\0') if x];unknown=[x.decode() for x in subprocess.check_output(['git','ls-files','--others','--exclude-standard','-z']).split(b'\0') if x];assert set(changed)<=allowed and all(s.startswith(str(p)+'/') for s in unknown)
assert subprocess.check_output(['git','branch','--show-current'],text=True).strip()=='codex/code-quality-3y';subprocess.run(['git','diff','--check'],check=True)
print('PASS: 6 exact old-green/new-single-AssertionError controls; frozen inputs/restoration/native/raw hashes; unchanged product JS; 8direct+221adjacent, TC/static receipts; 2 precise review reopenings,83 statuses,5 bounded review bindings and exclusive scope.')
