import { createRequire } from 'node:module'
import { readFile, writeFile, mkdir, readdir } from 'node:fs/promises'
import path from 'node:path'
import { createHash } from 'node:crypto'
import assert from 'node:assert/strict'
const root=process.cwd()
const out=path.join(root,'docs/ops/evidence/QUALITY-PRE94-RETROSPECTIVE-1/72-boot-loading/approved-fix')
const buildRoot=(await readFile(path.join(out,'build-location.txt'),'utf8')).trim()
const require=createRequire(path.join(root,'packages/game/package.json'))
const { chromium }=require('playwright')
process.env.E2E='1'
const { preview }=await import(require.resolve('vite'))
const hash=data=>createHash('sha256').update(data).digest('hex')
const artifacts=path.join(root,'artifacts/boot-failure-progress')
await mkdir(artifacts,{recursive:true})
const browser=await chromium.launch({channel:'chrome',headless:true})
const receipts=[]
try {
 for (const version of ['before','after']) {
  const dist=path.join(buildRoot,version)
  const server=await preview({root:path.join(root,'packages/game'),configFile:path.join(root,'packages/game/vite.config.ts'),build:{outDir:dist},preview:{host:'127.0.0.1',port:0,strictPort:true}})
  const address=server.httpServer.address()
  const url=`http://127.0.0.1:${address.port}`
  const context=await browser.newContext({viewport:{width:960,height:720},serviceWorkers:'allow'})
  const page=await context.newPage()
  const events=[]
  page.on('console',msg=>events.push({type:'console:'+msg.type(),text:msg.text()}))
  page.on('pageerror',error=>events.push({type:'pageerror',text:String(error)}))
  let releaseScene,releaseGlyph,sceneSeen,glyphSeen
  const sceneBarrier=new Promise(resolve=>releaseScene=resolve)
  const glyphBarrier=new Promise(resolve=>releaseGlyph=resolve)
  const seenScene=new Promise(resolve=>sceneSeen=resolve)
  const seenGlyph=new Promise(resolve=>glyphSeen=resolve)
  await page.route('**/extracted/data/scene/0.json',async route=>{sceneSeen();await sceneBarrier;await route.fulfill({status:404,contentType:'text/plain',body:'controlled boot failure'})})
  await page.route('**/extracted/data/font/glyphs.json',async route=>{glyphSeen();await glyphBarrier;await route.continue()})
  try {
   await page.goto(url,{waitUntil:'domcontentloaded',timeout:20000})
   await Promise.race([Promise.all([seenScene,seenGlyph]),new Promise((_,reject)=>{const timer=setTimeout(()=>reject(new Error('required resource routes not reached')),10000);timer.unref()})])
   await page.evaluate(()=>{
    window.__capturedBootFetch=window.fetch
    const status=document.getElementById('boot-loading-status')
    const observer=new MutationObserver(()=>{
     if(!status.textContent.startsWith('启动失败:')) return
     window.__failureSnapshot={text:status.textContent,width:document.getElementById('boot-loading-fill')?.style.width,error:document.getElementById('boot-loading')?.classList.contains('boot-loading-error'),fetchReleased:window.fetch!==window.__capturedBootFetch,swSupported:'serviceWorker' in navigator}
     observer.disconnect()
    })
    observer.observe(status,{childList:true,subtree:true,characterData:true})
   })
   releaseScene()
   await page.waitForFunction(()=>Boolean(window.__failureSnapshot),{},{timeout:10000})
   const snapshot=()=>page.evaluate(()=>({text:document.getElementById('boot-loading-status')?.textContent,width:document.getElementById('boot-loading-fill')?.style.width,error:document.getElementById('boot-loading')?.classList.contains('boot-loading-error'),fetchReleased:window.fetch!==window.__capturedBootFetch,swSupported:'serviceWorker' in navigator}))
   const atFailure=await page.evaluate(()=>window.__failureSnapshot)
   const response=page.waitForResponse(res=>res.url().endsWith('/extracted/data/font/glyphs.json')&&res.status()===200)
   releaseGlyph()
   const lateResponse=await response
   await lateResponse.finished()
   await page.evaluate(()=>new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve))))
   const afterLate=await snapshot()
   const screenshot=path.join(artifacts,version+'.png')
   await page.screenshot({path:screenshot})
   let assertionError=null
   try {assert.equal(afterLate.text,atFailure.text)} catch(error) {assertionError={name:error.name,code:error.code,message:error.message}}
   const files=['index.html',...(await readdir(path.join(dist,'assets'))).map(f=>'assets/'+f)]
   const buildSha256=Object.fromEntries(await Promise.all(files.map(async file=>[file,hash(await readFile(path.join(dist,file)))])))
   const row={version,command:['node','/tmp/boot-runtime-probe.mjs'],cwd:root,url,browserVersion:browser.version(),realProductionEntry:true,realServiceWorkerRegistration:true,ioInjection:'Only scene/0 HTTP404 and delayed real glyphs HTTP200; no bootstrap/UI/fetch core mock',atFailure,afterLate,glyphStatus:lateResponse.status(),glyphFromServiceWorker:lateResponse.fromServiceWorker(),screenshot,screenshotSha256:hash(await readFile(screenshot)),buildSha256,events,assertionError}
   receipts.push(row)
   await writeFile(path.join(out,'runtime.json'),JSON.stringify(receipts,null,2)+'\n')
   console.log(version,JSON.stringify({atFailure,afterLate,assertionError}))
   assert.equal(atFailure.swSupported,true)
   assert.equal(atFailure.error,true)
   if(version==='before') {assert.equal(assertionError?.code,'ERR_ASSERTION');assert.equal(atFailure.fetchReleased,false)}
   else {assert.equal(assertionError,null);assert.equal(atFailure.fetchReleased,true);assert.equal(afterLate.width,atFailure.width);assert.equal(afterLate.error,true)}
  } finally {releaseScene();releaseGlyph();await context.close();await new Promise((resolve,reject)=>server.httpServer.close(error=>error?reject(error):resolve()))}
 }
} finally {await browser.close()}
