import {createRequire} from 'node:module'
import {readFile,writeFile} from 'node:fs/promises'
import path from 'node:path'
import assert from 'node:assert/strict'
import {createHash} from 'node:crypto'
const root=process.cwd(),out=path.join(root,'docs/ops/evidence/QUALITY-PRE94-RETROSPECTIVE-1/72-boot-loading/approved-fix'),dist=path.join((await readFile(path.join(out,'build-location.txt'),'utf8')).trim(),'after')
const require=createRequire(path.join(root,'packages/game/package.json'))
process.env.E2E='1'
const {preview}=await import(require.resolve('vite'))
const {chromium}=require('playwright')
const server=await preview({root:path.join(root,'packages/game'),configFile:path.join(root,'packages/game/vite.config.ts'),build:{outDir:dist},preview:{host:'127.0.0.1',port:0,strictPort:true}})
const browser=await chromium.launch({channel:'chrome',headless:true})
try {
 const context=await browser.newContext({viewport:{width:960,height:720}}),page=await context.newPage(),events=[]
 page.on('console',msg=>events.push({type:msg.type(),text:msg.text()}))
 page.on('pageerror',err=>events.push({type:'pageerror',text:String(err)}))
 await page.goto(`http://127.0.0.1:${server.httpServer.address().port}/?skip-intro=1`,{waitUntil:'domcontentloaded'})
 await page.locator('#boot-loading-enter:not([hidden])').waitFor({timeout:20000})
 const playable=await page.evaluate(()=>({text:document.getElementById('boot-loading-status').textContent,width:document.getElementById('boot-loading-fill').style.width,buttonHidden:document.getElementById('boot-loading-enter').hidden}))
 assert.equal(playable.buttonHidden,false)
 assert.match(playable.text,/必要资源就绪|已缓存/)
 await page.locator('#boot-loading-enter-btn').click()
 await page.locator('#boot-loading').waitFor({state:'detached',timeout:10000})
 await page.waitForFunction(()=>Boolean(document.querySelector('#screen')))
 const screenshot=path.join(root,'artifacts/boot-failure-progress/normal-entry.png')
 await page.screenshot({path:screenshot})
 const row={command:['node','/tmp/boot-runtime-positive.mjs'],cwd:root,browserVersion:browser.version(),realProductionEntry:true,url:page.url(),scope:'Unmodified onPlayable/button and enterGate using real assets; skip-intro=1 bypasses videos/story; does not claim whole-game E2E or offline cache acceptance',playable,overlayRemoved:await page.locator('#boot-loading').count()===0,events,screenshot,screenshotSha256:createHash('sha256').update(await readFile(screenshot)).digest('hex')}
 await writeFile(path.join(out,'runtime-positive.json'),JSON.stringify(row,null,2)+'\n')
 console.log(JSON.stringify(row))
 assert.equal(events.some(e=>e.type==='pageerror'||e.type==='error'||e.type==='warning'),false)
 assert.equal(events.some(e=>e.text.includes('[bootstrap] startup ready')),true)
 await context.close()
} finally {await browser.close();await new Promise(resolve=>server.httpServer.close(resolve))}
