import { afterEach, expect, it, vi } from 'vitest'
import { initBootLoading, restoreBootFetch } from './boot-loading.js'
import { createUnifiedProgressUi } from './precache-ui.js'

afterEach(async () => {
  restoreBootFetch()
  await vi.advanceTimersByTimeAsync(16)
  vi.clearAllTimers()
  vi.useRealTimers()
  vi.unstubAllGlobals()
  document.body.replaceChildren()
})

it('启动失败后迟到 fetch 进度不能覆盖失败文案', async () => {
  vi.useFakeTimers()
  document.body.innerHTML = '<div id="boot-loading"><div id="boot-loading-fill"></div><div id="boot-loading-status"></div></div>'
  let resolve!: (response: Response) => void
  const deferred = new Promise<Response>((r) => { resolve = r })
  vi.stubGlobal('fetch', vi.fn<typeof fetch>(() => deferred))
  const ui = createUnifiedProgressUi()
  initBootLoading(2, (fraction) => ui.setNecessaryProgress(fraction))
  const inFlight = fetch('/still-pending')
  try {
    ui.fail('主资源加载失败')
    expect(document.getElementById('boot-loading-status')?.textContent).toBe('启动失败:主资源加载失败')
    resolve(new Response('{}'))
    await inFlight
    await vi.advanceTimersByTimeAsync(16)
    expect(document.getElementById('boot-loading-status')?.textContent).toBe('启动失败:主资源加载失败')
  } finally {
    resolve(new Response('{}'))
    await inFlight
  }
})
