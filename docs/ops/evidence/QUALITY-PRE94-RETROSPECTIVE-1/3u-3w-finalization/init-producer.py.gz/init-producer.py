from pathlib import Path
import json,gzip,hashlib,subprocess
root=Path.cwd();base=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert base=='6fde6d86cf9754e441de948c82ac99ebc1f480c8';assert not subprocess.check_output(['git','status','--porcelain'],text=True)
p=root/'docs/ops/evidence/QUALITY-PRE94-RETROSPECTIVE-1/3u-3w-finalization';p.mkdir();rows=[]
for name in ['battle-finalization.ts','battle-finalization.test.ts','battle-runtime-context.ts','battle-runtime-context.test.ts']:
 path='packages/game/src/core/battle/'+name;b=Path(path).read_bytes();h=hashlib.sha256(b).hexdigest();snap=h[:12]+'-'+name+'.before.gz';(p/snap).write_bytes(gzip.compress(b,mtime=0));rows.append({'path':path,'sha256':h,'lines':len(b.splitlines()),'ranges':[[1,len(b.splitlines())]],'snapshot':snap,'beforeLiveLedgerStatus':'已验证'})
(p/'before.json').write_text(json.dumps({'base':base,'owner':'Codex single agent','files':rows},ensure_ascii=False,indent=2)+'\n')
for fn in ['all-cards.json','all-cards.md','README.md']:(p/(('parent-report' if fn=='README.md' else fn)+'.before.gz')).write_bytes(gzip.compress((p.parent/fn).read_bytes(),mtime=0))
f=Path('docs/ops/tasks/QUALITY-PRE94-RETROSPECTIVE-1.md');f.write_text(f.read_text()+'''\n### 2026-10-18 CODE3u/3w runtime-context与finalization复审准入\n\nCodex premise verified/design agree/build allowed：四文件67/80/98/75行全文、真实startBattle/tickBattle/settlement与resume/writeback、正式BattleState/对话factory、SDL battle.c:1822–1857/global.c:1567–1614,2311–2339/script.c:3315–3333已读。单Owner Codex/同3y树，只准两源事实注释与两既有测试的合法工厂、完整九状态、接回瞬间资源观察、finalize分支接线和跨GameState资源隔离补强；不改生产执行、公共接口、机制/毒域、schema/save、资源或UI。非队员Extra的C全role/TS party差异先只读归因：真实开战/换队会重建所有装备效果，不能拿手搭残留当剧情缺陷或擅改循环。必要测试/TC/静态门，完整check/coverage/protected留大任务收尾；逐文件有直接证据才改账，不借旧卡done复活准入。\n''')
Path('/tmp/type-pal-finalization-capture.py').write_text(Path('/tmp/type-pal-ga-capture.py').read_text().replace('3z-google-analytics','3u-3w-finalization'))
(p/'init-producer.py.gz').write_bytes(gzip.compress(Path('/tmp/type-pal-finalization-init.py').read_bytes(),mtime=0))
print('Four files frozen; source execution read-only, typed test repairs admitted.')
