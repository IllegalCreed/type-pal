from pathlib import Path
import gzip, hashlib, json

p = Path('docs/ops/evidence/QUALITY-PRE94-RETROSPECTIVE-1/3u-3w-finalization')
def sha(b): return hashlib.sha256(b).hexdigest()
def read(n): return json.loads((p/n).read_text())
def write(n,d): (p/n).write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
def replace(f,a,b):
    text=f.read_text()
    assert text.count(a)==1,(str(f),a)
    f.write_text(text.replace(a,b))

native=Path('/tmp/type-pal-finalization-current-20261018.json')
raw=native.read_bytes(); d=json.loads(raw)
assert d['success'] and d['numPassedTests']==275 and d['numFailedTests']==d['numPendingTests']==0
(p/'module-current.vitest.json.gz').write_bytes(gzip.compress(raw,mtime=0))
native.unlink()
boundaries=read('read-boundaries.json')
(p/'read-boundaries-before-private-decoupling.json.gz').write_bytes(gzip.compress((p/'read-boundaries.json').read_bytes(),mtime=0))
path='packages/game/src/core/battle/battle-runtime-context.test.ts'
raw=Path(path).read_bytes(); h=sha(raw); lines=len(raw.decode().splitlines())
row=next(r for r in boundaries['rows'] if r['path']==path)
row.update(sha256=h,lines=lines,ranges=[[1,lines]],fullRead=True,snapshot=h[:12]+'-battle-runtime-context.test.ts.read.gz')
(p/row['snapshot']).write_bytes(gzip.compress(raw,mtime=0));write('read-boundaries.json',boundaries)

t=read('assertion-transfers.json')
t['transfers'][2]['retained']='Exact public resource/live-role identities retained; actual second GameState install must not overwrite first owner. Private key/property-layout assertions removed as implementation coupling, not credited as public business contracts.'
t['transfers'][3]['retained']='All fallback/injected identity and undefined-override behavior retained, typed RunScriptFn generic replaces casts; public resource and live-role getters both release. Private own-property/delete shape assertions removed after literal production census and the separate old-false-positive/current-green equivalent-shape control; source storage unchanged.'
t['privateAssertionDecoupling']={'wholeCasesRemoved':0,'publicBusinessOraclesRetained':True,'privateLayoutAssertionsRemoved':True,'reason':'No public consumer contract requires own undefined resource key versus an absent key. Actual typed ports and literal private-key census separately read; no arbitrary dynamic whole-runtime claim.','equivalenceEvidence':'private-shape-metamorphism.json','direction':'old 2 passed/1 specific AssertionError; current 3 passed; separate from seven regression controls'}
write('assertion-transfers.json',t)
i=read('integration-base.json');checkpoint=next(r for r in i['unchangedFilesRestored'] if r['path']==path)
i['subsequentPrivateDecoupling']={'path':path,'beforeSha256':checkpoint['sha256'],'afterSha256':h,'scope':'Remove private property-layout assertions, preserve all public identity/runner/release oracles, keep 3 cases. Context owner regression rerun as v3, six unchanged main v2 controls reused; separate equivalent-shape control rejects old false positive.'}
write('integration-base.json',i)

f=p/'README.md'
replace(f,'clear保留resource自有undefined属性并删除runner。','clear通过公开getter释放两种资源视图、恢复fallback；私有存储实现未改。')
replace(f,'[迁移表](assertion-transfers.json)保留原全部有效断言；','[迁移表](assertion-transfers.json)保留原公开业务oracle；私有属性布局断言按下文等价反控撤除；')
replace(f,'正式6文件275绿（9直接/266相邻），typecheck零诊断；V1最后四反控后两直接文件9例再绿作为历史；夹具按实际caller调整后，全部七反控以v2标签重跑，再以275正式例和最终typecheck核候选，逐字节恢复与同一正式身份核对。','正式6文件275绿（9直接/266相邻），typecheck零诊断，以module-current/typecheck-current为最终候选。V1直接9例及旧275例原件保留为历史；夹具按实际caller调整后七反控以v2重跑，runtime私有布局断言撤除后仅该文件owner针重跑v3，六枚不变main v2按相同源/测SHA复用，逐字节恢复与正式身份核对。')
replace(f,'原五直接身份及四个新出口保留，断言没有退役；V1全部原件保留，当前canonical七针为-v2，正常恢复后正式6文件275绿和typecheck-final为最终代码候选。','原五直接case的公开业务oracle及四个新出口保留，无整例退役；V1全部原件保留，当前canonical为六main v2与一runtime v3，正式6文件275绿和typecheck-current为最终代码候选。')
with f.open('a') as out:
    out.write('\n私有布局排重：原runtime测试直接检查stash自有键/删除形状，真实生产端口依赖公开getter与runner。已读typed caller，另附字面键检索原件（仅字面源码普查，不声称穷尽任意动态访问）。把清理resource暂换成delete、公开结果保持预期时，冻结旧3例为2绿1特定AssertionError，当前3例全绿；[等价形状反控](private-shape-metamorphism.json)与七枚回归反控分开计数。最终源逐字节恢复，三例保留全部公开身份/override/释放oracle，不再认证私有对象布局。\n')
f=Path('docs/ops/audits/code-quality-file-ledger.md')
replace(f,'75行原测全文，3例保持、去强转、精确属性语义与双GameState owner','75行原测全文，3例保持、去强转、公开getter身份与双GameState owner')
replace(f,'旧3绿→新2绿1指定红；原身份/runner/释放断言保留，0新增关闭','旧3绿→新2绿1指定红；公开身份/runner/释放保留，私有布局断言以独立等价反控排除，0新增关闭')
f=Path('docs/ops/tasks/QUALITY-PRE94-RETROSPECTIVE-1.md')
replace(f,'两原测试用真实factory/类型去强转，final2→6、runtime3保持；保留原有效oracle，','两原测试用真实factory/类型去强转，final2→6、runtime3保持；保留公开业务oracle，私有布局断言另以旧误报/新全绿等价反控排除，')
g=read('gates.json')
for row in g['rows']:
    if row['label'] in ['current','module-final','restored-direct','module-after-caller']:
        row['supersededBy']='module-current';row['scope']='Historical earlier fixture/assertion candidate retained; latest public-contract candidate has separate canonical receipt'
    elif row['label'] in ['typecheck','typecheck-final']:
        row['supersededBy']='typecheck-current'
g['rows'] += [{'label':'module-current','receipt':'module-current.json','exit':0,'diagnostics':{'stderrBlocks':0,'errors':0,'warnings':0,'infos':0,'unhandledErrors':0},'files':6,'passed':275,'direct':9,'adjacent':266,'nativeReport':'module-current.vitest.json.gz','nativeReportSha256':sha(gzip.decompress((p/'module-current.vitest.json.gz').read_bytes()))},{'label':'typecheck-current','receipt':'typecheck-current.json','exit':0,'diagnostics':{'errors':0,'warnings':0,'infos':0}}]
g['status']='Latest 275 tests/typecheck and ledger recorded; final docs/lint/scope verification pending'
write('gates.json',g)
(p/'finish-producer.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
print('Latest native archived, own temp removed; runtime read boundary/public-oracle transfer and metadata updated.')
