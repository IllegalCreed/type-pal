from pathlib import Path
import json,hashlib,subprocess,gzip
base='37e2cd7c9a54b29766a87d17ffed90e4dae465dd';prefix=Path('docs/phase-governance/reviews');p=Path('docs/ops/evidence/QUALITY-PRE94-RETROSPECTIVE-1/3u-3w-finalization');targets={'20261004-semantic-current-batch.json':['docs/ops/board.md','docs/ops/tasks/index.md'],'20261016-historical-cards-d.json':['docs/ops/audits/code-quality-file-ledger.md'],'20261017-r93-phase-governance-artifacts.json':[str(prefix/f) for f in ['20261004-semantic-current-batch.json','20261016-historical-cards-d.json']],'20261017-r94-final-machine-artifacts.json':[str(prefix/'20261017-r93-phase-governance-artifacts.json')]};records=[]
for name,paths in targets.items():
 f=prefix/name;current=json.loads(f.read_text());d=json.loads(subprocess.check_output(['git','show',base+':'+str(f)]))
 assert {k:v for k,v in current.items() if k!='entries'}=={k:v for k,v in d.items() if k!='entries'}
 assert len(current['entries'])==len(d['entries'])
 for live,original in zip(current['entries'],d['entries']):
  assert live['path']==original['path']
  if live['path'] not in paths: assert live==original,(str(f),live['path'])
  else:
   assert live['revision']['history'][1:]==original['revision']['history']
   def stable(row):
    row=json.loads(json.dumps(row))
    for k in ['afterSha256','reviewedLines']:row.pop(k,None)
    for k in ['history','afterSha256','implementationSha']:row.get('revision',{}).pop(k,None)
    if isinstance(row.get('evidence'),dict):
     for k in ['lineCount','afterSha256']:row['evidence'].pop(k,None)
    return row
   assert stable(live)==stable(original),(str(f),live['path'])
 for path in paths:
  r=next(r for r in d['entries'] if r['path']==path);raw=Path(path).read_bytes();old=subprocess.check_output(['git','show',base+':'+path]);h=hashlib.sha256(raw).hexdigest();assert r['afterSha256']==hashlib.sha256(old).hexdigest();oldRow=json.loads(json.dumps(r));r['revision']['history'].insert(0,{'revision':base,'date':'2026-10-18','action':'Battle cleanup/runtime typed fixtures, actual handoff and owner oracle review','previousAfterSha256':r['afterSha256'],'scope':'Only two comment-only battle lifecycle sources and two existing tests. Four old closed rows reopened review;3316/255closed/96review/2965pending, zero new closure. Seven complete old-green/new-specific-AssertionError controls (six unchanged main v2 reused, runtime owner v3 rerun); a separate private-layout equivalent-shape control old2green/1false-positive to current3green removes implementation coupling while preserving public getter/runner oracles; direct9/adjacent266, actual factory/hydrate/dialogue/owner ports and real cursor handoff. Non-party Extra reachability is draft with start/party equipment rebuild as strongest alternative, no fake product red or behavior fix. Only CODE3u and3w pending to partial;83cards55partial/28pending/0accept, scopeConfirmed=false. Source snapshot base6fde6d86c, metadata base37e2cd7c9 after independent Git buffer prerequisite; exact source restoration and bounded metadata rebase preserve prerequisite evidence. One new draft board/index row, no baseline/retirement/schema/assets/save/public API/product execution change. Historical native verdicts preserved.','evidence':str(p/'README.md'),'notRun':['whole repository check','official coverage ratchet','protected fast','product runtime','E2E','visual']});r['afterSha256']=h;r['reviewedLines']='1-'+str(len(raw.decode().splitlines()))
  for key in ['implementationSha','afterSha256']:
   if key in r['revision']:r['revision'][key]=h
  if isinstance(r.get('evidence'),dict):
   if 'afterSha256' in r['evidence']:r['evidence']['afterSha256']=h
   if 'lineCount' in r['evidence']:r['evidence']['lineCount']=len(raw.decode().splitlines())
  records.append({'review':str(f),'target':path,'previousAfterSha256':hashlib.sha256(old).hexdigest(),'currentSha256':h,'lines':len(raw.decode().splitlines())})
 f.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n');subprocess.run(['pnpm','exec','biome','format','--write',str(f)],check=True,stdout=subprocess.PIPE)
(p/'review-chain.json').write_text(json.dumps({'base':base,'bindings':records},ensure_ascii=False,indent=2)+'\n');(p/'chain-producer.py.gz').write_bytes(gzip.compress(Path('/tmp/type-pal-finalization-chain.py').read_bytes(),mtime=0));print('Four bounded incoming review files; frozen historical content and native verdicts retained.')
