import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import { createHash } from 'node:crypto'
import { execFileSync } from 'node:child_process'
import { createRequire } from 'node:module'
import { fileURLToPath, pathToFileURL } from 'node:url'
const root=process.cwd(),folder=path.dirname(fileURLToPath(import.meta.url)),target='acb96a123bcb062c7204fdbc51903188c9fa0c5f'
const json=p=>JSON.parse(fs.readFileSync(p)),hash=b=>createHash('sha256').update(b).digest('hex'),ts=createRequire(root+'/package.json')('typescript')
const execution=json(folder+'/module-ratchet.execution.json');assert.equal(execution.exit,0);assert.equal(execution.signal,null);assert.equal(fs.readFileSync(folder+'/module-ratchet.stderr.raw','utf8'),'')
assert.deepEqual(execution.args,['VITEST_MAX_WORKERS=1','TYPE_PAL_COVERAGE_BASE_REF='+target,'pnpm','coverage:ratchet','--allow-scope-removal'])
const actual=json(root+'/coverage/fast/summary.json'),baseline=json(root+'/scripts/coverage/baseline.fast.json')
const source=fs.readFileSync(root+'/scripts/coverage/run.mjs','utf8'),ast=ts.createSourceFile('run.mjs',source,ts.ScriptTarget.Latest,true,ts.ScriptKind.JS)
const projectionNode=ast.statements.filter(ts.isVariableStatement).flatMap(s=>s.declarationList.declarations).find(d=>d.name.getText(ast)==='baselineView')?.initializer;assert(projectionNode)
const projection=Function('return ('+projectionNode.getText(ast)+')')();assert.deepEqual(projection(actual),baseline)
const {compareCoverage}=await import(pathToFileURL(root+'/scripts/coverage/metrics.mjs')),{auditScope}=await import(pathToFileURL(root+'/scripts/coverage/inventory.mjs')),{adjustApprovedBaseline}=await import(pathToFileURL(root+'/scripts/coverage/approved-baseline-adjustments.mjs'))
const strict=compareCoverage(actual,baseline),scope=auditScope(actual,baseline);assert.deepEqual(strict.regressions,[]);assert.deepEqual(scope.changes,[])
const protectedBytes=execFileSync('git',['show',target+':scripts/coverage/baseline.fast.json']),protectedBaseline=JSON.parse(protectedBytes),adjusted=await adjustApprovedBaseline(protectedBaseline,p=>fs.promises.readFile(p)),protectedMetrics=compareCoverage(baseline,adjusted.baseline),protectedScope=auditScope(baseline,protectedBaseline)
assert.deepEqual(protectedMetrics.regressions,[])
const {isApprovedTestRetirement}=await import(pathToFileURL(root+'/scripts/coverage/approved-test-retirements.mjs'))
const testEntry=(snapshot,file)=>Object.values(snapshot.packages).flatMap(p=>p.fastTests.fileEntries).find(e=>e.file===file)
const allowed=['packages/game/src/assets/tileset-blob.test.ts','packages/game/src/assets/tileset-gzip.grok-r1.test.ts','packages/game/src/assets/dialog-icons.grok-r1.test.ts','packages/game/src/assets/dialog-assets.glm-phase1-leaves.test.ts'];assert.deepEqual(protectedScope.removals.map(r=>r.value).sort(),allowed.sort())
for(const removal of protectedScope.removals){assert.equal(removal.kind,'test-count');assert(isApprovedTestRetirement({removal,previous:testEntry(protectedBaseline,removal.value),current:testEntry(baseline,removal.value),fileSha256:hash(fs.readFileSync(root+'/'+removal.value))}))}

for (const [name,bytes] of [['module-summary.json',JSON.stringify(actual,null,2)+'\n'],['module-baseline.after.json',fs.readFileSync(root+'/scripts/coverage/baseline.fast.json')]])fs.writeFileSync(folder+'/'+name,bytes,{flag:'wx'})
const report={target,head:execution.head,testCount:actual.testCount,sourceFileCount:actual.sourceFileCount,summarySha256:hash(fs.readFileSync(root+'/coverage/fast/summary.json')),baselineBeforeSha256:hash(execFileSync('git',['show',target+':scripts/coverage/baseline.fast.json'])),baselineAfterSha256:hash(fs.readFileSync(root+'/scripts/coverage/baseline.fast.json')),projectionSha256:hash(projectionNode.getText(ast)),runnerSha256:hash(source),strict,scope,protectedMetrics,protectedScope,approvalsApplied:adjusted.applied,limits:'Strict protected fast check of the single official report;no second coverage collection and no rule/baseline mutation by verifier'}
fs.writeFileSync(folder+'/module-protected-report.json',JSON.stringify(report,null,2)+'\n',{flag:'wx'})
console.log(JSON.stringify({testCount:actual.testCount,sourceFileCount:actual.sourceFileCount,regressions:strict.regressions,scopeChanges:scope.changes,protectedRegressions:protectedMetrics.regressions,protectedRemovals:protectedScope.removals}))
