import fs from 'node:fs'
import {spawn,execFileSync} from 'node:child_process'
import {dirname} from 'node:path'
import {fileURLToPath} from 'node:url'
const folder=dirname(fileURLToPath(import.meta.url)),[id,command,...args]=process.argv.slice(2),start=new Date().toISOString()
const stdout=fs.openSync(folder+'/'+id+'.stdout.raw','wx'),stderr=fs.openSync(folder+'/'+id+'.stderr.raw','wx')
let spawnError=null
const child=spawn(command,args,{stdio:['ignore',stdout,stderr]})
fs.closeSync(stdout);fs.closeSync(stderr)
child.on('error',error=>{spawnError={name:error.name,message:error.message,code:error.code}})
child.on('close',(code,signal)=>{const report={id,command,args,cwd:process.cwd(),start,end:new Date().toISOString(),exit:code,signal,spawnError,head:execFileSync('git',['rev-parse','HEAD'],{encoding:'utf8'}).trim(),observerTimeout:false,stdoutBytes:fs.statSync(folder+'/'+id+'.stdout.raw').size,stderrBytes:fs.statSync(folder+'/'+id+'.stderr.raw').size};fs.writeFileSync(folder+'/'+id+'.execution.json',JSON.stringify(report,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify(report));process.exitCode=spawnError||signal?1:code??1})
