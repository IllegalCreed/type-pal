import fs from 'node:fs'
import path from 'node:path'
import {createRequire} from 'node:module'
import {fileURLToPath} from 'node:url'
const ts=createRequire(process.cwd()+'/package.json')('typescript'),results=[]
for(const file of ["packages/game/src/assets/tileset-blob.ts", "packages/game/src/assets/tileset-blob.test.ts", "packages/game/src/assets/tileset-gzip.grok-r1.test.ts", "packages/game/src/assets/tileset-load.grok-r1.test.ts", "packages/game/src/assets/dialog-assets.ts", "packages/game/src/assets/dialog-assets.glm-phase1-leaves.test.ts", "packages/game/src/assets/dialog-icons.grok-r1.test.ts", "packages/game/src/assets/dialog-resources.grok-mid-1.test.ts", "packages/game/src/assets/rle-decode.ts", "packages/game/src/assets/rle-decode.test.ts", "packages/game/src/__tests__/grok-render-r1/legal-host.ts"]){
 const source=ts.createSourceFile(file,fs.readFileSync(file,'utf8'),ts.ScriptTarget.Latest,true)
 function visit(node){
  if(ts.isFunctionLike(node)&&node.body){
   let complexity=1
   function branch(n){if(n!==node&&ts.isFunctionLike(n))return;if(ts.isIfStatement(n)||ts.isForStatement(n)||ts.isForInStatement(n)||ts.isForOfStatement(n)||ts.isWhileStatement(n)||ts.isDoStatement(n)||ts.isCaseClause(n)||ts.isCatchClause(n)||ts.isConditionalExpression(n)||(ts.isBinaryExpression(n)&&[ts.SyntaxKind.AmpersandAmpersandToken,ts.SyntaxKind.BarBarToken,ts.SyntaxKind.QuestionQuestionToken].includes(n.operatorToken.kind)))complexity++;ts.forEachChild(n,branch)}
   branch(node);results.push({file,name:node.name?.getText(source)??'<anonymous>',line:source.getLineAndCharacterOfPosition(node.getStart(source)).line+1,complexity,mark:complexity>10?'read-priority':'normal'})
  }
  ts.forEachChild(node,visit)
 }visit(source)
}
const report={tool:'TypeScript '+ts.version,method:'Approximate cyclomatic: decisions + &&/||/??; nested functions scored separately. Hint only,not acceptance target.',results,review:'Hint only: IO assembly and cache ownership reviewed separately; helper route/data-builder high scores remain partial, not lowered by speculative abstraction. UI list removal repairs frame identity, not a metric target.'}
fs.writeFileSync(path.dirname(fileURLToPath(import.meta.url))+'/complexity-hints.json',JSON.stringify(report,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify({tool:report.tool,method:report.method,high:results.filter(r=>r.complexity>10)}))
