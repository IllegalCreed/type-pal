import fs from 'node:fs'
import cp from 'node:child_process'
import crypto from 'node:crypto'
import path from 'node:path'
import {fileURLToPath} from 'node:url'
const dir=path.dirname(fileURLToPath(import.meta.url)),source='packages/game/src/assets/dialog-assets.ts',test='packages/game/src/assets/dialog-icons.grok-r1.test.ts',a=fs.readFileSync(source),b=fs.readFileSync(test),hash=x=>crypto.createHash('sha256').update(x).digest('hex')
const needle="console.warn('[dialog-assets] icons failed, skip:', err)",replacement="console.warn('[dialog-assets] icons failed WITHOUT CONTEXT:', err)"
if(a.toString().split(needle).length!==2)throw new Error('Expected unique warning site')
const mutant=a.toString().replace(needle,replacement),runs=[]
try {
 fs.writeFileSync(source,mutant)
 for(const [id,body] of [['warning-new-r2',b]]){
  fs.writeFileSync(test,body)
  const run=cp.spawnSync(process.execPath,[dir+'/capture.mjs',id,'env','VITEST_MAX_WORKERS=1','pnpm','--filter','@type-pal/game','exec','vitest','run','src/assets/dialog-icons.grok-r1.test.ts','-t','G02-D02','--reporter=default','--reporter=json','--outputFile.json='+dir+'/'+id+'.native.json'],{encoding:'utf8'})
  process.stdout.write(run.stdout);process.stderr.write(run.stderr)
  runs.push({id,exit:run.status,testSha256:hash(body),sourceSha256:hash(mutant)})
 }
}finally{
 fs.writeFileSync(source,a);fs.writeFileSync(test,b)
 const proof={site:{source,needle,replacement},runs,restored:[{path:source,sha256:hash(a),actual:hash(fs.readFileSync(source))},{path:test,sha256:hash(b),actual:hash(fs.readFileSync(test))}]}
 fs.writeFileSync(dir+'/warning-control-r2.json',JSON.stringify(proof,null,2)+'\n',{flag:'wx'})
 if(!proof.restored.every(r=>r.sha256===r.actual))throw new Error('Restoration mismatch')
}
