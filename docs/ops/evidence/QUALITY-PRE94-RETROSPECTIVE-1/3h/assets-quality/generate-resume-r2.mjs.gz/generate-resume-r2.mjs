import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import {createHash}from'node:crypto'
import {createRequire}from'node:module'
import {pathToFileURL}from'node:url'
const root=process.cwd(),d=fs.readFileSync('/tmp/type-pal-pre94-assets-current.txt','utf8').trim(),ts=createRequire(root+'/package.json')('typescript')
const file='scripts/coverage/run.mjs',source=fs.readFileSync(file,'utf8'),sf=ts.createSourceFile(file,source,ts.ScriptTarget.Latest,true,ts.ScriptKind.JS),main=sf.statements.find(n=>ts.isFunctionDeclaration(n)&&n.name?.text==='main')
const at=main.body.statements.findIndex(n=>ts.isVariableStatement(n)&&n.declarationList.declarations.some(d=>d.name.getText(sf)==='baseline'));assert(at>=0)
const tail=main.body.statements.slice(at).map(n=>n.getText(sf)).join('\n')
let relocated=source;const edits=sf.statements.filter(ts.isImportDeclaration).filter(n=>n.moduleSpecifier.text.startsWith('./')).map(n=>({start:n.moduleSpecifier.getStart(sf),end:n.moduleSpecifier.end,text:JSON.stringify(pathToFileURL(path.resolve('scripts/coverage',n.moduleSpecifier.text)).href)}))
for(const e of edits.sort((a,b)=>b.start-a.start))relocated=relocated.slice(0,e.start)+e.text+relocated.slice(e.end)
const call=relocated.lastIndexOf('\nmain().catch(');assert(call>0);relocated=relocated.slice(0,call)
const sha=b=>createHash('sha256').update(b).digest('hex'),run=JSON.parse(fs.readFileSync(d+'/module-ratchet.execution.json')),rawError=fs.readFileSync(d+'/module-ratchet.stderr.raw','utf8'),summary=fs.readFileSync('coverage/fast/summary.json'),before=fs.readFileSync('scripts/coverage/baseline.fast.json')
assert.equal(run.exit,1);assert.equal(run.signal,null);assert(rawError.includes('显式加 --allow-scope-removal'));assert.equal(JSON.parse(summary).testCount,20046)
const pre=[
"const resumeDirectory="+JSON.stringify(d),
"const originalCollection="+JSON.stringify(run),
"assert.equal(profile,'fast');assert.equal(ratchet,true);assert.equal(allowScopeRemoval,true)",
"const resumedResult=await readJson(resolve(repoRoot,'coverage/fast/summary.json'))",
"assert.equal(createHash('sha256').update(await readFile(resolve(repoRoot,'coverage/fast/summary.json'))).digest('hex'),"+JSON.stringify(sha(summary))+")",
"assert.equal(createHash('sha256').update(await readFile(baselinePath)).digest('hex'),"+JSON.stringify(sha(before))+",'baseline already changed; do not overwrite')",
"assert.equal(createHash('sha256').update(await readFile(resolve(repoRoot,'scripts/coverage/run.mjs'))).digest('hex'),"+JSON.stringify(sha(source))+")",
"await spawnCapture('git',['diff','--exit-code',originalCollection.head,'--','packages','scripts','package.json','pnpm-lock.yaml','pnpm-workspace.yaml','biome.json'])",
"await assertToolVersions()",
"const freeze=await readJson(resolve(resumeDirectory,'recount-entry-refreshed.json'))",
"for(const pin of freeze.sources)assert.equal(createHash('sha256').update(await readFile(resolve(repoRoot,pin.path))).digest('hex'),pin.sha256,pin.path)",
"const oldBaseline=await readJson(baselinePath)",
"const scope=auditScope(resumedResult,oldBaseline)",
"assert.deepEqual(scope.removals,[{kind:'test-count',value:'packages/game/src/assets/loader.test.ts',previous:7,current:4}])",
"const protectedTarget='40cc96ffd8a41a16da5ea3788f1d6fbf58374420'",
"process.env.TYPE_PAL_COVERAGE_BASE_REF=protectedTarget",
"const protectedSnapshot=await readBaselineFromGit(protectedTarget)",
"await assertCandidateDoesNotLowerProtectedBaseline(baselineView(resumedResult),protectedSnapshot)",
"console.log('[coverage:fast] RESUME completed official20046/758 report finalization; no test collection')",
"async function resumeOriginalTail(){const result=resumedResult;\n"+tail+"\n}",
"await resumeOriginalTail()",
"assert.deepEqual(await readJson(baselinePath),baselineView(resumedResult))",
"await writeFile(resolve(resumeDirectory,'ratchet-resume-report.json'),JSON.stringify({collector:originalCollection,originalExitPreserved:1,collectorFailure:'missing explicit --allow-scope-removal',resumedArguments:process.argv.slice(2),resultSha256:"+JSON.stringify(sha(summary))+",runnerSha256:"+JSON.stringify(sha(source))+",tailSha256:"+JSON.stringify(sha(tail))+",sameSourceFiles:true,actualTests:resumedResult.testCount,sources:resumedResult.sourceFileCount,scope,protectedTarget,canonicalBaselineWrittenByOriginalFunction:true,limits:'Original CLI attempt remains exit1. Unchanged original finalization/writer/guards resumed on same measured report with explicit retirement confirmation; not a second collector.'},null,2)+'\\n')"
].join('\n')
const generated="import assert from 'node:assert/strict'\n"+relocated.replace(/^#![^\n]*\n/, '')+'\n'+pre
fs.writeFileSync(d+'/resume-ratchet-r2.mjs',generated,{flag:'wx'})
fs.writeFileSync(d+'/resume-generation-r2.json',JSON.stringify({runner:file,runnerSha256:sha(source),tailSha256:sha(tail),adaptations:['Imports relocated to identical original modules for private location','Only top-level main invocation omitted; no function body changed','Exact original main statements from let baseline through end reused','Added immutable report/source/baseline guards and stronger exact retirement/protected check'],generatedSha256:sha(generated)},null,2)+'\n')
console.log('Prepared exact original finalization; original collector exit1 retained.')
