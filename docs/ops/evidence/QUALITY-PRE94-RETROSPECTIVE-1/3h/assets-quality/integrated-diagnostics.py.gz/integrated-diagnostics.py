from pathlib import Path
import re,json,hashlib
p=Path(__file__).parent
ids=[n for n in ['module-check-r4','module-ratchet','integrated-check-r2','integrated-ratchet-r2'] if (p/(n+'.execution.json')).exists()]
results=[]
for name in ids:
 out=(p/(name+'.stdout.raw')).read_text();err=(p/(name+'.stderr.raw')).read_text();clean=re.sub(r'\x1b\[[0-9;]*[a-zA-Z]','',out+'\n'+err)
 counts={'stderrBytes':len(err.encode()),'vitestStderrBlocks':len(re.findall(r'^\s*stderr \|',clean,re.M)),'actDiagnosticMessages':len(re.findall(r'^(?:An update to .+|The current testing environment is not configured to support act|Warning: .+not wrapped in act)',clean,re.M)),'nodeWarnings':len(re.findall(r'^\(node:\d+\).*Warning:',clean,re.M)),'typeErrors':len(re.findall(r'error TS\d+:',clean))}
 stdout_blocks=re.split(r'^\s*stdout \|',clean,flags=re.M)[1:]
 result={'id':name,'execution':json.loads((p/(name+'.execution.json')).read_text()),'diagnostics':counts,'stdoutBlocks':len(stdout_blocks),'stdoutBlockHeaders':[b.splitlines()[0] for b in stdout_blocks],'vitestSummaryTests':[int(n) for n in re.findall(r'^\s*Tests\s+(\d+) passed',clean,re.M)],'vitestSummaryFiles':[int(n) for n in re.findall(r'^\s*Test Files\s+(\d+) passed',clean,re.M)],'nodeTestSummaries':[int(n) for n in re.findall(r'^# tests (\d+)$',clean,re.M)],'stdoutSha256':hashlib.sha256(out.encode()).hexdigest(),'stderrSha256':hashlib.sha256(err.encode()).hexdigest()}
 results.append(result)
 if name=='module-ratchet':
  assert result['execution']['exit']==1
  assert err=='\n[coverage:fast] FAIL\nscope/test identity 有删除；核实真实删除或重命名后显式加 --allow-scope-removal:\n- test-count: packages/game/src/assets/loader.test.ts\n'
  result['collectionCompleteButFinalizationRejected']='Missing explicit scope-removal flag; original exit1 retained; original tail resumed separately'
  assert not any(v for k,v in counts.items() if k!='stderrBytes'),counts
 else:
  assert result['execution']['exit']==0,name
  assert not any(counts.values()),counts
(p/'integrated-diagnostics.json').write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n');print(json.dumps([{k:r[k] for k in ['id','diagnostics','stdoutBlocks','vitestSummaryTests','vitestSummaryFiles','nodeTestSummaries']} for r in results],ensure_ascii=False))
