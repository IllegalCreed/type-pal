import hashlib,json,pathlib,subprocess,sys
folder=pathlib.Path(__file__).resolve().parent
report=json.loads((folder/'review.json').read_text())
problems=[]
if subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()!=report['candidate']:
 problems.append('candidate HEAD drift')
for section in ['files','attachments']:
 for item in report[section]:
  path=pathlib.Path(item['path']) if section=='files' else folder/item['path']
  if not path.exists() or hashlib.sha256(path.read_bytes()).hexdigest()!=item['sha256']:
   problems.append(str(path)+' bytes missing or drifted')
restored=json.loads((folder/'restored.json').read_text())
if not restored['success'] or restored['numPassedTests']!=60 or restored['numFailedTests']!=0 or restored['numPendingTests']!=0:
 problems.append('restored native test result mismatch')
if (folder/'restored.stderr').read_bytes()!=b'': problems.append('unexpected restored stderr')
for item in ['typecheck-final','diff-check']:
 native=json.loads((folder/(item+'.run.json')).read_text())
 if native['exit']!=0 or native['signal'] is not None or native['spawnError'] is not None:
  problems.append(item+' native completion mismatch')
biome=json.loads((folder/'biome-final.stdout').read_text())
if biome['diagnostics'] or any(biome['summary'][k]!=0 for k in ['errors','warnings','infos','skipped','diagnosticsNotPrinted','changed']):
 problems.append('biome diagnostics/partial scan')
if biome['summary']['unchanged']!=14: problems.append('biome file count mismatch')
counter=json.loads((folder/'counter-quadrant.json').read_text())
if (counter['numPassedTests'],counter['numFailedTests'],counter['numPendingTests'],counter['numTodoTests'])!=(9,1,0,0):
 problems.append('formal counter native counts mismatch')
manifest=json.loads((folder/'counter-quadrant.manifest.json').read_text())
if manifest['originalSha256']!=manifest['restoredSha256']:
 problems.append('mutant restore mismatch')
if problems:
 print(json.dumps({'status':'failed','problems':problems},ensure_ascii=False,indent=2))
 sys.exit(1)
print(json.dumps({'status':'matched','candidate':report['candidate'],'files':len(report['files']),'attachments':len(report['attachments']),'native':{'restored':60,'formalCounter':'9 passed / 1 AssertionError / 0 skipped','biome':'14 files / 0 diagnostics'},'semanticLimit':'Identity and native result checks only; design and oracle judgments remain contributor review; browser/hardware not certified'},ensure_ascii=False,indent=2))
