import { chromium } from 'playwright'
import assert from 'node:assert/strict'
import { writeFile } from 'node:fs/promises'
const browser=await chromium.launch({headless:true,channel:'chrome'})
const context=await browser.newContext({viewport:{width:1100,height:760}})
await context.addInitScript(()=>{localStorage.setItem('tp-language','en');window.__cacheEvents=[];navigator.serviceWorker.addEventListener('message',e=>window.__cacheEvents.push(e.data))})
const page=await context.newPage();const errors=[]
page.on('pageerror',e=>errors.push(String(e)))
page.on('console',m=>{if(m.type()==='error')errors.push(m.text())})
await page.goto('http://127.0.0.1:6006/?skip-intro=1')
await page.locator('#boot-loading-enter-btn').waitFor({state:'visible',timeout:60000})
const loadingText=await page.locator('#boot-loading').innerText()
await page.locator('#boot-loading-enter-btn').click()
const decline=page.getByRole('button',{name:'Decline',exact:true});if(await decline.isVisible())await decline.click()
await page.waitForFunction(()=>window.__cacheEvents.some(e=>e.type==='precache-done'),null,{timeout:120000})
const cached=await page.evaluate(async()=>{const response=await caches.match('/extracted/lookup/en.json');return{names:await caches.keys(),english:response?{status:response.status,pack:await response.json()}:null}})
assert(cached.english);assert.equal(cached.english.pack.groups.length,4768)
await context.setOffline(true)
const offline=await page.evaluate(async()=>{const response=await fetch('/extracted/lookup/en.json');const pack=await response.json();return{status:response.status,language:pack.language,words:Object.keys(pack.words).length}})
await page.locator('#tp-tools-launcher').click();await page.locator('.tp-tab[data-key=system]').click()
await page.locator('#tp-language').selectOption('zh-CN');await page.locator('#tp-language').selectOption('en')
const selected=await page.locator('#tp-language').inputValue()
assert.equal(selected,'en');assert.equal(errors.length,0)
await page.screenshot({path:'build/english-integration/production-offline-english.png'})
const events=await page.evaluate(()=>window.__cacheEvents)
const receipt={kind:'production-static-preview-english',origin:'http://127.0.0.1:6006',loadingText,cacheNames:cached.names,groupCount:cached.english.pack.groups.length,offline,selected,errors,completed:events.filter(e=>e.type==='precache-done'),scope:'production build + real service worker + offline in-page language switching; no offline navigation or cloud deployment claim'}
await writeFile('build/english-integration/production-smoke.json',JSON.stringify(receipt,null,2)+'\n');console.log(receipt)
await browser.close()
