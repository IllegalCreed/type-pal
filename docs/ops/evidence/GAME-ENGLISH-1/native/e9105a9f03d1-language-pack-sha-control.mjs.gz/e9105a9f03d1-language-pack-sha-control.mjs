import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { readFileSync,writeFileSync } from 'node:fs'
import { spawnSync } from 'node:child_process'
import { resolve } from 'node:path'
const sha=v=>createHash('sha256').update(v).digest('hex')
const dir=resolve('build/english-integration')
const cases=[{id:'language-pack-sha',file:'packages/game/src/assets/language-pack.ts',test:'src/assets/language-pack.test.ts',testFile:'packages/game/src/assets/language-pack.test.ts',needle:'!/^[a-f0-9]{64}$/.test(source[key])',replacement:'false',name:'rejects an advertised corrupt language response: invalid source hash'}]
const receipts=[]
for(const c of cases){
 const source=readFileSync(c.file,'utf8');assert.equal(source.split(c.needle).length,2)
 const mutant=source.replace(c.needle,c.replacement)
 const run=kind=>{const json=resolve(dir,`${c.id}-${kind}.json`);const args=['--filter','@type-pal/game','exec','vitest','run',c.test,'--reporter=json',`--outputFile=${json}`];const result=spawnSync('pnpm',args,{encoding:'utf8'});writeFileSync(`${dir}/${c.id}-${kind}.stdout.txt`,result.stdout??'');writeFileSync(`${dir}/${c.id}-${kind}.stderr.txt`,result.stderr??'');const report=JSON.parse(readFileSync(json,'utf8'));return{command:['pnpm',...args],exit:result.status,signal:result.signal,report,json}}
 let red
 try{writeFileSync(c.file,mutant);red=run('mutant');assert.equal(red.exit,1);assert.equal(red.report.numFailedTests,1);assert.equal(red.report.numPendingTests,0);const failures=red.report.testResults.flatMap(f=>f.assertionResults).filter(t=>t.status==='failed');assert.equal(failures[0].fullName,c.name);assert.match(failures[0].failureMessages[0],/promise resolved.*instead of rejecting/s)}finally{writeFileSync(c.file,source)}
 const green=run('restored');assert.equal(green.exit,0);assert.equal(green.report.numFailedTests,0);assert.equal(sha(readFileSync(c.file)),sha(source));receipts.push({id:c.id,source:c.file,sourceSha256:sha(source),mutantSha256:sha(mutant),test:c.testFile,testSha256:sha(readFileSync(c.testFile)),red:{command:red.command,exit:red.exit,signal:red.signal,json:red.json,failed:1,passed:red.report.numPassedTests},green:{command:green.command,exit:green.exit,json:green.json,passed:green.report.numPassedTests},scope:'one exact business assertion; fixtures and runtime calls unchanged'})
}
writeFileSync(`${dir}/language-pack-sha-control.json`,JSON.stringify(receipts,null,2)+'\n');console.log(receipts.map(r=>({id:r.id,red:r.red.failed,green:r.green.passed})))
