import {readFileSync} from 'node:fs'
import {createHash} from 'node:crypto'
import {openMkf,readChunk} from '/Users/zhangxu/illegal/type-pal/packages/pal-extract/src/io/mkf.ts'
import {parseSpriteChunk} from '/Users/zhangxu/illegal/type-pal/packages/pal-extract/src/io/rle.ts'
import {decompressYj2} from '/Users/zhangxu/illegal/type-pal/packages/pal-extract/src/io/yj2.ts'
import {parseBdf} from '/Users/zhangxu/illegal/type-pal/packages/pal-extract/src/font/bdf-to-json.ts'
import {createInitialGameState,hydratePlayerRolesRuntime} from '/Users/zhangxu/illegal/type-pal/packages/game/src/core/game-state.ts'
import {createPlayerStatus} from '/Users/zhangxu/illegal/type-pal/packages/game/src/core/menu/player-status.ts'
import {createEquipMenu,confirmEquipItem} from '/Users/zhangxu/illegal/type-pal/packages/game/src/core/menu/equip-menu.ts'
import {createInGameMenu} from '/Users/zhangxu/illegal/type-pal/packages/game/src/core/menu/in-game-menu.ts'
import {drawPlayerStatus} from '/Users/zhangxu/illegal/type-pal/packages/game/src/present/menu/draw-player-status.ts'
import {drawEquipMenu} from '/Users/zhangxu/illegal/type-pal/packages/game/src/present/menu/draw-equip.ts'
import {drawMenuStack} from '/Users/zhangxu/illegal/type-pal/packages/game/src/present/menu/draw-menu.ts'
import {createFramebuffer} from '/Users/zhangxu/illegal/type-pal/packages/game/src/present/framebuffer.ts'
import {setWordTable,setEnglishWordTable} from '/Users/zhangxu/illegal/type-pal/packages/game/src/core/word-lookup.ts'
import {setLanguage} from '/Users/zhangxu/illegal/type-pal/packages/game/src/localization/language.ts'
import {setEnglishLayout} from '/Users/zhangxu/illegal/type-pal/packages/game/src/localization/layout.ts'
const root='/Users/zhangxu/illegal/type-pal';const read=(path:string)=>JSON.parse(readFileSync(`${root}/data/extracted/${path}`,'utf8'));const hash=(bytes:Uint8Array|string)=>createHash('sha256').update(bytes).digest('hex')
const pack=read('lookup/en.json');setWordTable(read('lookup/words.json').flat);setEnglishWordTable(pack.words);setEnglishLayout(pack.layout);setLanguage('zh-CN')
const roles=read('data/player-roles.json');const items=read('data/items.json');const gs=createInitialGameState({x:0,y:0,facing:'down'});hydratePlayerRolesRuntime(gs.PlayerRolesRuntime,roles);gs.partyMembers=[4];gs.inventory=[{itemId:202,count:1}]
const gmap=new Map(parseBdf(readFileSync(`${root}/data/raw/unifont-cn.bdf`,'utf8')).map(g=>[g.codepoint,g]));const glyphs={get:(cp:number)=>gmap.get(cp),has:(cp:number)=>gmap.has(cp)}
const data=openMkf(readFileSync(`${root}/data/raw/DATA.MKF`));const frames=parseSpriteChunk(readChunk(data,9)).map(f=>({width:f.width,height:f.height,indices:f.pixels,opaque:f.opaque}));const fbp=openMkf(readFileSync(`${root}/data/raw/FBP.MKF`));const background=(n:number)=>({width:320,height:200,indices:decompressYj2(readChunk(fbp,n))})
const statusState=createPlayerStatus([4]);const equipState=createEquipMenu(gs,items);confirmEquipItem(equipState,items,roles,[4]);const mainState=createInGameMenu();gs.menuStack=[{kind:'in-game',state:mainState}]
const oldNow=Date.now;Date.now=()=>0
try{
 const observations=[]
 for(const [name,state,render]of [
  ['main',mainState,(fb:any)=>drawMenuStack(fb,gs,frames,glyphs)],
  ['status',statusState,(fb:any)=>drawPlayerStatus({fb,state:statusState,gs,playerRoles:roles,items,uiSpriteFrames:frames,glyphs,statusBg:background(0)})],
  ['equip',equipState,(fb:any)=>drawEquipMenu({fb,state:equipState,gs,playerRoles:roles,items,uiSpriteFrames:frames,glyphs,equipBg:background(1)})]
 ]as const){
  const before=hash(JSON.stringify({gs,state}));const images=[]
  for(const language of ['zh-CN','en','zh-CN']as const){setLanguage(language);const fb=createFramebuffer();render(fb);images.push(hash(fb.indices))}
  const unchanged=before===hash(JSON.stringify({gs,state}));if(!unchanged||images[0]!==images[2]||images[0]===images[1])throw new Error(`${name}: language render contract failed`)
  observations.push({name,stateUnchanged:unchanged,chinesePixelsRestored:images[0]===images[2],englishPixelsDiffer:images[0]!==images[1],hashes:images})
 }
 console.log(JSON.stringify({equipmentPhase:equipState.phase,observations},null,2))
}finally{Date.now=oldNow;setLanguage('zh-CN')}
