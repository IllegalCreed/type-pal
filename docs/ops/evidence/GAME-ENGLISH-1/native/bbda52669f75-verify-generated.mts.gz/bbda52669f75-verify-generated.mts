import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { readFileSync, writeFileSync } from 'node:fs'
import { parseLanguagePack } from '../../packages/game/src/assets/language-pack.ts'
import { setLanguage } from '../../packages/game/src/localization/language.ts'
import { resolveMessageGroup, setEnglishMessages, getMissingEnglishMessageGroups } from '../../packages/game/src/localization/messages.ts'
import { recompile } from '../../packages/pal-extract/src/events/recompile.ts'
const sha=(bytes)=>createHash('sha256').update(bytes).digest('hex')
const read=(p)=>JSON.parse(readFileSync(p,'utf8'))
const pack=parseLanguagePack(read('data/extracted/lookup/en.json'))
assert(!/\p{Script=Han}/u.test(JSON.stringify(pack)))
assert(Object.values(pack.words).every(word=>[...word].length<=10))
assert.equal(pack.groups.length,4768)
assert.equal(Object.keys(pack.words).length,578)
const file=read('data/extracted/events/all.json')
const commands=file.segments.flatMap(seg=>seg.commands)
const sourceJson=JSON.stringify(commands)
const bytecode=recompile(commands,read('data/extracted/lookup/strings.json'))
assert.equal(sha(bytecode),pack.source.scriptSha256)
setLanguage('en');setEnglishMessages(pack.groups)
let matches=0
for(let i=0;i<commands.length;i++){
 if(commands[i].op!=='showDialog')continue
 const group=resolveMessageGroup(commands,i)
 assert(group,`unmatched group at ${i}`)
 matches++; i=group.resumeIp-1
}
assert.equal(matches,4768)
assert.equal(getMissingEnglishMessageGroups().length,0)
assert.equal(JSON.stringify(commands),sourceJson)
const glyphs=new Set(read('data/extracted/data/font/glyphs.json').glyphs.map(g=>g.codepoint))
const chars=new Set([...Object.values(pack.words).join('')+pack.groups.flatMap(g=>g.lines.filter(l=>l!==null)).join('')])
const missing=[...chars].filter(c=>!glyphs.has(c.codePointAt(0)))
assert.deepEqual(missing,[])
const receipt={kind:'generated-english-closure',date:'2026-10-22',source:pack.source,commonCommands:commands.length,matchedGroups:matches,words:Object.keys(pack.words).length,clearTokens:pack.groups.flatMap(g=>g.lines).filter(l=>l===null).length,han:0,missingGlyphs:missing,scriptJsonSha256:sha(sourceJson),packSha256:sha(readFileSync('data/extracted/lookup/en.json')),manifest:read('data/extracted/asset-manifest.json').version,scope:'static generated resource and real resolver; no full story/runtime claim'}
writeFileSync('build/english-integration/generated-closure.json',JSON.stringify(receipt,null,2)+'\n')
console.log(receipt)
