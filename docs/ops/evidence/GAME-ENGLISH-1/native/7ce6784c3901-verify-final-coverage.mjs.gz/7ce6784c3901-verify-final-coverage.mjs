import assert from 'node:assert/strict'
import {readFileSync,writeFileSync} from 'node:fs'
import {execFileSync} from 'node:child_process'
import {createHash} from 'node:crypto'
import {compareCoverage} from '../../scripts/coverage/metrics.mjs'
import {auditScope} from '../../scripts/coverage/inventory.mjs'
const read=p=>JSON.parse(readFileSync(p,'utf8'))
const baseline=read('scripts/coverage/baseline.fast.json'),actual=read('coverage/fast/summary.json')
const target='6a29b455fc51664df85334bc177d0994348a7987'
const protectedBaseline=JSON.parse(execFileSync('git',['show',`${target}:scripts/coverage/baseline.fast.json`],{encoding:'utf8'}))
const strict=compareCoverage(actual,baseline),scope=auditScope(actual,baseline)
const protectedComparison=compareCoverage(baseline,protectedBaseline),protectedScope=auditScope(baseline,protectedBaseline)
assert.equal(actual.schemaVersion,2);assert.equal(actual.profile,'fast');assert.deepEqual(actual.provider,baseline.provider)
assert.deepEqual(strict.regressions,[]);assert.deepEqual(scope.changes,[]);assert.deepEqual(protectedComparison.regressions,[]);assert.deepEqual(protectedScope.removals,[])
const receipt={kind:'read-only-final-metric-and-scope-check',task:'GAME-ENGLISH-1',officialRun:'VITEST_MAX_WORKERS=2 TYPE_PAL_COVERAGE_BASE_REF='+target+' pnpm coverage:ratchet',officialExit:0,summarySha256:createHash('sha256').update(readFileSync('coverage/fast/summary.json')).digest('hex'),baselineSha256:createHash('sha256').update(readFileSync('scripts/coverage/baseline.fast.json')).digest('hex'),strictRegressions:strict.regressions,strictScopeChanges:scope.changes,protectedTarget:target,protectedRegressions:protectedComparison.regressions,protectedScopeRemovals:protectedScope.removals,total:actual.total,packages:Object.fromEntries(Object.entries(actual.packages).map(([id,v])=>[id,v.metrics])),scope:'Actual final native summary checked using unchanged exported comparison/inventory functions. This is not another Vitest/official fast execution; the official ratchet already executed all20180 tests.'}
writeFileSync('build/english-integration/coverage-comparison.json',JSON.stringify(receipt,null,2)+'\n');console.log({strictRegressions:strict.regressions,scopeChanges:scope.changes,protectedRegressions:protectedComparison.regressions,removals:protectedScope.removals})
