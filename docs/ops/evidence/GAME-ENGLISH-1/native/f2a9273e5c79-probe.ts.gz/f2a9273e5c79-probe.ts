import {readFileSync,writeFileSync} from 'node:fs'
import {createHash} from 'node:crypto'
import {openMkf,readChunk} from '/Users/zhangxu/illegal/type-pal/packages/pal-extract/src/io/mkf.ts'
import {decompressYj2} from '/Users/zhangxu/illegal/type-pal/packages/pal-extract/src/io/yj2.ts'
import {englishStatusBackground,englishEquipBackground} from '/Users/zhangxu/illegal/type-pal/packages/game/src/present/menu/localized-background.ts'
import {SMALL_FONT} from '/Users/zhangxu/illegal/type-pal/packages/game/src/present/small-font.ts'
import {drawScriptDescription} from '/Users/zhangxu/illegal/type-pal/packages/game/src/present/menu/draw-description.ts'
import {createFramebuffer} from '/Users/zhangxu/illegal/type-pal/packages/game/src/present/framebuffer.ts'
import {setLanguage} from '/Users/zhangxu/illegal/type-pal/packages/game/src/localization/language.ts'
const root='/Users/zhangxu/illegal/type-pal'
const hash=(bytes:Uint8Array)=>createHash('sha256').update(bytes).digest('hex')
const mkf=openMkf(readFileSync(`${root}/data/raw/FBP.MKF`))
const status=decompressYj2(readChunk(mkf,0));const equip=decompressYj2(readChunk(mkf,1));const statusHash=hash(status);const equipHash=hash(equip)
const pack=JSON.parse(readFileSync(`${root}/data/extracted/lookup/en.json`,'utf8'))
const positions=Array.from({length:6},(_,i)=>pack.layout[String(53+i)])
// Independent transcription of the SDLPal C memcpy loops, including the equip-image save/erase/restore.
const expected=status.slice();const box=new Uint8Array(50*49)
const copy=(data:Uint8Array,dx:number,dy:number,sx:number,sy:number,n:number)=>data.set(data.slice(sy*320+sx,sy*320+sx+n),dy*320+dx)
for(let i=0;i<49;i++)box.set(expected.slice((i+39)*320+247,(i+39)*320+297),i*50)
for(let i=0;i<49;i++){
 copy(expected,81,i+125,31,i+125,50);copy(expected,141,i+141,31,i+141,50);copy(expected,201,i+133,31,i+133,50);copy(expected,251,i+101,31,i+101,50);copy(expected,247,i+39,139,i+39,50);if(i>0)copy(expected,189,i-1,139,i-1,50)
}
for(const{x,y}of positions)for(let sy=Math.max(0,-y);sy<49&&y+sy<200;sy++)expected.set(box.slice(sy*50+Math.max(0,-x),sy*50+50-Math.max(0,x-270)),(y+sy)*320+x+Math.max(0,-x))
const actual=englishStatusBackground({width:320,height:200,indices:status},positions).indices
const statusDifferences=actual.reduce((sum,pixel,i)=>sum+(pixel!==expected[i]?1:0),0)
const expectedEquip=equip.slice()
for(let i=8;i<72;i++){copy(expectedEquip,92,i,92,i+128,32);copy(expectedEquip,92,i+64,92,i+128,32)}
for(let i=9;i<90;i++)copy(expectedEquip,226,i,226,i+104,32)
for(let i=99;i<113;i++)copy(expectedEquip,226,i,226,i+16,32)
const image=new Uint8Array(72*72)
for(let i=8;i<80;i++){image.set(expectedEquip.slice(i*320+8,i*320+80),(i-8)*72);copy(expectedEquip,8,i,8,i+72,72)}
for(let i=0;i<72;i++)expectedEquip.set(image.slice(i*72,i*72+72),(i+pack.layout['1'].y)*320+pack.layout['1'].x)
const actualEquip=englishEquipBackground({width:320,height:200,indices:equip}).indices
const equipDifferences=actualEquip.reduce((sum,pixel,i)=>sum+(pixel!==expectedEquip[i]?1:0),0)
const groups=pack.groups.filter((g:any)=>g.start>=12500)
const uncommon=groups.flatMap((g:any)=>g.lines.filter((line:any)=>line!==null).flatMap((line:string)=>[...line].filter(ch=>!SMALL_FONT.has(ch.codePointAt(0)!)).map(ch=>({group:g.start,char:ch,codepoint:ch.codePointAt(0)}))))
const line=pack.groups.find((g:any)=>g.start===12747)?.lines.find((l:string)=>l.includes('Atk+28')) ?? pack.groups.find((g:any)=>g.start===12746)?.lines.find((l:string)=>l.includes('Atk+28'))
const example=pack.groups.flatMap((g:any)=>g.lines.map((l:any)=>({start:g.start,line:l}))).find((g:any)=>typeof g.line==='string'&&g.line.includes('Atk+28\u3000Agi+12'))
setLanguage('en');const fb=createFramebuffer();drawScriptDescription(fb,[example.line],71,151,240,0x3c)
const litRows=Array.from({length:200},(_,y)=>y).filter(y=>fb.indices.subarray(y*320,(y+1)*320).some(p=>p!==0))
setLanguage('zh-CN')
const names:any[]=[];const words=JSON.parse(readFileSync(`${root}/data/extracted/lookup/words.json`,'utf8')).flat
for(const file of ['items','spells'])for(const item of JSON.parse(readFileSync(`${root}/data/extracted/data/${file}.json`,'utf8')))if(words[item.id]!==item._name)names.push({file,id:item.id,word:words[item.id],name:item._name})
for(const role of JSON.parse(readFileSync(`${root}/data/extracted/data/player-roles.json`,'utf8')).roles)if(words[role.name]!==role._name)names.push({file:'roles',id:role.id,word:words[role.name],name:role._name})
console.log(JSON.stringify({statusDifferences,equipDifferences,statusSourceUnchanged:statusHash===hash(status),equipSourceUnchanged:equipHash===hash(equip),missingSmallFontCharacters:uncommon,actualDescription:example,actualDescriptionLitRows:litRows,sourceChineseNameMismatches:names,hashes:{statusHash,equipHash}},null,2))
