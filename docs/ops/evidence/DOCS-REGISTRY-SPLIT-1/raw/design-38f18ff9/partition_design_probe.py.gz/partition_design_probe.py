from pathlib import Path
import json,hashlib,subprocess
r=Path('/Users/zhangxu/.codex/worktrees/docs-integrity-readonly/type-pal');d=json.loads((r/'docs/phase-governance/document-registry.json').read_bytes());groups={}
for i,e in enumerate(d['entries']):
 g=groups.setdefault(e['phase'],{'schemaVersion':1,'phase':e['phase'],'positions':[],'entries':[]});g['positions'].append(i);g['entries'].append(e)
restored=[None]*len(d['entries']);sizes={}
for ph,g in groups.items():
 for pos,e in zip(g['positions'],g['entries']):assert restored[pos] is None;restored[pos]=e
 cmd=['/Users/zhangxu/illegal/type-pal/node_modules/.bin/biome','format','--stdin-file-path=docs/phase-governance/document-registry.'+ph+'.json']
 q=subprocess.run(cmd,cwd=r,input=json.dumps(g,ensure_ascii=False).encode(),capture_output=True,timeout=15);assert q.returncode==0,q.stderr
 sizes[ph]={'total':len(g['entries']),'formattedBytes':len(q.stdout),'sha256':hashlib.sha256(q.stdout).hexdigest(),'below1MiB':len(q.stdout)<=1048576}
assert restored==d['entries'];assert all(s['below1MiB'] for s in sizes.values())
print(json.dumps({'kind':'design-partition-feasibility-model-not-candidate-loader','reconstructedObjectsAndOrderEqual':True,'sourceTotal':len(restored),'perPhase':sizes,'scope':'Uses actual source objects and positions. No proposed implementation was executed or accepted.'},indent=2))
