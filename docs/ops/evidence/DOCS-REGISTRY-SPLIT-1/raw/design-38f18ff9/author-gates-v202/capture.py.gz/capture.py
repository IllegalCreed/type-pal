from pathlib import Path
import subprocess,os,hashlib,json,datetime,concurrent.futures
p=Path(__file__).parent
cwd='/Users/zhangxu/illegal/type-pal-docs-audit-rework'
def run(item):
 name,cmd=item
 start=datetime.datetime.now(datetime.timezone.utc).isoformat()
 r=subprocess.run(cmd,cwd=cwd,env={**os.environ,'NODE_PATH':'/Users/zhangxu/illegal/type-pal/node_modules'},capture_output=True)
 for stream in ['stdout','stderr']: (p/(name+'.'+stream)).write_bytes(getattr(r,stream))
 receipt={'command':cmd,'cwd':cwd,'startedAt':start,'endedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exitCode':r.returncode,'stdoutSha256':hashlib.sha256(r.stdout).hexdigest(),'stderrSha256':hashlib.sha256(r.stderr).hexdigest()}
 (p/(name+'.json')).write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
 return {'name':name,'exitCode':r.returncode,'directory':str(p)}
with concurrent.futures.ThreadPoolExecutor() as ex:
 for result in ex.map(run,[('check-docs',['pnpm','check:docs']),('lint',['pnpm','lint']),('full-diff',['git','diff','--check','28fd9013e09e8792decbff2fa117aae14c36b196'])]): print(json.dumps(result),flush=True)
