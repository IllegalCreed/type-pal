from pathlib import Path
import json,subprocess,hashlib,collections
r=Path('/Users/zhangxu/.codex/worktrees/docs-integrity-readonly/type-pal')
p='docs/phase-governance/document-registry.json'
b=(r/p).read_bytes();g=subprocess.check_output(['git','show','3fae68aec8f448bf83d1d85e61da35c94d5200ae:'+p],cwd=r);d=json.loads(b);es=d['entries']
common=set.intersection(*(set(e) for e in es));fields=collections.Counter(k for e in es for k in e);shape=collections.Counter(tuple(sorted(e)) for e in es)
count=lambda k:dict(collections.Counter(e.get(k,'<absent>') for e in es))
summary={'total':len(es),'byPhase':count('phase'),'byType':count('docType'),'reviewStatus':count('reviewStatus'),'templateCompliance':count('templateCompliance')}
actual=d['summary']; mismatches={k:{'stored':v,'computed':summary.get(k)} for k,v in actual.items() if summary.get(k)!=v}
phaseSeq=[e['phase'] for e in es];blocks=[]
for i,ph in enumerate(phaseSeq):
 if not blocks or blocks[-1]['phase']!=ph:blocks.append({'phase':ph,'start':i,'end':i})
 else:blocks[-1]['end']=i
print(json.dumps({'kind':'mechanical-source-shape-audit-not-entry-semantic-review','sourceEqualsFrozenGit':b==g,'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b),'remainingTo1MiB':1048576-len(b),'topLevelKeys':list(d),'metadata':{k:v for k,v in d.items() if k not in ['entries','summary']},'summary':actual,'computedSummary':summary,'summaryMismatches':mismatches,'commonEntryKeys':sorted(common),'fieldCounts':dict(sorted(fields.items())),'shapeCounts':[{'keys':list(k),'count':v} for k,v in shape.items()],'duplicatePaths':[p for p,c in collections.Counter(e['path'] for e in es).items() if c>1],'phaseBlocks':blocks,'optionalFieldExamples':{k:[{'index':i,'entry':e} for i,e in enumerate(es) if k in e][:2] for k in ['templateVersion','templateVariant','artifactOnly','historyOverlay','retentionException']},'phaseGroupedFlattenPreservesOrder':phaseSeq==sorted(phaseSeq,key=lambda v:list(dict.fromkeys(phaseSeq)).index(v))},ensure_ascii=False,indent=2))
assert b==g and not mismatches and len(es)==2374
