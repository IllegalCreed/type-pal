import os,sys,subprocess,json,hashlib,time,datetime
from pathlib import Path
p=Path(__file__).parent
name=sys.argv[1]; argv=sys.argv[2:]
cwd='/Users/zhangxu/.codex/worktrees/docs-integrity-readonly/type-pal'
env=os.environ.copy();env['NODE_PATH']='/Users/zhangxu/illegal/type-pal/node_modules'
start=datetime.datetime.now(datetime.timezone.utc).isoformat();t=time.monotonic()
try:
 r=subprocess.run(argv,cwd=cwd,env=env,capture_output=True,timeout=90); out=r.stdout;err=r.stderr;code=r.returncode;spawn=None
except subprocess.TimeoutExpired as e:
 out=e.stdout or b'';err=e.stderr or b'';code=None;spawn='TimeoutExpired(90s); subprocess.run killed only own child'
end=datetime.datetime.now(datetime.timezone.utc).isoformat()
meta={'name':name,'reviewerTask':'/root/receipt_integrity_independent','candidateCommit':'38f18ff9102bf45104573b29beda4e3a2b662483','argv':argv,'cwd':cwd,'envOverrides':{'NODE_PATH':env['NODE_PATH']},'startedAt':start,'endedAt':end,'elapsedSeconds':time.monotonic()-t,'exitCode':code if code is None or code>=0 else None,'signal':-code if code is not None and code<0 else None,'spawnError':spawn}
for key,data in [('stdout',out),('stderr',err)]:
 f=p/'raw'/f'{name}.{key}';f.write_bytes(data);meta[key]={'path':str(f),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
(p/'raw'/f'{name}.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(meta,ensure_ascii=False))
