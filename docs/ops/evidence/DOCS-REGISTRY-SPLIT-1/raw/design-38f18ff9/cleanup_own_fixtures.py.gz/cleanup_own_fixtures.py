from pathlib import Path
import subprocess,hashlib,json,shutil,datetime
p=Path(__file__).parent/'fixtures';expected={'node-compile-cache','type-pal-doc-move-SduOfN','type-pal-frozen-binding-PU8hje','type-pal-doc-move-M0PS5O'}
assert {x.name for x in p.iterdir()}==expected
q=subprocess.run(['lsof','-Fpn','+D',str(p)],capture_output=True,timeout=15)
assert q.returncode==1 and not q.stdout,(q.returncode,q.stdout,q.stderr)
rows=[]
for d in sorted(p.iterdir()):
 assert d.parent==p and not d.is_symlink() and d.is_dir()
 fs=[]
 for f in sorted(d.rglob('*')):
  if f.is_symlink():fs.append({'path':str(f.relative_to(p)),'symlink':str(f.readlink())})
  elif f.is_file():fs.append({'path':str(f.relative_to(p)),'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()})
 rows.append({'path':str(d),'files':len(fs),'bytes':sum(x.get('bytes',0) for x in fs),'inventorySha256':hashlib.sha256(json.dumps(fs,sort_keys=True).encode()).hexdigest()})
 shutil.rmtree(d)
assert not list(p.iterdir())
print(json.dumps({'kind':'own-timeout-fixture-cleanup','time':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Only exact four paths under reviewer-created TMPDIR after own full check timeout; no other task processes or files modified','lsofReturnCode':q.returncode,'lsofStdoutSha256':hashlib.sha256(q.stdout).hexdigest(),'lsofStderrSha256':hashlib.sha256(q.stderr).hexdigest(),'removed':rows,'remaining':[]},indent=2))
