# Design-permitted interleaving model, NOT a candidate writer implementation.
from pathlib import Path
import json,hashlib,tempfile,shutil
p=Path(tempfile.mkdtemp(prefix='race-model-',dir=Path(__file__).parent));events=[]
def sha(b):return hashlib.sha256(b).hexdigest()
def publish(value):
 b=(json.dumps(value,sort_keys=True)+'\n').encode();(p/'shard.json').write_bytes(b);(p/'manifest.json').write_text(json.dumps({'sha256':sha(b)}))
def snap():return {q.name:sha(q.read_bytes()) for q in p.iterdir()}
def load():
 b=(p/'shard.json').read_bytes();assert json.loads((p/'manifest.json').read_bytes())['sha256']==sha(b);return json.loads(b)
publish({'A':0,'B':0});a=load();b=load();a0=snap();b0=snap();a['A']=1;b['B']=1
assert snap()==a0;events.append('A input SHA check passes on M0')
assert snap()==b0;events.append('B input SHA check passes on M0')
publish(a);assert load()=={'A':1,'B':0};events.append('A publishes M1 and reload succeeds')
publish(b);final=load();events.append('B publishes M2 and reload succeeds')
assert final=={'A':0,'B':1};events.append('A committed update lost; every stated input check/reload passed')
print(json.dumps({'kind':'design-specification-countermodel-not-runtime-acceptance','designCommit':'09ecbcbb9f5932cf41af7479b7c3287766dfd62f','designLines':[32,52],'events':events,'finalLogicalState':final,'lostUpdate':True,'scope':'Single pre-write SHA check plus manifest-last/reload admits this execution. No candidate writer exists yet.'},indent=2))
shutil.rmtree(p)
