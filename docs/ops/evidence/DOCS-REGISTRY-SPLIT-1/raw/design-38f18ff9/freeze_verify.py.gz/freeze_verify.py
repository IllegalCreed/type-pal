from pathlib import Path
import json,hashlib,subprocess
r=Path('/Users/zhangxu/.codex/worktrees/docs-integrity-readonly/type-pal')
git=lambda *a:subprocess.check_output(['git',*a],cwd=r)
assert git('status','--porcelain=v1')==b''
assert git('rev-parse','HEAD').decode().strip()=='38f18ff9102bf45104573b29beda4e3a2b662483'
assert git('diff','58e899bf000e0d3bbeafb5c4a7ecb478b07ac656..HEAD','--','scripts/docs')==b''
p='docs/phase-governance/document-registry.json';b=(r/p).read_bytes();assert b==git('show','3fae68aec8f448bf83d1d85e61da35c94d5200ae:'+p)
d=json.loads(b)
examples=[e for e in d['entries'] if e['path'] in ['docs/README.md','docs/ops/tasks/ED-ENTITY-STATE-PLAN-1.md']]
print(json.dumps({'commit':git('rev-parse','HEAD').decode().strip(),'mainCommit':git('rev-parse','refs/heads/main').decode().strip(),'worktreeClean':True,'docsToolDeltaSince58eBytes':0,'registrySourceEqualsFixedGit':True,'registrySha256':hashlib.sha256(b).hexdigest(),'nativePhaseExamples':examples},ensure_ascii=False,indent=2))
