/**
 * 主循环 wrapper(02 架构 + D13 + M3 T28)。
 *  - tickN(n, ctx):headless,跑 n 个逻辑 tick,供 e2e / record-replay 用。
 *  - startRafLoop(ctx):浏览器,rAF + accumulator 节流;按 gs.mode 切 fps
 *    (explore/event 10fps,battle 25fps),返回 cancel。
 *
 * loop启动时发布初始探索地图，后续由资源装载Owner替换。
 * 不在每tick覆写，避免用启动时的tilemap盖回新场景。
 *
 * 每个rAF按当前mode决定interval，至多推进一次逻辑；正常溢出余量结转，
 * tick后仍超过一个interval的积压丢弃。tickN不参与wall-clock节流。
 */

import type { InputSource, Tilemap } from '@type-pal/shared'
import { FRAME_MS_BATTLE, FRAME_MS_EXPLORE } from '@type-pal/shared'
import { advanceContactBattleReveal } from '../core/battle/battle-entry.js'
import { advanceBattleEnemyEscape, finishBattleEntry } from '../core/battle/battle-system.js'
import type { BusEntry, CommandBus } from '../core/command-bus.js'
import type { GameState } from '../core/game-state.js'
import { pendingEncounterFadeOut, resumeEncounterAfterFadeOut, tickByMode } from '../core/mode.js'
import { setSceneContext } from '../core/scene-system.js'
import { initStateDump } from '../dev/state-dump.js'
import { tickFps } from '../tools/fps-overlay.js'
import { isSpeedrunPaused, tickSpeedrunTimer } from '../tools/speedrun/index.js'

export interface LoopContext {
  gs: GameState
  bus: CommandBus
  input: InputSource
  tilemap: Tilemap
  isRestoringSave?: () => boolean
  /** DM32:ticked=false 表示 fade-only present(palette/dither fade 进行中的补帧)——
   *  特效计数器(wave 累加/相位 index/shakeTime 自减)**不推进**,只用当前值扭曲。 */
  onPresent: (drained: BusEntry[], ticked: boolean) => void
  /** sdlpal `PlayerRoles.rgwWalkFrames[leaderRoleId]`(3 或 4),dump 计算 wFrame 用 */
  partyWalkFrames?: number
}

/**
 * **逻辑** tick interval —— battle 40ms / 其他 100ms。**fade 不再提速逻辑**。
 *
 * 旧设计:fade 进行中把 tick 提到 16ms(60fps)让 present 多采样平滑 fade。副作用:fade 期间
 * 走步 / 打字 / frame-wait(都是每 tick 推进的逻辑)被一起加速 6×(香兰报信 cutscene 瞬移+一口气根因)。
 * 现解耦(2026-05-30):逻辑固定 100/40ms;fade 的平滑由 startRafLoop 在 fade 进行中**每 raf 帧** present
 * 实现(present.ts 内按 wall-clock 步进 fade,duration time-based 不变)。
 */
export function logicIntervalMs(gs: GameState): number {
  return gs.mode === 'battle' ? FRAME_MS_BATTLE : FRAME_MS_EXPLORE
}

/** rAF 累积器状态(startRafLoop 持有,advanceRafFrame mutate)。 */
export interface RafLoopState {
  lastTickTime: number
  accumulator: number
  paintedEncounterFadeOut?: ReturnType<typeof pendingEncounterFadeOut>
}

/**
 * 单 raf 帧推进(从 startRafLoop 抽出便于单测,无需 mock rAF)。三不变量:
 *  ① 逻辑 interval = logicIntervalMs(battle 40 / 否则 100,fade 不提速)
 *  ② 每帧至多一tick；tick后余量超过一个interval时丢弃，暂停时清空积压
 *  ③ 逻辑tick或dither/palette fade、战斗淡出/动画期间present，其它rAF不重画
 * 返回 {ticked, presented}。
 */
export function advanceRafFrame(
  state: RafLoopState,
  now: number,
  ctx: LoopContext,
  dump?: ReturnType<typeof initStateDump>,
  frozen = false,
): { ticked: boolean; presented: boolean } {
  const dt = now - state.lastTickTime
  state.lastTickTime = now
  // Load the saved scene before advancing the restored world clock or consuming input.
  if (ctx.isRestoringSave?.()) {
    state.accumulator = 0
    state.paintedEncounterFadeOut = undefined
    return { ticked: false, presented: false }
  }
  state.accumulator += dt

  const battle = ctx.gs.mode === 'battle' ? ctx.gs.battleState : undefined
  const reveal =
    battle && !frozen ? advanceContactBattleReveal(battle, performance.now()) : undefined
  if (battle && reveal) {
    state.accumulator = 0
    if (reveal === 'hold') return { ticked: false, presented: false }
    if (reveal === 'complete') {
      finishBattleEntry(battle)
      // The source clears accumulated presses before admitting the first battle frame.
      ctx.input.nextSnapshot(ctx.gs.frameNum)
    }
    ctx.onPresent([], false)
    return { ticked: false, presented: true }
  }

  if (battle && !frozen && advanceBattleEnemyEscape(ctx.gs, dt)) {
    state.accumulator = 0
    ctx.input.nextSnapshot(ctx.gs.frameNum)
    ctx.onPresent([], false)
    return { ticked: false, presented: true }
  }

  const pendingFadeOut = frozen ? undefined : pendingEncounterFadeOut(ctx.gs)
  const painted = state.paintedEncounterFadeOut
  const resumeFade =
    pendingFadeOut &&
    painted?.fade === pendingFadeOut.fade &&
    painted.cursor === pendingFadeOut.cursor
  if (resumeFade) {
    // PAL_MakeScene starts its fade on the frame after exact black over the frozen source.
    resumeEncounterAfterFadeOut(ctx.gs)
  }
  state.paintedEncounterFadeOut = undefined

  const interval = logicIntervalMs(ctx.gs)
  // DM30 修正(2026-06-12 user 报"战后 fadeout 卡键"):渐变清键的 C 真值边界是**函数级**的——
  //   清键(每步 ClearKeyState + dir=Unknown):PAL_SceneFade(0x93,palette.c:314-316)、
  //     PAL_PaletteFade 的 fUpdateScene 变体(0x80,palette.c:441-446)= 我们 waiting='scene-fade' 集合;
  //   不清键(纯色表 ramp,按键累积、按住的方向 fade 一结束立即生效,原版按住方向连穿门即此):
  //     PAL_FadeOut/FadeIn/ColorFade/FadeToRed(0x50/0x51/0x8C/0x4F/0x4E/战后&进场自动渐入)。
  //   旧条件 `paletteFadeState != null` 把清键泛化到全部渐变 → 战后 ~1.2s 吞键、按住方向须松开重按。
  //   世界冻结由 scene-system tickSceneInput/PreInput 的 paletteFadeState 门负责(忠实 PAL_FadeIn 阻塞);
  //   按住的方向键在 fade 完成的下一 tick 立即续走 = C 时序。已知近似:fade 窗口内的"点按"被逐 tick
  //   drain 丢弃(C 的 dwKeyPress 会缓存到 fade 后首帧消费;改输入消费模型收益不值,先记录)。
  if (ctx.gs.eventCursor?.waiting === 'scene-fade') ctx.input.suppressHeldForFade?.()
  let drained: BusEntry[] = []
  let ticked = false
  // DM31:C 真值(game.c:75-78 / battle.c:782-787)`PAL_DelayUntil(dwTime); dwTime = now + FRAME_TIME`
  //   —— 下一截止从**当前时刻**起算:慢帧只顺延、**永不补帧**,一次渲染恰一帧逻辑。旧 while 连跑
  //   (滞后 1~3×interval 时单 rAF 跑 2-3 tick 只 present 末态)→ 卡顿后走路瞬移/演出跳帧;
  //   accumulator 跨 mode 残留还会在 explore(100ms)→battle(40ms) 切换瞬间多跑 2 tick。
  //   当前每rAF至多1tick，正常溢出余量结转，真正积压才丢弃；不宣称逐次deadline与C完全相同。
  if (state.accumulator >= interval && frozen) {
    // 速通手动暂停(F8):冻结游戏世界(不推进逻辑、不消费输入 → 角色/NPC/演出全停),
    //   仅消费累积量避免恢复时一次性补帧。速通覆盖层/倒计时由 tickSpeedrunTimer 另行刷新。
    //   注意:仅 manualPaused 冻结;香蕉树暂停(bananaPaused)不冻结,否则无法走过去捡香蕉解除。
    state.accumulator = 0
  } else if (state.accumulator >= interval) {
    ctx.gs.nowMs = now // Bug1 fix:对话打字用 wall-clock,主循环每帧注入
    const snap = ctx.input.nextSnapshot(ctx.gs.frameNum)
    tickByMode(ctx.gs, snap, ctx.bus, pendingFadeOut !== undefined && !resumeFade)
    const d = ctx.bus.drain()
    if (d.length) drained = d
    if (dump?.enabled) dump.push(ctx.gs, ctx.partyWalkFrames ?? 3)
    ticked = true
    // DM31 修正(2026-06-13 user 报"死亡淡出比原版长"):旧版 `accumulator = 0` 把 tick 时
    //   [interval, interval+rafDt) 的**溢出量也清掉**,与本函数注释"<interval 的余量正常累积"自相矛盾。
    //   battle interval=40ms 不是 60Hz 帧时(16.667ms)整数倍 → 每 tick 实际等 3 帧=50ms → 全战斗动画
    //   (含 PAL_BattleFadeScene 死亡淡出)在 60Hz 慢 25%(30Hz 慢 68%)。改:结转溢出余量 → 节奏回到
    //   忠实 25fps(各刷新率均 ~40ms/tick avg)。DM31 的"永不补帧"由下一行 clamp 保留:残留 > 1 个
    //   interval 的**真积压**(lag spike,如卡顿后 dt≫interval)才丢弃 → 仍至多 1 tick/rAF、不连追。
    state.accumulator -= interval
    if (state.accumulator > interval) state.accumulator = 0
  }

  let presented = false
  // ③ 门控:逻辑 tick 时 / 各类 fade 进行中才 present。battleFade(D17 死亡淡出)同 palette/scene fade ——
  //   present 每 rAF 走 stepDeathFadeRender 按 wall-clock 细分渲染步(62.5fps),非 tick 帧也需放行,
  //   否则淡出只在 25fps 逻辑 tick 刷新 → 顿挫。
  if (
    ticked ||
    ctx.gs.fadeState != null ||
    ctx.gs.paletteFadeState != null ||
    ctx.gs.battleState?.battleFade != null ||
    ctx.gs.battleState?.hidingFade != null ||
    // 战斗动画期:每 rAF present 让 stepBattleAnimRender 按 wall-clock 细分 renderIdx(法术效果帧 (speed+5)*10ms
    //   在 40ms 逻辑 tick 下抖成拍频 = "施法慢"根因;实测施法期 present 仅 25fps、rAF 120fps)。涵盖普通仙术/
    //   回复/合体/召唤攻击 + 物理(40ms 帧细分后 renderIdx≈idx,无副作用)。battleAnim 外照常按 tick present。
    //   summon.loop 帧的 iSummonFrame 推进同样靠每 rAF present 跑 stepSummonLoopRender —— 已被本条覆盖。
    ctx.gs.battleState?.battleAnim != null
  ) {
    ctx.onPresent(drained, ticked)
    // Confirm the frozen renderer has actually applied the black palette. Quantization can
    // already produce black just before the deadline, so also require the complete ramp.
    if (
      pendingFadeOut &&
      !resumeFade &&
      performance.now() - pendingFadeOut.fade.startTimeMs >= pendingFadeOut.fade.totalMs &&
      ctx.gs.palette?.colors.every(([r, g, b]) => (r | g | b) === 0)
    ) {
      state.paintedEncounterFadeOut = pendingFadeOut
    }
    presented = true
  }
  return { ticked, presented }
}

function singleTick(ctx: LoopContext): void {
  ctx.gs.nowMs = performance.now() // Bug1 fix:对话打字用 wall-clock,主循环每帧注入
  const snap = ctx.input.nextSnapshot(ctx.gs.frameNum)
  tickByMode(ctx.gs, snap, ctx.bus)
  const drained = ctx.bus.drain()
  ctx.onPresent(drained, true)
}

function applySceneContext(ctx: LoopContext): void {
  setSceneContext({
    tilemap: ctx.tilemap,
  })
}

export function tickN(n: number, ctx: LoopContext): void {
  applySceneContext(ctx)
  for (let i = 0; i < n; i++) singleTick(ctx)
}

export function startRafLoop(ctx: LoopContext): () => void {
  applySceneContext(ctx)
  // state-dump 仅 DEV:生产构建 `import.meta.env.DEV`=false → initStateDump 不被引用,
  // 整个 dev/state-dump.js 模块被 tree-shake 掉(与 bootstrap 守卫 setupDevPanel 同模式;
  // 那里注释说明用 cast 避免依赖 vite/client triple-slash 类型)。dump 为 undefined 时
  // advanceRafFrame的dump端口为空时安全跳过。e2e走vite dev(DEV=true)不受影响。
  const dump = (import.meta as unknown as { env?: { DEV?: boolean } }).env?.DEV
    ? initStateDump()
    : undefined
  const state: RafLoopState = { lastTickTime: performance.now(), accumulator: 0 }
  let raf = 0
  const loop = (now: number): void => {
    advanceRafFrame(state, now, ctx, dump, isSpeedrunPaused()) // frozen=手动暂停时冻结游戏世界
    tickSpeedrunTimer(ctx.gs, now) // 速通计时器:每 rAF wall-clock 推进(未启用时内部早退)
    tickFps(now) // 左上角 FPS 覆盖层:每 rAF 累计帧数(未启用时内部早退)
    raf = requestAnimationFrame(loop)
  }
  raf = requestAnimationFrame(loop)
  return () => cancelAnimationFrame(raf)
}
