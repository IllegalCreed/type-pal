import type {
  Command,
  EventFile,
  EventObjectsFile,
  Palette,
  PlayerRoles,
  SceneEventObject,
  Tilemap,
} from '@type-pal/shared'
import { loadEnglishLanguage } from '../assets/language-pack.js'
import {
  fetchPalette,
  type SceneAssets,
  SceneAssetsCache,
  type SceneFetcher,
} from '../assets/loader.js'
import type { IndexedImage } from '../assets/png.js'
import { loadSpriteFramesBlob, loadTilesetBlob } from '../assets/tileset-blob.js'
import { isBattleContact } from '../core/battle/battle-entry.js'
import { INTRO_FADE_TICKS, startBattle } from '../core/battle/battle-system.js'
import { createCommandBus } from '../core/command-bus.js'
import { restoreDialogHistory } from '../core/dialog-history.js'
import { updateAllEquipments } from '../core/equip-effect.js'
import {
  buildLabelMap,
  getGlobalCommands,
  getGlobalLabelMap,
  runEnterScript,
  setEndingAnimationHandler,
  setEnemyObjectsTable,
  setFetchPalette,
  setGlobalEvents,
  setLoadLastSaveHandler,
  setMapReloader,
  setObjectPoisons,
  setObstacleChecker,
  setPaletteSource,
  setQuitHandler,
  setRefreshEquipmentsHandler,
  setRngPlayHandler,
  setSceneLoader,
  setScrollFbpHandler,
  setShopMenuHandler,
  setShowFbpHandler,
  setStartBattleHandler,
  setStoreTable,
} from '../core/event-system.js'
import {
  createInitialGameState,
  createInitialPlayerStatus,
  type GameState,
  getOverworldSpriteNum,
  hydrateNpcStaticDefaults,
  loadDefaultGame,
  normalizePlayerRolesRuntime,
  npcFromEventObject,
  projectRuntimeToBattleRoles,
  resetPresentationTransients,
  resetSceneRuntimeForNewGame,
  setSpriteFrameCountProvider,
  sliceSceneEventObjects,
} from '../core/game-state.js'
import {
  setLoadGameHandler,
  setMenuCatalogs,
  setStartGameHandler,
  setSystemQuitHandler,
} from '../core/menu/menu-driver.js'
import { openMenu } from '../core/menu/menu-mode.js'
import { createOpeningMenu } from '../core/menu/opening-menu.js'
import { createSellMenu } from '../core/menu/sell-menu.js'
import { createBuyMenu } from '../core/menu/shop-menu.js'
import { makeWorkingPalette } from '../core/palette-fade.js'
import { Save } from '../core/save/api.js'
import type { SaveSnapshot } from '../core/save/data.js'
import { number as isFiniteNumber } from '../core/save/v1-shape.js'
import { supplySupplementalSceneObjects } from '../core/scene-supplemental-objects.js'
import { isWalkable, setCurrentMapNum, setSceneContext } from '../core/scene-system.js'
import { setEnglishWordTable, setWordTable } from '../core/word-lookup.js'
import {
  type BattleFixturesData,
  type SceneJumpsData,
  type SceneNamesData,
  setupDevPanel,
} from '../dev/dev-panel.js'
import battleFixturesRaw from '../dev/fixtures/battle-fixtures.json' with { type: 'json' }
import sceneJumpsRaw from '../dev/fixtures/scene-jumps.json' with { type: 'json' }
import sceneNamesRaw from '../dev/fixtures/scene-names.json' with { type: 'json' }
import { localize, useFallbackLanguage } from '../localization/language.js'
import { setEnglishLayout } from '../localization/layout.js'
import { setEnglishMessages } from '../localization/messages.js'
import type { SpriteAsset } from '../present/battle/draw-battle-sprites.js'
import { type BattleAssets, BattlePresent } from '../present/battle/present-battle.js'
import { toSpriteImages } from '../present/draw-sprite.js'
import { renderText } from '../present/font.js'
import { createFramebuffer } from '../present/framebuffer.js'
import {
  applyDialogIconPaletteShift,
  flushToCanvas,
  type PresentContext,
  presentBattleFrame,
  presentFrame,
} from '../present/present.js'
import { createDisplayScaleController } from '../tools/display-scale.js'
import { setupQuickSave } from '../tools/quick-save.js'
import { setupSpeedrunHotkeys } from '../tools/speedrun/index.js'
import { showToast } from '../tools/toast.js'
import { setupToolsPanel } from '../tools/tools-panel.js'
import {
  type AudioManager,
  battleVictoryTrack,
  createAudioManager,
  pickMusicTrack,
  setSfxVolume,
  sfxForBattleEvent,
} from './audio.js'
import { createSpessaSynthBackend } from './audio-midi.js'
import { createRixBackend } from './audio-rix.js'
import { createAudioVolumeController } from './audio-volume.js'
import { playAvi, setVideoVolume } from './avi-player.js'
import { finishBootLoading, setBootLoadingNote } from './boot-loading.js'
import { startBootstrapResourceLoad } from './bootstrap-resources.js'
import { createDosCutscenes } from './dos-cutscenes.js'
import { playEndingAnimation } from './ending-player.js'
import { scrollFbp, showFbp } from './fbp-player.js'
import type { GameShell } from './game-shell.js'
import { KeyboardInputSource } from './input.js'
import { type LoopContext, startRafLoop } from './main-loop.js'
import { createMusicSourceController, readMusicSource } from './music-source.js'
import { pausePrecache, resumePrecache } from './precache-client.js'
import { playRng } from './rng-player.js'
import { createSceneThumbnailRenderer } from './scene-thumbnail.js'

// JSON 静态 import 的 TS 类型推断会把每条 fixture 推成具体 key 集合(eg. fixture-zh1
// 没 "1" → 推 "1": undefined),与 BattleFixturesData 的 Record<string, ...> 不严格匹配。
// 这里仅提供静态类型视图,cast本身不校验JSON的运行时合法性。
const battleFixtures = battleFixturesRaw as unknown as BattleFixturesData
// scene-jumps使用同一静态视图方式,不在此增加运行时校验。
const sceneJumps = sceneJumpsRaw as unknown as SceneJumpsData
// dev 场景名表(scene-names.json,人工补全;`_doc` 字段 runtime 忽略)。
const sceneNames = sceneNamesRaw as unknown as SceneNamesData

class InvalidSaveSlotError extends Error {}

// sdlpal 真值:`PAL_LoadDefaultGame` 起手 `wNumScene=1`,`PAL_GameUpdate` 取 `scenes[wNumScene-1]=scenes[0]`
// 即 dump 文件 `scene/0.json`(mapNum=20 黑地图 + onEnterLabel=L_4)— 这才是开场梦境(主角躺地 +
// 罗刹鬼婆声音 + 主角喊话)。L_4 末尾 `loadScene { sceneId: 2 }` 把 wNumScene 设 2 → `scenes[1]`
// 才是客栈(mapNum=12)L_3545 cutscene。
//
// `?skip-intro=1` URL 参数:跳过开场梦境直接进客栈(scene/1.json,inn),并跳过 cutscene 对话 —
// e2e / dev verify 用,正常用户路径仍走 scene 0 → loadScene(2) → scene 1 全流程。
const skipIntroBoot =
  typeof window !== 'undefined' && new URLSearchParams(window.location.search).has('skip-intro')
// dev:?dev-scene=N 覆写落地场景(配 ?skip-intro;E7 考证用 —— 空场景走 8 字采队形真值)
const devSceneBoot =
  typeof window !== 'undefined'
    ? Number(new URLSearchParams(window.location.search).get('dev-scene') ?? Number.NaN)
    : Number.NaN
const SCENE_ID = Number.isInteger(devSceneBoot) ? devSceneBoot : skipIntroBoot ? 1 : 0

/**
 * M5.6 T18 Step 7:`?build=win95`(默认)/ `?build=dos` URL flag。
 * - win95:trademark / splash 走 mp4 视频(playAvi 1/2.avi)— sdlpal `gConfig.fIsWIN95=TRUE`
 *   真值同口径
 * - dos:走 sdlpal DOS fallback 真做(playTrademarkFallback RNG.MKF chunk 6 +
 *   playSplashFallback FBP chunk 0x26/0x27 + 仙鹤 + 标题 RLE + palette渐变)
 * `?skip-intro=1` 优先短路全部(同前)。
 */
const buildFlag: 'win95' | 'dos' =
  typeof window !== 'undefined' &&
  new URLSearchParams(window.location.search).get('build') === 'dos'
    ? 'dos'
    : 'win95'

export function cloneScreenPalette(src: Palette): Palette {
  return { ...src, colors: src.colors.map(([r, g, b]) => [r, g, b]) }
}

export function makeBlackScreenPalette(src: Palette): Palette {
  return { ...src, colors: src.colors.map(() => [0, 0, 0] as [number, number, number]) }
}

export function syncShellAudio(
  audio: AudioManager,
  gs: GameState,
  drained: ReadonlyArray<{
    cmd: { op: string; soundId?: number; enemyIdx?: number; playerIdx?: number }
  }>,
  playerRoles: PlayerRoles,
): void {
  const inBattle = gs.battleState !== undefined
  const stoppingForContact = gs.mode === 'event' && isBattleContact(gs.eventCursor)
  // 系统菜单「音乐」「音效」开关(gs.fMusicEnabled/fSoundEnabled,PAL_SwitchMenu 切)→ AudioManager。
  //   setter 幂等(无变化 no-op),每帧调安全。
  audio.setMusicEnabled(gs.fMusicEnabled ?? true)
  audio.setSfxEnabled(gs.fSoundEnabled ?? true)
  // 战斗胜利曲(battle.c:1030-1032,'won' 结算期 isBoss?2:3 不循环;结算完 battleState 清→场景乐恢复)。
  const victoryTrack = battleVictoryTrack(gs.battleState)
  const battleIntroActive = gs.battleState?.introFade !== undefined // DM29:揭场未完 → 静默
  const useEncounterMusic = inBattle && !gs.battleState?.scriptMusicActive
  audio.sync(gs.pendingSounds, {
    track:
      stoppingForContact || battleIntroActive
        ? 0
        : victoryTrack > 0
          ? victoryTrack
          : pickMusicTrack(useEncounterMusic, gs.wNumMusic, gs.wNumBattleMusic),
    loop: victoryTrack > 0 ? false : useEncounterMusic ? true : (gs.musicLoop ?? true),
  })
  // M6 战斗 SFX:扫本帧 bus 视觉事件 → per-单位声(敌死 deathSound / 敌攻 attackSound /
  //   我攻 role.weaponSound,fight.c/battle.c AUDIO_PlaySound)。explore SFX 走 gs.pendingSounds。
  if (inBattle) {
    for (const { cmd } of drained) {
      // core 已解析好的固定声(出招/暴击 attack.ts、濒死/阵亡 battle-system 等 AUDIO_PlaySound)→ 直接播。
      if (cmd.op === 'playSound') {
        if ((cmd.soundId ?? 0) > 0) audio.playSound(cmd.soundId ?? 0)
        continue
      }
      const s = sfxForBattleEvent(cmd, gs.battleState?.enemies, gs.partyMembers, playerRoles.roles)
      if (s > 0) audio.playSound(s)
    }
  }
}

export function showError(canvas: HTMLCanvasElement, msg: string): void {
  const ctx = canvas.getContext('2d')
  if (!ctx) return
  ctx.fillStyle = '#400'
  ctx.fillRect(0, 0, canvas.width, canvas.height)
  ctx.fillStyle = '#f88'
  ctx.font = '10px monospace'
  ctx.fillText(msg, 8, 32)
}

export interface BootstrapDeps {
  gameShell?: GameShell
  openPrivacySettings?: () => void
  /** soundfontSettled 后调:必要资源就绪(PROD 出「进入游戏」按钮;dev/无门 no-op)。 */
  onPlayable?: () => void
  /** bootstrap await 它:用户点进入 / 自动放行后 resolve(dev 预先 resolved → 不阻塞)。 */
  enterGate?: Promise<void>
}

export async function bootstrap(canvas: HTMLCanvasElement, deps?: BootstrapDeps): Promise<void> {
  // soundfont 是启动期最大单体(当前 TimGM6mb ~6MB;曾是 32MB GeneralUser GS),提前到 boot
  // 阶段与其余资源并行下载(main.ts 已包 fetch → 计入 loading 进度),数据到手才放行视频/菜单
  // (下方 await soundfontSettled)。不等它的话覆盖层收掉后它仍在后台占满带宽(生产
  // pal.illegalscreed.cn 实测 ~440KB/s,32MB 时代要 ~74s):3.mp4 流卡顿、loadScene 黑屏拉长、
  // BGM 等到 AVI 中途才响(2026-06-12 user 报)。失败不挡启动:audio-midi 回退自取,最终 BGM 静默 + warn。
  const initialMusicSource = readMusicSource()
  const { soundfontData, soundfontSettled, resourcesReady } = startBootstrapResourceLoad(
    SCENE_ID,
    undefined,
    initialMusicSource === 'midi',
  )
  // M4 P4.T3: loadGlyphs 与 loadAll 并行加载(glyphs.json 7.8MB,不阻塞 tiles/sprites)。
  // glyphs 加载失败则 warn + 继续(所有文字退化为 tofu 占位,不影响游戏可运行性)。
  // M5 Sync.2: dialog 资产(portrait RGM 92 + DATA chunk 12 icon sprite group)并行加载。
  const [{ assets, glyphs, dialogAssets }, englishPack] = await Promise.all([
    resourcesReady,
    loadEnglishLanguage().catch(() => undefined),
  ])
  setEnglishWordTable(englishPack?.words ?? {})
  setEnglishMessages(englishPack?.groups ?? [])
  setEnglishLayout(englishPack?.layout ?? {})
  if (!englishPack) useFallbackLanguage('zh-CN')

  const {
    tilemap,
    palette,
    scene,
    events,
    playerRoles,
    tileImages,
    characterSprites,
    battleSprites,
    battleBgs,
    enemies,
    enemyObjects,
    enemyTeams,
    battleFields,
    enemyPos,
    battleEffectIndex,
    items,
    spells,
    magics,
    objectMagics,
    objectPoisons,
    objectPlayers,
    stores,
    words,
  } = assets

  // W3 C1/C2:注入 WORD.DAT 词表(words.json flat[]),getWord(id) 取菜单文案(单一文案源,替代各处硬编码)。
  setWordTable(words)

  // M5.6 W0.b:注入大世界 menu catalogs(items / spells / playerRoles),
  // menu-driver 内 dispatchInGameMenu 在 Confirm 时调 createInventoryMenu / createInGameMagicMenu 等需要。
  setMenuCatalogs({ items, spells, magics, playerRoles })

  // 队伍 sprite 兜底帧 —— 启动时用 role0,后续 presentFrame 会按 gs.partyMembers[0] 的
  // runtime rgwSpriteNum 切到实际队长。role0 只作为旧资源兜底。
  const leader = playerRoles.roles[0]
  if (!leader) throw new Error('bootstrap: playerRoles.roles[0] missing')
  const partyLeaderSpriteId = leader.spriteNum

  // P0.e: party 起始位置改由首屏 scene wScriptOnEnter 脚本设(setPartyPos opcode 真生效)。
  // 初始值 (0,0,down) 只是占位;loadScene / runEnterScript 会覆盖到真实原版位置。
  const gs = createInitialGameState({ x: 0, y: 0, facing: 'down' as const })
  // sdlpal global.c::PAL_NewGame 真值:wMaxPartyMemberIndex=0 + rgParty[0].wPlayerRole=0(主角)。
  // 不设 partyMembers 则撞怪进战斗 createBattleState 构 0 player → 立刻 phase='lost' 闪退。
  gs.partyMembers = [0]
  // sdlpal wNumScene 是 1-based,scenes[wNumScene-1] 才是真 scene。dump 文件 scene/N.json 对应
  // scenes[N](0-based),所以 wNumScene = SCENE_ID + 1。loadScene opcode 真做时(callback)会写新值。
  gs.wNumScene = SCENE_ID + 1
  // 特效 A(2026-05-29):种子调色板。
  //   gs.palette = 可变工作副本(makeWorkingPalette 深拷 colors;fade 引擎每帧原地 ramp 它,不污染源)。
  //   gs.basePalette = pristine 场景色(fade target / snapshot 参照;始终与 gs.palette 不同对象)。
  // 与旧行为等价:flushToCanvas 之前用 `gs.palette ?? palette`,现 gs.palette 已是 palette 深拷 → 同色。
  gs.palette = makeWorkingPalette(palette)
  gs.basePalette = palette

  const segment = events.segments[0]
  if (!segment) throw new Error('events.json 无 segment[0]')
  const eventCommands = segment.commands
  const labelMap = buildLabelMap(eventCommands)

  // scene-level commands + label map(autoScript runner 用)
  gs.sceneCommands = eventCommands
  gs.sceneLabelMap = labelMap

  // 忠实 sdlpal lprgEventObject:一次性加载全局 event object 表 → gs.allEventObjects + 区间。
  // gs.npcs = 当前 scene 切片(引用全局元素 → 脚本改动持久,重进保留:李大娘走了不复现)。
  // H1:保存初始 raw 表 — 通关后重开新游戏时 resetSceneRuntimeForNewGame 据此重建(断开上一局脚本改动)。
  let initialEventObjects: SceneEventObject[] = []
  try {
    const eoRes = await fetch('/extracted/data/event-objects.json')
    if (eoRes.ok) {
      const eoFile = (await eoRes.json()) as EventObjectsFile
      initialEventObjects = eoFile.eventObjects
      // 全局数组建表时不传 labelMap(autoCursor 留切片时按各 scene labelMap 延迟解)。
      gs.allEventObjects = eoFile.eventObjects.map((eo) => npcFromEventObject(eo))
      gs.sceneEventRanges = eoFile.sceneRanges
    } else {
      console.warn(
        `[bootstrap] event-objects.json fetch failed (${eoRes.status}),NPC 状态退化为非持久`,
      )
    }
  } catch (err) {
    console.warn('[bootstrap] event-objects.json 加载失败,NPC 状态退化为非持久:', err)
  }
  // 切当前 scene 视图;全局表缺失则兜底从 scene dump 建(传 labelMap 立即解 autoCursor)。
  gs.npcs =
    sliceSceneEventObjects(gs, gs.wNumScene) ??
    scene.eventObjects.map((eo) => npcFromEventObject(eo, labelMap))
  supplySupplementalSceneObjects(gs, scene.eventObjects)
  hydrateNpcStaticDefaults(gs.npcs, scene.eventObjects)

  // M5.6 T17:onEnter 启动改由 startNewGameFromPrimary helper 触发,
  // OpeningMenu 选 new-game / ?skip-intro=1 路径都调它。
  // (helper 定义在下面 setStartGameHandler 之前;此处仅保留注释占位。)
  // skipIntro 行为见 ?skip-intro=1 路径分支(SCENE_ID=1 + runEnterScript 同步只取 setPartyPos)。
  // 正常启动:OpeningMenu选new-game → playOpeningAvi(Win95播3.mp4,DOS直接返回) → 装载完整
  // onEnter(对话由 tickEventSystem 步进)。

  // sprite 装配 — sdlpal `scene.c:750-755`:站立帧 = wDirection * walkFrames,
  // WIN95 party sprite 默认 12 帧 = 4 方向 × 3 帧(walkFrames 默认 3)。
  // 这里把所有 frame 都装成 SpriteImage 数组,presentFrame 按 facing 取站立帧。
  const partyData = characterSprites.get(partyLeaderSpriteId)
  if (!partyData) throw new Error(`队长 sprite (id ${partyLeaderSpriteId}) 加载失败`)
  if (partyData.frames.length === 0) throw new Error('队长 sprite 无 frame')
  // 逐帧 anchor(sdlpal scene.c:224/358 PAL_RLEGetWidth/Height 用当前帧)— 见 toSpriteImages。
  const partyFrames = toSpriteImages(partyData.frames)
  // ctx 兜底 walkFrames = 3(sdlpal scene.c:752 `if (i == 0) i = 3` 默认)。真值按 per-role 查:
  // present.getPartyWalkFrames 优先 runtime rgwWalkFrames[role] → playerRoles.walkFrames[role],
  // 都缺才回落本值。
  const partyWalkFrames = 3
  type NpcSprite = (typeof partyFrames)[number]
  const npcSprites = new Map<number, NpcSprite>()
  // Sync.2 fix3 pose:per-spriteId 全帧数组,opcode 0x0014/0x0016/0x000F 写 npc.scriptedFrame 用。
  const npcSpriteFrames = new Map<number, NpcSprite[]>()
  for (const [id, data] of characterSprites) {
    const allFrames: NpcSprite[] = toSpriteImages(data.frames)
    npcSpriteFrames.set(id, allFrames)
    if (allFrames[0]) npcSprites.set(id, allFrames[0])
  }

  // sdlpal res.c:295-298:kLoadScene 时把"装载好的精灵总帧数"回填进 EventObject.nSpriteFramesAuto
  // (PAL_NPCWalkOneStep 对 nSpriteFrames==0 的对象用它取模推帧 — 血池冒泡/血柱等氛围动画)。
  // 注入查询器后,hydrateNpcStaticDefaults(三条装载路径都会调)即可回填;初始 scene 的 gs.npcs
  // 在 map 装配前已建好 → 这里补跑一次(幂等,scene dump 与 gs.npcs 都在闭包内)。
  setSpriteFrameCountProvider((spriteNum) => npcSpriteFrames.get(spriteNum)?.length)
  hydrateNpcStaticDefaults(gs.npcs, scene.eventObjects)

  const fb = createFramebuffer()
  const canvasCtx = canvas.getContext('2d')
  if (!canvasCtx) throw new Error('canvas 2d context 不可用')

  // T17:per-scene tileImages 路由 —— 不动 SceneAssets schema,closure only。
  // 首屏 scene 的 tile bitmap 进 by-sceneId map;dev jump 时 sceneFetcher 内补 fetch
  // 新 scene 的 tile PNG(cache hit 跳过),applySceneAssetsToPresent mutate currentSceneId,
  // presentCtx.tileImages.get 自动路由到对应 scene 的 map。
  const tileImagesBySceneId = new Map<number, Map<number, IndexedImage>>()
  tileImagesBySceneId.set(SCENE_ID, tileImages)
  let currentSceneId = SCENE_ID
  let mapReloadRevision = 0
  let currentSceneAssets: SceneAssets | undefined

  const presentCtx: PresentContext = {
    tilemap,
    tileImages: { get: (i) => tileImagesBySceneId.get(currentSceneId)?.get(i) },
    partyFrames,
    partyWalkFrames,
    npcSprites,
    npcSpriteFrames,
    glyphs,
    dialogAssets,
    uiSpriteFrames: assets.uiSpriteFrames,
    // M5.6 T17:OpeningMenu 背景 — sdlpal `MAINMENU_BACKGROUND_FBPNUM (fIsWIN95?2:60)`,
    // 我们 WIN95 data 走 chunk 2;M4 P2.T4 已 dump 进 battleBgs map(key=2)。
    openingMenuBg: assets.battleBgs.get(2),
    // M5.6 T10b:BALL 物品图标(audit 第 1 漏洞已修)— InventoryMenu / Equip / 商店用。
    itemIcons: assets.itemIcons,
    items: assets.items,
    // M5.6 T10d:PlayerStatus 全屏背景 — sdlpal `STATUS_BACKGROUND_FBPNUM = 0`(ui.h:83)。
    // FBP chunk 0 → battleBgs.get(0)(M4 P2.T4 已 dump)。
    statusBg: assets.battleBgs.get(0),
    // PlayerStatus 渲染读 stat / equipment / avatar(rgwAvatar→portrait chunk index)。
    playerRoles: assets.playerRoles,
    // C6:PlayerStatus 毒 row(uigame.c:1245-1253)— object-poisons.json id→{level,color}。
    objectPoisons: new Map(objectPoisons.map((p) => [p.id, { level: p.level, color: p.color }])),
    // PlayerStatus 显示 RoleNextExp 用 LevelUpExp[level] 阈值(DATA.MKF chunk 14)。
    levelUpExp: assets.levelUpExp,
    // C5(2026-05-28):EquipItemMenu 全屏背景 — sdlpal `EQUIPMENU_BACKGROUND_FBPNUM = 1`(ui.h:118)。
    equipBg: assets.battleBgs.get(1),
    // C7(2026-05-29):InGameMagicMenu 渲染需 spells / magics catalog。
    spells: assets.spells,
    magics: assets.magics,
  }

  // M3 T28/T29:战斗一帧装配 —— BattlePresent 持有 floating nums 跨帧状态;
  // BattleAssets 注入资源表(sprites/bgs/items/spells/playerRoles)。
  const battlePresent = new BattlePresent()
  const battleAssets: BattleAssets = {
    battleSprites,
    battleBgs,
    playerRoles,
    spells,
    items,
    enemyPos,
    glyphs,
    uiSpriteFrames: assets.uiSpriteFrames, // D17b:伤害数字弹幕用 UI sprite 数字帧
    itemIcons: assets.itemIcons, // itemmenu.c:战斗使用/投掷菜单选中物品的 BALL 图标
    effectSprite: assets.effectSprite, // D17a:物理攻击命中特效 overlay sprite(chunk 10)
    magicSprites: assets.magicSprites, // D17:法术 FIRE.MKF sprite overlay(chunk = magic.effect)
    dialogAssets, // 战斗内对话(scriptOnReady/scriptOnTurnStart showDialog)复用大世界 portrait/icon 渲染
    // 毒头像染色表(PAL_PlayerInfoBox 中毒/死亡 mono 重染,uibattle.c:114-162)。
    objectPoisons: new Map(objectPoisons.map((p) => [p.id, { level: p.level, color: p.color }])),
  }

  // D17:FIRE.MKF magic sprite 帧数 Map(chunk → frameCount)— performMagic OffMagic 时间线取 n。
  const magicSpriteFrameCounts = new Map<number, number>()
  for (const [chunk, sprite] of assets.magicSprites) {
    magicSpriteFrameCounts.set(chunk, sprite.frames.length)
  }

  // 召唤神精灵帧数 Map(F.MKF chunk = magic.special+10 → frameCount)— performMagic 召唤动画取逐帧 loop 帧数。
  //   召唤神精灵存于 battleSprites 'player-{chunk}'(F.MKF dump-all,chunk 10..18 = 9 个召唤神)。
  const summonSpriteFrameCounts = new Map<number, number>()
  for (const [key, sprite] of battleSprites) {
    const m = /^player-(\d+)$/.exec(key)
    if (m) summonSpriteFrameCounts.set(Number(m[1]), sprite.frames.length)
  }

  // M8:敌方混乱攻击火花 Y 需 PAL_RLEGetHeight(frame0)(fight.c:4614),从预载 ABC.MKF frame0 取。
  const enemySpriteFrameHeights = new Map<number, number>()
  const enemySpriteFrameWidths = new Map<number, number>()
  for (const [key, sprite] of battleSprites) {
    const m = /^enemy-(\d+)$/.exec(key)
    const first = sprite.frames[0]
    if (m && first) {
      enemySpriteFrameHeights.set(Number(m[1]), first.height)
      enemySpriteFrameWidths.set(Number(m[1]), first.width)
    }
  }

  const bus = createCommandBus()
  const input = new KeyboardInputSource(window)
  // M6 音频:shell 层 Web Audio。core 发意图(gs.pendingSounds SFX 队列 / gs.wNumMusic BGM),
  //   每帧 onPresent 调 audio.sync 消费。首个 keydown resume AudioContext(浏览器 autoplay policy)。
  const audio = createAudioManager('/extracted')
  // BGM 后端:SpessaSynth 运行时 MIDI 合成(直接播 Musics/{NNN}.mid,开箱即响)。
  //   public/soundfont.sf3提供GM音色；加载失败由音源控制器发布错误状态，见audio-midi.ts。
  //   worklet与已安装依赖的dist保持字节一致，供应者许可证随public产物保留。
  const musicSource = createMusicSourceController(
    (source) =>
      source === 'rix'
        ? createRixBackend('/extracted')
        : createSpessaSynthBackend({
            baseUrl: '/extracted',
            workletUrl: '/spessasynth_processor.min.js',
            soundfontUrl: '/soundfont.sf3',
            soundfontData: initialMusicSource === 'midi' ? soundfontData : undefined,
          }),
    initialMusicSource,
  )
  audio.setMusicBackend(musicSource)
  const fetchMgoSprite = (id: number): Promise<IndexedImage[]> =>
    loadSpriteFramesBlob(`${BASE}/data/sprite/${id}.rle`)
  const { playDosOpening, playDosEnding } = createDosCutscenes({
    fb,
    canvasCtx,
    palette,
    battleBgs,
    characterSprites,
    fetchMgoSprite,
    getScreenPalette: () => gs.palette ?? palette,
    setMusic: (track) => {
      gs.wNumMusic = track
      syncShellAudio(audio, gs, [], playerRoles)
    },
  })

  // autoplay 解锁:浏览器要求 AudioContext 在用户手势后 resume。**不能用 { once:true } 只听首个
  //   keydown** —— 若首个手势是鼠标点击(如点 devpanel 触发战斗/BGM)keydown 不触发,ctx 永久挂起
  //   → BGM/SFX 全哑(user 2026-06-03 实测控制台 "AudioContext was not allowed to start")。改:
  //   keydown + pointerdown 都听、**持续触发**(audio.resume 内部 + backend.resume 都有 suspended 守卫,
  //   解锁后重复调是 no-op,不会重启 BGM)。
  const unlockAudio = (): void => audio.resume()
  window.addEventListener('keydown', unlockAudio, { capture: true })
  window.addEventListener('pointerdown', unlockAudio, { capture: true })

  // SW 预缓存让路:跟踪 suspendRaf 变化(下方 onPresent 据此 pause/resume 预缓存)。
  let _lastSuspendForPrecache = false
  let pendingSaveSceneLoads = 0
  const loopCtx: LoopContext = {
    gs,
    bus,
    input,
    tilemap,
    partyWalkFrames,
    isRestoringSave: () => pendingSaveSceneLoads > 0,
    onPresent: (drained, ticked) => {
      // 音频同步必须在 suspendRaf gate 前跑:山神庙传剑等 modal CG/RNG 播放期间仍会有脚本
      // 设置 BGM/SFX。只暂停 canvas present,不能暂停 audio drain,否则声音会等 CG 结束后才一起触发。
      syncShellAudio(audio, gs, drained, playerRoles)
      // SW 预缓存让路:modal(开场视频/CG/RNG/FBP/结局动画 suspendRaf)独占期间暂停预缓存,不抢视频
      // Range 请求 / 用户输入的带宽 IO(否则点击「进入游戏」/ 空格跳过视频后延迟很大,2026-06-15)。
      // dev 无 SW → pause/resume no-op。加载页(虚线后)raf 未起,此处不跑 → SW 全速,竞速可等满。
      const suspendForPrecache = !!gs.suspendRaf
      if (suspendForPrecache !== _lastSuspendForPrecache) {
        _lastSuspendForPrecache = suspendForPrecache
        if (suspendForPrecache) pausePrecache()
        else resumePrecache()
      }
      // suspendRaf 期间:modal 播放器(AVI / trademark / splash / RNG / FBP / 结局动画)**独占** canvas,
      // 自管 fb + flushToCanvas。主循环这里**完全不碰 canvas** —— 否则下面的 flushToCanvas 会用 gs.palette
      // (场景调色板)重刷 fb,跟 modal 播放器的 flush(各自 palette)互抢 → 画面在两套色表间闪烁
      //(2026-05-29 user 从 devpanel 触发开场 DOS 时发现"正常↔偏红"闪烁;开机时 raf 还没起所以不显)。
      if (gs.suspendRaf) return
      // 按 gs.mode 路由 present:battle → presentBattleFrame(消费 commands 进 floating nums);
      // 否则走 explore/event 路径 presentFrame(commands 由 M2 EventSystem 直接消费 GameState)
      if (!presentBattleFrame(fb, gs, battlePresent, battleAssets, drained, ticked)) {
        presentFrame(fb, gs, presentCtx, ticked)
      }
      // M4 P3.T2: gs.palette 由 setPalette opcode handler 异步写入;优先用它,否则 fallback 到初始 palette。
      // dialog 等键时,applyDialogIconPaletteShift 套瞬态 palette 轮转(sdlpal text.c:1408-1426 箭头闪烁)。
      flushToCanvas(fb, canvasCtx, applyDialogIconPaletteShift(gs, gs.palette ?? palette))
    },
  }

  // 按scene懒载scene/events/tilemap,并行补该场景的tileset RLE blob与缺失sprite RLE blob。
  // tileImagesBySceneId随SceneAssetsCache淘汰;NPC帧存closure map,由presentCtx共享。
  // SceneAssets.palette当前复用启动palette,不是按scene另取;屏幕色表由palette/fade脚本管理。
  const BASE = '/extracted'

  async function fetchMissingSprite(id: number): Promise<void> {
    if (npcSprites.has(id)) return
    try {
      // NPC 资源管线优化:每 sprite 一个 gzip RLE blob(取代 sprite-{id}.json + per-frame PNG)。
      const frames = await loadSpriteFramesBlob(`${BASE}/data/sprite/${id}.rle`)
      if (!frames[0]) return
      // Sync.2 fix3 pose:存全帧 + frame 0。逐帧 anchor(爬行 chunk193 各帧高度 31~73 不等,
      // 必须每帧用自身高度,否则高帧脚底下溢 = 密道攀爬偏下 bug)— 见 toSpriteImages。
      const allFrames: NpcSprite[] = toSpriteImages(frames)
      npcSpriteFrames.set(id, allFrames)
      npcSprites.set(id, allFrames[0]!)
    } catch (err) {
      console.warn(`[bootstrap] scene-jump sprite ${id} fetch failed, skip:`, err)
    }
  }

  async function ensurePlayerSpritesLoaded(): Promise<void> {
    const ids = new Set<number>()
    for (const roleId of gs.partyMembers) {
      const spriteId = getOverworldSpriteNum(gs, roleId, playerRoles)
      if (spriteId && spriteId > 0 && !npcSpriteFrames.has(spriteId)) ids.add(spriteId)
    }
    if (ids.size > 0) await Promise.all([...ids].map((id) => fetchMissingSprite(id)))
  }

  // 按需补 fetch 新 scene 的 tileset blob → 写进 tileImagesBySceneId(同 sceneId cache hit 跳过)。
  // tileset 资源管线优化(2026-06-22):每地图一个 gzip RLE blob,fetch 一次解压解码成 Map。
  async function fetchSceneTileImages(sceneId: number, tilemapJson: Tilemap): Promise<void> {
    if (tileImagesBySceneId.has(sceneId)) return
    const map = await loadTilesetBlob(`${BASE}/data/${tilemapJson.tileset}`)
    tileImagesBySceneId.set(sceneId, map)
  }

  const sceneFetcher: SceneFetcher = async (sceneId: number): Promise<SceneAssets> => {
    const padded = sceneId.toString().padStart(3, '0')
    // M4 P3.T3: scene→mapNum→tilemap 链:先 fetch scene JSON 拿到 mapNum,再 fetch tilemap by mapNum。
    const sceneJson = await fetch(`${BASE}/data/scene/${sceneId}.json`).then((r) => {
      if (!r.ok) throw new Error(`scene-${sceneId}.json fetch failed (${r.status})`)
      return r.json() as Promise<{
        mapNum: number
        eventObjects: SceneEventObject[]
        onEnterLabel?: string
        onTeleportLabel?: string
      }>
    })
    const mapNum = gs.sceneMapNumOverride?.[sceneId + 1] ?? sceneJson.mapNum
    const [tilemapJson, eventsJson] = await Promise.all([
      fetch(`${BASE}/data/tilemap/${mapNum}.json`).then((r) => {
        if (!r.ok) throw new Error(`tilemap-${mapNum}.json fetch failed (${r.status})`)
        return r.json() as Promise<Tilemap>
      }),
      // P3.T1: per-scene events(lazy load,修 M3.5 ⚠️ a9 #8)
      fetch(`${BASE}/events/scene-${padded}.json`).then((r) => {
        if (!r.ok) throw new Error(`events/scene-${padded}.json fetch failed (${r.status})`)
        return r.json() as Promise<EventFile>
      }),
    ])

    // P3.T1: 把所有 segment 的 commands 展平成单数组,保持与 buildLabelMap 的约定一致。
    const eventCommands = eventsJson.segments.flatMap((seg) => seg.commands)
    const sceneLabelMap = buildLabelMap(eventCommands)

    // 新 scene NPC sprite 补 fetch(已有的跳过)。fetch 之后写进 closure 的 npcSprites,
    // applySceneAssetsToPresent 里 presentCtx.npcSprites 是同一个引用,无需二次 mutate。
    const newSpriteIds = new Set<number>()
    for (const eo of sceneJson.eventObjects) {
      if (eo.spriteNum > 0) newSpriteIds.add(eo.spriteNum)
    }
    // tile PNG 与 sprite 并行 fetch — tileImages 切换在 applySceneAssetsToPresent
    // 通过 currentSceneId 路由(写进 closure 的 tileImagesBySceneId)。
    await Promise.all([
      ...[...newSpriteIds].map((id) => fetchMissingSprite(id)),
      fetchSceneTileImages(sceneId, tilemapJson),
    ])

    // loadScene 当前不读取 SceneAssets.npcSprites;present 使用 closure 中共享的
    // npcSprites map。此处空 map 仅满足现有接口,不承担精灵缓存的所有权。
    return {
      sceneId,
      mapNum, // 场景名按 mapNum 命名(tools/map-names) + scene-system.getCurrentMapNum
      tilemap: tilemapJson,
      palette,
      eventObjects: sceneJson.eventObjects,
      npcSprites: new Map<number, SpriteAsset>(),
      eventCommands,
      labelMap: sceneLabelMap,
      // P0.e: 透传 wScriptOnEnter label → loadScene 跑 enter script 设 party 起点
      onEnterLabel: sceneJson.onEnterLabel,
      // 0x38 归隐脱出:透传 wScriptOnTeleport label → loadSceneCommon 解析缓存 gs.sceneOnTeleportEntry
      onTeleportLabel: sceneJson.onTeleportLabel,
    }
  }
  // LRU 上限:保留最近 N 个 scene 的资源(SceneAssets 元数据 + 联动的解码 tile 位图)。
  // 全 223 scene 的 tile 位图解码后常驻可达 ~100MB(每 scene ~450 tile × ~1KB);保留最近 16 个
  //(≈ 来回横跳的活动范围)平衡内存与重访 re-fetch 成本。淘汰联动:onEvict 同步释放
  // tileImagesBySceneId 对应条目 —— 必须一致,否则 SceneAssets 命中会跳过 sceneFetcher 内的
  // fetchSceneTileImages → tileImages 缺失 → 黑屏无 tile。protect=currentSceneId 保证正在渲染的
  // 场景即使在 LRU 端也永不被淘汰。
  const MAX_SCENE_CACHE = 16
  const sceneAssetsCache = new SceneAssetsCache(sceneFetcher, {
    maxEntries: MAX_SCENE_CACHE,
    onEvict: (sceneId) => {
      tileImagesBySceneId.delete(sceneId)
    },
    protect: () => currentSceneId,
  })

  /**
   * T17 重做核心:scene 切换后同步 presentCtx + scene-system 的 tilemap 引用。
   * 不调这个,loadScene 改了 gs.npcs/party/camera 但 canvas 仍画首屏 tilemap。
   *
   * 1. presentCtx.tilemap = 新 tilemap(下一帧 drawTilemap 取新 cells)
   * 2. currentSceneId 切到新 scene:presentCtx.tileImages.get 自动路由到对应 scene 的
   *    tile bitmap map(sceneFetcher 已 fetch 进 tileImagesBySceneId)。
   * 3. setSceneContext 重置:scene-system tick 用新 tilemap.width/height 做 walkability + camera clamp
   * 4. npcSprites:closure 同一引用,sceneFetcher 里已补 fetch missing sprite,无需再动
   * 5. 只发布探索地图；脚本由全局目录解析，basePalette由loadSceneCommon更新
   */
  function applySceneAssetsToPresent(sceneAssets: SceneAssets): void {
    mapReloadRevision++ // Any scene activation retires earlier map-only publications, including same-scene reloads.
    currentSceneAssets = sceneAssets
    presentCtx.tilemap = sceneAssets.tilemap
    currentSceneId = sceneAssets.sceneId
    // 资源就绪后同步探索地图；脚本目录不在此重复保存。
    setSceneContext({
      tilemap: sceneAssets.tilemap,
    })
  }

  const renderSceneThumbnail = createSceneThumbnailRenderer(palette)

  // 扫新 scene eventCommands 的 setPlayerSprite(opcode 0x65)预 fetch cutscene sprite group。
  async function preloadCutsceneSprites(commands: Command[]): Promise<void> {
    const ids = new Set<number>()
    for (const cmd of commands) {
      if (cmd.op === 'raw' && cmd.opcode === 0x0065) {
        const spriteId = cmd.operands[1] ?? 0
        if (spriteId > 0 && !npcSpriteFrames.has(spriteId)) ids.add(spriteId)
      }
    }
    if (ids.size > 0) {
      console.log(`[bootstrap] preloading ${ids.size} cutscene party sprite(s):`, [...ids])
      await Promise.all([...ids].map((id) => fetchMissingSprite(id)))
    }
  }

  // loadScene opcode (0x0059) callback:fetch 新 scene assets → 重置 gs.npcs + setSceneContext +
  // applySceneAssetsToPresent + 预 fetch 新 scene cutscene sprites + 写 gs.eventCursor 到新 scene
  // onEnterLabel ip → 释放 waiting='scene-load'。
  // 注:cmd.sceneId 是 sdlpal wNumScene 值(1-based,scenes[wNumScene-1] 才是真 scene),
  //     我们 dump 文件 scene/N.json 是 0-based(对应 scenes[N]),所以 dumpFileIndex = wNumScene - 1。
  /**
   * 公共 scene reload helper。
   * - opcode 0x59 loadScene 走 `fromSavedGame=false`:重置 npcs(从 scene dump)+ 跑 onEnter
   * - C8 SystemMenu Load 走 `fromSavedGame=true`:**保留** SAVEDGAME 内 npcs / mode / eventCursor,
   *   只 fetch scene assets + apply present(不跑 onEnter,玩家保存时未必在 onEnter)
   */
  async function loadSceneCommon(
    newWNumScene: number,
    opts: { fromSavedGame: boolean } = { fromSavedGame: false },
  ): Promise<void> {
    const dumpFileIndex = newWNumScene - 1
    // P2#7:async 加载窗口起手设 sceneLoading=true(loadScene opcode 已设过,这里覆盖初始 / skip-intro /
    // loadGame 路径)→ present 保留旧帧(供 fadeScreen backup)。冻到 onEnter 第一个可渲染 yield 才清。
    gs.sceneLoading = true
    const sceneAssets = await sceneAssetsCache.loadScene(dumpFileIndex)
    const requestedMap = gs.sceneMapNumOverride?.[newWNumScene]
    if (requestedMap !== undefined && requestedMap !== sceneAssets.mapNum) {
      const replacement = await fetchMapResources(requestedMap)
      sceneAssets.mapNum = requestedMap
      sceneAssets.tilemap = replacement.tilemap
      tileImagesBySceneId.set(dumpFileIndex, replacement.tiles)
    }
    gs.wNumScene = newWNumScene
    setCurrentMapNum(sceneAssets.mapNum) // 同步当前 mapNum:小地图底图 / 地图名 / 历史对话按 map 分组都读它(此前仅 scene-system.loadScene 设,opcode/读档路径漏设→停 0 梦境)
    // DM25:res.c:236-240 `if (fEnteringScene) { wScreenWave = 0; sWaveProgression = 0; }` ——
    //   换场景(传送/0x59)即清屏波,上一场景的 0x71 常驻波不跨场景。读档(fromSavedGame)路径
    //   C 中 fEnteringScene=FALSE 不清(波从存档恢复),与此分支一致。
    if (!opts.fromSavedGame) {
      gs.partyCameraOffset = undefined // res.c:301 restores the default party anchor for the loaded scene.
      gs.wScreenWave = 0
      gs.sWaveProgression = 0
    }
    gs.gameOverActive = false // 死亡读档 → 新场景加载 → 清 game-over 演出标记(present 恢复正常渲染)
    gs.deathHoldActive = false // 同清过渡帧 hold(残留会冻住新场景渲染)
    // 0x38 归隐脱出:缓存当前场景 base onTeleport 全局 entry(onTeleportLabel L_<n>→n;无则 0)。
    //   sdlpal g.rgScene[wNumScene-1].wScriptOnTeleport;0x6D op2 override 优先。
    gs.sceneOnTeleportEntry = sceneAssets.onTeleportLabel
      ? (getGlobalLabelMap()[sceneAssets.onTeleportLabel] ?? 0)
      : 0
    // 新 scene 的 commands + labelMap 写入 gs(autoScript runner 用)
    gs.sceneCommands = sceneAssets.eventCommands
    gs.sceneLabelMap = sceneAssets.labelMap
    // 特效 A(2026-05-29):更新 basePalette = 场景调色板(fade target 参照;0x51 FadeIn / 0x93 SceneFade /
    //   0x8C ColorFade / 0x4F FadeToRed 据此算目标色)。pristine 引用,fade 不动它(gs.palette 才是工作副本)。
    //   gs.palette(屏幕)不在此重置 —— 仍由 onEnter 的 0x8B setPalette / fade opcode 管理(避免改既有行为)。
    gs.basePalette = sceneAssets.palette
    // opcode 0x6D 设的 onEnter 全局 override → 解析为本 scene local ip,写入 sceneOnEnterIp(消耗 override)。
    // override===0(清)→ -1 哨兵(下方 onEnter setup 视作"无 onEnter")。
    const oeOverride = gs.sceneOnEnterOverride?.[newWNumScene]
    if (oeOverride !== undefined) {
      delete gs.sceneOnEnterOverride![newWNumScene]
      // 0x6D override(operands[1])是绝对 script entry 号 = 全局数组下标(L_<n>→n 恒等,见 jumpToGlobalIp
      // event-system.ts:2220)。**直接用**,不查 `L_<n>` label —— 仅被 0x6D 引用的 entry(如香兰报信
      // cutscene entry 903)在反汇编里没打 label,查表必 →undefined→ -1 → onEnter 漏触发
      // (bug:码头对话讲传说 NPC 设 0x6D[5,903,0],重进 scene5 香兰应报"李大娘病了",旧码 L_903 不存在 → 不触发)。
      gs.sceneOnEnterIp[newWNumScene] = oeOverride === 0 ? -1 : oeOverride
    }
    if (!opts.fromSavedGame) {
      // 忠实全局 event object 数组(sdlpal lprgEventObject):gs.npcs = 当前 scene 切片
      //(引用 gs.allEventObjects 元素 → 脚本改动持久,重进保留)。
      // gs.sceneLabelMap 已在上面设为新 scene → 切片内 autoCursor 延迟解析用对的 labelMap。
      // 全局表缺失则兜底从 scene dump 建(退化为非持久)。
      gs.npcs =
        sliceSceneEventObjects(gs, newWNumScene) ??
        sceneAssets.eventObjects.map((eo) => npcFromEventObject(eo, sceneAssets.labelMap))
    } else {
      // C8 load game 路径:存档 JSON.stringify 会断开 gs.npcs 与 gs.allEventObjects 的引用。
      // 从加载回的 gs.allEventObjects 重切当前 scene → 重建引用(状态一致,后续脚本改动持久)。
      // 旧档无 allEventObjects → sliceSceneEventObjects 返 undefined → 保留存档内 gs.npcs。
      const reslice = sliceSceneEventObjects(gs, newWNumScene)
      if (reslice) gs.npcs = reslice
    }
    supplySupplementalSceneObjects(gs, sceneAssets.eventObjects)
    hydrateNpcStaticDefaults(gs.npcs, sceneAssets.eventObjects)
    applySceneAssetsToPresent(sceneAssets)
    await preloadCutsceneSprites(sceneAssets.eventCommands)
    await ensurePlayerSpritesLoaded()
    // P2#7:**不**在此清 sceneLoading(那样 onEnter 的 setPartyPos 还没跑,camera 在旧坐标 → 渲染
    // 出"其他地方坐标的场景"再跳。保持冻到 onEnter 的第一个可渲染 yield:fadeScreen(event-system 清)/
    // showDialog(event-system 清,content-no-fade 场景)/ onEnter-end(幂等清)。setPartyPos 是非等待
    // opcode,在那之前跑完 → camera 已对。no-onEnter 场景(下方 else)立即清。
    if (!opts.fromSavedGame) {
      // 正常 loadScene:跑 onEnter。入口优先级(sdlpal play.c:64 真值):
      //   sceneOnEnterIp(持久化:上次跑完存回 / 0x6D override 解析后,-1=无 onEnter)> onEnterLabel。
      // 重进已播过的 cutscene scene → 入口已被推进到 0x00 stop → 不重播(开场只播一次)。
      const persistedIp = gs.sceneOnEnterIp[newWNumScene] // P2#5:已是全局 ip
      const labelIp = sceneAssets.onEnterLabel
        ? getGlobalLabelMap()[sceneAssets.onEnterLabel] // P2#5:onEnterLabel = L_<global> → 全局 ip
        : undefined
      const ip = persistedIp ?? labelIp
      if (ip !== undefined && ip >= 0) {
        // ip === -1 = 0x6D 清的"无 onEnter"
        gs.eventCursor = {
          ip, // P2#5:全局 ip,默认读全局数组(不内嵌 commands/labelMap)
          onEnterSceneId: newWNumScene,
          onEnterStartIp: ip,
        }
        gs.mode = 'event'
        // P2#7:onEnter 冻屏中跑(setPartyPos 等定位 opcode),到第一个可渲染 yield 才清 sceneLoading 解冻:
        // fade-first onEnter → fadeScreen 清(camera 已对,present 从冻屏旧帧拷 backup 渐变到新场景);
        // content-no-fade onEnter → showDialog 清(对话正常显示,scene 14 修复)。
      } else {
        // 无 onEnter script(door 切换):无 fadeScreen/dialog 来解冻 → 立即清 sceneLoading 渲染新场景。
        gs.eventCursor = undefined
        gs.mode = 'explore'
        gs.sceneLoading = false
      }
    } else {
      // fromSavedGame:无 onEnter,assets 已应用 → 立即清渲染(SAVEDGAME 已恢复 party/mode)。
      gs.sceneLoading = false
    }
    // fromSavedGame:**不**跑 onEnter — SAVEDGAME 内 gs.mode / gs.eventCursor 已恢复
  }

  setSceneLoader(async (newWNumScene: number) => {
    await loadSceneCommon(newWNumScene, { fromSavedGame: false })
  })

  // Map-only replacement and a cached scene override share the same complete IO bundle.
  // Ownership/publication stays in their callers; rejection cannot mutate the live resources.
  async function fetchMapResources(mapNum: number) {
    const tilemapJson = await fetch(`${BASE}/data/tilemap/${mapNum}.json`).then((r) => {
      if (!r.ok) throw new Error(`tilemap-${mapNum}.json fetch failed (${r.status})`)
      return r.json() as Promise<Tilemap>
    })
    const tiles = await loadTilesetBlob(`${BASE}/data/${tilemapJson.tileset}`)
    return { tilemap: tilemapJson, tiles }
  }

  // opcode 0x99(changeMap)op0==0xFFFF:map-only 重载当前场景 tilemap(不重跑 onEnter / 不重置 npcs)。
  // 完整加载后同步发布；失败保留活资源。新请求或场景重装会撤销旧请求的发布权。
  setMapReloader(async (mapNum: number) => {
    const requestRevision = ++mapReloadRevision
    const sceneId = currentSceneId
    const replacement = await fetchMapResources(mapNum)
    if (requestRevision !== mapReloadRevision) return
    if (currentSceneAssets) {
      currentSceneAssets.mapNum = mapNum
      currentSceneAssets.tilemap = replacement.tilemap
    }
    tileImagesBySceneId.set(sceneId, replacement.tiles)
    presentCtx.tilemap = replacement.tilemap
    setSceneContext({ tilemap: replacement.tilemap })
    setCurrentMapNum(mapNum)
  })

  // 脚本队友走位和怪物追逐共用障碍检测。队友另外使用原盘地图边界。
  //   checkObjects=TRUE  → tilemap + 当前 scene event objects(排除自身 selfId)
  //   checkObjects=FALSE → 只查 tilemap(传空 npcs 数组)
  // isWalkable 返 TRUE=可走;PAL_CheckObstacle 返 TRUE=被阻挡 → 取反。
  setObstacleChecker(
    (x, y, checkObjects, selfId, checkRange) =>
      !isWalkable(presentCtx.tilemap, x, y, checkObjects ? gs.npcs : [], selfId, checkRange),
  )

  // M3 T29:dev panel(仅 DEV;生产构建 dead-code)。快捷键 B 弹 fixture picker → 启战。
  // M3.5 T16:加 sceneJumps,picker 内多一段 scene jump 列表(T17 接真 loadScene)。
  // T17 重做:onSceneChanged callback 注入 — dev jump 后 dev-panel 回调它,
  //          bootstrap 在回调里 mutate presentCtx 让 canvas 重画。
  // P4.T5: Font Test closure — 清 fb → renderText 渲染中英文混合 sheet → flushToCanvas。
  // 通用安全字符串:不含角色名/地名/具体物品名(版权)。
  // palette index 15:原版 BMP 调色板第 15 项通常为高亮白/淡色,足够文字可见。
  const FONT_TEST_LINES = [
    '0123456789 ABCDEFGHIJKLMNOP',
    'QRSTUVWXYZ abcdefghijklmnop',
    'qrstuvwxyz !@#$%^&*()-=+[]',
    '主菜单 物品 法术 装备 状态',
    '攻击 防御 法术 道具 逃跑',
    '生命 法力 等级 经验 金币',
    '回合 行动 防御 攻击 治疗',
  ]
  function onFontTest(): void {
    fb.clear()
    if (!glyphs) {
      console.warn('[font-test] glyphs 未加载,无法渲染 sheet')
      return
    }
    let y = 8
    for (const line of FONT_TEST_LINES) {
      renderText(fb, line, 4, y, 15, glyphs)
      y += 20
    }
    flushToCanvas(fb, canvasCtx!, gs.palette ?? palette)
    console.log('[font-test] sheet rendered — 按任意键退出 font test 恢复 raf loop')
    // M5.6 UX hotfix:user 怒怼'font test 一帧就没了' — 修法 suspendRaf=true 防下一帧覆盖,
    // 任意 keydown 退出 resume(once listener)。
    gs.suspendRaf = true
    const exitOnce = (): void => {
      gs.suspendRaf = false
      window.removeEventListener('keydown', exitOnce, true)
    }
    window.addEventListener('keydown', exitOnce, true)
  }

  setupDevPanel({
    gs,
    fixtures: battleFixtures,
    sceneJumps,
    // dev 场景名表(scene-names.json,人工补全)+ 场景缩略图渲染器(整 map → 96px dataURL,按 mapNum 缓存)。
    sceneNames,
    renderSceneThumbnail,
    // 队伍 tab 头像 + 物品作弊图标:RGM 头像帧(by role.avatar)/ BALL 物品图标(by item.bitmap)+ 主调色板上色。
    portraitFrames: dialogAssets.portraitFrames,
    itemIcons: assets.itemIcons,
    // 自定义战斗 / boss 入口敌人缩略图:战斗精灵 Map(key enemy-{id} / player-{chunk})。
    battleSprites,
    palette,
    sceneAssetsCache,
    onSceneChanged: applySceneAssetsToPresent,
    onFontTest,
    // devpanel 看开场/结局 AVI 双版:WIN95 走 mp4(1/2=开场,3=新游戏,4/5/6=结局)。
    //   传数组 → 顺序播(结局 WIN95 = 4→5→6,对应 PAL_EndingScreen AVI 序)。suspendRaf 包,播完恢复。
    playVideo: (mp4s) => {
      const list = Array.isArray(mp4s) ? mp4s : [mp4s]
      gs.suspendRaf = true
      void (async () => {
        for (const m of list) await playAvi({ src: `${BASE}/videos/${m}` })
      })()
        .catch((err) => {
          console.warn(`[dev] playVideo failed:`, err)
        })
        .finally(() => {
          gs.suspendRaf = false
        })
    },
    // 开场 DOS 版(trademark RNG chunk 6 + splash 卷轴):任何 build 下都能跑(资产已加载)。
    playDosOpening: () => {
      gs.suspendRaf = true
      void playDosOpening()
        .catch((err) => {
          console.warn('[dev] playDosOpening failed:', err)
        })
        .finally(() => {
          gs.suspendRaf = false
        })
    },
    // 结局 DOS 全片(PAL_EndingScreen DOS 编排:RNG + FadeOut/In + ShowFBP + ScrollFBP + ColorFade + EndingAnim)。
    playDosEnding: () => {
      gs.suspendRaf = true
      void playDosEnding()
        .catch((err) => {
          console.warn('[dev] playDosEnding failed:', err)
        })
        .finally(() => {
          gs.suspendRaf = false
        })
    },
    // devpanel 单播一段 RNG 演出:快照当前调色盘 → 设目标调色盘 → playRng(可按 Space/Enter/Esc 中止)
    //   → finally **恢复快照**(否则演出调色盘留在场景上整屏偏色;场景 palette 非 numbered,故按对象快照而非按编号复位)。
    //   不走事件系统 opcode 路径,纯 dev 预览;真机 0x37 仍不可跳、忠实。
    playRngCutscene: (chunk, palIdx, speed) => {
      const prev = {
        palette: gs.palette,
        basePalette: gs.basePalette,
        numPalette: gs.numPalette,
        nightPalette: gs.nightPalette,
      }
      const sp = speed > 0 ? speed : 16 // sdlpal iSpeed==0 → 16
      gs.suspendRaf = true
      void fetchPalette(palIdx)
        .then((pal) => {
          gs.numPalette = palIdx
          gs.basePalette = makeWorkingPalette(pal)
          gs.palette = makeWorkingPalette(pal)
          gs.iCurPlayingRNG = chunk
          return playRng({
            chunkIdx: chunk,
            startFrame: 0,
            endFrame: -1,
            frameDelayMs: 1000 / sp,
            fb,
            canvasCtx: canvasCtx!,
            palette: gs.palette,
            skipKeys: ['Space', 'Enter', 'Escape'], // dev 预览可中止(rng-player 设计的 dev 入口)
            shakeState: gs,
          })
        })
        .catch((err) => {
          console.warn('[dev] playRngCutscene failed:', err)
        })
        .finally(() => {
          gs.suspendRaf = false
          gs.palette = prev.palette
          gs.basePalette = prev.basePalette
          gs.numPalette = prev.numPalette
          gs.nightPalette = prev.nightPalette
        })
    },
    resources: {
      enemies,
      enemyObjects, // 对话:dev 战斗 enemy scriptOnReady/scriptOnTurnStart(boss 嘲讽)
      enemyTeams,
      battleFields,
      playerRoles,
      levelUpExp: assets.levelUpExp, // D11:dev 战斗胜利升级阈值
      levelUpMagic: assets.levelUpMagic, // D11:dev 战斗升级学法术
      items,
      spells,
      magics,
      objectMagics,
      objectPoisons,
      objectPlayers,
      commands: eventCommands,
      enemyPos, // D17a:dev 战斗也用真 EnemyPos 表(非 fallback)
      battleEffectIndex, // D17a:dev 战斗命中特效帧基号
      magicSpriteFrameCounts, // D17:dev 战斗 OffMagic 时间线 n
      summonSpriteFrameCounts, // 召唤神逐帧 loop 帧数
    },
  })

  // ── 生产工具面板 + 快存快读 + 音量/分辨率(非 DEV 门,生产保留;玩家便利,只读 + 安全动作)──
  // 音乐 / 音效 / 视频三路各自独立音量(各有音量键),但**共用同一静音键 tp-muted** —— 工具面板
  //   的「主静音」一键覆盖三路(setMuted 写同一键、保持一致);音量键独立,静音只叠加不改音量值。
  const audioVolume = createAudioVolumeController({
    applyVolume: (v) => {
      musicSource.setVolume?.(v)
    },
  })
  const sfxVolume = createAudioVolumeController({
    applyVolume: setSfxVolume,
    keyVol: 'tp-sfx-volume',
    keyMute: 'tp-muted',
  })
  // 视频(过场 mp4)音量:applyVolume → avi-player 模块级 setVideoVolume(静音 → 0)。
  const videoVolume = createAudioVolumeController({
    applyVolume: setVideoVolume,
    keyVol: 'tp-video-volume',
    keyMute: 'tp-muted',
  })
  const displayScale = createDisplayScaleController(canvas, deps?.gameShell)
  setupToolsPanel({
    languageAvailable: englishPack !== undefined,
    onOpenChange: (open) => deps?.gameShell?.setToolsOpen(open),
    openPrivacySettings: deps?.openPrivacySettings,
    getGs: () => gs,
    getResources: () => ({
      playerRoles,
      objectPoisons,
      items,
      enemyObjects,
      levelUpExp: assets.levelUpExp,
    }),
    displayScale,
    audioVolume,
    musicSource,
    sfxVolume,
    videoVolume,
    saveSlot: (slot, g) => Save.saveSlot(slot, g),
    loadSlot: (slot) => Save.loadSlot(slot),
    // 小地图输出宽640,与minimap BASE_PX一致;标准地图高也为640。
    // 显示缩放由minimap的DPR/裁剪决定;色表与seam边界仍以CODE57为准。
    getMapThumbnail: (mapNum) => renderSceneThumbnail(0, mapNum, 640),
  })
  deps?.gameShell?.connect(input)
  setupQuickSave({
    getGs: () => gs,
    saveSlot: (slot, g) => Save.saveSlot(slot, g),
    loadSlotIntoGame: async (slot) => {
      const loaded = await Save.loadSlot(slot)
      if (!loaded) return false
      await loadGameFromSlot(slot, loaded)
      return true
    },
  })
  setupSpeedrunHotkeys() // 启用计时器后:F8暂停/恢复,F4重置本局,F2切覆盖层

  // M3.5 T19:dev gate 暴露 GameState + assets 供 L2 Playwright helper 用 page.evaluate 探针。
  // 生产构建 dead-code(Vite tree-shake import.meta.env.DEV 分支)。
  // 用 dev-panel.ts 同模式 cast(避免依赖 vite/client triple-slash 类型)。
  if ((import.meta as unknown as { env?: { DEV?: boolean } }).env?.DEV) {
    ;(
      window as unknown as {
        __game: { gs: typeof gs; assets: typeof assets; presentCtx: typeof presentCtx }
      }
    ).__game = {
      gs,
      assets,
      presentCtx, // Sync.2 fix10:暴露 npcSpriteFrames 供 e2e verify cutscene sprite 加载
    }
  }

  // M4 P3.T2:注入 fetchPalette(类同 setSceneContext);setPalette 同步源未命中时的异步回退。
  setFetchPalette(fetchPalette)

  // 酒剑仙坐葫芦 RNG 偏色根因修复(2026-06-16):sdlpal PAL_GetPalette 从 pat.mkf **同步**读,
  //   0x8B setPalette 当帧即生效。我们的 fetchPalette 异步,纯 fire-and-forget 会让**同一同步 tick**
  //   内 setPalette→PlayRNG / FadeIn 读到尚未回填的旧 basePalette(scene-140:0x50 FadeOut → setPalette 2
  //   → SetRNG 3 → PlayRNG 全在一 tick 跑完 → RNG 淡入旧 palette 0 → 整段偏色)。
  //   开机把 PAT.MKF 全部调色板预载成同步 Map 注入 setPaletteSource,让 setPalette 同帧回填 basePalette,
  //   匹配 sdlpal 语义且**零时序改动**(仅 9 块、各 ≤22KB,初始 palette 0 本就要加载)。
  const PALETTE_COUNT = 9 // PAT.MKF 有效调色板 chunk 数(pal-extract dump palette/0..8;原版固定数据)
  const paletteCache = new Map<number, Palette>()
  await Promise.all(
    Array.from({ length: PALETTE_COUNT }, (_, id) =>
      fetchPalette(id)
        .then((p) => {
          paletteCache.set(id, p)
        })
        .catch((err: unknown) => {
          console.warn(`[bootstrap] preload palette ${id} failed:`, err)
        }),
    ),
  )
  setPaletteSource((id) => paletteCache.get(id))

  // P2#5(2026-05-29 单一全局脚本数组):events/all.json(= sdlpal 单一 lprgScriptEntry,L_<n>→n 恒等)
  // 是**唯一**脚本来源 — 所有 cursor 以全局 ip 索引它。必须在任何脚本(onEnter/trigger/skip-intro)跑前
  // **await 就绪**(不再 fire-and-forget,否则首个 onEnter 撞空数组)。per-scene / shared 切片已废弃。
  {
    const allRes = await fetch(`${BASE}/events/all.json`)
    if (!allRes.ok)
      throw new Error(`[bootstrap] all.json fetch failed (${allRes.status}) — 脚本系统无法运行`)
    const allJson = (await allRes.json()) as EventFile
    const allCommands = allJson.segments.flatMap((seg) => seg.commands)
    setGlobalEvents(allCommands)
    console.log(
      `[bootstrap] global script array loaded:${allCommands.length} commands(单一全局脚本数组)`,
    )
  }

  // 注入装备效果重建 handler — opcode 0x75 OP_SET_PARTY(队伍变动)用,对齐 sdlpal script.c:2196
  //   PAL_UpdateEquipments。闭包持 items 表;event-system 不污染 import equip-effect 的 items 依赖。
  setRefreshEquipmentsHandler((gs) => updateAllEquipments(gs, items))

  // P0.e: 注入 startBattle handler — opcode 7 (raw#7 / op:startBattle) 用。
  // 战斗资源闭包持引用,event-system 不污染 import battle/。
  // sdlpal play.c PAL_StartBattle 取 gpGlobals->wNumBattleField 作 battleFieldId,
  // 该字段由 wScriptOnEnter opcode 0x4A setBattlefield 写入(P0.e 新接)。
  setStartBattleHandler(({ gs, enemyTeamId, isBoss }) => {
    const battleFieldId = gs.wNumBattleField ?? 0
    try {
      startBattle({
        gs,
        enemyTeamId,
        battleFieldId,
        isBoss,
        enemies,
        enemyObjects,
        enemyTeams,
        battleFields,
        // 架构边界:用 runtime 当前属性(等级/HP/MP/攻防 等)投影战斗 roles,使战斗吃上升级后属性
        //   (原直接传 playerRoles 静态 1 级基线)。staticRoles=playerRoles 供不可变字段(精灵/音效/名字)。
        // D14:第 3 参 gs.rgEquipmentEffect → 战斗 stat = effective(base + 装备 + Extra),mirror sdlpal getter。
        playerRoles: projectRuntimeToBattleRoles(
          gs.PlayerRolesRuntime,
          playerRoles,
          gs.rgEquipmentEffect,
        ),
        items,
        spells,
        magics,
        objectMagics, // E2:0x42 SimulateMagic 解析 magic object id
        objectPoisons, // 0x28 apply poison
        objectPlayers, // OBJECT_PLAYER:队友死亡 / 濒死脚本
        enemyPos, // D17a:enemy 初始 pos/posOriginal(battle.c:936-939)
        battleEffectIndex, // D17a:player 攻击命中特效帧基号(fight.c:2055)
        magicSpriteFrameCounts, // D17:OffMagic 时间线 n(FIRE.MKF chunk 帧数)
        summonSpriteFrameCounts, // 召唤神逐帧 loop 帧数(F.MKF chunk 帧数)
        enemySpriteFrameHeights, // M8:enemy frame0 height(PAL_RLEGetHeight)
        enemySpriteFrameWidths,
        levelUpExp: assets.levelUpExp, // D11:战斗胜利升级阈值
        levelUpMagic: assets.levelUpMagic, // D11:升级学新法术
        // P2#5:不再传 per-scene 切片 — startBattle 默认 getGlobalCommands()(战斗脚本是全局 entry)。
        introFadeTicks: INTRO_FADE_TICKS, // D19:生产入场 dither fade-in(present-battle 揭示);单测/dev 不传
      })
    } catch (e) {
      console.error('[bootstrap.startBattleHandler] startBattle FAILED:', e)
      throw e
    }
    // dev gate:e2e observability。battle 可能瞬间 finalize 回 explore(空 partyMembers
    // 或资源缺失场景),mode 轮询 miss 不到 → 维持一个累积计数器供 a9 等 spec 断言"曾进过"。
    if ((import.meta as unknown as { env?: { DEV?: boolean } }).env?.DEV) {
      const w = window as unknown as {
        __battleStartCount?: number
        __lastBattleEnemyTeam?: number
        __lastBattleFieldId?: number
      }
      w.__battleStartCount = (w.__battleStartCount ?? 0) + 1
      w.__lastBattleEnemyTeam = enemyTeamId
      w.__lastBattleFieldId = battleFieldId
    }
  })

  // 商店买 / 卖菜单(opcode 0x0026 PAL_BuyMenu / 0x0027 PAL_SellMenu)。event-system 不能 import
  // menu 层,故 bootstrap 注入 handler:开对应 menu(buy 用 store[storeNum] 解析出 Item[])。
  // cursor.waiting='shop' 由 event-system 设;菜单关 → menu-mode resume 切 mode='event' 续跑脚本。
  setShopMenuHandler(({ gs, mode, storeNum }) => {
    if (mode === 'buy') {
      const store = stores[storeNum]
      const shopItems = (store?.items ?? [])
        .map((objId) => items.find((it) => it.id === objId))
        .filter((it): it is (typeof items)[number] => it != null)
      openMenu(gs, { kind: 'shop-buy', state: createBuyMenu(shopItems) })
    } else {
      openMenu(gs, { kind: 'shop-sell', state: createSellMenu(gs, items) })
    }
  })

  // opcode 0x0034(妖魔转化)用 store[0].rgwItems 索引发物品。注入完整 store 表。
  setStoreTable(stores)

  // 毒 OBJECT 表(0x29 apply-player 取 wPlayerScript / cure-by-level 取真 level)。
  setObjectPoisons(objectPoisons)

  // 静态敌人 OBJECT 表(0x90 SetObjectScript 新建 gs.rgObject overlay 时按 OBJECT_ENEMY 布局播种,
  //   battleEnd/ready/抗性不被零填充冲掉;startBattle 开战读 overlay → 刀手/胖苗对话 show-once 跨战斗)。
  setEnemyObjectsTable(enemyObjects)

  // 特效 C:RNG 动画 handler(opcode 0x37 PlayRNG)。event-system 设 cursor.waiting='rng-play' 后调本 handler;
  //   suspendRaf 期间 present 暂停、playRng 自管 fb 直写 + flushToCanvas;播完 finally 清 suspendRaf + waiting 续跑。
  //   speed→frameDelayMs = 1000/speed(sdlpal PAL_RNGPlay iDelay = 1/iSpeed 秒);palette 用当前工作 palette。
  setRngPlayHandler(({ gs, chunkIdx, startFrame, endFrame, speed, fadeIn }) => {
    gs.suspendRaf = true
    void playRng({
      chunkIdx,
      startFrame,
      endFrame,
      frameDelayMs: 1000 / speed,
      initialFadeInMs: fadeIn ? 600 : undefined,
      fb,
      canvasCtx: canvasCtx!,
      palette: gs.palette ?? palette,
      // sdlpal PAL_RNGPlay 每帧 VIDEO_UpdateScreen:0x35 震屏对视频施加 + 递减。
      //   suspendRaf 期间 presentFrame 不跑,不接则计数冻结、震屏泄漏进下一场景(血池演出狂抖)。
      shakeState: gs,
    })
      .catch((err) => {
        console.warn('[bootstrap.rngPlayHandler] playRng failed:', err)
      })
      .finally(() => {
        gs.suspendRaf = false
        if (gs.eventCursor?.waiting === 'rng-play') gs.eventCursor.waiting = undefined
        // 结局 RNG 演出对话(setDialogStyle arg2=op[2]!=0,仅 scene 281)期间 present 要恢复 RNG 动画画面
        //   而非重绘大世界 → 在此(RNG 播完,fb=最后一帧)备份,对齐 sdlpal PAL_StartDialog 的 fPlayingRNG
        //   分支 VIDEO_BackupScreen(text.c:1273)。非结局 RNG 也备份(无害:仅 gs.dialogPlayingRNG 时用,
        //   且 reset 会清);避免依赖"播完→对话"的脆弱帧序。
        gs.rngDialogBackup = new Uint8Array(fb.indices)
      })
  })

  // 特效 B:FBP 全屏图 handler(opcode 0x76 ShowFBP)。chunk 已提取为 battleBgs(FBP.MKF 全 dump);
  //   有图 → showFbp 真显(DOS 路径 + 可选 dither fade-in);无图(in-game 0xFFFF)→ 全黑(sdlpal 同)。
  //   suspendRaf 期间 showFbp 自管 fb + flushToCanvas;完成 finally 清 suspendRaf + waiting 续跑。
  setShowFbpHandler(({ gs, chunkIdx, fade }) => {
    gs.suspendRaf = true
    const bg = battleBgs.get(chunkIdx)
    void showFbp({
      fbpIndices: bg?.indices ?? new Uint8Array(320 * 200),
      fade,
      chunkNum: chunkIdx,
      isWin95: buildFlag === 'win95',
      fb,
      canvasCtx: canvasCtx!,
      palette: gs.palette ?? palette,
    })
      .catch((err) => {
        console.warn('[bootstrap.showFbpHandler] showFbp failed:', err)
      })
      .finally(() => {
        gs.suspendRaf = false
        if (gs.eventCursor?.waiting === 'show-fbp') gs.eventCursor.waiting = undefined
      })
  })

  // 特效 B:FBP 滚动卷入 handler(opcode 0xA4 ScrollFBP)。同 showFbp 模式,fScrollDown=TRUE(0xA4 真值)。
  setScrollFbpHandler(({ gs, chunkIdx, speed }) => {
    gs.suspendRaf = true
    const bg = battleBgs.get(chunkIdx)
    void scrollFbp({
      fbpIndices: bg?.indices ?? new Uint8Array(320 * 200),
      speed,
      fScrollDown: true,
      fb,
      canvasCtx: canvasCtx!,
      palette: gs.palette ?? palette,
    })
      .catch((err) => {
        console.warn('[bootstrap.scrollFbpHandler] scrollFbp failed:', err)
      })
      .finally(() => {
        gs.suspendRaf = false
        if (gs.eventCursor?.waiting === 'scroll-fbp') gs.eventCursor.waiting = undefined
      })
  })

  // 结局动画 handler(opcode 0x96 PAL_EndingAnimation)。fetch FBP 61/62(battleBgs)+ MGO 571/572 妖兽/女孩
  //   sprite(非预载,按需加载sprite/{id}.rle blob)→跑400帧cutscene。modal,suspendRaf。
  setEndingAnimationHandler(({ gs }) => {
    gs.suspendRaf = true
    void (async () => {
      const [beast, girl] = await Promise.all([
        fetchMgoSprite(571).catch(() => [] as IndexedImage[]),
        fetchMgoSprite(572).catch(() => [] as IndexedImage[]),
      ])
      await playEndingAnimation({
        upperIndices: battleBgs.get(61)?.indices ?? new Uint8Array(320 * 200),
        lowerIndices: battleBgs.get(62)?.indices ?? new Uint8Array(320 * 200),
        beastFrames: beast,
        girlFrames: girl,
        fb,
        canvasCtx: canvasCtx!,
        palette: gs.palette ?? palette,
      })
    })()
      .catch((err) => {
        console.warn('[bootstrap.endingAnimationHandler] failed:', err)
      })
      .finally(() => {
        gs.suspendRaf = false
        if (gs.eventCursor?.waiting === 'ending-anim') gs.eventCursor.waiting = undefined
      })
  })

  // Sync.2 fix4+:扫 setPlayerSprite(opcode 0x65)的 sprite id,预 fetch。
  //   操作:operand[0]=roleId, operand[1]=spriteId;任何队员都可能被剧情换形象。
  // present.ts 渲染时按当前 roleId 的 runtime rgwSpriteNum → ctx.npcSpriteFrames.get(spriteId);
  //   若未预 fetch → 取不到 override 帧 → role0 兜底画成默认(可见)精灵,不会消失。
  // **扫全局 all.json(getGlobalCommands),非仅首屏 scene(2026-06-08 林家堡 bug)**:
  //   李逍遥变蛇逃跑过场走出后 `0x65[0,232]` 把队首换成**1×1 空精灵 232(隐身)**让他消失,loadScene 前
  //   再 `0x65[0,2]` 换回。这段在全局脚本里,旧码只扫首屏 eventCommands → 232 漏载 → 李逍遥不消失(user 报)。
  const cutsceneSpriteIds = new Set<number>()
  for (const cmd of getGlobalCommands()) {
    if (cmd.op === 'raw' && cmd.opcode === 0x0065) {
      const spriteId = cmd.operands[1] ?? 0
      if (spriteId > 0 && !npcSpriteFrames.has(spriteId)) {
        cutsceneSpriteIds.add(spriteId)
      }
    }
  }
  if (cutsceneSpriteIds.size > 0) {
    console.log(`[bootstrap] preloading ${cutsceneSpriteIds.size} cutscene party sprite(s):`, [
      ...cutsceneSpriteIds,
    ])
    await Promise.all([...cutsceneSpriteIds].map((id) => fetchMissingSprite(id)))
  }

  // ── M5.6 T17:启动路由 — OpeningMenu vs ?skip-intro ──────────────────────
  // sdlpal main.c:545-546 真值:`PAL_TrademarkScreen → PAL_SplashScreen → PAL_OpeningMenu`,
  // OpeningMenu 选 new-game 返回 0 → `PAL_PlayAVI("3.avi")` → loop 进 scene。
  //
  // 当前启动序列见showTrademarkAndSplash;new-game的Win95路径由playOpeningAvi实播3.mp4。
  //
  // ?skip-intro=1 URL flag(M3.5 commit a9a87ac)— 之前跳 scene 0 梦境直接 scene 1,
  // T17 扩为同时跳过 OpeningMenu(dev / e2e 用)。

  /** 用 primary scene(SCENE_ID)资产真正"开始"游戏 — 装 events + 跑 onEnter。 */
  function startNewGameFromPrimary(): void {
    // H1(2026-06-07 sdlpal 差异审查):对齐 PAL_LoadDefaultGame(global.c:434-465)— 重置玩家进度
    //   字段(金钱/背包/毒/队伍/trail/采集值/昼夜/层/跟随/追击/调色板/音乐/战速)+ hydrate
    //   PlayerRoles 基线到 gs.PlayerRolesRuntime + 设 8 类经验 wLevel = 各角色等级。
    //   通关 / 系统菜单退出回标题后再开新游戏时,returnToTitle 只重置 cursor/menu/mode,gs 仍带
    //   上一局脏数据 —— loadDefaultGame 清掉它,否则满背包 / 满金钱 / 满经验开局(回归测试见 game-state.test.ts)。
    loadDefaultGame(gs, playerRoles)
    // C5(2026-05-28):PAL_LoadDefaultGame 真值随后调 PAL_UpdateEquipments(global.c:1333)— 跨
    //   role × 6 part 跑每件装备 scriptOnEquip 累加 stat 到 rgEquipmentEffect,否则 effective
    //   Atk/Def/Mag 等 stat getter 永远 = base(D14 装备 effect 根因)。
    updateAllEquipments(gs, items)
    // H1 续(2026-06-07):scene 运行时复位到 primary。通关 / 系统菜单退出回标题后再开新游戏时,gs 仍带
    //   上一局的 wNumScene / npcs / allEventObjects / scene flag —— 对齐启动顶层(250-288)复位,否则
    //   onEnter 在脏场景号上跑、NPC 错乱、对象状态(李大娘走了 / 宝箱开了)残留、清掉的 onEnter 停点让开场不重播。
    //   首次启动时 gs 本就干净 → 以下复位全部幂等。
    resetSceneRuntimeForNewGame(gs, initialEventObjects)
    // 先回到稳定探索态;正常序章下方会再切 event,skip-intro 同步跑完 enter script 后则保持 explore。
    gs.mode = 'explore'
    gs.wNumScene = SCENE_ID + 1
    setCurrentMapNum(scene.mapNum) // 同步当前 mapNum(小地图底图/地图名/对话按 map 分组);new-game/skip-intro 此路径此前漏设 → 停 0 梦境
    gs.sceneCommands = eventCommands
    gs.sceneLabelMap = labelMap
    gs.basePalette = palette
    gs.npcs =
      sliceSceneEventObjects(gs, gs.wNumScene) ??
      scene.eventObjects.map((eo) => npcFromEventObject(eo, labelMap))
    supplySupplementalSceneObjects(gs, scene.eventObjects)
    hydrateNpcStaticDefaults(gs.npcs, scene.eventObjects)
    // 渲染路由复位到 primary scene(等价 applySceneAssetsToPresent;scene 闭包是 SceneObjects 无
    //   tilemap/palette,故用 loadAll 顶层 primary tilemap)。
    presentCtx.tilemap = tilemap
    currentSceneId = SCENE_ID
    setSceneContext({ tilemap })
    // 结局 / 死亡演出可能把工作 palette 留在黑色、红色或其他场景色;新游戏从 primary palette 重建。
    gs.palette = makeWorkingPalette(palette)

    if (scene.onEnterLabel) {
      const ip = getGlobalLabelMap()[scene.onEnterLabel] // P2#5:onEnterLabel = L_<global> → 全局 ip
      if (ip !== undefined) {
        if (skipIntroBoot) {
          // skip-intro: 同步跑 enter script,只取 setPartyPos/Direction,跳过对话(scene 1 客栈)。
          // 传 sceneId(gs.wNumScene)→ 跑完持久化 onEnter 停点,重进 scene 不重播开场
          // (否则从大厅进客栈时 onEnter 重放传说 + setPartyPos 把人拉回起点,覆盖门的落点)。
          const overrideIp = gs.sceneOnEnterIp[gs.wNumScene]
          runEnterScript(gs, undefined, undefined, overrideIp ?? ip, gs.wNumScene) // P2#5:默认全局数组
        } else {
          // 正常启动:跑完整 onEnter script(scene 0 梦境对话)— tickEventSystem 步进。
          // 打 onEnter tag → 'end' 持久化停点,scene 0 也不重播(同 loadScene 路径)。
          const overrideIp = gs.sceneOnEnterIp[gs.wNumScene]
          const startIp = overrideIp ?? ip
          gs.eventCursor = {
            ip: startIp, // P2#5:全局 ip,默认读全局数组
            onEnterSceneId: gs.wNumScene,
            onEnterStartIp: startIp,
          }
          gs.mode = 'event'
        }
      }
    }
    // 清 OpeningMenu(若有);startNewGameFromPrimary 由 OpeningMenu 触发时 menuStack 非空
    gs.menuStack = []
  }

  /**
   * M5.6 T19 Step 8:OpeningMenu 选 new-game 后播 3.avi。
   * sdlpal uigame.c:162 `PAL_PlayAVI("3.avi")` 真值:
   *   if (wItemSelected == 0) PAL_PlayAVI("3.avi");
   *   return (INT)wItemSelected;
   *
   * `?build=win95`:走 mp4 视频(我们默认)
   * `?build=dos`:DOS 数据没 3.avi 替代,直接 return(sdlpal main.c 同口径,
   *   PAL_PlayAVI 失败时 return 0 不走 fallback)
   */
  async function playOpeningAvi(): Promise<void> {
    if (buildFlag === 'dos') {
      console.log('[bootstrap] DOS build:3.avi 无 fallback,直接进 scene')
      return
    }
    gs.suspendRaf = true
    try {
      await playAvi({ src: '/extracted/videos/3.mp4' })
    } finally {
      // 3.mp4 是 <video> 浮层,suspendRaf 期间 canvas 底下残留的是 OpeningMenu 那一帧(菜单是 AVI 前
      // 最后 flush 的)。video 一移除到下一 raf 画梦境之间会露出旧菜单 → 闪一帧(user 2026-06-02 报)。
      // 恢复渲染前先把 canvas 清成黑:过渡变 菜单→[3.mp4]→黑→梦境,无菜单残帧。
      //   对齐 sdlpal:PAL_PlayAVI 结束屏幕本就黑屏,随后 PAL_MakeScene 淡入(黑过渡忠实)。
      fb.clear()
      flushToCanvas(fb, canvasCtx!, gs.palette ?? palette)
      gs.suspendRaf = false
    }
  }

  /**
   * C8(2026-05-29):大世界 SystemMenu Load + OpeningMenu Load 共享 — sdlpal
   * `PAL_ReloadInNextTick`(global.c:888)真值:fEnteringScene + fNeedToFadeIn +
   * SetLoadFlags(GlobalData | Scene | PlayerSprite),下一 tick 主循环 reload。
   *
   * ts 端整套:Save.loadSlot → gs 字段全替换 → sceneLoader callback 重 load 当前 scene。
   * Object.assign 后到新 scene assets ready 前,canvas 必须保持黑屏:否则旧 framebuffer 会被存档 palette
   * 先重染一帧(白天读夜档会先变夜;死亡读档会露战斗帧),再进入目标场景。
   */
  async function loadGameFromSlot(slot: number, snapshot?: SaveSnapshot): Promise<void> {
    const loadedGs = snapshot ?? (await Save.loadSlot(slot))
    if (!loadedGs) {
      console.warn(`[bootstrap.loadGame] slot ${slot} 空,load skip`)
      return
    }
    // Native IndexedDB snapshots can bypass the portable import validator.
    if (!isFiniteNumber(loadedGs.dwCash)) {
      throw new InvalidSaveSlotError(
        localize('存档损坏，无法读取', 'The save is corrupt and cannot be loaded'),
      )
    }
    // DM26/DLg:读档起手停乐(uigame.c:608 `AUDIO_PlayMusic(0,FALSE,1)`)。Object.assign 恢复
    //   存档 wNumMusic 后,曲号必经 0→N 变化 → AudioManager 必从头重播(= res.c:223 先停后播
    //   必从头;旧"同曲号续播"一并修)。
    gs.wNumMusic = 0
    syncShellAudio(audio, gs, [], playerRoles)
    console.log(`[bootstrap.loadGame] slot ${slot} loaded`)
    // mutate gs in-place(外部持有同 ref;无法替换 ref)
    // 把 loadedGs 全字段拷到 gs(用 Object.assign 浅 + 关键嵌套手动 deepClone)
    Object.assign(gs, loadedGs)
    gs.partyCameraOffset = loadedGs.partyCameraOffset && { ...loadedGs.partyCameraOffset }
    // 「跟着存档走」:dialogHistory 随 deepClone(gs) 进存档,但 Object.assign 对老档(无此字段)**不覆盖**
    //   → 残留当前 session 历史(圣姑家+比武招亲时间线倒错的根因)。显式从 loadedGs 归一(老档兜底空、
    //   超 CAP 截断)。**须读 loadedGs.dialogHistory 而非 gs.dialogHistory**:后者对老档恰是要清掉的残留值。
    gs.dialogHistory = restoreDialogHistory(loadedGs.dialogHistory)
    // 读档归一化:旧 schema 存档(2026-06-07 起加 rgwAvatar/rgwWalkFrames 等新 runtime 字段)经
    //   Object.assign 整体替换了 createInitialGameState 建好的完整 runtime → 缺字段时 ESC 开菜单
    //   投影 projectRuntimeToBattleRoles 读 undefined[0] 崩。以默认模板补齐缺失键(保留存档已有数据)。
    gs.PlayerRolesRuntime = normalizePlayerRolesRuntime(gs.PlayerRolesRuntime)
    for (const role of playerRoles.roles) {
      if (!gs.PlayerRolesRuntime.rgwSpriteNum[role.id]) {
        gs.PlayerRolesRuntime.rgwSpriteNum[role.id] = role.spriteNum
      }
    }
    if (gs.partyLeaderSpriteId !== undefined) {
      gs.PlayerRolesRuntime.rgwSpriteNum[0] = gs.partyLeaderSpriteId
    }
    // 读档 transition guard:存档 palette 要留给目标场景,但加载窗口只能刷黑屏。
    //   普通读档:避免旧场景先套目标档昼夜 palette(白天读夜档会瞬间变夜)。
    //   死亡读档:避免 0x4E FadeOut 后 Object.assign 把黑 palette 覆成存档色,露出残留战斗帧。
    //   **新建 palette 对象**:Object.assign 后 gs.palette === loadedGs.palette 同引用,不得原地改 colors。
    const restoredPalette = cloneScreenPalette(gs.palette ?? gs.basePalette ?? palette)
    gs.sceneLoading = true
    gs.paletteFadeState = undefined
    gs.palette = makeBlackScreenPalette(restoredPalette)
    fb.clear()
    flushToCanvas(fb, canvasCtx!, gs.palette)
    // sdlpal bCurrentSaveSlot 是 runtime 全局(非 SAVEDGAME)— Object.assign 带入的是存档里那份旧值,
    // 须用本次读的 slot 覆盖(opcode 0x4E load-last-save 据此重载"上次读/存"的槽)。
    gs.currentSaveSlot = slot
    // 关菜单回 explore — loadSceneCommon 完成后 explore tick 接管
    gs.menuStack = []
    gs.mode = 'explore'
    // M6(2026-06-07 sdlpal 审查):PAL_InitGameData(global.c:951)在 PAL_LoadGame 后、UpdateEquipments
    //   前 memset rgPlayerStatus —— 存档里那份非装备持久状态(大世界 0x2D 上的护身 / 勇气 / 加速等)丢弃,
    //   装备授予的状态由下方 updateAllEquipments 重建。否则读档后这些状态跨存档残留。
    gs.rgPlayerStatus = createInitialPlayerStatus()
    // DH7:PAL_LoadGame_Common(global.c:630)读回后无条件 memset rgPoisonStatus —— 毒虽被保存
    //   (global.c:772)但**读档即解毒**(原版机制,玩家惯用读档清毒)。否则带毒存档读回毒残留
    //   (头像染色/每回合掉血/减速持续)。
    gs.rgPoisonStatus = {}
    // sdlpal PAL_InitGameData(global.c:953)真值:PAL_LoadGame 后**无条件** PAL_UpdateEquipments()。
    // rgEquipmentEffect 是派生字段(不在 SAVEDGAME_WIN),必须从 rgwEquipment 重算 —— 不信存档里那份
    // (避免存档时 effect 处于脏/旧状态被原样载入;item/script 定义变更后也能自愈)。P1#4(2026-05-29)。
    updateAllEquipments(gs, items)
    gs.iCurEquipPart = -1
    // L6/L7:PAL_InitGameData(global.c:948)/PAL_LoadGame_Common(global.c:611)读档后无条件复位 ——
    //   iCurInvMenuItem(物品菜单光标)与 sWaveProgression(屏幕波动增量)均不在 SAVEDGAME_WIN,恒归 0。
    //   存档经 structuredClone 带进旧值、Object.assign 灌回 → 此处强制清(对齐 C 不持久化语义)。
    gs.iCurInvMenuItem = 0
    gs.sWaveProgression = 0
    // 重 load scene assets — 走 fromSavedGame 路径,**不**重置 npcs / **不**跑 onEnter。
    // sceneLoading 在读档 transition guard 已置 true;loadSceneCommon 完成后恢复目标存档 palette 绘制新场景。
    pendingSaveSceneLoads++
    try {
      await loadSceneCommon(gs.wNumScene, { fromSavedGame: true })
    } finally {
      pendingSaveSceneLoads--
    }
    gs.palette = restoredPalette
    // DM26:PAL_ReloadInNextTick(global.c:910)无条件 fNeedToFadeIn=TRUE → 进场 1s 淡入
    //   (scene.c:503-507)。此前仅 0x4E 死亡读档设,系统菜单读档画面硬切。
    gs.needToFadeIn = true
  }

  async function loadGameFromMenu(slot: number): Promise<void> {
    try {
      await loadGameFromSlot(slot)
    } catch (error) {
      if (!(error instanceof InvalidSaveSlotError)) throw error
      showToast(error.message, { type: 'error' })
    }
  }

  setLoadGameHandler(loadGameFromMenu)

  // opcode 0x4E load-last-save(sdlpal script.c:1765 PAL_ReloadInNextTick(bCurrentSaveSlot))。
  // event-system 已先跑完 fade-out(淡黑)+ 清 cursor;此处只重载槽 + 设 needToFadeIn(对齐
  // PAL_ReloadInNextTick 的 fNeedToFadeIn=TRUE → loaded scene 经 explore auto fade-in 淡入)。
  setLoadLastSaveHandler((slot) => {
    // PAL_InitGameData(0)不读存档,而是 PAL_LoadDefaultGame。新游戏尚未保存就死亡时,
    // currentSaveSlot=0 必须重建默认游戏;Save.loadSlot(0)只会返回空,会把死亡态留在黑屏下。
    if (slot === 0) {
      startNewGameFromPrimary()
      gs.needToFadeIn = true
      return
    }
    void loadGameFromSlot(slot)
      .then(() => {
        gs.needToFadeIn = true
      })
      .catch((err: unknown) => {
        console.error('[bootstrap.loadLastSave] failed:', err)
      })
  })

  /** 回标题(opcode 0xA0 quit / 结局后)— 复用 OpeningMenu 启动路径(同 showTrademarkAndSplash 末尾)。 */
  function returnToTitle(): void {
    // 清结局/死亡/对话演出残留(eventCursor + dialogPlayingRNG/rngDialogBackup/blackScreenHold/fade 等)。
    //   结局 0xA0 QUIT 从「拜月投河 RNG 演出对话」期触发,播完片尾 4/5/6.mp4 后若漏清 dialogPlayingRNG,
    //   present.ts 会短路画结局 RNG 末帧(血池)盖住主菜单 → user 报「看完片尾自动回 RNG 末帧 + 吞键」。
    resetPresentationTransients(gs)
    gs.menuStack = [{ kind: 'opening', state: createOpeningMenu() }]
    gs.mode = 'menu'
    // DM28:主菜单曲 4(RIX_NUM_OPENINGMENU,uigame.c:114);选项确定后被新游戏/读档路径覆盖
    //   (= uigame.c:157-158 确定后停乐)。
    gs.wNumMusic = 4
    syncShellAudio(audio, gs, [], playerRoles)
  }

  // C2-quit:系统菜单 QUIT → ConfirmMenu 选「是」(sdlpal PAL_QuitGame PAL_Shutdown(0))。浏览器映射为回标题。
  //   **不**复用下方 0xA0 setQuitHandler(那含 WIN95 结局 mp4 播放,语义不同):系统菜单退出不放任何结局动画。
  setSystemQuitHandler(returnToTitle)

  // opcode 0xA0 quit(sdlpal script.c:2988-2996)。用户决策:跳过 PAL_AdditionalCredits(SDLPAL 引擎
  // GNU GPL 版权页,非游戏内容)→ 回标题。WIN95 → 播结局 mp4(4/5/6,对应 PAL_EndingScreen AVI 序)→ 回标题;
  // DOS → 结局已由 scene-281 前序 opcode(FBP/ScrollFBP/ColorFade/EndingAnimation 等)跑完 → 直接回标题。
  setQuitHandler(() => {
    if (buildFlag === 'win95') {
      gs.suspendRaf = true
      void (async () => {
        for (const m of ['4.mp4', '5.mp4', '6.mp4']) await playAvi({ src: `${BASE}/videos/${m}` })
      })()
        .catch((err: unknown) => {
          console.warn('[bootstrap.quit] 结局 mp4 播放失败:', err)
        })
        .finally(() => {
          gs.suspendRaf = false
          returnToTitle()
        })
    } else {
      returnToTitle()
    }
  })

  setStartGameHandler(async (choice) => {
    if (choice.kind === 'new-game') {
      // sdlpal uigame.c:157-162 真值:OpeningMenu 选定后先停乐(AUDIO_PlayMusic(0,FALSE,1))
      // 再 PAL_PlayAVI("3.avi")。兼修慢网根因之一:32MB soundfont 未就绪时主菜单曲挂在
      // audio-midi `last` 等补播,stop 把它取消 —— 否则 soundfont 在 AVI 中途 ready,
      // 主菜单曲突然混进视频声轨(2026-06-12 user 报"快播完了主菜单音乐才出来")。
      // 新游戏的场景曲随后由 loadDefaultGame 重置 wNumMusic → sync 0→N 正常起播。
      gs.wNumMusic = 0
      syncShellAudio(audio, gs, [], playerRoles)
      await playOpeningAvi()
      startNewGameFromPrimary()
    } else {
      // C8(2026-05-29):OpeningMenu 选 load-game → 复用 loadGameFromSlot 真做
      await loadGameFromMenu(choice.slot)
    }
  })

  /**
   * Step 7:Trademark + Splash 启动序列 — sdlpal main.c:545-546 真值。
   * `?build=win95`:playAvi(1/2)— mp4 视频(WIN95 build path,我们默认)
   * `?build=dos`:playTrademarkFallback + playSplashFallback — RNG + 卷轴动画
   *
   * suspendRaf 包 try/finally,modal 期间 canvas render 暂停。
   */
  // 独立DOS工厂提供开场/结局有序演出；showTrademarkAndSplash 的
  // dos 分支 + devpanel "开场 DOS" 按钮共用(资产 battleBgs/characterSprites/palette 在任何 build 都已加载,
  // 故 win95 build 下 devpanel 也能跑 DOS 版)。不管 suspendRaf(caller 包)。

  async function showTrademarkAndSplash(): Promise<void> {
    gs.suspendRaf = true
    try {
      if (buildFlag === 'win95') {
        // sdlpal main.c:197 PAL_PlayAVI("1.avi") / main.c:237 PAL_PlayAVI("2.avi")
        await playAvi({ src: '/extracted/videos/1.mp4' })
        await playAvi({ src: '/extracted/videos/2.mp4' })
      } else {
        await playDosOpening()
      }
    } finally {
      gs.suspendRaf = false
    }
  }

  // soundfont 收尾等待:其余 boot 资源完成后,
  // 慢网下进度计数会停在最后一格等这单个大文件请求 —— 注明在等什么;到手(或失败)即清。必须在视频/菜单发起**之前**等,
  // 否则 1.mp4 在 loading 覆盖层底下开播。(大小不写死:音色库可换,2026-06-12 已从 32MB
  // GeneralUser GS 换 6MB TimGM6mb,见 public/soundfont-LICENSE.txt)
  if (initialMusicSource === 'midi') setBootLoadingNote(localize('音色库', 'Soundfont'))
  await soundfontSettled
  setBootLoadingNote('')

  // ── 可玩门(2026-06-14)──:必要资源就绪 → 通知 UI 出「进入游戏」按钮,await 用户点(或自动放行)。
  // 不再自动进游戏。dev/e2e / SW 不可用:enterGate 已预先 resolved、onPlayable no-op → 立即通过(现状)。
  // audio 解锁:点按钮的 pointerdown 已被上方 window 监听器触发 audio.resume();await 后补一次幂等保险。
  // video 解锁:由 main.ts 的 onEnter 在 click 同步栈 warmUpVideoAutoplay()(transient activation 要求)。
  deps?.onPlayable?.()
  if (deps?.enterGate) await deps.enterGate
  audio.resume()

  if (skipIntroBoot) {
    // ?skip-intro=1 → 跳 trademark + splash + OpeningMenu 直接走 SCENE_ID(=1)新游戏
    startNewGameFromPrimary()
    // dev:?dev-party=0,1,2 覆写队伍(看跟随者队形用)+ 预载各队员大世界精灵。
    //   roleId 顺序 = [李逍遥0,赵灵儿1,林月如2,巫后3,阿奴4,盖罗娇5]。
    const devPartyParam = new URLSearchParams(window.location.search).get('dev-party')
    if (devPartyParam) {
      const ids = devPartyParam
        .split(',')
        .map(Number)
        .filter((n) => Number.isInteger(n) && n >= 0)
      if (ids.length > 0) {
        gs.partyMembers = ids
        const spriteIds = ids
          .map((rid) => playerRoles.roles[rid]?.spriteNum)
          .filter((s): s is number => typeof s === 'number' && s > 0 && !npcSpriteFrames.has(s))
        await Promise.all(spriteIds.map((s) => fetchMissingSprite(s)))
      }
    }
  } else {
    // 默认:trademark → splash → OpeningMenu
    // 注:await 不阻塞 startRafLoop(后者立即调,raf 已暂停 via suspendRaf)
    void showTrademarkAndSplash()
      .then(() => {
        // sdlpal ui.c:473 PAL_ReadMenu 每轮先 PAL_ClearKeyState 再读输入 —— 进 OpeningMenu 前清掉跳过
        // splash 的残留 Space('Confirm'),否则菜单首帧即被误确认开新游戏。覆盖 DOS fallback 分支
        // (playDosOpening 不经 avi-player 的 stopImmediatePropagation)。
        input.clearPressed()
        gs.menuStack = [{ kind: 'opening', state: createOpeningMenu() }]
        gs.wNumMusic = 4 // DM28:主菜单曲(uigame.c:114)
        syncShellAudio(audio, gs, [], playerRoles)
        gs.mode = 'menu'
      })
      .catch((err: unknown) => {
        console.error('[bootstrap] trademark/splash 失败,直接进 OpeningMenu:', err)
        input.clearPressed()
        gs.menuStack = [{ kind: 'opening', state: createOpeningMenu() }]
        gs.wNumMusic = 4 // DM28:主菜单曲(uigame.c:114)
        syncShellAudio(audio, gs, [], playerRoles)
        gs.mode = 'menu'
      })
  }

  startRafLoop(loopCtx)
  // DEV-only:暴露 GameState 引用给 console / 自动化调试(配合 dev-panel 坐标传送排查卡死)。
  if ((import.meta as unknown as { env?: { DEV?: boolean } }).env?.DEV) {
    ;(window as unknown as Record<string, unknown>).__tpgs = gs
  }
  // 首帧可见(trademark/splash/OpeningMenu 或 skip-intro 场景)→ 启动 loading 覆盖层淡出
  finishBootLoading()
  console.log(
    '[bootstrap] startup ready, SCENE_ID=',
    SCENE_ID,
    'skipIntro=',
    skipIntroBoot,
    'build=',
    buildFlag,
  )
}
