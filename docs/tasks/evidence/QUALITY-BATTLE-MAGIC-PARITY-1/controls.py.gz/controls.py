# -*- coding: utf-8 -*-
from pathlib import Path
import subprocess,json,gzip,hashlib,re
root=Path.cwd();out=root/'docs/ops/evidence/QUALITY-BATTLE-MAGIC-PARITY-1'
cases=[
 ('prefer-previous','packages/game/src/core/battle/simulated-magic-target.ts','const previous = state.iPrevEnemyTarget ?? -1','const previous = -1','base=198, hp=9000'),
 ('raw-runtime','packages/game/src/core/battle/battle-opcodes.ts','ctx.gs?.PlayerRolesRuntime.rgwAttackStrength[roleId] ?? 0','ctx.playerRoles?.roles[roleId]?.attackStrength ?? 0','raw attack=50'),
 ('non-damage-preroll','packages/game/src/core/battle/actions/magic.ts','if (input.casterIsEnemy) {\n    const adTarget','if (input.casterIsEnemy && asShort(magic.baseDamage) > 0) {\n    const adTarget','normal pre-roll'),
 ('pose-independent-of-damage','packages/game/src/core/battle/actions/magic.ts','const autoDefendIdxs = preRolledAutoDefend\n    ? [...preRolledAutoDefend].filter(([, defended]) => defended).map(([idx]) => idx)\n    : []','const autoDefendIdxs: number[] = []','normal pre-roll'),
 ('freeze-lethal-target','packages/game/src/core/battle/battle-opcodes.ts','pushThrowOffMagicAnim(ctx, operands[0] ?? 0, target)','pushThrowOffMagicAnim(ctx, operands[0] ?? 0, resolveSimulatedMagicTarget(state, objectMagic, targetIdx))','base=198, hp=100'),
]
results=[]
for name,source,before,after,selection in cases:
 p=root/source;original=p.read_bytes();s=original.decode();count=s.count(before)
 # Both opcodes use the same animation call; this control changes only 0x42.
 assert count==(2 if name=='freeze-lethal-target' else 1),(name,count)
 mutated=s.replace(before,after,1).encode();p.write_bytes(mutated)
 jsonpath=Path('/tmp')/('type-pal-'+name+'.json')
 cmd=['pnpm','--filter','@type-pal/game','exec','vitest','run','src/core/battle/__tests__/magic-parity.test.ts','-t',re.escape(selection),'--reporter=default','--reporter=json','--outputFile='+str(jsonpath)]
 try:
  done=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);raw=done.stdout
  report=json.loads(jsonpath.read_text());assertions=[a for f in report['testResults'] for a in f['assertionResults'] if a['status']=='failed']
  exact=len(assertions)==1 and report['numFailedTests']==1 and report['numPassedTests']==0 and report.get('numRuntimeErrorTestSuites',0)==0 and done.returncode==1 and 'AssertionError' in raw.decode()
  (out/(name+'.raw.gz')).write_bytes(gzip.compress(raw,mtime=0));(out/(name+'.vitest.json.gz')).write_bytes(gzip.compress(jsonpath.read_bytes(),mtime=0))
  row={'name':name,'command':cmd,'cwd':str(root),'exit':done.returncode,'source':source,'originalSha256':hashlib.sha256(original).hexdigest(),'mutantSha256':hashlib.sha256(mutated).hexdigest(),'selection':selection,'failedTests':report['numFailedTests'],'passedTests':report['numPassedTests'],'runtimeErrorSuites':report.get('numRuntimeErrorTestSuites',0),'businessFailureNames':[a['fullName'] for a in assertions],'exactOneBusinessAssertion':exact,'raw':name+'.raw.gz','rawSha256':hashlib.sha256(raw).hexdigest()}
 finally:
  p.write_bytes(original)
 row['restoredSha256']=hashlib.sha256(p.read_bytes()).hexdigest();assert row['originalSha256']==row['restoredSha256'];results.append(row);print(json.dumps(row,ensure_ascii=False),flush=True)
 assert exact,name
(out/'controls.json').write_text(json.dumps({'producer':'Codex deterministic controls; not third-party review','results':results},ensure_ascii=False,indent=2)+'\n')
