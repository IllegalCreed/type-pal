from pathlib import Path
import sys,subprocess,json,gzip,hashlib,datetime
root=Path.cwd();out=root/'docs/ops/evidence/QUALITY-BATTLE-MAGIC-PARITY-1';label=sys.argv[1];cmd=sys.argv[2:];started=datetime.datetime.now(datetime.timezone.utc).isoformat();error=None
try:
 p=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);raw=p.stdout;code=p.returncode
except OSError as e:
 error=str(e);raw=error.encode();code=None
(out/(label+'.raw.gz')).write_bytes(gzip.compress(raw,mtime=0));row={'command':cmd,'cwd':str(root),'startedAt':started,'completedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit':code,'signal':-code if code is not None and code<0 else None,'spawnError':error,'raw':label+'.raw.gz','rawBytes':len(raw),'rawSha256':hashlib.sha256(raw).hexdigest(),'fullUncutMergedStdoutStderr':True};(out/(label+'.json')).write_text(json.dumps(row,ensure_ascii=False,indent=2)+'\n');print(json.dumps(row,ensure_ascii=False));print(raw.decode()[-7000:]);sys.exit(0 if code==0 else 1)
