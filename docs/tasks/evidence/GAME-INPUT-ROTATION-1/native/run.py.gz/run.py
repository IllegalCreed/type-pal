import datetime, hashlib, json, os, pathlib, subprocess, sys, time
name = sys.argv[1]
command = sys.argv[2:]
folder = pathlib.Path(__file__).resolve().parent
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
process = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
(folder / (name + '.stdout')).write_bytes(process.stdout)
(folder / (name + '.stderr')).write_bytes(process.stderr)
metadata = {
 'command': command, 'cwd': os.getcwd(), 'started': started,
 'finished': datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'exit': process.returncode if process.returncode >= 0 else None,
 'signal': -process.returncode if process.returncode < 0 else None,
 'spawnError': None,
 'gitHead': subprocess.check_output(['git','rev-parse','HEAD'], text=True).strip(),
 'sourceHashes': {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in pathlib.Path('packages/game/src').rglob('*.ts') if p.name in ['input-direction.ts','input-rotation.ts','gamepad-input.ts','touch-controls.ts','game-shell.ts','input.ts','tools-panel.ts']},
 'stdout': name + '.stdout', 'stderr': name + '.stderr'
}
(folder / (name + '.run.json')).write_text(json.dumps(metadata, ensure_ascii=False, indent=2) + '\n')
sys.stdout.buffer.write(process.stdout)
sys.stderr.buffer.write(process.stderr)
sys.exit(process.returncode)
