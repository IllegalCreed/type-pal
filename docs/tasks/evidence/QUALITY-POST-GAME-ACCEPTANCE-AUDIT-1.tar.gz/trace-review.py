import collections
import hashlib
import io
import json
import pathlib
import re
import subprocess
import sys
import tarfile

BASE = 'c56192d8b'
LEDGER = 'docs/tasks/audits/code-quality-file-ledger.md'
WINDOWS = [
    (68, '778928d19', 'QUALITY-CONTENT-REFERENCES-1-execution.tar.gz'),
    (69, '701b34334', 'QUALITY-CONTENT-REFERENCES-1-review-closeout.tar.gz'),
    (70, 'c08cdc3ed', 'QUALITY-CONTENT-ASSET-CONTRACTS-1.tar.gz'),
    (71, 'dc745c127', 'QUALITY-CONTENT-ASSET-REVIEW-CLOSEOUT.tar.gz'),
    (72, 'b3f610456', 'QUALITY-MIGRATION-SOURCE-PROJECTIONS-1.tar.gz'),
    (73, 'bfd5b5c4c', 'QUALITY-REFORGE-PRESENTATION-1.tar.gz'),
]
PATH = re.compile(r'^(?:packages|scripts)/[^\s:]+\.(?:js|ts|jsx|tsx|mjs|mts|json)$')
DIGEST = re.compile(r'^(?:[a-f0-9]{40}|[a-f0-9]{64})$')
CLOSED = {'已验证','保留'}

def git(*args):
    return subprocess.check_output(['git', *args])

def ledger(rev):
    source = git('show', f'{rev}:{LEDGER}').decode()
    table = source.split('| 文件 | 类别 | 状态 | 证据 / 验证 | 备注 |\n', 1)[1]
    rows = {}
    for line in table.splitlines()[1:]:
        if not line.startswith('|'):
            break
        match = re.match(r'\| `([^`]+)` \| ([^|]+) \| ([^|]+) \| ([^|]+) \| (.*) \|$', line)
        assert match, line[:140]
        rows[match[1]] = match.groups()[1:]
    return rows

def tree(rev):
    return {
        path: typ.split()[2]
        for row in git('ls-tree','-r','-z',rev).decode().split('\0') if row
        for typ, path in [row.split('\t', 1)]
    }

def archive(rev, filename):
    raw = git('show', f'{rev}:docs/tasks/evidence/{filename}')
    with tarfile.open(fileobj=io.BytesIO(raw), mode='r|gz') as bundle:
        for m in bundle:
            if m.isfile() and m.size < 5_000_000 and m.name.endswith('.json') and not re.search(r'/(?:native|report|execution|coverage(?:-final)?)\.json$', m.name):
                try:
                    yield m.name, json.load(bundle.extractfile(m))
                except (UnicodeError, json.JSONDecodeError):
                    continue

def source_fingerprints(object_ids):
    values = {}
    with subprocess.Popen(['git','cat-file','--batch'], stdin=subprocess.PIPE, stdout=subprocess.PIPE) as pipe:
        for oid in sorted(object_ids):
            pipe.stdin.write(oid.encode()+b'\n')
            pipe.stdin.flush()
            name, kind, size = pipe.stdout.readline().decode().split()
            assert name == oid and kind == 'blob'
            payload = pipe.stdout.read(int(size))
            assert pipe.stdout.read(1)==b'\n'
            values[oid] = hashlib.sha256(payload).hexdigest()
    return values

def read_receipts(data, known, refs, member, here=''):
    if isinstance(data, list):
        for item in data:
            read_receipts(item, known, refs, member, here)
    elif isinstance(data, dict):
        paths = [
            value for k,value in data.items()
            if k in ('path','file','originalPath','currentPath','newPath','candidatePath') and isinstance(value,str) and value in known
        ]
        if len(set(paths)) == 1:
            here = paths[0]
            refs[here][member]
        for key, item in data.items():
            cursor = here
            if key in known:
                cursor = key
            elif PATH.fullmatch(key):
                cursor = ''
            if isinstance(item, str) and PATH.fullmatch(item):
                if item in known:
                    refs[item][member]
                continue
            if cursor and isinstance(item, str) and DIGEST.fullmatch(item):
                refs[cursor][member].add(item)
            elif isinstance(item, (dict,list)):
                read_receipts(item, known, refs, member, cursor)

base = ledger(BASE)
previous = base
baseline_tree = tree(BASE)
game_paths = {p for p in baseline_tree if p.startswith('packages/game/') and PATH.fullmatch(p) and p.rsplit('.',1)[-1] in ('js','mjs','mts','ts','tsx','json')}
print('game at baseline',len(game_paths),sum(path in base and base[path][1] in CLOSED for path in game_paths),flush=True)
all_paths = []
for number, revision, filename in WINDOWS:
    current = ledger(revision)
    closed_now = {p for p,row in current.items() if row[1] in CLOSED and (p not in previous or previous[p][1] not in CLOSED)}
    prior_closed = {p for p,row in previous.items() if row[1] in CLOSED}
    removed = sorted(p for p in prior_closed if p not in current or current[p][1] not in CLOSED)
    present = tree(revision)
    assert closed_now <= present.keys()
    sha = source_fingerprints({present[p] for p in closed_now})
    associations = collections.defaultdict(lambda:collections.defaultdict(set))
    for member,payload in archive(revision, filename):
        read_receipts(payload,closed_now,associations,member)
    data = []
    for path in sorted(closed_now):
        row = current[path]
        candidate = sha[present[path]]
        matches = sorted(member for member, ids in associations[path].items() if candidate in ids or present[path] in ids)
        members = sorted(associations[path])
        card = re.findall(r'\]\((\.\./cards/[^)#]+)',row[2])[0].replace('../','docs/tasks/')
        assert card in present, (path,card)
        data.append({'path':path,'card':card,'acceptedBlob':present[path],'receiptMentions':members,'exactIdentityMembers':matches})
    all_paths.extend({'pr':number,**r} for r in data)
    print(f'#{number} {revision}: {len(data)} closed +, withdrawn {removed}, receipt paths {sum(bool(x["receiptMentions"]) for x in data)}, exact accepted bytes {sum(bool(x["exactIdentityMembers"]) for x in data)}',flush=True)
    for row in data:
        if not row['exactIdentityMembers']:
            print('  reconcile:', row['path'],','.join(row['receiptMentions'][:3]),flush=True)
    previous=current
pathlib.Path(sys.argv[1]).write_text(json.dumps(all_paths,ensure_ascii=False,indent=2))
