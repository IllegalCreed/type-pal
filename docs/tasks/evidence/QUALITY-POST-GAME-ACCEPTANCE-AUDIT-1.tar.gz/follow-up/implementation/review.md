# Reforge 音频实现复审

范围为 BGM、试听传输器和共用 MIDI 初始化。Game 收口后 e47880b0a 加入的战斗音乐预取也在本次实际调用读域内。E2E 仍持有主装配和菜单发布证据，音频实现由本轮 Codex 单写入。未扩展到编辑器试听形态、游戏机制或第三方生成物。

| 维度 | BGM | MIDI 试听 | 共用浏览器初始化 |
|---|---|---|---|
| A 正确性 | battle-host 的 prepare 捕获 signal，入场完成后调用提交；同曲接管、停与取消各自经过既有代次 | 先检查曲目和已准备字节，resume 和 init 后分别检查播放代次 | 只在可用 worklet 中加载，音色库失败保留原因并销毁已创建 synth |
| B 注释 | 去任务号与重复的上游说明。保留首段静音、同曲接管、gain 恢复及缓存失败的理由 | 代码区分浏览器适配器和传输器，注释明确可视化是音符活动 | 注释清楚指出共享音色库和合成器，成功值归调用方 |
| C 内聚 | 选曲、听见的曲和后端初始化三种职责。后端对象已足以表示后端就绪 | 选择和播放代次分别归 load/play，试听宿主拥有 context 与 synth | 共同代码只创建和初始化 synth，不调度播放，不保存宿主选择 |
| D 复用 | 两次 gain 定锚的取消和 setValueAtTime 原样共享。停止、静音、销毁保持独立合同 | 复用实际的 SpessaSynth 初始化，缺浏览器时由试听报错 | 两个消费者的 worklet、音色角色、RIFF 魔数与 CC91 是同一合同 |
| E 证据 | 旧语义据原专测、正式调用与冻结差异；此轮 29 项 BGM 回归验证重构 | 现有 10 项 browser-runtime 验证初始化失败、迟到释放及重复初始化的宿主范围 | 以真实两消费者和包的 WorkletSynthesizer 类型、实现为判定 |
| F 表达 | requestedTrack 和 playingAsset 清楚表达未发生与已发生的不同身份 | loadPromise、playPromise、loadedKey 分别定位不同状态 | 初始化函数名表示返回已初始化 synth；调用者专属命名 main、preview |
| G 简洁 | 删除只与后端指针同时置位的 ready、去同义判断，初始化保证仍由同一 Promise 缓存 | duration 接口的现有留项继续复核。请求与播放代次的用途不同，有正当拆分理由 | 未引入统一 orchestrator、模式参数或额外调用层 |
| H 可测性 | runtime 接口依旧能注入独立 context 与定序器。主游戏与战斗试玩的入口不变 | 两个可控后端与独立资源读端口，能模拟选择期间切换 | 可由浏览器宿主独立验证两种生命周期，从初始化唯一公共出口移交 |

## 资源所有权留项

spessasynth_lib 4.3.6 固定依赖的 dist/index.js.map 含 ../src/synthesizer/worklet/worklet_synthesizer.ts。destroy 发送 destroyWorklet、断开 AudioWorkletNode、删除内部 worklet 持有。共享初始化只会在自身失败时调用它。试听负责初始化完成后的正常和迟到释放。BGM 的浏览器适配器只关闭 context，取得 synth 后发现已释放也直接抛错。源码显示缺少显式销毁，尚无真实浏览器堆对象或释放观测。bgm.ts 保持 review。

## 复验边界

基点取 runs.json。Git 差异显示后端引用与 ready 唯一成功写点重合，退役布尔值后所有读取改用同一引用。私有 gain 定锚两行原样移动，外部 fadeTo 和 cancelFade 调用保持。battle-simulator-runtime-mutants 引用的 dispose 生产锚保持。相邻专测只改两行注释。运行原件按该次候选绑定，旧文件验收原始结果仍保留原执行身份。
