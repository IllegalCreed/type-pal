# Game 后关闭复查与窄返工

基点 a11fe2b0246e96426d16041b42a6e40818ae6c8c。最新 origin/main 为 bfd5b5c4c179268a8dacedd42ac4adb651149652。实际分支 codex/code-quality-94-102。单一 Coding Owner Codex。主工作树无写入。

## 复核路径

1. 首轮按原档 trace-review.py 重放六次合入的 374 个关闭路径，以 Git blob 固定各时点。scan-claims.cjs 读取冻结 blob、提取字面测试声明及直接写调用。命中的措辞和命名只是读域线索。它不能发现经别名转发的写点、动态标题或没有标题提示的语义缺口。
2. 结构化结果有 1,403 个字面测试声明，71 个文件 133 条线索。生命周期 86、输入不变性 48，1 条同时命中。直接写或删除有 4 个文件的 5 个表达式，其中一份是临时 PAL 夹具。另人工对照迁移发布命令的 materializePalAssets、commitMigrationTransaction 与未传 --write 时的恢复调用。
3. 下列基线证据带可观察的具体结果，按其实际范围沿用。未开展六次合并的全量逐文件八维重做。后续发现同类错放时，扩查受影响组内的同类声明，避免用测试数量、退出码或指纹替代事实核验。

## 同类复核锚点

- Content 的 actor-validation、world-script-state、projected-script-validation 和 enemy-ai-condition-guard 的拒绝用例快照取自被调用的那份输入，非有限值仍由共用深快照保留。world-variable.boundaries 实际互改两份运行数据及作者定义。entity-lifecycle 的第三个合法对象不能支撑两个失败输入的不变性，已直接补齐。
- Editor 的 frame-animation-worker-client 两个请求均已发给各自的 Worker，错误身份消息后检查两个任务均未结束，再取得不同字节结果并确认各自释放。frame-animation-draft 的异常保留错误身份及真实输入值，project-copy 同时观察源文件表、真实写入操作轨迹和目标内容。asset-catalog-commands 的原测试仅比相同引用，已补快照。
- Reforge 的 fade-driver 旧信号与旧 owner 两条先让新请求进入在途，再检查它仍可结束。scene-switch-transaction 用真正的驱动制造两个所有者的交叠，检查当前值、接管和提交队列。project-image-cache 的新旧同键解码各自有门槛，后继同键请求必须取得替代 Promise。fsa-source 用中断的真实读阶段、AbortError 与后续 I/O 不发生核同行为。
- Reforge 的 MIDI 试听从两个不同输入的解码时长、发布字节和最终可观察状态证明后到结果有效。销毁 BGM 专测有实读前置、同输入正控与独立释放计时器回归。BGM 预取专项报错由回执中的弱/强反控确定。实际分工是 prepare 获得可提交的执行函数、play 持有当前曲和请求代次。
- Migrate 的发布和 PAL 资产已有全部路径预检、晚路径链接、替换中读、真正字节与无写入观察。bake-assets 先检查全部固定引擎输出；运行时资产发布及引擎素材生成的原证据保持各自适用边界。另两个工具的固定目的地此前只有正常生成证明，本轮补上真实未改外部字节的拒绝合同。

## 逐文件裁定

A 正确性和边界。B 注释。C 职责和状态归属。D 复用。E 测试判别力。F 命名与可读性。G 多余部分。H 可测试性。

| 路径 | A | B | C | D | E | F | G | H |
|---|---|---|---|---|---|---|---|---|
| packages/content/src/entity-lifecycle.test.ts | 保存解码走 normalizeEntityLifecycleTable，未知场景、实体各有精确路径 | 拒绝标题和实际不变性一致 | 独立成功归一归属 | 复用一份合法参考索引 | 修改拒绝输入仍抛相同错时出现单红 | 测试名区分拒绝与合法副本 | 去掉成功断言给失败标题背书的混合用例 | 小字面对象可比，无 IO |
| packages/reforge/src/scene-preflight.chain.test.ts | main 函数调用真实 ScenePreparer，观察完整无脚本 WorldState 与继承过场 | 标题所称的 world 都比较 | 预检与提交职责分离 | 相邻 ScenePreparer 正例继续负责完整装配 | 专改无关 money，合法计划仍通过而快照单红 | 保留实际 `script` 语义的测试名 | 移除已由全量快照覆盖的字段断言 | 可控资产端口和真实生产调用可分开观察 |
| packages/migrate/src/pal-content-supply.pal.test.ts | 使用真实来源载入、构建发布与隔离重导。独立摘要覆盖全部来源含二进制内存值 | 区分内存来源和磁盘资源 | 发布映射、当前 baseline 和真实文件事务各负其责 | 复用现行来源、摘要及发布入口 | 已核地图/别名/角色/回调/消息现有判别，本轮补完整来源无写入 | 仍按 PAL 供应分类，快照局部名有范围 | 删两份手选字段和重复序列化器代码 | Node 序列化保留 typed array 与普通值，来源文件由既有依赖载入 |
| packages/migrate/scripts/generate-project-battle-placeholders.mts | 固定两目标均预检才建目录，正常 107 字节对应当前目录登记 | 注释说明为何先核两处 | 素材编码留在脚本，所有权检测交既有路径层 | 复用 Shared RLE 和 assertMigrationFilePath | 真实命令两红及普通输出字节，恢复后通过 | 具名 outputs 表达固定两处 | 省去直接构造并写任一绝对目标 | 隔离根可调用未改 CLI |
| packages/migrate/scripts/preview-fbp.mts | 缺省输出守卫，显式输出由命令调用者指定 | 可选参数与缺省责任准确 | PNG I/O 在 CLI，indexed RGBA 和边界检查各归一处 | 共用色彩转换与同一迁移路径守卫 | 真 PAL 命令覆盖外部标记，正式夹具红例及实际颜色/覆盖外字节绿 | 仍用 FBP 和明确 `dst` | 只替换实际失去所有权的缺省表达式 | 不启动游戏可运行 |
| packages/migrate/src/battle-placeholder-generator.test.ts | 真实 tsx、第二个目标两类链接、先前正常产物保留 | 简洁标题说明观察的每个目的地 | 生成器的写入合同及两个目录 byte-for-byte | 复用本轮 CLI 宿主和临时文件设施 | 两个异常分别实际覆盖外部见证，旧版本仅正常例通过 | 文件名及标题说清正常/失败职责 | 无重复 fake path checker | 真实隔离目录，清理和实现导入分开 |
| packages/migrate/src/preview-fbp.test.ts | 读取合法 indexed PNG 及调色板，缺省和显式路由真实运行 | 说明默认失败和实际像素位置 | 一份预览专测不夹占位编码 | 同一入口宿主与 PAL PNG 夹具 | 外部字节断言先于退出码，正常 oracle 是独立固定 RGBA 值 | 文件名对应实际工具 | 共享同形正控参数，只有一条链接例 | 每次独立目录和源图片 |
| packages/migrate/src/__tests__/migration-cli-fixture.ts | 复制原脚本与其静态依赖到测试自有临时根，发给真实 tsx 并返回退出 | 注释说清用途和生命周期 | 只持有子进程入口和 test fixture 清理，oracle 在各专测 | 两个直接测试消费者共用 | 真实退出码、错误、信号及结果 stdout/stderr 均传回 | migrationCliFixture 反映工程级命令 | 不模拟参数，也不引入产品导出 | 输入脚本、依赖与 args 显式 |
| packages/reforge/src/audio/bgm.test.ts | 消费真实 prepare 的 commit，与当前曲同时发生 | 注释说明原读结果与播放续体差异 | 落盘只模拟端口，BGM 真实决策保留在实现 | 沿用同组 sequencer/reader/runtime 和计时器技术 | 去 abort guard 后旧用例绿、新断言只此一红，原曲与晚到曲 AssetId 不同 | 原身份与职责不变 | 一次排尽下一轮续体，未增加固定延迟 | 假 timer 收口后恢复真实 timer |
| packages/editor/src/core/asset-catalog-commands.test.ts | 真实合法工程经 EditSession 调用，保留原拒绝和回退状态 | unchanged 既比引用也比数据 | 临时读取层归 fixture，历史由 EditSession 观察 | 沿用 portraitProject、内容索引和真实命令 | 原地改 label 仍抛原错，只有快照单红；合法正控不变 | 文件名与业务名分明 | 不重复新增失败身份 | 独立快照与真正的引用 provider |
| packages/reforge/src/menu/item-use-session.ts | main 各自持有实例，菜单据 pending 拦输入，取消只撤本实例 | 模块头明确等待原操作 settle 再释放占位 | pending 是占有权，controller 是取消权，两个生命周期可独立 | 一份私有类由真菜单合测，不通用化到加载意图 | 真实菜单、取消到 settle、错误身份及补强后的两实例反控 | pending/cancel/run 均可从调用点核语义 | 保留现有分开持有与等价清理；finally 的身份判断可独立简化，目前有其他表达方式可选 | 入口接受注入操作和实际信号，可排两个时序 |
| packages/reforge/src/menu/item-use-session.test.ts | 新候选有两个同时在途的真实类实例 | 新标题描述实际触发 | 取消 A 时 B 的 controller 和占位分别观察 | 与既有真实菜单同跑，复用 deferred | 静态共享 controller 旧测试 3/3、更新后特定 1 红，关闭信用仍待真实绑定 | 测试标题在途及各实例分明 | 替换旧弱例，例数不增 | 两道 gate 在 finally 都释放；当前发布证据由 E2E 持有，补丁单独保存 |

## 留项和恢复

- 物品操作专测及其完整文件 SHA 固定在 docs/testing/catalog.json 与菜单报告的现行 evidence。活动 E2E 分支仍修改该域。item-use-session-test.patch 是相对 a11fe2b02 文件的试验补丁，可用 git apply --check 先核。E2E 合入后核现行 sourceRefs 和真实菜单入口，再应用并更新准入，核剩余的两实例证据。
- 两个工具的本地路径预检沿用现有守卫。未改变显式指定目的地的契约。没有模拟系统级写入错误的全量回滚或跨进程写入锁。
- 局部 typecheck 首次暴露 Content 栈没有 structuredClone 的全局类型，最终用精确业务字面量比较。首次 preflight 反控镜像缺 TS 解析依赖，PAL 反控镜像缺只读 soundfont。原件与真实业务反控分别归档。
- 从原 tar 读取 trace-review.py 到临时目录，用脚本生成 closed.json，再从治理树根用 Node 运行 scan-claims.cjs closed.json 临时输出路径。file JSON 与 stdout 能重查原始结果。运行身份取 runs.json 与实际输出。当前目标集中于已有关闭信用的纠偏，仓库重型检查、官方覆盖率、protected 和 GitHub PR 等稳定窗口执行。
