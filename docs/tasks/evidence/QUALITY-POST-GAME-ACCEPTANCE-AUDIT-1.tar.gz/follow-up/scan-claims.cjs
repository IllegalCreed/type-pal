const { execFileSync } = require('node:child_process')
const { readFileSync, writeFileSync } = require('node:fs')
const { resolve } = require('node:path')
const ts = require(require.resolve('typescript', { paths: [process.cwd()] }))
const rows = JSON.parse(readFileSync(process.argv[2], 'utf8'))
const revisions = { 68: '778928d19', 69: '701b34334', 70: 'c08cdc3ed', 71: 'dc745c127', 72: 'b3f610456', 73: 'bfd5b5c4c' }
const caseRoot = /^(?:test|it|describe)(?:\.(?:each|only|skip|todo|concurrent|sequential|skipIf|runIf|for))*$/
const asyncClaim = /\b(?:abort\w*|cancel\w*|in[- ]flight|stale|settle\w*|supersed\w*|late|obsolete|foreign reply|independent requests|overlap\w*|pending\b|dispos\w*)|取消|迟到|未决|接管|归属/i
const immutableClaim = /\b(?:without (?:mutat|writ|replac)|does not (?:mutat|writ|overwrit)|leav\w*\b.*\b(?:untouched|unchanged)|unchanged|read[- ]only|non[- ]mutat\w*|does not modify)|不变|只读|不改|不污染/i
const outputName = /(?:^|[.\-_/])(?:glm|grok|kimi|haiku|sonnet|gemini|opus|claude|gpt|codex|audit\d+|cov\d+|r[123]|next-wave)(?=$|[.\-_/])/i
const outcomes = []
let tests = 0
function calleeName(expression, file) {
  if (ts.isCallExpression(expression) || ts.isTaggedTemplateExpression(expression))
    return calleeName(expression.expression ?? expression.tag, file)
  return expression.getText(file)
}
for (const row of rows) {
  // The accepted blob is the source of truth for claims at the review time.
  const source = execFileSync('git', ['cat-file', 'blob', row.acceptedBlob], { encoding: 'utf8' })
  const file = ts.createSourceFile(row.path, source, ts.ScriptTarget.Latest, true)
  const matches = []
  const suppressed = []
  const writeSites = []
  function visit(node) {
    if (ts.isCallExpression(node)) {
      const callee = calleeName(node.expression, file)
      const title = node.arguments[0]
      if (row.path.endsWith('.test.ts') && caseRoot.test(callee) && title &&
        (ts.isStringLiteral(title) || ts.isNoSubstitutionTemplateLiteral(title))) {
        if (!callee.startsWith('describe')) tests++
        const start = file.getLineAndCharacterOfPosition(node.getStart(file)).line + 1
        const end = file.getLineAndCharacterOfPosition(node.end).line + 1
        if (/\.(?:only|skip|todo)(?:\.|$)/.test(callee)) suppressed.push({ start, callee, title: title.text })
        const axes = [asyncClaim.test(title.text) && 'lifecycle', immutableClaim.test(title.text) && 'immutability'].filter(Boolean)
        if (axes.length && !callee.startsWith('describe')) matches.push({ start, end, title: title.text, axes })
      }
      if (!row.path.endsWith('.test.ts') && /(?:^|\.)(?:writeFileSync|writeFile|appendFileSync|appendFile|renameSync|rename|unlinkSync|rmSync)$/.test(callee)) {
        writeSites.push({ line: file.getLineAndCharacterOfPosition(node.getStart(file)).line + 1, callee })
      }
    }
    ts.forEachChild(node, visit)
  }
  if (/\.[cm]?[jt]sx?$/.test(row.path)) visit(file)
  outcomes.push({ path: row.path, pr: row.pr, revision: revisions[row.pr], namingSignal: outputName.test(row.path), matches, suppressed, writeSites })
}
for (const key of ['matches','suppressed','writeSites']) {
  const hits = outcomes.filter(row => row[key].length)
  process.stdout.write(key + ' ' + hits.length + ' files, ' + hits.reduce((n,row) => n+row[key].length,0) + ' entries\n')
  for (const row of hits) for (const hit of row[key]) {
    process.stdout.write(JSON.stringify([row.pr,row.path,hit])+'\n')
  }
}
process.stdout.write('files: ' + outcomes.length + ', tests with literal names: ' + tests + '\n')
process.stdout.write('non-semantic-name candidates: ' + JSON.stringify(outcomes.filter(r=>r.namingSignal).map(r=>r.path))+'\n')
writeFileSync(resolve(process.argv[3]),JSON.stringify(outcomes,null,2)+'\n',{flag:'wx'})
