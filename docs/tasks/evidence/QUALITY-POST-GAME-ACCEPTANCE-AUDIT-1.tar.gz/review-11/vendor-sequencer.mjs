import assert from 'node:assert/strict'
const { Sequencer } = await import('spessasynth_lib')
const registrations = new Set()
globalThis.window = Object.assign(new EventTarget(), {
  addEventListener(kind, callback) {
    if (kind === 'beforeunload') registrations.add(callback)
  },
  removeEventListener(kind, callback) {
    if (kind === 'beforeunload') registrations.delete(callback)
  },
})
const synth = {
  currentTime: 0,
  assignNewSequencer: () => 0,
  post() {},
  stopAllChannels() {},
}
const sequencer = new Sequencer(synth, { skipToFirstNoteOn: false })
sequencer.pause()
const result = {
  listenersAfterPause: registrations.size,
  dispose: typeof sequencer.dispose,
  destroy: typeof sequencer.destroy,
}
assert.deepEqual(result, { listenersAfterPause: 1, dispose: 'undefined', destroy: 'undefined' })
console.log(JSON.stringify(result))
