import assert from 'node:assert/strict'
import { execFileSync, spawnSync } from 'node:child_process'
import { createHash } from 'node:crypto'
import { readFileSync, rmSync, writeFileSync } from 'node:fs'
import { dirname, join, resolve } from 'node:path'

const root = process.cwd()
const snapshotPath = resolve(process.argv[2])
const receipt = dirname(snapshotPath)
const snapshot = readFileSync(snapshotPath)
const [base, tree] = readFileSync(join(receipt, 'ratchet-editor-gap.revisions'), 'utf8').trim().split('\n')
const digest = (data) => createHash('sha256').update(data).digest('hex')
const git = (...args) => execFileSync('git', args, { encoding: 'utf8' }).trim()

assert.equal(digest(snapshot), readFileSync(join(receipt, 'ratchet-editor-gap.sha256'), 'utf8').trim())
assert.equal(git('rev-parse', 'origin/main'), base)
assert.equal(git('rev-parse', 'HEAD^{tree}'), tree)
assert.equal(git('diff', '--name-only', tree, '--'), 'scripts/coverage/approved-baseline-adjustments.mjs')
assert.equal(git('ls-files', '--others', '--exclude-standard'), '')
assert.deepEqual(readFileSync('coverage/fast/summary.json'), snapshot)
assert.match(readFileSync(join(receipt, 'ratchet-editor-gap.stderr'), 'utf8'), /^\n\[coverage:fast\] FAIL\n覆盖率不得下降:\n- editor\.branches: 83\.76% \(25690\/30672\) < 83\.76% \(25691\/30672\)\n$/u)
assert.equal(readFileSync(join(receipt, 'ratchet-editor-gap.exit'), 'utf8').trim(), '1')

const script = 'scripts/coverage/run.mjs'
const source = readFileSync(script, 'utf8')
const collectStart = source.indexOf('  await rm(outputRoot, { recursive: true, force: true })')
const collectEnd = source.indexOf('  const total = aggregateMetrics', collectStart)
const time = '  const generatedAt = new Date().toISOString()\n'
assert(collectStart >= 0 && collectEnd > collectStart)
assert.equal(source.split(time).length, 2)
const generated = source.slice(0, collectStart) +
  `  const { packages, generatedAt } = await readJson(${JSON.stringify(snapshotPath)})\n` +
  source.slice(collectEnd).replace(time, '')

const temporary = join(root, dirname(script), `.review-coverage-${process.pid}.mjs`)
writeFileSync(temporary, generated, { flag: 'wx' })
try {
  const result = spawnSync(process.execPath, [temporary, 'fast', '--ratchet', '--allow-scope-removal'], {
    stdio: 'inherit',
    env: { ...process.env, TYPE_PAL_COVERAGE_BASE_REF: base },
  })
  if (result.error) throw result.error
  assert.equal(result.status, 0, 'Original ratchet comparator and writer rejected the completed collection')
  assert.deepEqual(readFileSync('coverage/fast/summary.json'), snapshot)
  console.log(`Reused unchanged V8 collection ${digest(snapshot)} from source tree ${tree}`)
  console.log(`Original comparator and writer source ${digest(source)}`)
} finally {
  rmSync(temporary)
}
