import assert from 'node:assert/strict'
import { execFileSync } from 'node:child_process'
import { createHash } from 'node:crypto'
import { existsSync, readFileSync } from 'node:fs'
import { join } from 'node:path'
import { pathToFileURL } from 'node:url'

const root = process.cwd()
const moduleUrl = (file) => pathToFileURL(join(root, 'scripts/coverage', file))
const { adjustApprovedBaseline } = await import(moduleUrl('approved-baseline-adjustments.mjs'))
const { isApprovedTestRetirement } = await import(moduleUrl('approved-test-retirements.mjs'))
const { auditScope } = await import(moduleUrl('inventory.mjs'))
const { compareCoverage } = await import(moduleUrl('metrics.mjs'))
const [base] = process.argv.slice(2)
const baselinePath = 'scripts/coverage/baseline.fast.json'
const protectedBaseline = JSON.parse(execFileSync('git', ['show', `${base}:${baselinePath}`], { encoding: 'utf8', maxBuffer: 8 * 1024 * 1024 }))
const candidate = JSON.parse(readFileSync(baselinePath))
const result = JSON.parse(readFileSync('coverage/fast/summary.json'))
assert.deepEqual(candidate.provider, protectedBaseline.provider)
assert.deepEqual(candidate.provider, result.provider)
assert.deepEqual(candidate.total, result.total)
assert.equal(candidate.testCount, result.testCount)
for (const [id, value] of Object.entries(candidate.packages)) assert.deepEqual(value.metrics, result.packages[id].metrics)
assert.deepEqual(auditScope(result, candidate).changes, [])
const {baseline, applied} = await adjustApprovedBaseline(protectedBaseline, (path) => readFileSync(path))
const comparison = compareCoverage(candidate, baseline, {allowNewPackages: true})
assert.deepEqual(comparison.regressions, [])
const scope = auditScope(candidate, protectedBaseline)
const entry = (snapshot, file) => Object.values(snapshot.packages).flatMap(pkg=>pkg.fastTests.fileEntries).find(row=>row.file===file)
for (const removal of scope.removals) {
  if (!existsSync(removal.value)) continue
  assert(removal.kind === 'test-file' || removal.kind === 'test-count', JSON.stringify(removal))
  assert(isApprovedTestRetirement({removal,
    previous: entry(protectedBaseline, removal.value),
    current: entry(candidate, removal.value),
    fileSha256: createHash('sha256').update(readFileSync(removal.value)).digest('hex'),
  }), JSON.stringify(removal))
}
console.log(JSON.stringify({base, testCount: result.testCount, applied, comparison, scope,
  total: result.total, packages: Object.fromEntries(Object.entries(result.packages).map(([id,pkg])=>[id,pkg.metrics]))},null,2))
