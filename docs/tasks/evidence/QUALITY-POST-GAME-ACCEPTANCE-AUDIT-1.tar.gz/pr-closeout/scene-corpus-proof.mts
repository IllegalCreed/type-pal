import assert from 'node:assert/strict'
import { execFileSync, spawnSync } from 'node:child_process'
import { readFileSync } from 'node:fs'
import { resolve } from 'node:path'
import { pathToFileURL } from 'node:url'

const root=process.cwd()
const { collectCommandTargetReferences }= await import(pathToFileURL(resolve(root,'packages/content/src/command-target-reference.ts')).href)
const { validateAuthorScenes, validateSceneIndex }= await import(pathToFileURL(resolve(root,'packages/content/src/index.ts')).href)
const [old,current]=process.argv.slice(2)
const sceneDirectory='projects/pal/content/scenes'
const changed=execFileSync('git',['diff','--name-only','--no-renames',old,current,'--',sceneDirectory],{encoding:'utf8'}).trim().split('\n').filter(Boolean)
const requested=changed.map(path=>`${old}:${path}`)
const raw=spawnSync('git',['cat-file','--batch'],{input:requested.join('\n')+'\n',maxBuffer:128*1024*1024})
assert.equal(raw.status,0)
let offset=0
const historical=new Map<string,Buffer>()
for(const path of changed){
  const newline=raw.stdout.indexOf(10,offset)
  assert(newline>offset)
  const [oid,kind,size]=raw.stdout.subarray(offset,newline).toString().split(' ')
  assert(oid&&kind==='blob'&&Number.isSafeInteger(Number(size)),path)
  const end=newline+1+Number(size)
  historical.set(path,raw.stdout.subarray(newline+1,end))
  offset=end+1
}
assert.equal(offset,raw.stdout.length)
function summarize(useOld:boolean){
  const read=(path:string)=>{
    const local='projects/pal/'+path
    return JSON.parse((useOld?historical.get(local)??readFileSync(local):readFileSync(local)).toString())
  }
  const index=validateSceneIndex(read('content/scenes/index.json'))
  const scenes=validateAuthorScenes(index.scenes.map(entry=>read(entry.path)))
  const rows=scenes.map((scene)=>{
    const refs=collectCommandTargetReferences(scene,`scene:${scene.id}`)
    const count=refs.filter(({target})=>{
      if(target.kind==='scene') return target.id===scene.id
      if(target.kind==='scene-entry'||target.kind==='scene-hook'||target.kind==='entity') return target.sceneId===scene.id
      return false
    }).length
    return {id:scene.id,count}
  })
  const onEnter = (scene: (typeof scenes)[number]) => Object.entries(scene.hooks?.onEnter?.variants ?? {})
  const entryLocations = scenes.flatMap(scene => onEnter(scene).flatMap(([variant, hook]) =>
    hook.flow.stages.filter(stage => stage.entry !== undefined).map(stage =>
      `${scene.id}/onEnter/${variant}/${stage.id} ${stage.entry.reveal.kind}`,
    ),
  )).sort()
  function hasDither(node: unknown): boolean {
    if (Array.isArray(node)) return node.some(hasDither)
    if (node === null || typeof node !== 'object') return false
    if ('kind' in node && node.kind === 'ditherScreen') return true
    return Object.values(node).some(hasDither)
  }
  const usesOrdinaryOnEnterDither = scenes
    .filter(scene => !entryLocations.some(location => location.startsWith(`${scene.id}/`)))
    .filter(scene => onEnter(scene).some(([, hook]) => hasDither(hook.flow.stages)))
    .map(scene => scene.id).sort()
  return {scenes:scenes.length,withSelf:rows.filter(({count})=>count>0).length,
    largest:rows.sort((a,b)=>b.count-a.count).slice(0,5),entryLocations,usesOrdinaryOnEnterDither}
}
console.log(JSON.stringify({old,current,changedScenes:changed.length,before:summarize(true),after:summarize(false)},null,2))
