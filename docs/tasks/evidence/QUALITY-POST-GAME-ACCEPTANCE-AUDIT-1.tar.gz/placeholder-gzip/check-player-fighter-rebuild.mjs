import assert from 'node:assert/strict'
import { spawnSync } from 'node:child_process'
import { createHash } from 'node:crypto'
import { copyFileSync, mkdirSync, mkdtempSync, readFileSync, rmSync, symlinkSync } from 'node:fs'
import { createRequire } from 'node:module'
import { dirname, join, resolve } from 'node:path'
import { gunzipSync } from 'node:zlib'

const repo = process.cwd()
const preloader = resolve(process.argv[2])
const root = mkdtempSync(join(dirname(preloader), 'rebuild-'))
const generator = 'packages/migrate/scripts/generate-project-battle-placeholders.mts'
const guard = 'packages/migrate/src/migration-path.ts'
const assetPath = 'assets/generated/battle-sprites/player-fighter.rle'
const tsx = createRequire(join(repo, 'package.json')).resolve('tsx/cli')
const digest = (bytes) => createHash('sha256').update(bytes).digest('hex')

try {
  for (const file of [generator, guard]) {
    mkdirSync(dirname(join(root, file)), { recursive: true })
    copyFileSync(join(repo, file), join(root, file))
  }
  symlinkSync(join(repo, 'packages/migrate/node_modules'), join(root, 'packages/migrate/node_modules'), 'dir')

  const evidence = []
  const builds = [
    { id: 'native', env: process.env },
    { id: 'linux-os-byte-only', env: { ...process.env, NODE_OPTIONS: `--require=${preloader}` } },
  ]
  for (const { id, env } of builds) {
    const args = [tsx, join(root, generator)]
    const result = spawnSync(process.execPath, args, { cwd: root, env, encoding: 'utf8' })
    if (result.error) throw result.error
    assert.equal(result.signal, null)
    assert.equal(result.status, 0, result.stderr)
    assert.equal(result.stderr, '')
    const outputs = []
    for (const project of ['demo', 'e2e-own']) {
      const path = join('projects', project, assetPath)
      const published = readFileSync(join(repo, path))
      const generated = readFileSync(join(root, path))
      assert.deepEqual(generated, published)
      assert.deepEqual(gunzipSync(generated), gunzipSync(published))
      const catalog = JSON.parse(readFileSync(join(repo, 'projects', project, 'assets/index.json'), 'utf8'))
      const record = Object.values(catalog.assets).find((item) => item.path === assetPath)
      assert.equal(record?.sha256, digest(generated))
      assert.equal(record?.bytes, generated.length)
      outputs.push({ path, bytes: generated.length, os: generated[9], sha256: record.sha256 })
    }
    evidence.push({ id, command: [process.execPath, ...args], cwd: root, status: result.status, signal: result.signal, stdout: result.stdout, stderr: result.stderr, outputs })
  }
  console.log(JSON.stringify({ node: process.version, platform: process.platform, zlib: process.versions.zlib, generatorSha256: digest(readFileSync(join(repo, generator))), builds: evidence }, null, 2))
} finally {
  rmSync(root, { recursive: true, force: true })
}
