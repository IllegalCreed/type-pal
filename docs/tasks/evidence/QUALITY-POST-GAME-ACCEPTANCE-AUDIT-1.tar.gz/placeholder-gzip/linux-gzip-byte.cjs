const { syncBuiltinESMExports } = require('node:module')
const zlib = require('node:zlib')

if (process.argv.some((arg) => arg.endsWith('/generate-project-battle-placeholders.mts'))) {
  const nativeGzip = zlib.gzipSync
  zlib.gzipSync = (...args) => {
    const encoded = nativeGzip(...args)
    if (encoded[3] !== 0) throw new Error('Expected the default gzip header without optional fields')
    encoded[9] = 3
    return encoded
  }
  syncBuiltinESMExports()
}
