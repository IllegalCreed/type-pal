import { readFileSync } from 'node:fs'
import { resolve } from 'node:path'

const anchor = '  return loadProjectMap(project.assetBase, asset.path)'
const replacement = "  return loadProjectMap(project.assetBase, asset.path).catch(() => loadProjectMap(project.assetBase, 'content/maps/map-001.json'))"
const product = resolve('src/project-loader.ts')
export default {
  plugins: [{
    name: "map-counter-error",
    enforce: 'pre',
    load(id) {
      if (id.split('?')[0] !== product) return
      const source = readFileSync(product, 'utf8')
      if (source.split(anchor).length !== 2) throw new Error('counter site identity mismatch')
      return source.replace(anchor, replacement)
    },
  }],
  test: { maxWorkers: 1 },
}
