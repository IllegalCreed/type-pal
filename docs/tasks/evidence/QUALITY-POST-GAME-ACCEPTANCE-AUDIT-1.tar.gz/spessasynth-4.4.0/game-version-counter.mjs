import { readFileSync } from 'node:fs'
import { resolve } from 'node:path'
const file = resolve("src/shell/audio-midi.ts")
const before = "    processor.searchParams.set('v', spessaPackage.version)\n"
export default {
  test: { maxWorkers: 1 },
  plugins: [{
    name: 'unversioned-worklet-probe',
    enforce: 'pre',
    load(id) {
      if (id.split('?')[0] !== file) return
      const text = readFileSync(file, 'utf8')
      if (text.split(before).length !== 2) throw new Error('worklet version site does not match')
      return text.replace(before, "")
    },
  }],
}
