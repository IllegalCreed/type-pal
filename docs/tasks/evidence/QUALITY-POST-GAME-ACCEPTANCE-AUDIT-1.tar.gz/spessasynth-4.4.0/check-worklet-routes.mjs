import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { readFileSync } from 'node:fs'
import { createRequire } from 'node:module'
import { join, resolve } from 'node:path'
import { pathToFileURL } from 'node:url'

const [repo, dist] = process.argv.slice(2)
for (const app of ['game', 'reforge', 'editor']) {
  const root = resolve(repo, 'packages', app)
  const from = createRequire(join(root, 'package.json'))
  const { preview } = await import(pathToFileURL(from.resolve('vite')))
  const vite = await preview({
    root,
    build: { outDir: join(dist, app) },
    preview: { host: '127.0.0.1', port: 0, strictPort: true },
  })
  try {
    const url = '/spessasynth_processor.min.js?v=4.4.0'
    const { port } = vite.httpServer.address()
    const response = await fetch(`http://127.0.0.1:${port}${url}`)
    assert.equal(response.status, 200)
    assert.match(response.headers.get('content-type') ?? '', /javascript/u)
    const bytes = Buffer.from(await response.arrayBuffer())
    const owner = app === 'editor' ? 'reforge' : app
    assert.deepEqual(bytes, readFileSync(join(repo, 'packages', owner, 'public', url.split('?')[0])))
    console.log(JSON.stringify({ app, url, status: response.status, mime: response.headers.get('content-type'),
      sha256: createHash('sha256').update(bytes).digest('hex') }))
  } finally {
    await vite.close()
  }
}
