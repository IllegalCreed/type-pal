import assert from 'node:assert/strict'
import {execFileSync} from 'node:child_process'
import {existsSync, readFileSync} from 'node:fs'
import {pathToFileURL} from 'node:url'
const docTool=(path)=>pathToFileURL(process.cwd()+'/scripts/docs/'+path)
const {localTarget, taskInfo}=await import(docTool('check.mjs'))
const {markdownLinks}=await import(docTool('markdown.mjs'))
const card='docs/tasks/cards/QUALITY-REFORGE-PRESENTATION-1.md'
const docs=['docs/phase1/engineering-notes.md','docs/tasks/audits/code-quality-file-ledger.md','docs/tasks/board.md',card]
const rows=[]
for (const file of docs) {
 const prior=new Set(markdownLinks(execFileSync('git',['show',`HEAD:${file}`],{encoding:'utf8'})).map(({target})=>target))
 const after=readFileSync(file,'utf8')
 assert.equal(after.includes('game-midi-worklet.test.mjs'),false,file)
 const links=markdownLinks(after).map(({target})=>target).filter(target=>!prior.has(target))
 for(const link of new Set(links)) {
   const target=localTarget(file,link)
   if (!target) continue
   execFileSync('git',['ls-files','--error-unmatch','--',target])
   assert(existsSync(target),`${file}: ${link}`)
   if(link.includes('#spessasynth-配套升级与真实退出'))
     assert(readFileSync(target,'utf8').includes('### SpessaSynth 配套升级与真实退出'),target)
 }
 rows.push({file,newTargets:[...new Set(links)]})
}
assert.equal(taskInfo(card,readFileSync(card,'utf8')).status,'review')
console.log(JSON.stringify({scope:'affected local links, task status, and retired guard path',rows,issues:[]},null,2))
