import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { readdirSync, readFileSync } from 'node:fs'
import { createRequire } from 'node:module'
import { join, resolve } from 'node:path'
import { pathToFileURL } from 'node:url'

const [currentRepo, previousOwner, currentCoreVersion = '4.4.0'] = process.argv.slice(2)
async function loadCore(owner, version) {
  const from = createRequire(resolve(owner, 'package.json'))
  assert.equal(from('spessasynth_core/package.json').version, version)
  return (await import(pathToFileURL(from.resolve('spessasynth_core')))).BasicMIDI
}

const previous = await loadCore(previousOwner, '4.3.20')
const current = await loadCore(join(currentRepo, 'packages/reforge'), currentCoreVersion)
const dir = join(currentRepo, 'projects/pal/assets/migrated/music')
const names = readdirSync(dir).filter((name) => /^\d{3}\.mid$/u.test(name)).sort()
assert.equal(names.length, 86)
const hash = (bytes) => createHash('sha256').update(bytes).digest('hex')
const scores = names.map((name) => {
  const bytes = readFileSync(join(dir, name))
  const buffer = () => bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength)
  const oldSong = previous.fromArrayBuffer(buffer(), name)
  const newSong = current.fromArrayBuffer(buffer(), name)
  const oldNotes = oldSong.getNoteTimes().flat()
  const newNotes = newSong.getNoteTimes().flat()
  assert.equal(newSong.duration, oldSong.duration, name)
  assert.deepEqual(newNotes, oldNotes, name)
  return { name, inputSha256: hash(bytes), duration: newSong.duration, notes: newNotes.length,
    noteEventsSha256: hash(JSON.stringify(newNotes)) }
})
console.log(JSON.stringify({ previous: '4.3.20', current: currentCoreVersion, scores }, null, 2))
