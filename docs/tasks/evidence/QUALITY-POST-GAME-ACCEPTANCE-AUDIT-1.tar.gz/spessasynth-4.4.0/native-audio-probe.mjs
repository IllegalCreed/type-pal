import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { readFileSync, realpathSync } from 'node:fs'
import { createRequire } from 'node:module'
import { createServer as reserveSocket } from 'node:net'
import { join } from 'node:path'
import { pathToFileURL } from 'node:url'

const [rootArg, mode, candidateModules, browserExecutable, legacyFile] = process.argv.slice(2)
const root = realpathSync(rootArg)
const editorRoot = join(root, 'packages/editor')
const requireEditor = createRequire(join(editorRoot, 'package.json'))
const requireRoot = createRequire(join(root, 'package.json'))
const { createServer } = await import(pathToFileURL(requireEditor.resolve('vite')))
const { chromium } = requireRoot('playwright')
assert(['baseline', 'preflight', 'installed'].includes(mode))
const legacyBytes = legacyFile ? readFileSync(legacyFile) : undefined
const aliases = {}
if (mode === 'preflight') {
  const requireCandidate = createRequire(join(realpathSync(candidateModules), '../package.json'))
  for (const id of ['spessasynth_lib', 'spessasynth_core'])
    aliases[id] = requireCandidate.resolve(id)
}
const asset = (path) => JSON.stringify('/@fs' + join(root, path))
const entryPath = join(editorRoot, 'src/__temporary_native_midi_probe.ts')
const moduleUrl = '/__temporary_native_midi_probe.ts'
const entry = `
import { createElement } from 'react'
import { createRoot } from 'react-dom/client'
import { createMusicSourceController } from ${asset('packages/game/src/shell/music-source.ts')}
import { createSpessaSynthBackend } from ${asset('packages/game/src/shell/audio-midi.ts')}
import { createRixBackend } from ${asset('packages/game/src/shell/audio-rix.ts')}
import { httpSource } from ${asset('packages/reforge/src/file-source.ts')}
import { loadCurrentProjectFrom } from ${asset('packages/reforge/src/project-loader.ts')}
import { runBattleTrial } from ${asset('packages/reforge/src/battle-trial-host.ts')}
import { battleTrialRevision } from ${asset('packages/reforge/src/battle-trial-prepare.ts')}
import { assertProjectSaveReadable } from ${asset('packages/reforge/src/project-save-state.ts')}
import { analyzeMidiBytes } from ${asset('packages/reforge/src/audio/midi-preview.ts')}
import { ProjectAudioPreviewButton } from ${asset('packages/editor/src/ui/ProjectAudioPreviewButton.tsx')}
import { createEditorAssetReader } from ${asset('packages/editor/src/core/editor-asset-reader.ts')}

const target = new URLSearchParams(location.search).get('target')
const go = document.getElementById('go')
const swap = document.getElementById('swap')
const exit = document.getElementById('exit')
const probe = globalThis.__probe = {}
if (target === 'game') {
  let controller
  go.onclick = () => {
    controller = createMusicSourceController(
      (source) => source === 'rix'
        ? createRixBackend('/extracted')
        : createSpessaSynthBackend({
            baseUrl: '/extracted', workletUrl: '/spessasynth_processor.min.js', soundfontUrl: '/soundfont.sf3',
          }),
      'midi',
    )
    controller.setVolume(0.5)
    controller.play(1, true)
    controller.resume()
  }
  swap.onclick = () => controller.setSource('rix')
  exit.onclick = () => controller.dispose()
  probe.status = () => controller?.getState()
} else {
  const project = await loadCurrentProjectFrom(httpSource('/projects/pal'))
  if (target === 'trial') {
    const [sourceToken, revision] = await Promise.all([
      assertProjectSaveReadable(project.source), battleTrialRevision(project),
    ])
    go.onclick = () => {
      probe.exited = false
      const signal = new AbortController().signal
      void runBattleTrial(project, {
        party: { members: [{
          actorId: 'li-xiaoyao', stats: {}, equipment: {}, skills: { kind: 'inherit' },
          hp: { kind: 'full' }, mp: { kind: 'full' },
        }] },
        enemies: { kind: 'team', teamId: 'team-1' },
        bag: { items: [] },
        fieldId: 6, music: { kind: 'asset', assetId: 'music.pal.001' },
        money: 0, auto: false, boss: false,
      }, {
        sourceToken, revision, signal, onRestart() {},
      }).finally(() => { probe.exited = true })
    }
  } else if (target === 'editor') {
    const reader = createEditorAssetReader(project.source, {
      manifest: project.manifest, assetCatalog: project.assetCatalog, assetBlobs: {},
    })
    probe.timeline = await analyzeMidiBytes(await reader.readBytes('music.pal.001', 'music'))
    let mounted
    go.onclick = () => {
      mounted = createRoot(document.getElementById('preview'))
      mounted.render(createElement(ProjectAudioPreviewButton, {
        asset: 'music.pal.001', label: 'PAL 001', kind: 'music', cacheKey: 'native-probe', reader,
      }))
    }
    exit.onclick = () => mounted.unmount()
  }
}
probe.ready = true
`
const diagnostics = []
const reports = {}
let workletSha256
const hash = (bytes) => createHash('sha256').update(bytes).digest('hex')
const targetPackage = { game: 'game', trial: 'reforge', editor: 'reforge' }
const freePort = () => new Promise((resolve, reject) => {
  const reservation = reserveSocket()
  reservation.once('error', reject)
  reservation.listen(0, '127.0.0.1', () => {
    const { port } = reservation.address()
    reservation.close((error) => error ? reject(error) : resolve(port))
  })
})
const browser = await chromium.launch({
  headless: true,
  ...(browserExecutable ? { executablePath: browserExecutable } : {}),
  args: ['--autoplay-policy=user-gesture-required'],
})
try {
  for (const [target, pkg] of Object.entries(targetPackage)) {
    const processor = mode === 'preflight'
      ? join(candidateModules, 'spessasynth_lib/dist/spessasynth_processor.min.js')
      : join(root, 'packages', pkg, 'public/spessasynth_processor.min.js')
    const processorBytes = readFileSync(processor)
    if (workletSha256) assert.equal(hash(processorBytes), workletSha256)
    else workletSha256 = hash(processorBytes)
    const servedWorklets = []
    const port = await freePort()
    const server = await createServer({
      root: editorRoot, configFile: join(editorRoot, 'vite.config.ts'), publicDir: false,
      resolve: { alias: aliases },
      cacheDir: join(realpathSync(new URL('.', import.meta.url)), 'vite-cache', mode, target),
      server: {
        host: '127.0.0.1', port, strictPort: true, hmr: false, watch: null,
        fs: { allow: [root, realpathSync(new URL('.', import.meta.url))] },
      },
      plugins: [{
        name: 'native-midi-probe',
        enforce: 'pre',
        resolveId(id) { if (id === moduleUrl) return entryPath },
        load(id) { if (id === entryPath) return entry },
        configureServer(vite) {
          vite.middlewares.use((req, res, next) => {
            const { pathname, search } = new URL(req.url, 'http://localhost')
            if (pathname === '/native-audio-probe.html') {
              res.setHeader('Content-Type', 'text/html')
              res.end('<!doctype html><meta charset="utf-8"><body><button id="go">Start audio</button><button id="swap">Switch to RIX</button><button id="exit">Leave audio</button><canvas id="screen"></canvas><div id="preview"></div><script type="module" src="' + moduleUrl + '"></script></body>')
            } else if (pathname === '/spessasynth_processor.min.js') {
              const bytes = !search && legacyBytes ? legacyBytes : processorBytes
              servedWorklets.push({ url: pathname + search, sha256: hash(bytes) })
              res.setHeader('Content-Type', 'application/javascript')
              res.setHeader('Cache-Control', 'max-age=2592000')
              res.end(bytes)
            } else next()
          })
        },
      }],
    })
    const context = await browser.newContext()
    const page = await context.newPage()
    const positiveResponses = []
    const issues = []
    const missingSaveRecords = []
    const errors = []
    page.on('pageerror', (error) => errors.push(error.message))
    page.on('console', (message) => {
      if (message.type() !== 'warning' && message.type() !== 'error') return
      const url = message.location().url
      if (url && new URL(url).pathname === '/projects/pal/.type-pal/save-state.json' && /404/.test(message.text())) {
        missingSaveRecords.push({ url, text: message.text() })
      } else issues.push({ url, text: message.text() })
    })
    page.on('response', (response) => {
      const pathname = new URL(response.url()).pathname
      if (/spessasynth_processor\.min\.js|\/(001\.mid|mus\.mkf|soundfont\.sf3)$/u.test(pathname) && response.ok())
        positiveResponses.push(pathname)
    })
    await page.addInitScript(() => {
      const listeners = new Set()
      const registrations = []
      const contexts = []
      const events = []
      const worklets = []
      const observedContexts = new WeakMap()
      const observedPorts = new WeakMap()
      const add = window.addEventListener
      const remove = window.removeEventListener
      window.addEventListener = function (type, listener, options) {
        if (type === 'beforeunload' && listener) {
          listeners.add(listener)
          registrations.push('add')
        }
        return add.call(this, type, listener, options)
      }
      window.removeEventListener = function (type, listener, options) {
        if (type === 'beforeunload' && listener) {
          listeners.delete(listener)
          registrations.push('remove')
        }
        return remove.call(this, type, listener, options)
      }
      const NativeAudioContext = window.AudioContext
      const NativeAudioWorkletNode = window.AudioWorkletNode
      const close = NativeAudioContext.prototype.close
      const connect = AudioNode.prototype.connect
      const send = MessagePort.prototype.postMessage
      window.AudioContext = class extends NativeAudioContext {
        constructor(...args) {
          super(...args)
          const record = { ctx: this, id: contexts.length, meter: null }
          observedContexts.set(this, record)
          contexts.push(record)
        }
        close() {
          events.push(['close', observedContexts.get(this).id])
          return close.call(this)
        }
      }
      window.AudioWorkletNode = class extends NativeAudioWorkletNode {
        constructor(ctx, name, options) {
          super(ctx, name, options)
          const record = { id: observedContexts.get(ctx)?.id, name }
          observedPorts.set(this.port, record)
          worklets.push(record)
          this.addEventListener('processorerror', () => events.push(['processorerror', record.id]))
        }
      }
      AudioNode.prototype.connect = function (dest, ...rest) {
        const result = connect.call(this, dest, ...rest)
        const record = observedContexts.get(this.context)
        if (record && dest === this.context.destination && !record.meter) {
          record.meter = this.context.createAnalyser()
          connect.call(this, record.meter, ...rest)
        }
        return result
      }
      MessagePort.prototype.postMessage = function (payload, ...rest) {
        const record = observedPorts.get(this)
        if (record && (payload?.type === 'destroyWorklet' || payload?.type === 'dispose'))
          events.push([payload.type, record.id])
        return send.call(this, payload, ...rest)
      }
      const pcm = (meter) => {
        if (!meter) return 0
        const samples = new Float32Array(meter.fftSize)
        meter.getFloatTimeDomainData(samples)
        return Math.sqrt(samples.reduce((a, b) => a + b * b, 0) / samples.length)
      }
      globalThis.__audio = () => ({
        beforeunload: listeners.size,
        registrations: [...registrations],
        contexts: contexts.map(({ ctx, id, meter }) => ({ id, state: ctx.state, rms: pcm(meter) })),
        events: [...events],
        worklets: [...worklets],
      })
    })
    const snapshot = () => page.evaluate(() => globalThis.__audio())
    const audible = async (ordinal = 0) => {
      await page.waitForFunction((i) => {
        const state = globalThis.__audio()
        return state.contexts.find((row) => row.id === state.worklets[i]?.id)?.rms > 0.0001
      }, ordinal, { timeout: 25000 })
      return snapshot()
    }
    const closed = (n) => page.waitForFunction((count) => {
      const rows = globalThis.__audio().contexts
      return rows.length === count && rows.every((row) => row.state === 'closed')
    }, n)
    try {
      await server.listen()
      const origin = 'http://127.0.0.1:' + server.httpServer.address().port
      const response = await page.goto(origin + '/native-audio-probe.html?target=' + target)
      assert(response?.ok())
      await page.waitForFunction(() => globalThis.__probe?.ready)
      assert.equal((await snapshot()).beforeunload, 0)
      let precachedLegacy
      if (legacyBytes) {
        const fetchCachedLegacy = () => page.evaluate(async () => {
          const response = await fetch('/spessasynth_processor.min.js', { cache: 'force-cache' })
          const digest = await crypto.subtle.digest('SHA-256', await response.arrayBuffer())
          return Array.from(new Uint8Array(digest), (value) => value.toString(16).padStart(2,'0')).join('')
        })
        precachedLegacy = await fetchCachedLegacy()
        assert.equal(precachedLegacy, hash(legacyBytes))
        assert.equal(await fetchCachedLegacy(), precachedLegacy)
        assert.equal(servedWorklets.length, 1, 'the old unversioned processor must be resident in HTTP cache')
      }
      await page.getByRole('button', { name: 'Start audio' }).click()
      let before, afterSwitch, second, timeline
      if (target === 'editor') {
        await page.getByRole('button', { name: '试听 PAL 001', exact: true }).click()
        before = await audible()
        await page.getByRole('button', { name: 'Leave audio' }).click()
        await closed(1)
        afterSwitch = await snapshot()
        await page.getByRole('button', { name: 'Start audio' }).click()
        await page.getByRole('button', { name: '试听 PAL 001', exact: true }).click()
        second = await audible(1)
        await page.getByRole('button', { name: 'Leave audio' }).click()
        await closed(2)
        timeline = await page.evaluate(() => {
          const { duration, noteCount, buckets } = globalThis.__probe.timeline
          return { duration, noteCount, nonzeroBuckets: buckets.filter(Boolean).length }
        })
        assert(timeline.duration > 0 && timeline.noteCount > 0 && timeline.nonzeroBuckets > 0)
      } else if (target === 'trial') {
        await page.getByRole('status').filter({ hasText: '战斗中' }).waitFor({ timeout: 25000 })
        before = await audible()
        await page.getByRole('button', { name: '停止试打', exact: true }).click()
        await page.waitForFunction(() => globalThis.__probe.exited)
        await closed(2)
      } else {
        await page.waitForFunction(() => globalThis.__probe.status()?.status === 'ready')
        before = await audible()
        await page.getByRole('button', { name: 'Switch to RIX' }).click()
        await page.waitForFunction(() => {
          const status = globalThis.__probe.status()
          return status?.source === 'rix' && status.status === 'ready'
        })
        afterSwitch = await audible(1)
        assert.equal(afterSwitch.contexts[0].state, 'closed')
        assert.equal(afterSwitch.worklets[1].name, 'type-pal-rix')
        await page.getByRole('button', { name: 'Leave audio' }).click()
        await closed(2)
      }
      const after = await snapshot()
      const expected = mode === 'baseline' ? (target === 'editor' ? 2 : 1) : 0
      assert.equal(before.beforeunload, mode === 'baseline' ? 1 : 0)
      assert.equal(after.beforeunload, expected)
      assert.equal(after.registrations.length, expected)
      assert(!after.events.some(([event]) => event === 'processorerror'))
      if (target !== 'game') {
        const midiContexts = after.worklets.map(({ id }) => id)
        for (const id of midiContexts) {
          const destroyed = after.events.findIndex(([event, targetId]) => targetId === id && event === 'destroyWorklet')
          const finished = after.events.findIndex(([event, targetId]) => targetId === id && event === 'close')
          assert(destroyed >= 0 && finished > destroyed, JSON.stringify(after.events))
        }
      }
      const expectedUrl = mode === 'installed'
        ? '/spessasynth_processor.min.js?v=4.4.0'
        : '/spessasynth_processor.min.js'
      assert(servedWorklets.some(({url, sha256}) => url === expectedUrl && sha256 === workletSha256),
        'the native Worklet request must obtain the matching processor')
      if (legacyBytes) assert.equal(servedWorklets.filter(({ url }) => !url.includes('?')).length, 1)

      assert(positiveResponses.some((item) => item.endsWith('/001.mid')))
      assert(positiveResponses.some((item) => item.endsWith('/soundfont.sf3')))
      assert.deepEqual(errors, [])
      assert.deepEqual(issues, [])
      reports[target] = { before, afterSwitch, second, after, timeline, positiveResponses, servedWorklets, precachedLegacy, missingSaveRecords, diagnostics: issues }
      console.log(target, JSON.stringify(reports[target]))
    } catch (error) {
      diagnostics.push({ target, message: String(error), status: await page.locator('body').innerText().catch(() => ''),
        audio: await snapshot().catch(() => undefined), positiveResponses, servedWorklets, missingSaveRecords, errors, issues })
      console.error(JSON.stringify(diagnostics))
      throw error
    } finally {
      await context.close()
      await server.close()
    }
  }
} finally {
  await browser.close()
}
console.log(JSON.stringify({ mode, workletSha256, chromium: browser.version(), reports }))
