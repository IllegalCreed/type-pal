# SpessaSynth 配套升级与真实退出

原树基点 `c7deefe56026f99991e523e254d09e4eeed2e762`，主线 `10378100a33013d8c2030ca266e125b913e9c6a7`。候选应用输入由 `source-files.json` 固定。构建前核对活跃 E2E 的五个修改路径，与本片无交集。原窗口 `review-11/` 的全文八维、已播放和迟到生命周期红绿继续使用。上一片 `exports-retired/` 已收口闲置的适配器时长字段。本片重验库变更及请求缓存影响。

## 逐文件结论

| 文件 | A 正确性 | B 注释 | C 归属 | D 复用 | E 判别 | F 命名 | G 简洁 | H 可测 |
|---|---|---|---|---|---|---|---|---|
| `packages/reforge/src/audio/bgm.ts` | `runBattleTrial` 控件停止试打，真实 MIDI 已发声，暂停与销毁 Worklet 先于上下文关闭，监听降为 0。场景使用同一 `createBgmPlayer`，场景切换走相邻宿主测试 | 前导静音、移交前 abort、淡变 timer 的注释可对应源码 | 时钟、选曲 serial 与开关在 BGM，外部浏览器 IO 藏于适配器，增益和上下文只由该 owner 清理 | 复用 `initializeBrowserSpessaSynth` 的匹配加载、RIFF 校验和在途取消，保留 BGM 的 gain 与淡变 | 旧版原生对照相同试打入口残留 1 个监听。既有 `bgm.browser-runtime.test.ts` 单独覆盖 in-flight 与 ready 的释放 | `releaseBackend` 只保存成功移交后的清理，场景、脚本和试打仍消费相同职责编排 | 保留真实消费的 prepare、resume、音乐切换；窗口监听由供应库版本解决，应用层无拦截全局监听补丁 | 正式控制器可观察音频端口和资源时序；原生 probe 检查真实 PCM、worklet 销毁命令和 context state |
| `packages/reforge/src/audio/midi-preview.ts` | 真实 `ProjectAudioPreviewButton` 同页开关两次，分别发声并释放，窗口监听降为 0。新旧 Core 输出的 86 首曲谱时长及事件相同 | 音符活动说明与 Core 输出一致，先前移除低层时长后的说明继续适用 | UI 只持 transport，播放/加载 serial 与数据快照属于 transport，合成器和浏览器上下文属于 runtime | 只共享准备和解码边界，保留试听独有的 seek、snapshot 与结束 | 旧版相同操作残留 2 个监听。正常、迟到和失败仍有不同 oracle，真实执行检查时间轴及两次关闭 | `activity`、`loadedKey`、`initializePromise` 分别表示曲谱、请求身份和浏览器启动 | 使用曲谱解析时长；退役接口未恢复；无同文件泛用状态包装 | 真实标准 MIDI 文件在独立播放器解析，原生输入、播放与卸载可观察，失败端口仍可定向隔离 |
| `packages/reforge/src/audio/spessa-browser-runtime.ts` | 实际 `AudioWorklet.addModule` 收到已安装版本的 URL。安装态先缓存旧版，仍匹配新版 | 保留移交边界说明 | 加载、RIFF 与 abort 归初始化器，成功后播放器持 synth | 同一实现为 BGM 与试听供给，Game 的 URL 配置和音源切换保持独立 | 只移除版本参数触发一个正式浏览器工厂断言。init 失败和取消仍执行 | 从包元数据直接命名/取值 | 版本源唯一，未新增同步常量或调用层 | 可从加载端口观测 URL，并用实际浏览器在预存旧缓存时复现 |
| `packages/game/src/shell/audio-midi.ts` | `createMusicSourceController` 用标准 MIDI、soundfont、RIX 资源播放并切换，监听 1→0，旧上下文关闭。新 URL 保留配置查询项 | 更新旧 API 版本说明及复制约束 | URL 解析在 MIDI adapter，切源/重放意图仍由现有 controller 负责 | URL API 管查询参数，复用已有后端，不引入跨阶段依赖 | 相对地址带原查询项，丢失版本的反控只红新增断言。真实 RIX PCM 检查切换后的第二后端 | `processor` 指 Worklet URL，与传入 `workletUrl` 视图分开 | 用真实包版本，未新增副本 | URL、await 和 native AudioContext 退出分别可验证 |
| `scripts/quality/midi-worklet.test.mjs` | 以两个实际安装入口解析供应包，检查内嵌源图、文件与许可证，Reforge 还匹配直接 Core 与 lib Core | 明示直接解析与播放 Core 的两个依赖边 | 只做供应与许可证合同，原生播放由新的浏览器证据负责 | 对两种 app 套用相同供应合同，额外直接依赖只核有该 caller 的 Reforge | 同一个 guard 在实际安装两份通过，隔离副本只改 Reforge 一字节后恰一红 | 由原 `game-midi-worklet.test.mjs` 迁至按实际供应范围命名 | 原 Game 复制/许可证断言保留，单次 loop 共用来源；无重复生成或手写签名 | 可用 Node 独立读发布产物，不起游戏；内容比较可单点反控 |

`audio-midi.test.ts` 新例只验证真实后端的 URL 边界。 `midi-preview.browser-runtime.test.ts` 原初始化成功、init 失败、关闭等测试保留，独立写入预期发布版本。共享宿主 `audio-host.ts` 只替身外部 IO，既有真实标题、读档、场景 BGM 和试打查验仍由产品函数完成。检查两端维护现有路径的状态、命名及分层，未按相邻绿批量升格状态。

## 来源、快检与失效

- 上游 4.4.0 [Sequencer 变更](https://github.com/spessasus/spessasynth_lib/commit/126a62cc1fc0) 把 `beforeunload` 安装移到外部 MIDI 输出的启用路径。本项目三个已测入口均未连接 Web MIDI；真实窗口监听由原生 API 记录。
- `source-files.json` 记录原树对象与候选文件 SHA。 `release.json` 绑定 npm tarball、源图依赖和真实资源；源图比较着重处理上游 `latest` 依赖的漂移。正式 lock 精确固定库、Core 及解码器。MIT 和 Apache 许可证随两个应用发布。
- 快检运行 `node --test scripts/quality/midi-worklet.test.mjs`。按 `gates.json` 核退出与原件 SHA，原生三会话的状态在对应 stdout 末行 JSON。旧版 `baseline-r4` 的 1、1、2 个残留是关闭合同的反例。候选隔离 `preflight-r4` 与正式安装 `native-installed` 各为 0、0、0。
- 复验已安装候选时先将 `git show c7deefe56:packages/game/public/spessasynth_processor.min.js` 输出到独立临时目录作为旧缓存字节。在该目录从归档取得 `native-audio-probe.mjs` 及可选脚本。以已安装 Chromium 路径设置其第四个参数。旧版及别名预检需要先在另一个干净基点安装旧 lock。浏览器观察只旁路取 PCM，保留真实 destination，不模拟乐谱、网络资源所有权或停止试打入口。
- 旧脚本首两轮缺默认 Chromium 路径或未采到 Worklet 请求，随后首次试打传入的 token/revision 无效。保留设置失败，正式 r4 改用实际工程身份及服务器请求。安装态额外启用旧 HTTP 缓存对照。
- 试打 8 条和试听 2 条浏览器 404 均为可选的 `projects/pal/.type-pal/save-state.json`；如实单列，`httpSource` 的不存在合约返回无标记。无其它浏览器诊断、`processorerror` 或未捕获异常。原生范围限 Chromium 149.0.7827.55，不外推物理听感、硬件 MIDI、其他浏览器或合成器算法审查。
- Reforge 首次与其它验证并行时三条标题用例超时。文件列表、阈值与选择保持相同，单独复跑 74 项均绿且无 stderr。完整诊断保留两次。锁解析有 Core 维护者的仅最新版本支持提示及已有 `prebuild-install` 弃用提示；冻结安装原件空 stderr 且 stdout 无警示。Biome 机器输出零代码诊断；工具 JSON 输出实验性说明保留。
- 库、Core、解码器、公开处理器、Worklet 请求路由及播放器生命周期变化会使相关结论失效。只改锁或只改生成物不能沿用此证据。真实 preview 的三个发布路径返回 JavaScript 与配套字节，E2E 工具对版本查询分类有实际回归。
- 全仓检查、覆盖率、全仓 lint-zero、protected fast 与 PR 等到下一稳定窗口。静态定向、相邻套件与真实音频退出均完成。
