import { readFileSync } from 'node:fs'
import { resolve } from 'node:path'
const file = resolve("src/audio/spessa-browser-runtime.ts")
const before = "await worklet.addModule(`/spessasynth_processor.min.js?v=${spessaPackage.version}`)"
export default {
  test: { maxWorkers: 1 },
  plugins: [{
    name: 'unversioned-worklet-probe',
    enforce: 'pre',
    load(id) {
      if (id.split('?')[0] !== file) return
      const text = readFileSync(file, 'utf8')
      if (text.split(before).length !== 2) throw new Error('worklet version site does not match')
      return text.replace(before, "await worklet.addModule('/spessasynth_processor.min.js')")
    },
  }],
}
