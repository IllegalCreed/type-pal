
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>
typedef int INT, BOOL;
typedef unsigned int UINT;
typedef uint16_t WORD;
typedef unsigned char BYTE, *LPBYTE;
typedef const unsigned char *LPCBITMAPRLE, *LPCSPRITE;
typedef const void *LPCVOID;
typedef void *LPVOID;
typedef uint32_t PAL_POS;
typedef int16_t SHORT;
#define PAL_FORCE_INLINE static inline
#define PAL_X(xy) (SHORT)((xy) & 0xFFFF)
#define PAL_Y(xy) (SHORT)(((xy) >> 16) & 0xFFFF)
#define SDL_SwapLE32(value) (value)
typedef struct { int w, h, pitch; void *pixels; } SDL_Surface;
PAL_FORCE_INLINE
BYTE
PAL_CalcShadowColor(
   BYTE bSourceColor
)
{
    return ((bSourceColor&0xF0)|((bSourceColor&0x0F)>>1));
}

INT
PAL_RLEBlitToSurfaceWithShadow(
   LPCBITMAPRLE      lpBitmapRLE,
   SDL_Surface      *lpDstSurface,
   PAL_POS           pos,
   BOOL              bShadow
)
/*++
  Purpose:

    Blit an RLE-compressed bitmap to an SDL surface.
    NOTE: Assume the surface is already locked, and the surface is a 8-bit one.

  Parameters:

    [IN]  lpBitmapRLE - pointer to the RLE-compressed bitmap to be decoded.

    [OUT] lpDstSurface - pointer to the destination SDL surface.

    [IN]  pos - position of the destination area.

    [IN]  bShadow - flag to mention whether blit source color or just shadow.

  Return value:

    0 = success, -1 = error.

--*/
{
   UINT          i, j, k, sx;
   INT           x, y;
   UINT          uiLen       = 0;
   UINT          uiWidth     = 0;
   UINT          uiHeight    = 0;
   UINT          uiSrcX      = 0;
   BYTE          T;
   INT           dx          = PAL_X(pos);
   INT           dy          = PAL_Y(pos);
   LPBYTE        p;

   //
   // Check for NULL pointer.
   //
   if (lpBitmapRLE == NULL || lpDstSurface == NULL)
   {
      return -1;
   }

   //
   // Skip the 0x00000002 in the file header.
   //
   if (lpBitmapRLE[0] == 0x02 && lpBitmapRLE[1] == 0x00 &&
      lpBitmapRLE[2] == 0x00 && lpBitmapRLE[3] == 0x00)
   {
      lpBitmapRLE += 4;
   }

   //
   // Get the width and height of the bitmap.
   //
   uiWidth = lpBitmapRLE[0] | (lpBitmapRLE[1] << 8);
   uiHeight = lpBitmapRLE[2] | (lpBitmapRLE[3] << 8);

   //
   // Check whether bitmap intersects the surface.
   //
   if (uiWidth + dx <= 0 || dx >= lpDstSurface->w ||
       uiHeight + dy <= 0 || dy >= lpDstSurface->h)
   {
      goto end;
   }

   //
   // Calculate the total length of the bitmap.
   // The bitmap is 8-bpp, each pixel will use 1 byte.
   //
   uiLen = uiWidth * uiHeight;

   //
   // Start decoding and blitting the bitmap.
   //
   lpBitmapRLE += 4;
   for (i = 0; i < uiLen;)
   {
      T = *lpBitmapRLE++;
      if ((T & 0x80) && T <= 0x80 + uiWidth)
      {
         i += T - 0x80;
         uiSrcX += T - 0x80;
         if (uiSrcX >= uiWidth)
         {
            uiSrcX -= uiWidth;
            dy++;
         }
      }
      else
      {
         //
         // Prepare coordinates.
         //
         j = 0;
         sx = uiSrcX;
         x = dx + uiSrcX;
         y = dy;

         //
         // Skip the points which are out of the surface.
         //
         if (y < 0)
         {
            j += -y * uiWidth;
            y = 0;
         }
         else if (y >= lpDstSurface->h)
         {
            goto end; // No more pixels needed, break out
         }

         while (j < T)
         {
            //
            // Skip the points which are out of the surface.
            //
            if (x < 0)
            {
               j += -x;
               if (j >= T) break;
               sx += -x;
               x = 0;
            }
            else if (x >= lpDstSurface->w)
            {
               j += uiWidth - sx;
               x -= sx;
               sx = 0;
               y++;
               if (y >= lpDstSurface->h)
               {
                  goto end; // No more pixels needed, break out
               }
               continue;
            }

            //
            // Put the pixels in row onto the surface
            //
            k = T - j;
            if (lpDstSurface->w - x < k) k = lpDstSurface->w - x;
            if (uiWidth - sx < k) k = uiWidth - sx;
            sx += k;
            p = ((LPBYTE)lpDstSurface->pixels) + y * lpDstSurface->pitch;
            if(bShadow)
            {
               j += k;
               for (; k != 0; k--)
               {
                  p[x] = PAL_CalcShadowColor(p[x]);
                  x++;
               }
            }
            else
            {
               for (; k != 0; k--)
               {
                  p[x] = lpBitmapRLE[j];
                  j++;
                  x++;
               }
            }

            if (sx >= uiWidth)
            {
               sx -= uiWidth;
               x -= uiWidth;
               y++;
               if (y >= lpDstSurface->h)
               {
                  goto end; // No more pixels needed, break out
               }
            }
         }
         lpBitmapRLE += T;
         i += T;
         uiSrcX += T;
         while (uiSrcX >= uiWidth)
         {
            uiSrcX -= uiWidth;
            dy++;
         }
      }
   }

end:
   //
   // Success
   //
   return 0;
}
LPCBITMAPRLE
PAL_SpriteGetFrame(
   LPCSPRITE       lpSprite,
   INT             iFrameNum
)
/*++
  Purpose:

    Get the pointer to the specified frame from a sprite.

  Parameters:

    [IN]  lpSprite - pointer to the sprite.

    [IN]  iFrameNum - number of the frame.

  Return value:

    Pointer to the specified frame. NULL if the frame does not exist.

--*/
{
   int imagecount, offset;

   if (lpSprite == NULL)
   {
      return NULL;
   }

   //
   // Hack for broken sprites like the Bloody-Mouth Bug
   //
//   imagecount = (lpSprite[0] | (lpSprite[1] << 8)) - 1;
   imagecount = (lpSprite[0] | (lpSprite[1] << 8));

   if (iFrameNum < 0 || iFrameNum >= imagecount)
   {
      //
      // The frame does not exist
      //
      return NULL;
   }

   //
   // Get the offset of the frame
   //
   iFrameNum <<= 1;
   offset = ((lpSprite[iFrameNum] | (lpSprite[iFrameNum + 1] << 8)) << 1);
   if (offset == 0x18444) offset = (WORD)offset;
   return &lpSprite[offset];
}
typedef struct _YJ2_TreeNode
{
	unsigned short      weight;
	unsigned short      value;
	struct _YJ2_TreeNode   *parent;
	struct _YJ2_TreeNode   *left;
	struct _YJ2_TreeNode   *right;
} YJ2_TreeNode;

typedef struct _YJ2_Tree
{
	YJ2_TreeNode    *node;
	YJ2_TreeNode   **list;
} YJ2_Tree;

static unsigned char yj2_data1[0x100] =
{
	0x3f, 0x0b, 0x17, 0x03, 0x2f, 0x0a, 0x16, 0x00, 0x2e, 0x09, 0x15, 0x02, 0x2d, 0x01, 0x08, 0x00,
	0x3e, 0x07, 0x14, 0x03, 0x2c, 0x06, 0x13, 0x00, 0x2b, 0x05, 0x12, 0x02, 0x2a, 0x01, 0x04, 0x00,
	0x3d, 0x0b, 0x11, 0x03, 0x29, 0x0a, 0x10, 0x00, 0x28, 0x09, 0x0f, 0x02, 0x27, 0x01, 0x08, 0x00,
	0x3c, 0x07, 0x0e, 0x03, 0x26, 0x06, 0x0d, 0x00, 0x25, 0x05, 0x0c, 0x02, 0x24, 0x01, 0x04, 0x00,
	0x3b, 0x0b, 0x17, 0x03, 0x23, 0x0a, 0x16, 0x00, 0x22, 0x09, 0x15, 0x02, 0x21, 0x01, 0x08, 0x00,
	0x3a, 0x07, 0x14, 0x03, 0x20, 0x06, 0x13, 0x00, 0x1f, 0x05, 0x12, 0x02, 0x1e, 0x01, 0x04, 0x00,
	0x39, 0x0b, 0x11, 0x03, 0x1d, 0x0a, 0x10, 0x00, 0x1c, 0x09, 0x0f, 0x02, 0x1b, 0x01, 0x08, 0x00,
	0x38, 0x07, 0x0e, 0x03, 0x1a, 0x06, 0x0d, 0x00, 0x19, 0x05, 0x0c, 0x02, 0x18, 0x01, 0x04, 0x00,
	0x37, 0x0b, 0x17, 0x03, 0x2f, 0x0a, 0x16, 0x00, 0x2e, 0x09, 0x15, 0x02, 0x2d, 0x01, 0x08, 0x00,
	0x36, 0x07, 0x14, 0x03, 0x2c, 0x06, 0x13, 0x00, 0x2b, 0x05, 0x12, 0x02, 0x2a, 0x01, 0x04, 0x00,
	0x35, 0x0b, 0x11, 0x03, 0x29, 0x0a, 0x10, 0x00, 0x28, 0x09, 0x0f, 0x02, 0x27, 0x01, 0x08, 0x00,
	0x34, 0x07, 0x0e, 0x03, 0x26, 0x06, 0x0d, 0x00, 0x25, 0x05, 0x0c, 0x02, 0x24, 0x01, 0x04, 0x00,
	0x33, 0x0b, 0x17, 0x03, 0x23, 0x0a, 0x16, 0x00, 0x22, 0x09, 0x15, 0x02, 0x21, 0x01, 0x08, 0x00,
	0x32, 0x07, 0x14, 0x03, 0x20, 0x06, 0x13, 0x00, 0x1f, 0x05, 0x12, 0x02, 0x1e, 0x01, 0x04, 0x00,
	0x31, 0x0b, 0x11, 0x03, 0x1d, 0x0a, 0x10, 0x00, 0x1c, 0x09, 0x0f, 0x02, 0x1b, 0x01, 0x08, 0x00,
	0x30, 0x07, 0x0e, 0x03, 0x1a, 0x06, 0x0d, 0x00, 0x19, 0x05, 0x0c, 0x02, 0x18, 0x01, 0x04, 0x00
};
static unsigned char yj2_data2[0x10] =
{
	0x08, 0x05, 0x06, 0x04, 0x07, 0x05, 0x06, 0x03, 0x07, 0x05, 0x06, 0x04, 0x07, 0x04, 0x05, 0x03
};

static void yj2_adjust_tree(YJ2_Tree tree, unsigned short value)
{
	YJ2_TreeNode* node = tree.list[value];
	YJ2_TreeNode tmp;
	YJ2_TreeNode* tmp1;
	YJ2_TreeNode* temp;
	while (node->value != 0x280)
	{
		temp = node + 1;
		while (node->weight == temp->weight)
			temp++;
		temp--;
		if (temp != node)
		{
			tmp1 = node->parent;
			node->parent = temp->parent;
			temp->parent = tmp1;
			if (node->value > 0x140)
			{
				node->left->parent = temp;
				node->right->parent = temp;
			}
			else
				tree.list[node->value] = temp;
			if (temp->value > 0x140)
			{
				temp->left->parent = node;
				temp->right->parent = node;
			}
			else
				tree.list[temp->value] = node;
			tmp = *node; *node = *temp; *temp = tmp;
			node = temp;
		}
		node->weight++;
		node = node->parent;
	}
	node->weight++;
}

static int yj2_build_tree(YJ2_Tree *tree)
{
	int i, ptr;
	YJ2_TreeNode** list;
	YJ2_TreeNode* node;
	if ((tree->list = list = (YJ2_TreeNode **)malloc(sizeof(YJ2_TreeNode*) * 321)) == NULL)
		return 0;
	if ((tree->node = node = (YJ2_TreeNode *)malloc(sizeof(YJ2_TreeNode) * 641)) == NULL)
	{
		free(list);
		return 0;
	}
	memset(list, 0, 321 * sizeof(YJ2_TreeNode*));
	memset(node, 0, 641 * sizeof(YJ2_TreeNode));
	for (i = 0; i <= 0x140; i++)
		list[i] = node + i;
	for (i = 0; i <= 0x280; i++)
	{
		node[i].value = i;
		node[i].weight = 1;
	}
	tree->node[0x280].parent = tree->node + 0x280;
	for (i = 0, ptr = 0x141; ptr <= 0x280; i += 2, ptr++)
	{
		node[ptr].left = node + i;
		node[ptr].right = node + i + 1;
		node[i].parent = node[i + 1].parent = node + ptr;
		node[ptr].weight = node[i].weight + node[i + 1].weight;
	}
	return 1;
}

static int yj2_bt(const unsigned char* data, unsigned int pos)
{
	return (data[pos >> 3] & (unsigned char)(1 << (pos & 0x7))) >> (pos & 0x7);
}


INT
	YJ2_Decompress(
	LPCVOID       Source,
	LPVOID        Destination,
	INT           DestSize
	)
{
	int Length;
	unsigned int len = 0, ptr = 0;
	unsigned char* src = (unsigned char*)Source + 4;
	unsigned char* dest;
	YJ2_Tree tree;
	YJ2_TreeNode* node;

	if (Source == NULL)
		return -1;

	if (!yj2_build_tree(&tree))
		return -1;

	Length = SDL_SwapLE32(*((unsigned int*)Source));
	if (Length > DestSize)
		return -1;
	dest = (unsigned char*)Destination;

	while (1)
	{
		unsigned short val;
		node = tree.node + 0x280;
		while (node->value > 0x140)
		{
			if (yj2_bt(src, ptr))
				node = node->right;
			else
				node = node->left;
			ptr++;
		}
		val = node->value;
		if (tree.node[0x280].weight == 0x8000)
		{
			int i;
			for (i = 0; i < 0x141; i++)
				if (tree.list[i]->weight & 0x1)
					yj2_adjust_tree(tree, i);
			for (i = 0; i <= 0x280; i++)
				tree.node[i].weight >>= 1;
		}
		yj2_adjust_tree(tree, val);
		if (val > 0xff)
		{
			int i;
			unsigned int temp, tmp, pos;
			unsigned char* pre;
			for (i = 0, temp = 0; i < 8; i++, ptr++)
				temp |= (unsigned int)yj2_bt(src, ptr) << i;
			tmp = temp & 0xff;
			for (; i < yj2_data2[tmp & 0xf] + 6; i++, ptr++)
				temp |= (unsigned int)yj2_bt(src, ptr) << i;
			temp >>= yj2_data2[tmp & 0xf];
			pos = (temp & 0x3f) | ((unsigned int)yj2_data1[tmp] << 6);
			if (pos == 0xfff)
				break;
			pre = dest - pos - 1;
			for (i = 0; i < val - 0xfd; i++)
				*dest++ = *pre++;
			len += val - 0xfd;
		}
		else
		{
			*dest++ = (unsigned char)val;
			len++;
		}
	}

	free(tree.list);
	free(tree.node);
	return Length;
}


static uint16_t u16(const BYTE *p) { return p[0] | (p[1]<<8); }
static uint32_t u32(const BYTE *p) { return p[0] | (p[1]<<8) | (p[2]<<16) | ((uint32_t)p[3]<<24); }
int main(int argc,char **argv) {
 if(argc!=3) return 2;
 FILE *input=fopen(argv[1],"rb"),*output=fopen(argv[2],"wb");
 if(!input||!output) return 3;
 uint32_t packet[3];size_t got;
 while((got=fread(packet,1,12,input))!=0) {
  if(got!=12||packet[0]>4||packet[2]>20000000) return 4;
  uint32_t family=packet[0],chunk=packet[1],length=packet[2];
  BYTE *raw=malloc(length?length:1);if(!raw||fread(raw,1,length,input)!=length) return 5;
  if(!length){free(raw);continue;}
  BYTE *bytes=raw;
  if(family==4) {
   if(length<4) return 6;
   uint32_t size=u32(raw);if(!size||size>20000000) return 7;
   bytes=calloc(size,1);if(!bytes||YJ2_Decompress(raw,bytes,size)!=(int)size) return 8;
   length=size;
  }
  int group=family==0||family==1||family==4;
  if(length<2) return 9;
  uint32_t count=group?u16(bytes):1;
  if(group&&count*2>length) return 10;
  for(uint32_t slot=0;slot<count;slot++) {
   if(group&&u16(bytes+slot*2)==0) continue;
   const BYTE *frame=group?PAL_SpriteGetFrame(bytes,slot):bytes;
   if(!frame||frame<bytes||frame+4>bytes+length) return 11;
   const BYTE *header=frame;
   if(u32(header)==2) header+=4;
   if(header+4>bytes+length) return 12;
   uint32_t width=u16(header),height=u16(header+2);
   if(!width||!height||width>400||height>400) return 13;
   size_t size=(size_t)width*height;
   BYTE *dark=calloc(size,1),*light=malloc(size),*rgba=malloc(size*4);
   if(!dark||!light||!rgba) return 14;
   memset(light,255,size);
   SDL_Surface a={(int)width,(int)height,(int)width,dark};
   SDL_Surface b={(int)width,(int)height,(int)width,light};
   if(PAL_RLEBlitToSurfaceWithShadow(frame,&a,0,0)||PAL_RLEBlitToSurfaceWithShadow(frame,&b,0,0)) return 15;
   for(size_t pixel=0;pixel<size;pixel++) {
    int opaque=dark[pixel]==light[pixel];
    if(!opaque&&(dark[pixel]!=0||light[pixel]!=255)) return 16;
    rgba[pixel*4]=rgba[pixel*4+1]=rgba[pixel*4+2]=opaque?dark[pixel]:0;
    rgba[pixel*4+3]=opaque?255:0;
   }
   uint32_t record[]={family,chunk,slot,width,height};
   if(fwrite(record,1,20,output)!=20||fwrite(rgba,1,size*4,output)!=size*4) return 17;
   free(dark);free(light);free(rgba);
  }
  if(bytes!=raw)free(bytes);free(raw);
 }
 fclose(input);fclose(output);return 0;
}
