import { readFileSync } from 'node:fs'
import { expect, test, vi } from 'vitest'
import { loadCursorFrames } from './dialog-assets.js'

const chrome = '/packages/reforge/src/engine-chrome/assets/dialog-icons-raw.json'
const broken = '/tmp/type-pal-review-window.82wv1T/isolated-bake-invalid-cursor' + chrome

function runWithFile(file: string) {
  vi.stubGlobal('fetch', async () => new Response(readFileSync(file, 'utf8')))
  return loadCursorFrames('fixture:dialog-icons')
}

test('canonical cursor output is accepted by the real Reforge loader', async () => {
  try {
    const frames = await runWithFile('/Users/zhangxu/.codex/worktrees/quality-94-102/type-pal' + chrome)
    expect(frames).toHaveLength(3)
  } finally {
    vi.unstubAllGlobals()
  }
})

test('bake output from a length-mismatched palette cursor is rejected by Reforge', async () => {
  try {
    await expect(runWithFile(broken)).rejects.toThrow(/对话光标长度错误:fixture:dialog-icons/)
  } finally {
    vi.unstubAllGlobals()
  }
})
