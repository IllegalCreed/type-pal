import { dirname, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'
import { validateAuthorScenes } from '@type-pal/content'
import { beforeAll, expect, test } from 'vitest'
import { loadPalBaseline } from './migration-baseline.js'
import type { MigrationJson } from './migration-files.js'
import { loadPalContentSupplySources } from './pal-content-supply-io.js'
import {
  buildPalCurrentPublication,
  validatePalCurrentPublication,
} from './pal-current-publication.js'
import { buildPalCurrentManifest } from './pal-manifest.js'

const repo = resolve(dirname(fileURLToPath(import.meta.url)), '../../..')
const path = 'content/scenes/s001.json'
let publication: ReturnType<typeof buildPalCurrentPublication>
let sources: ReturnType<typeof loadPalContentSupplySources>

function jsonRecord(value: MigrationJson | undefined): Record<string, MigrationJson> {
  if (!value || typeof value !== 'object' || Array.isArray(value))
    throw new Error('expected a publication object')
  return value
}

beforeAll(() => {
  const baseline = loadPalBaseline(repo)
  if (!baseline) throw new Error('expected the real PAL baseline')
  sources = loadPalContentSupplySources(repo)
  publication = buildPalCurrentPublication(baseline, sources)
})

function checkAuthorLabel(label: string) {
  const sceneFile = jsonRecord(structuredClone(publication.files.get(path)))
  const entities = sceneFile.entities
  if (!Array.isArray(entities)) throw new Error('expected entities in s001')
  const entity = entities.find(
    (value) => value && typeof value === 'object' && !Array.isArray(value) && value.id === 'e19',
  )
  const triggers = jsonRecord(jsonRecord(jsonRecord(entity).behaviors).trigger)
  if (Object.hasOwn(triggers, 'orphan-scheme')) throw new Error('expected a new variant')
  triggers['orphan-scheme'] = {
    label,
    order: 9801,
    flow: { kind: 'stages', initial: 'main', stages: [{ id: 'main', body: [] }] },
  }
  validateAuthorScenes([sceneFile])
  const files = new Map(publication.files)
  files.set(path, sceneFile)
  const candidate = { ...publication, files }
  validatePalCurrentPublication({
    publication: candidate,
    sources,
    manifest: buildPalCurrentManifest(sources.assetCatalog),
  })
}

test('publication can retain an unused ordinary author variant', () => {
  expect(() => checkAuthorLabel('门口临时对白')).not.toThrow()
})

test('the existing source contract catches a numbered scheme with no selecting item', () => {
  expect(() => checkAuthorLabel('凤纹手绢剧情方案 9')).toThrow(
    'PAL 物品剧情方案零 item root: scenes.s001.entities.e19.behaviors.trigger.orphan-scheme',
  )
})

test('publication also rejects an unowned scheme with ordinal 10', () => {
  expect(() => checkAuthorLabel('凤纹手绢剧情方案 10')).toThrow(
    'PAL 物品剧情方案零 item root: scenes.s001.entities.e19.behaviors.trigger.orphan-scheme',
  )
})
