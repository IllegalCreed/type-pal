from hashlib import sha256
from pathlib import Path
import json
import shutil
import subprocess

source = Path.cwd()
scratch = Path(__file__).resolve().parent
fundamental = [
    'packages/migrate/scripts/bake-assets.mts',
    'packages/migrate/src/bake-indexed-rgba.ts',
]
chrome = 'packages/reforge/src/engine-chrome/assets'
cursor = 'data/extracted/data/dialog-icons-raw.json'

def setup(name):
    run = scratch / name
    run.mkdir()
    for name in fundamental:
        dest = run / name
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source / name, dest)
    for name in ('data/extracted/images', 'data/extracted/data/palette', 'packages/migrate/node_modules'):
        dest = run / name
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.symlink_to(source / name, target_is_directory=True)
    shutil.copyfile(source / cursor, run / cursor)
    shutil.copytree(source / chrome, run / chrome)
    return run

def digest(path):
    return sha256(path.read_bytes()).hexdigest()

def execute(root):
    command = ['pnpm', '--filter', '@type-pal/migrate', 'exec', 'tsx', str(root / fundamental[0])]
    res = subprocess.run(command, cwd=source, capture_output=True)
    return {'command': command, 'exit': res.returncode,'stdout':res.stdout.decode(),'stderr':res.stderr.decode()}

def check_symlink():
    run = setup('isolated-bake-linked-box')
    outside = scratch / 'isolated-sibling-chrome-box'
    (run/chrome/'ui/box').rename(outside)
    frame = outside / 'frame-00.png'
    shutil.copyfile(outside/'frame-01.png', frame)
    old_digest = digest(frame)
    (run/chrome/'ui/box').symlink_to(outside, target_is_directory=True)
    result = execute(run)
    return dict(result, path=str(frame.relative_to(scratch)), before=old_digest, after=digest(frame), canonical=digest(source/chrome/'ui/box/frame-00.png'))

def check_cursor():
    run = setup('isolated-bake-invalid-cursor')
    malformed = json.loads((run/cursor).read_bytes())
    malformed['size'] += 1
    (run/cursor).write_text(json.dumps(malformed))
    output = run/chrome/'dialog-icons-raw.json'
    old_digest = digest(output)
    result = execute(run)
    cmd = ['pnpm', '--filter', '@type-pal/reforge', 'exec', 'tsx', '-e',
        f"import {{ readFileSync }} from 'node:fs'; import {{ decodeCursorFrames }} from './src/dialog/dialog-assets.ts'; decodeCursorFrames(JSON.parse(readFileSync({json.dumps(str(output))},'utf8')));"]
    use = subprocess.run(cmd, cwd=source, capture_output=True)
    return dict(result, before=old_digest, after=digest(output), consumed={'command':cmd,'exit':use.returncode,'stdout':use.stdout.decode(),'stderr':use.stderr.decode()})

link, payload = check_symlink(), check_cursor()
print(json.dumps({'linkedOutput': link, 'malformedCursor': payload}, ensure_ascii=False, indent=2))
assert link['exit']==0 and link['before']!=link['after']==link['canonical']
assert payload['exit']==0 and payload['before']!=payload['after'] and payload['consumed']['exit']==1 and '对话光标长度错误' in payload['consumed']['stderr']
