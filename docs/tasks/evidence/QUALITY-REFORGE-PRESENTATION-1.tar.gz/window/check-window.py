"""Read-only identity check for a completed Reforge governance window."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys


def read_json(path):
    return json.loads(path.read_text(encoding='utf-8'))


def check_hash(path, record, errors):
    if not path.is_file():
        errors.append(f'missing: {path}')
        return
    data = path.read_bytes()
    if len(data) != record['bytes'] or hashlib.sha256(data).hexdigest() != record['sha256']:
        errors.append(f'stale: {path}')


def main():
    if len(sys.argv) != 2:
        print('usage: python3 check-window.py /absolute/repository/path', file=sys.stderr)
        return 2
    repo = Path(sys.argv[1]).resolve()
    evidence = Path(__file__).resolve().parent
    manifest = read_json(evidence / 'window-manifest.json')
    errors = []
    checked = set()
    for row in [
        *(file['identity'] for file in manifest['currentFiles'].values()),
        *manifest['dependencies'],
        *manifest['modifiedCodeAndTools'],
    ]:
        path = repo / row['path']
        if path in checked:
            continue
        checked.add(path)
        if row.get('retired'):
            if path.exists() or path.is_symlink():
                errors.append(f'retired path now exists: {path}')
        else:
            check_hash(path, row, errors)
    base = manifest['base']
    raw = subprocess.run(['git', '-C', str(repo), 'ls-tree', '-r', base], capture_output=True, check=False)
    if raw.returncode != 0:
        errors.append(f'cannot verify original Git tree at {base}')
    else:
        blobs = {}
        for line in raw.stdout.decode('utf-8').splitlines():
            mode_type_oid, path = line.split('\t', 1)
            blobs[path] = mode_type_oid.split()[-1]
        for item in manifest['originals']:
            original = item['base']
            if blobs.get(original['path']) != original['blob']:
                errors.append(f'original blob differs: {original["path"]}')
    for record in read_json(evidence / 'archive-members.json'):
        check_hash(evidence / record['path'], record, errors)
    if errors:
        print('\n'.join(errors), file=sys.stderr)
        print('Review the affected claims. Other evidence stays at its recorded applicability.', file=sys.stderr)
        return 1
    print(f'Matching source, caller and evidence bytes for {len(manifest["originals"])} original paths.')
    print('Source identity matches. Semantic judgments, E2E applicability and visualization are reported separately.')
    return 0


if __name__ == '__main__':
    sys.exit(main())
