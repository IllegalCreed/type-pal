import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { readFile } from 'node:fs/promises'
import { resolve } from 'node:path'
import { pathToFileURL } from 'node:url'

const sourceModule = (path) => import(pathToFileURL(resolve(path)).href)
const loader = await sourceModule('packages/reforge/src/project-loader.ts')
const fixture = await sourceModule('packages/reforge/src/__tests__/project-loading-boundaries/fixture.ts')

async function sceneEntry() {
  async function readWithSecondEntry(sceneId, makeDefault) {
    const files = fixture.lbProjectFiles({ extraSceneIds: [sceneId] })
    files['manifest.json'].entryPoints.push({
      id: 'second',
      label: 'Second',
      scene: sceneId,
      startWorld: { party: [], money: 17, inventory: [] },
    })
    if (makeDefault) files['manifest.json'].defaultEntryId = 'second'
    const source = fixture.lbMemorySource(files)
    const project = await loader.loadCurrentProjectFrom(source)
    return {
      read: source.reads.includes(`json:content/scenes/${sceneId}.json`),
      ownsBody: Object.hasOwn(project.authorContent.entryScenes, sceneId),
      defaultBodyId: project.entryScene?.id,
    }
  }

  const ordinary = await readWithSecondEntry('second-scene', true)
  assert.deepEqual(ordinary, { read: true, ownsBody: true, defaultBodyId: 'second-scene' })
  const named = await readWithSecondEntry('constructor', true)
  console.log({ ordinary, named })
  assert.deepEqual(named, { read: true, ownsBody: true, defaultBodyId: 'constructor' })
}

async function malformedAmbience() {
  const { resolveAmbienceTint } = await sourceModule('packages/content/src/ambience.ts')
  const valid = fixture.lbProjectFiles({
    optionalTables: { ambiences: [{ id: 'night', name: 'Night', tint: [120, 140, 200] }] },
  })
  const project = await loader.loadCurrentProjectFrom(fixture.lbMemorySource(valid))
  const control = resolveAmbienceTint('night', project.ambiences)
  assert.deepEqual(control, [120, 140, 200])

  const broken = fixture.lbProjectFiles({ optionalTables: { ambiences: [null] } })
  const outcome = await loader.loadCurrentProjectFrom(fixture.lbMemorySource(broken)).then(
    (loaded) => {
      try {
        return { admitted: true, color: resolveAmbienceTint(undefined, loaded.ambiences) }
      } catch (error) {
        return { admitted: true, consumerError: String(error) }
      }
    },
    (error) => ({ admitted: false, cause: String(error) }),
  )
  console.log({ control, broken: outcome })
  assert.equal(outcome.admitted, false)
}

async function brokenCanvas() {
  const { AssetResolver } = await sourceModule('packages/reforge/src/asset-resolver.ts')
  const { loadBattleBgFull } = await sourceModule('packages/reforge/src/assets.ts')
  const physicalPath = 'projects/pal/assets/migrated/battle-backgrounds/006.png'
  const disk = await readFile(physicalPath)
  assert.equal(disk.subarray(0, 8).toString('hex'), '89504e470d0a1a0a')
  const width = disk.readUInt32BE(16)
  const height = disk.readUInt32BE(20)
  assert.deepEqual([width, height], [320, 200])
  const asset = 'battle-background.review'
  const relativePath = 'assets/migrated/battle-backgrounds/006.png'
  const digest = createHash('sha256').update(disk).digest('hex')
  const source = fixture.lbMemorySource({ [relativePath]: Uint8Array.from(disk).buffer })
  const catalog = {
    version: 1,
    assets: {
      [asset]: {
        kind: 'battle-background',
        path: relativePath,
        mediaType: 'image/png',
        bytes: disk.length,
        sha256: digest,
        origin: { kind: 'legacy-migrated' },
      },
    },
  }
  const base = { source, assetResolver: new AssetResolver('review', catalog, {}, source) }
  const palette = { colors: Array.from({ length: 256 }, () => [0, 0, 0]), cycles: [] }
  let closed = 0
  let decoded = 0
  const oldDocument = globalThis.document
  const oldDecoder = globalThis.createImageBitmap
  try {
    globalThis.createImageBitmap = async (blob) => {
      assert.equal(createHash('sha256').update(Buffer.from(await blob.arrayBuffer())).digest('hex'), digest)
      decoded++
      return { width, height, close() { closed++ } }
    }
    globalThis.document = { createElement: () => ({ getContext: () => null }) }
    await assert.rejects(loadBattleBgFull(base, asset, palette), /2d context 不可用/)
    assert.deepEqual(source.reads, [`bytes:${relativePath}`])
    assert.equal(decoded, 1)
    console.log({ bytes: disk.length, digest, width, height, decoded, closed })
    assert.equal(closed, 1)
  } finally {
    if (oldDecoder === undefined) delete globalThis.createImageBitmap
    else globalThis.createImageBitmap = oldDecoder
    if (oldDocument === undefined) delete globalThis.document
    else globalThis.document = oldDocument
  }
}

const witnesses = { scene: sceneEntry, ambience: malformedAmbience, canvas: brokenCanvas }
const selected = witnesses[process.argv[2]]
if (!selected) throw new Error('expected scene, ambience, or canvas')
await selected()
