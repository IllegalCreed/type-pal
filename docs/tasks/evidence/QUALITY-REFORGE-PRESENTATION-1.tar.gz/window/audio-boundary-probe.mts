import { strict as assert } from 'node:assert'
import { validateRuntimeScenes } from '/Users/zhangxu/.codex/worktrees/quality-94-102/type-pal/packages/content/src/validate-runtime.ts'
import { checkRuntimeCommands } from '/Users/zhangxu/.codex/worktrees/quality-94-102/type-pal/packages/content/src/runtime-script.ts'
import { emptyWorldScriptState } from '/Users/zhangxu/.codex/worktrees/quality-94-102/type-pal/packages/content/src/author-script-core.ts'
import { runtimeSceneView } from '/Users/zhangxu/.codex/worktrees/quality-94-102/type-pal/packages/reforge/src/runtime-project-view.ts'
import { collectSceneSoundAssets, collectScriptSoundAssets } from '/Users/zhangxu/.codex/worktrees/quality-94-102/type-pal/packages/reforge/src/audio/sfx-readiness.ts'
import { SfxPlayer } from '/Users/zhangxu/.codex/worktrees/quality-94-102/type-pal/packages/reforge/src/audio/sfx.ts'
import { createMidiPreviewTransport } from '/Users/zhangxu/.codex/worktrees/quality-94-102/type-pal/packages/reforge/src/audio/midi-preview.ts'
import type { RuntimeCommand, RuntimeScriptLibrary, SpriteDef } from '/Users/zhangxu/.codex/worktrees/quality-94-102/type-pal/packages/content/src/index.ts'

const cueSprite: SpriteDef = {
  id: 'sprite.guard',
  asset: 'sprite.guard',
  layout: {kind:'static'},
  poses: {
    first: {label:'First',steps:[{frame:0,durationMs:80,cues:[{kind:'sound',asset:'sound.inactive'}]}]},
    second: {label:'Second',steps:[{frame:0,durationMs:80,cues:[{kind:'sound',asset:'sound.active'}]}]},
  },
}
const scene = validateRuntimeScenes([{
  id:'test-scene',
  mapId:'test-map',
  entry:{pos:{col:0,row:0,height:0},facing:'down'},
  entities:[{
    id:'guard',
    pos:{col:1,row:1,height:0},
    sprite:'sprite.guard',
    initialPage:'second',
    pages:[
      {id:'first',label:'First',animation:{sprite:'sprite.guard',action:'first'}},
      {id:'second',label:'Second',animation:{sprite:'sprite.guard',action:'second'}},
    ],
  }],
}])[0]!
const projected = runtimeSceneView(scene,emptyWorldScriptState())
const soundInput = {spritesById:{'sprite.guard':cueSprite},signal:new AbortController().signal}
const collected = await collectSceneSoundAssets({scene,...soundInput})
const projectedSounds = await collectSceneSoundAssets({scene:projected,...soundInput})
assert.equal(projected.entities[0]?.pages?.[0]?.animation?.action,'second')
assert.deepEqual([...collected],['sound.inactive'])
assert.deepEqual([...projectedSounds],['sound.active'])

const inherited = 'constructor'
const command: RuntimeCommand = {kind:'callScript',script:inherited}
checkRuntimeCommands([command],'case.commands')
const library: RuntimeScriptLibrary = {}
const missingOwn = !Object.hasOwn(library,inherited)
const passedInheritedLookup = await collectScriptSoundAssets([command],library,new AbortController().signal)
const named: RuntimeScriptLibrary = {[inherited]:{name:'Named',self:'none',body:[{kind:'playSound',asset:'sound.named'}]}}
const ownSounds = await collectScriptSoundAssets([command],named,new AbortController().signal)
const ordinaryMissingReason = await collectScriptSoundAssets(
  [{kind:'callScript',script:'missing'}],
  library,
  new AbortController().signal,
).then(()=>null,e=>String(e))
assert.equal(missingOwn,true)
assert.deepEqual([...passedInheritedLookup],[])
assert.deepEqual([...ownSounds],['sound.named'])
assert.match(ordinaryMissingReason ?? '',/缺脚本 "missing"/)

const midi = Uint8Array.from([
  0x4d,0x54,0x68,0x64,0,0,0,6,0,0,0,1,0,96,0x4d,0x54,0x72,0x6b,0,0,0,12,0,
  0x90,0x3c,0x40,96,0x80,0x3c,0x40,0,0xff,0x2f,0,
]).buffer
let paused = true
const midiSeq = {
  currentTime: 0,
  duration: 0.5,
  get paused() {return paused},
  finished:false,
  load(){},
  play(){paused=false},
  pause(){paused=true},
}
const transport=createMidiPreviewTransport({
  async readBytes(id){if(id==='music.b') throw Error('test read failure'); return midi.slice(0)},
  async readRoleBytes(){throw Error('unexpected lower port')},
},{
  context:{state:'running',async resume(){}},
  async initialize(){return midiSeq},
  dispose(){},
})
const loaded = await transport.load('music.a')
assert.equal(loaded.duration,0.5)
await transport.play()
await assert.rejects(transport.load('music.b'), /test read failure/)
transport.stop()
const midiAfterStop=transport.snapshot()
assert.deepEqual(midiAfterStop,{asset:'music.b',duration:0.5,currentTime:0,paused:true})
transport.dispose()

const counters={contexts:0,closes:0,bytes:0}
Object.defineProperty(globalThis,'window',{configurable:true,value:{
  AudioContext: class ReadOnlyBrowserAdapter {
    constructor(){counters.contexts++}
    get state(){return 'running'}
    async close(){counters.closes++}
  },
}})
const err=await Promise.resolve().then(()=>new SfxPlayer({
  record(){throw Error('unexpected record lookup')},
  async readBytes(){counters.bytes++; throw Error('unexpected bytes')},
},undefined,0)).then(()=>null,e=>String(e))
assert.match(err ?? '',/maxDecoded.*收到 0/)
assert.deepEqual(counters,{contexts:1,closes:0,bytes:0})
Reflect.deleteProperty(globalThis,'window')

console.log(JSON.stringify({
  standardWaveScope:'协议与资源生命周期证据。未连接真实浏览器设备',
  scene:{
    projectedAction:projected.entities[0]?.pages?.[0]?.animation?.action,
    currentPortInput:'canonical (main prepareSceneSounds)',
    canonicalSounds:[...collected],
    projectedSounds:[...projectedSounds],
  },
  inheritedScript:{
    commandShapeAccepted:true,
    missingOwn,
    actualSoundsWithoutOwn:[...passedInheritedLookup],
    actualSoundsWithOwn:[...ownSounds],
    ordinaryMissingReason,
  },
  midiAfterStop:{
    successfulAsset:'music.a',
    originalDuration:loaded.duration,
    requestedAsset:'music.b',
    actualSnapshot:midiAfterStop,
  },
  sfxInvalidBudgetLifecycle:{err,counters},
},null,2))
