# Reforge 资源与呈现治理窗口复验

根目录保留首片及 Migrate 六个留项的原始执行。此目录接续同一次治理，候选代码基点为 `b3f6104561d77ba270f08a3a7f4535aa63513350`。本次完整读核覆盖 97 个原 pending。当前路径、Git blob、SHA-256、八维和依赖的唯一查询入口为 `window-manifest.json`。13 项留在 review，另外两项上批 E2E 持有继续留审。

## 快检

在临时目录解压 `docs/tasks/evidence/QUALITY-REFORGE-PRESENTATION-1.tar.gz`。从该目录运行 `python3 window/check-window.py /absolute/path/to/type-pal`。脚本检查源码、caller、旧 Git blob 和归档成员指纹，报告 `stale` 或 `missing` 时只重验受影响的结论。适用性还取决于实际工程输入、原资源版本和对应阶段合同。哈希匹配不授 E2E 或视觉结论。

## 实际执行证据

- `root-review.json`、`assets-review.json`、`audio-review.json`、`menu-review.json` 保存四组全文八维记录。`window-manifest.json` 的最终裁定覆盖原作者的候选处置文字。两份新夹具的单独读核见 `support-assessment.json`。测试根、诚实限定和活动 Owner 基点参考 `ownership-before-gates.json`。
- `reforge-integrated-final` 与 `editor-audio-neighbors` 保存候选的显式 default/Vitest JSON 原件。`targeted-reforge-files.json` 为直接文件选择。精确测试标识、排重和退出理由来自四组映射及 `test-transfer-verification.json`。清单工具用 ` > ` 表示 suite 层级，原生 reporter 用空格。保护门摘要沿用实际工具身份，映射另外核唯一通过的目标身份。
- `approved-asset-audio-red` 首跑包含三个资产文件。两个音频路径位置参数填错，本轮未收集。资产的正式失败为九条业务结果差异，打印原件保留。随后正确选择音频专测，于 `approved-audio-red` 记录四项正式失败；三条 SFX failure 是已实现业务合同的错误结果或错误原因。`approved-asset-green`、`approved-audio-green` 及最终现行路径的集成运行保留恢复。
- `shop-item-red`、`unicode-dialog-red`、`glyph-cache-red`、`scene-context-red` 和 `sprite-context-red` 保留指定反例。资产 alpha 和 legacy 坏尾单点反控分别见 `asset-test-rework`。音频的注入反控会改变后端持有结果，具体业务断言和恢复源见 `audio-organization-mutations`。
- `menu-run` 菜单组合运行出现一条 Canvas 超时，单文件复跑 6/6 通过。失败、恢复和集成身份分别保存。`reforge-base-identities` 与 `reforge-affected-base-identities` 是临时快照缺相邻代码和真实 BDF 的收集失败，均不授证。补齐基线所需原盘独立 BDF 后，正式已选路径身份用 `reforge-affected-base-identities-fixed` 读取，并逐文件匹配受保护旧快照摘要。工作树文件无覆盖。

## 失效与清理

首次 `pnpm check` 在静态文档桥接发现 Q2 当前证据严格绑定 `menu-box.ts` 字节和行锚。撤回该文件单独的注释与低收益清理，保留可独立验收的菜单测试。`menu-box-source-binding-withdrawal.patch` 自原候选反向应用并核主线字节一致，原失败保留。

活动 E2E 的 `main.ts`、对白观察源及菜单宿主按当前依赖身份附入快检。相关来源改变时只复核使用这些输入的结论。真实活动页、资源目录、公开 ABI 及启动异常合同按任务卡保留。原始数据及正式生成物通过事实锚复用。只归档执行身份、必要的未裁剪输出和小反控补丁，完整临时 checkout、缓存、重复报告及临时测试不会进入仓库。
