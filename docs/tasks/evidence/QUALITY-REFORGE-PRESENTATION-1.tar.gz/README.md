# 本窗口阶段执行证据

起点为 #72 合并提交 `b3f6104561d77ba270f08a3a7f4535aa63513350`。候选文件指纹与冻结的候选 Git tree 见 `candidate-files.json`，该树是包含代码变更的 Git index 快照。仓库状态与远端检查按实际时点取证。

## 快速复验

- 首列路径定位到候选代码，A–H 单元格陈述各维的限定证据。历史全文与未变边界复用 `QUALITY-MIGRATION-SOURCE-PROJECTIONS-1.tar.gz` 的 `maps-review.md:7–8`、`asset-and-publication-review.md:14,19,39`、`projections-review.md` 与 `file-review.json` 的同名条目。正式红例 `map-word-domain-red` 和 `sprite-layout-order-red` 原件在该归档，仅保留一份。
- 执行目录的 `execution.json` 记录实际命令、工作目录、时间和退出。用 `stdout/stderr` 和 Vitest 原生 `native.json` 定位完整测试身份与诊断。所有选定命令运行时使用临时输出文件来存 JSON reporter。两个用于调用 PAL、Reforge 最外层路径的临时测试随证据打包，复验时仅复制到隔离树并按执行入口恢复，切勿把 Vitest list 的位置参数当路径过滤用。
- 修订前后一律查涉项路径，不把绿结果推广到全部包或 E2E。地图读取、资产路径、Chrome 注册、DialogueCue 或布局入口变化时，请按实际影响重核相应行。固定源码优先按候选 Git blob 与历史基点回读。

## 原 review 的八维闭环

| 文件 | A 正确性与边界 | B 注释 | C 内聚／耦合 | D 复用 | E 测试 | F 可读性 | G 简洁性 | H 可测试性 |
|---|---|---|---|---|---|---|---|---|
| `packages/migrate/src/project-map-converter.ts` | 全读转换、两层回编码、跨度与字节度量。PAL 发布和地图审计都先验形状和每个半格 u32。地图、格、上下半格进入错误。同步纯函数无取消或资源接管。原版 `map.c:234–257,293–298,339–352`，源提取 `resources/map.ts:35–52`。 | 原展开说明适用于接受域，残差与回编码限定现行持久结构。 | 边界属于获取来源字后的转换，产物为新矩阵，来源对象只读。 | 同一批准校验供供给与地图审计使用，低层位解码仍是独立字操作。 | `project-map-audit.test.ts` 明确拒绝 u32+1、负上半格、小数，最大合法字和残差有固定 oracle。邻接用合法原盘通过。 | 地图号、行列、half 对应诊断，不藏在位操作里。 | 沿用既有 decoder，废除审计重复截断。 | 内存是真入口，原盘集成层可直接调用。 |
| `packages/migrate/src/project-map-audit.ts` | 全读报告、命令 `audit-project-maps.mts` 与 PAL `pal-source-io.ts`。转换失败不发布报告，合法词按原值比较。同步无取消，保持唯一地图 ID。 | 报告的残差、无覆盖高度及比率都是原语义。 | 审计只构造报告，转换所有权保持独立。 | 复用真实转换、字节度量和回编码。 | `project-map-audit.test.ts` 原空集合、UTF-8、残差、重复图及新增词域保留。 | 原值与目标格分别命名。 | 取消两处 sub 类型强转和二次无符号截断。 | 只需几组固定双半格，无需磁盘或 mock。 |
| `packages/migrate/src/pal-world-sprite-semantic-alias.ts` | 两个定义先对齐 JSON 值域，保序数组，比较忽略对象键顺序。锁定真实发布读取和角色引用闭包。 | 结构比较处说明字段和数组步骤的排序规则。 | 角色域、旧别名与替换结果属该投影，全程内存。 | 使用现成 Node 深比较器。当前／生成／角色源组合保持各自原有断言与报错。 | 真实 PAL 调换李逍遥布局键前后通过，错误资源、宽度、动作及角色构成由独立负例锁定。 | `comparableDefinition` 只保留资源、布局、动作三轴。 | 已发现角色域和别名两遍有重叠比较。现有第二遍同时读旧定义并管退役错误，纯运行内存且集合有限，本片保持其独立诊断与遍历边界。 | 能直接验证纯布局，也有真发布给合法输入。 |
| `packages/migrate/src/pal-item-scheme-labels.ts` | 合法作者图由 `validatePalCurrentPublication` 消费。2 起十进制，包括 10–19，沿用根归属，普通作者标签不进入孤儿检查。原作者规范凤纹手绢 2–13。 | 分清原盘脚本与作者标签约定，编号入口只说可核规则。 | 各阶段树查找与归属统计本地，保持原作者字段。 | 私有识别器沿用相同 Item 根图，跳转顺序由真实解析器决定。 | 合法普通标签、孤儿 9、10 只差标签，单元与实际发布各有证据。原 49/11 的 PAL 正控原样。 | 编号分成单个 2–9 和多位正首位两支，无隐式大数转型。 | 沿用一个匹配函数，节点查找没有第二份规则。 | 同一函数可用类型化小合法图或原盘内存发布执行。 |
| `packages/migrate/src/pal-store-boundary.ts` | 唯一生产生成入口过去传空，无读取回执。仍验证九种源奖励次序、268/270 炼化效果和 20 家货单。真实买卖由 Content 顶层校验消费。 | 说明生成 seed 的固定源盘名单与 merged 作者商店的引用检查。 | 迁移守住来源真实性，脚本解释域由 Content 持有。 | 删重复递归，将买卖真实语义留给已有统一入口。 | 原盘对照实际 1–20；unit 验证双 Store0、空/错误货单和材料漂移；原引用相邻 57 绿。 | `PalAlchemyInputs` 表达实际入参，源 Store0 与可见商店分开。 | 退休无消费者回执、仅测计数和两个重复遍历。 | 可对型完整源和独立作者层分别设置负例。 |
| `packages/migrate/scripts/bake-assets.mts` | 根 `pnpm bake`→Migrate 实际命令→Reforge registry。先读生成与校验，再写。链接只允许用作只读提取源，仓库输出目录／叶先拒绝。光标长度和解码与运行时一致。遇系统写盘失败没有多文件回滚，作用域是前置检查。 | 标明 85 PNG、两作者 seed、标题与光标各自级别，输出检查先于写。 | 既有纯转换与输出仍在单一命令生命周期，已编码缓冲由本次独占，写前不修改盘。 | 复用 `assertMigrationFilePath`、`bakeIndexedRgba`、共享 RLE 解码；切片每幅源只读一次。 | 原三例先红，链接目录/文件及坏长度又三红，所有正式负例锁定原输出或外树字节。完全重建逐字节正控。 | 输出路径与 `pendingAssets` 明确区分读、校验和写。 | 维持固定目录与摘要，去重复源图解码，现有额外 PNG 一并纳入摘要判据。 | 真命令在临时 repo 执行，固定源只读，输出/叶链接/错误均实际访问。 |

## 新回归以及 Reforge 首片

| 文件 | A | B | C | D | E | F | G | H |
|---|---|---|---|---|---|---|---|---|
| `packages/migrate/src/pal-item-scheme-ordinal.test.ts` | 合法 schema 和真实归属扫描。 | 测试标题给出标签语义与根归属。 | 只测方案编号入口。 | 用现行小规模作者图夹具。 | 三例只变标签，普通标签比对返回的真实所有者，两个拒绝均刻意断言真实位置。 | 文件指向编号，不按作者。 | 共用一份合法基线。 | 无磁盘、mock 或时间依赖。 |
| `packages/migrate/src/pal-world-sprite-layout-order.pal.test.ts` | 真基线和提取数据，使用真正发布入口。 | 错误明确指出缺少 PAL 资源或角色定义。 | 职责限布局键顺序等价。 | 现行来源 loader，独立 structuredClone 隔离只改一成员。 | 对照能发布及合法交换仍输出实际方向 layout，红先于修。真实内容差异由相邻单元反例负责。 | 文件表达业务合同与 PAL 依赖。 | 两例为同对照变量的正控和目标回归。 | 真实发布内存运行，无资源写。 |
| `packages/migrate/src/bake-engine-chrome.pal.test.ts` | 真实 CLI，原盘命令资源及独立临时输出目录。 | 注释交代刻意改过的旧图与源图。 | 自己持有临时 repo，集中模板和 stdout。 | 共享 `tempRepo` 与 `diskTree` 比较目录、文件摘要及链接。 | 源缺失、seed、总摘要、目录/叶链接、光标坏长度各有指定反例。成功组验证重建结果独立等于真实产物。 | 各标题描述具体争议合同。 | 不留额外弱断言，隔离源采用只读链接。 | 每例独立真实子进程，无伪造运行结果。 |
| `packages/reforge/src/dialog/narration-scroll.ts` | `DialogBox.renderNarrationScroll` 和 `drawRewardGainLine` 各自使用同一 320 宽几何。固定 8px 单位参照 Game 的 `dialog-draw.ts:277–338`，居中与奇偶参照 `sdlpal/text.c:1663–1698`；SDLPal 取字体宽，Reforge 维持现有定宽约定。无 mutable state 或 IO。 | 说明固定宽度单位与外部指定纵坐标。 | 仅坐标，不持语义颜色、计时、阴影、字库或 Canvas。 | 世界拾取的复制公式被统一，y=96 仍由 `main.ts` 的消费者提供。 | 两个固定坐标、实际旁白 render 和世界奖励像素测试相邻。 | 名称体现文字卷轴坐标。 | 辅助计数与形状改模块内，移除重复组装。 | 纯字符串和坐标直接可验。 |
| `packages/reforge/src/dialog/narration-scroll.test.ts` | 两组合法文本对应原盘着色旁白、拾取常见宽／窄混合形式。 | 示例给出奇偶语义。 | 单独测纯几何，Canvas 可见结果交真实 consumer 相邻例。 | 直接调用生产几何，无实现复制。 | 全宽位置 120/128/5，混宽 132/144/4 和 y=40/50。内部计数断言由坐标与中间段数完整判别。 | 两例以实际布局合同命名。 | 无测试专属参数出口或重复中间值。 | 纯可复算常数，两个例无共享 mutable state。 |
| `packages/reforge/src/menu/reward-gain.ts` | `main.ts` 从队首取非空奖励文本，战斗横幅由 `battle-session.ts` 单独给坐标。canvas 的绘制帧不拥有计时／异步；保持各自阴影和文字颜色。 | 去除“唯一入口”的旧声明，保留世界卷轴和战斗文本作用。 | 绘制模块，队列和 battle 生命周期外置。 | 相同居中几何复用旁白，颜色、World y、战斗绘制保持各自合同。 | 真实 320×200 Canvas 在 y=96 源位置的黑色像素、相邻无阴影原例继续通过。 | 文本／带卷轴各有明确函数。 | 去掉复制坐标和重复求单位，rgba 固定仍与战斗需求一致。 | 可直接用标准 glyph 加 canvas 独立执行。 |
| `packages/reforge/src/dialog/dialog-box.glm-large-wave.test.ts` → `dialog-box.lifecycle.test.ts` | 按实际 `open/advance/render/close/observeSlots` 核独立对话清除与脚本保留的不同生命周期。`DialogBox.close:373–381`，Phase2 harvest E4；相邻观察测试继续验证脚本时序。 | 删除会随批次与测试数量失实的头注，两个标题指出清理和重开。 | 生命周期归一份相邻测试，E2E 占用的实现与观察专测均未改。 | 现用 ShellHost 只替代 Canvas I/O，固定 ASCII 字形使测试隔离，无跨场景除错工具。 | 旧序列化字符串无相应像素字段；新 oracle 有共存正控、关闭清空、坐标正负对照。移除隔离实现清理后旧双绿，新残留断言指定单红，另一个安静关闭仍绿。 | 按生命周期命名，不按贡献者。 | 保留两条独立合同，没有继续维护旧标题／路径。 | 用虚构但合法两槽对话和记录 Canvas，无需计时器或图片输入，关闭释放每例 host。 |

## 测试合同去向

- `pal-store-boundary.boundaries.test.ts` 原三条。人工拼的深嵌套计数和非 0 sell 的旧 scanner 契约退出，真实命令 shape 与 sell 语义取 `author-script-core.test.ts` 的 `openShop accepts exact non-negative ids and validates mode independently of reference use`、`project-reference-closure.test.ts` 的 `checks authored command targets and leaves the selling menu independent of shop IDs`。旧输入前后克隆原可判别 mutation。退役输入本身后该合同不再适用。原源 Store0 缺/重复、首两店换序、篡改货单三个轴迁入 `pal-store-boundary.test.ts` 同名业务测试。
- `pal-supply-guards.glm-o.test.ts` 29→26。来源/生成 ShopDef0、id、货单轴与上述强断言重叠，买卖扫描域随退役。保留真实奖励空项和 `item268`/ `item270` 负例，并在 `review-store-test-identity` 留当前完整原生身份。该旧文件的其余职责与命名体系仍为 pending。
- `pal-store-boundary.pal.test.ts` 用原盘和今版 PAL 固定来源核二十店和语义 Store0。真实 Content 引用合同按相邻三文件实际执行。原 `pal-world-sprite-layout-order.pal.test.ts` 使用上窗口正式失败断言，现实现与测试 import 排序复用其语义。
- `review-bake-output-cursor-witness` 首次探针在 Vite import.meta.glob 处未能启动 Reforge loader，该部分不给运行信用。随后 `review-bake-cursor-runtime` 通过真实 Vitest/Vite 环境只替换 fetch I/O，正常三帧和长度错误均有明确业务断言。正式 bake 两个链接负例首次回绿时，盘字节和退出断言都通过，错误字符串漏了一个空格，保留该失败后再精确比对完整路径。
- 迁移最早 typecheck 的临时发布 fixture 赋值缺少 JSON 索引类型，修正为同结构 JSON 字面量。重跑通过，正式源码保留前三项单元和已有原盘标签专测，额外发布变种用例只存证据。最早 Biome 的导入顺序已定向纠正。余额初筛与全仓集成不计早期运行的技术故障为业务反控。
- `dialogue-lifecycle-counter` 中两个副本只替换测试相邻 import，生产反控为 `dialogue-cleanup-counter.patch` 的单一行。两原例身份取基点；后续对应“关闭后两槽清空，重开单槽仅在新正文位置绘制”和“关闭后 advance 与 render 是无观察副作用的 noop”。原两例都保留真实业务，旧文本字符串负断言换成可观察槽位和 Canvas 坐标。恢复版和旧槽单测共 15 例。
