import { execFileSync } from 'node:child_process'
import base from "/Users/zhangxu/.codex/worktrees/quality-94-102/type-pal/packages/editor/vite.config.ts"

const predecessor = '4c5a81553'
const paths = ['content/scenes/s273.json']
const previous = Object.fromEntries(paths.map(path => [
  path,
  execFileSync('git', ['show', predecessor + ':projects/pal/' + path]).toString(),
]))
const readSite = 'const value = rawJson.get(path)'
export default {
  ...base,
  plugins: [
    {
      name: 'pal-census-readonly-probe',
      enforce: 'pre',
      transform(source, id) {
        if (!id.endsWith('/src/core/project-reference.pal.test.ts')) return
        if (source.split(readSite).length !== 2) throw new Error('reference test source changed')
        return source.replace(readSite, 'const value = probeOldFiles?.[path] ?? rawJson.get(path)') + `
let probeOldFiles;
test('measures references removed by retiring the authored handkerchief auto', async () => {
  const live = await loadReferenceContext()
  probeOldFiles = ${JSON.stringify(previous)}
  const before = await loadReferenceContext()
  probeOldFiles = undefined
  const sources = (context) => {
    const behavior = context.edges.filter(({relation})=>relation.kind==='behavior-reference')
    return {
     addresses: context.diagnostics.entityAddressReferences,
     behavior: behavior.map(({id, ...edge})=>edge),
     all: context.edges.map(({id, ...edge})=>edge),
     counts: {
      addresses: context.diagnostics.entityAddressReferences.length,
      behavior: behavior.length,
      rows: context.diagnostics.projectReferences.rows.length,
      targetEdges: context.diagnostics.projectReferences.targetEdgeIds.length,
     }
    }
  }
  const a = sources(before), b = sources(live)
  function difference(from, to) {
    const counts = new Map()
    for (const item of from) {
      const key=JSON.stringify(item)
      counts.set(key,(counts.get(key)??0)+1)
    }
    return to.filter(item=>{
      const key=JSON.stringify(item)
      const count=counts.get(key)??0
      if (count===0) return true
      counts.set(key,count-1)
      return false
    })
  }
  const delta = { countsBefore:a.counts, countsAfter:b.counts }
  for (const key of ['addresses','behavior','all']) {
    delta[key]={ removed:difference(b[key],a[key]), added:difference(a[key],b[key]) }
  }
  const {writeFileSync} = await import('node:fs')
  writeFileSync(process.env.TYPE_PAL_REF_CENSUS_REPORT, JSON.stringify(delta,null,2)+'\\n')
  expect(b.counts.addresses).toBeLessThan(a.counts.addresses)
}, 90000)
`
      },
    },
    ...base.plugins,
  ],
}
