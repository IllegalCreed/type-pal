pnpm --filter @type-pal/migrate check
