pnpm check
