node /tmp/type-pal-reforge-window.ni9ArM/refresh-coverage-components.mjs fast --ratchet --allow-scope-removal 
