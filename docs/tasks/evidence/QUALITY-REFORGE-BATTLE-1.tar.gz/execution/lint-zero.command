node scripts/quality/lint-zero.mjs
