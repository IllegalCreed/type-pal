# 实际执行说明

记录目录相对仓库根。批准范围和源码冻结提交见父卡与 `window/per-file-decisions.json`。以 Vitest 原生 JSON 的 file、fullName、status 回读逐条断言，原始 stdout 与 stderr 保存初始、失败与恢复。映射替代的用例只按各自所在时点计数。

| 原件组 | 实际入口和验证目标 |
|---|---|
| targets-red / targets-green | Reforge Vitest，真实 `src/battle/battle-session.selection-flows.test.ts` 及菜单相邻套件。取消和确认同拍的物品目标与法术目标两条红后恢复。 |
| trial-lock-red / trial-lock-green | Reforge Vitest，真实 `src/battle-trial-host.glm-next-wave.test.ts`，绿色同时覆盖现行试打宿主脚本测试。读锁回调完成后取消或拒绝的两条红后恢复。 |
| round-poison-final-red / round-poison-green | Reforge Vitest，旧 `src/battle/battle-session.flow-residual.test.ts` 两条终态反例。绿同时覆盖规则和会话相邻文件。 |
| reforge-integration / reforge-battle-adjacent-final | 先保存两个攻击日志专测的会心前缀偏差，再按真实日志修并核当前 61 文件。明确 `--reporter=default --reporter=json`。 |
| round-outcome-title-final | 旧敌逃标题收窄后复用同一真实工作流，再跑 `src/battle/battle-session.round-outcomes.test.ts`。 |
| coverage-contract-before / coverage-contract-after | 仅 `src/battle/battle-round-effects.test.ts` 与 `src/battle/battle-ui.status-portraits.test.ts`。针对核心和画面缺省字段做同范围 V8 比较，6 项旧目标和 7 项正式候选分别保留。 |
| recovered-assertions-counter | 用本目录唯一 overlay 输入改动两行守卫，真实条目各报业务 AssertionError。测试集合用 `-t 'equipment restores HP and MP|活人只绘制实际给出的状态字'`，部分测试跳过仅属于反控。 |
| rules-organization / visual-*-control / session-boundary-counter-* | 规则对照异常、渲染输出和会话关闭后的反控，指向 `contract-mapping/` 的固定用例身份。 |
| ratchet-admission-census | 快照两行已登记而工具测试仍期望旧 117，覆盖率收集未开始。工具断言精确更新到 119，判据与保护规则保持。 |
| ratchet-first-measurement | 正式收集 20,415 个 fast 测试后的四项比例差异。 `coverage/` 保留完整报告、主线包报告与逐项归因。 |
| q2-source-binding-control | 三载体回退到旧候选，改报告正文、改旧业务主张皆拒绝。独审扩展的七项见 `window/independent-q2-binding.json`。 |

定向复验入口为 `pnpm --filter @type-pal/reforge exec vitest run src/battle/ src/battle-trial src/enemy-hook-runtime.test.ts src/battle-host.test.ts src/world-result.test.ts src/script-runner.test.ts --reporter=default`。最后两项受改判据的反控在内存 overlay，固定生产文件不改。归档中的原始错误文本维护史料字节，当前验收看最后执行记录。
