import base from "/Users/zhangxu/.codex/worktrees/quality-94-102/type-pal/packages/reforge/vite.config.ts"

const changes = new Map([
  ['/battle/battle-core.ts', [
    'if (p.regenHp) p.hp = Math.min(p.maxHp, p.hp + p.regenHp)',
    '',
  ]],
  ['/battle/battle-ui.ts', [
    'if ((p.status[w.key] ?? 0) <= 0) continue',
    'if (p.status[w.key] !== undefined && Number(p.status[w.key]) <= 0) continue',
  ]],
])
export default {
  ...base,
  plugins: [
    {
      name: 'view-restored-contracts',
      enforce: 'pre',
      transform(code, id) {
        const change = [...changes].find(([suffix]) => id.endsWith(suffix))
        if (!change) return
        const [original, replacement] = change[1]
        if (code.split(original).length !== 2) throw new Error('expected one targeted probe site')
        return code.replace(original, replacement)
      },
    },
    ...base.plugins,
  ],
}
