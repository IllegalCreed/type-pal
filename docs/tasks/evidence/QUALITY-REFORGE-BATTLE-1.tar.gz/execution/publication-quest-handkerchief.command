pnpm --filter @type-pal/migrate exec tsx /tmp/type-pal-reforge-window.ni9ArM/probe-publication-quest-handkerchief.mts (repository cwd; this probe runs from the root via pnpm exec)
