# Reforge 战斗治理的测试合同去向

原路径及行号统一取 Git 基点 3f1f672ab878521fa58a443a72781adc9602c187。承接路径、当前源码字节和实际 Vitest 全名在 `../window/per-file-decisions.json`。旧作者、任务号与 wave 标签只用来追溯撤换。计数以 fast 实际收集为准。

## 规则、演出、试打及会话夹具

- `battle-rule-test-identities.json` 逐项记录核心三份旧专测的 17 个身份及同义断言的承接。阈值反控与恢复保留在 `execution/rules-organization/`。
- `enemy-closure-and-hook.identities.json` 逐项记录闭包与钩子测试的命名、合并及结果强化。闭包只核现场合法已注册对象。
- `visual-rework-identities.json`、`visual-anim-rework-identities.json` 核画面合成、坐标、颜色及时间线的原身份与实际像素、音效和结束判据。
- `trial-test-organization-identities.md` 核试打配置表与真实宿主的移交。旧原生反控仍从原路径在基点复验。读锁两个红例的代码随修复从旧专测迁入 lifecycle。
- `session-boundary-organization-identities.json` 记录两份旧批次会话专测与现用败北专测的 12 个原身份。取消后的资源和指令互斥用同一已闭会话观察。

## 战斗列表

`battle-command-selection.residual.test.ts` 的六条按原顺序进入 `battle-command-selection.lists-and-targets.test.ts` 前六条。依次为杂项两个入口、全体和单体投掷、单体友方法术回退、真气与金币的不同检查阶段、耗尽物品的重放替代、单体合击提交与退出。全体和单体投掷在真实队员序列交叉观察，取消前后分别验零提交和保留合法敌槽。

`battle-command-selection.glm-next-wave.test.ts` 的技能网格、E 入口逐层回退和用品目标退回三条对应承接第七至九条。用品例改为合法同一用物对象，检查重进时默认槽回到使用者并确认实际动作。最后一条空敌场锁定了旧的等待死角，现由 `battle-session.round-outcomes.test.ts` 覆盖实际末敌倒下后零额外输入即可结算。强制攻击在无有效敌时的独立防御策略仍由承接第五条覆盖。

`battle-last-action.test.ts` 的目标类型声明检查迁往 `last-action.typecheck.ts`，由实际 Reforge tsconfig 运行三项精确类型断言。旧 `battle-result.test.ts` 的两条身份只调用获准退役的四个函数。五种结局和对应奖励页仍从正式会话、世界结果、脚本接续和流程专测观察。

## 结算与退出

| 原路径和行号 | 现行判据 |
|---|---|
| `battle-settlement.residual.test.ts:111` 和 `settlement.glm-runtime-resource.test.ts:64` | `battle-settlement-screens.test.ts` 首例用独立的角色、统计字段、金钱及技能名断言奖励页与各角色增长／习得顺序。 |
| `battle-settlement.residual.test.ts:178` 和 `settlement.glm-runtime-resource.test.ts:91` | 同一屏序正例含仅增长的独立队员；空输入例断言不建空页。 |
| `battle-settlement.residual.test.ts:200` | `battle-settlement-render.test.ts` 四条各对准一个真实页面，包括主等级页八项对照和 HP/MP 的两种数字图集。 |
| `settlement.glm-runtime-resource.test.ts:145`、`:188` | 同一渲染专测第一和第三条核具体坐标、字体、颜色和内容。六位数不挤占标签。 |
| `battle-session.flow-residual.test.ts:125` | `battle-session.round-outcomes.test.ts` 首例仍核两次实际毒发、胜利、5 经验加 3 金钱，强化零后继指令条件。第二例补我方毒发全灭分叉。 |
| `battle-session.flow-residual.test.ts:186` | 同一回合结果专测第三条仍核失败逃跑后同一会话胜利及战果。单次构建由现行 `battle-session.terminal-flows.test.ts` 核具体回调。旧用例标题中的单次结算超出其断言。 |
| `battle-session.enemy-flee-residual.test.ts:101` | 同一回合结果专测第四条由真实敌方规则进 `enemyFled`，不构建奖励、收益为零。 |
| `battle-action-presentation-scheduler.test.ts:90` | 退役源码匹配。首帧、真实节拍与宿主前进行为继续由当前五项执行身份和会话用例观察。 |
| `battle-settlement-presentation.test.ts:99` | 退役源码匹配。结算归属、页面一次构建、接受键与等待门继续由当前十三项执行身份观察。 |

## 试打资源及启动

| 原路径和行号 | 现行判据 |
|---|---|
| `battle-trial-assets.glm-n.test.ts:40` | 脚本专测 `battle-trial-assets.test.ts:13` 仍断言快照拒绝 URL，`:82` 以合法摘要与长度只坏一个维度的 fixture 分别核登记错误。 |
| `battle-trial-assets.glm-n.test.ts:70` | 脚本专测同文件 `:102` 仍在资源读取前取消，精确侧录 zero IO。 |
| `battle-trial-assets.glm-n.test.ts:80`、`:190` | 新资源专测用已登记的配乐和音色库按 asset/silent 分开判别，验证确切 MIDI 字节及 MIDI／音色库读取路径。另有实体攻击和法术图像计数。 |
| `battle-trial-assets.glm-n.test.ts:208` | 脚本专测 `:13` 用真实字节及双侧改动，核 seal 后已缓存读取并明确禁止新路径，dispose 后拒绝。 |
| `battle-trial-assets.wave2.test.ts:63`、`:73`、`:96` | 同名完整业务标题迁入快照专测，由实际在途读和迟到释放顺序支撑。取消和成功/失败保持独立。 |
| `battle-trial-assets.wave2.test.ts:144`、`:267` | 同名业务标题进入现行试打资产专测。读取前后分别验证实际项目、可见输出、持有资源的释放和失败不交付。 |
| `battle-launch-preparation.glm-n.test.ts:128` | 新启动资产专测选不同的合法遭遇曲和默认曲，核精确最终资产。 |
| `battle-launch-preparation.glm-n.test.ts:138` | 同一文件以已登记背景、常驻波和实际解码投掷帧验证接线。 |
| `battle-launch-preparation.glm-n.test.ts:155` | 同一文件仅在没有默认战场条目时不加载背景。旧标题暗示加载了 24 号背景，原断言仅证明无背景 IO。 |

## 独立复核后的补强

旧 `battle-core.c85-branches.test.ts:274` 只断言 MP 即使同时给了回血词条。新 `battle-round-effects.test.ts` 同时驱动受伤和少量消耗的合法角色，两组正交输入均精确断言 HP 与 MP 以及两个上限。移除装备回血语句得到预期 hp 83、实际 hp 80，MP 仍正确为 25。

旧 `battle-ui.residual.test.ts:102` 只给活人的乱、眠状态并观察正好两条。新 `battle-ui.status-portraits.test.ts` 用真实绘制接口恢复此负向合同，独立留全状态坐标和颜色测试。破坏缺字段回退得到四条状态字，零新 UI 需求。
