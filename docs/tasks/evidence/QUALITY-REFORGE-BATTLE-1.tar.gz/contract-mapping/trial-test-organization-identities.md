# 试打配置与宿主专测映射

固定源码基点 `3f1f672ab878521fa58a443a72781adc9602c187`。宿主旧文件的六项测试以本轮已得到资源释放红、绿回执的代码为输入。

## 配置解析

下表的配置用例现在位于 `packages/reforge/src/battle-trial-config.test.ts`，全名带原有 describe 前缀 `battle trial JSON contract`。`trial-organized-pre-apply.json` 保存实际 Vitest 名称及状态。

| 原文件和身份 | 承接职责与业务断言 |
| --- | --- |
| `battle-trial-config.wave2.test.ts:39` 非普通 JSON 对象 | `rejects a non-JSON object even when its fields match a legal trial`。实例在拒绝前具有合法配置全部字段，检查普通对象诊断。 |
| `battle-trial-config.wave2.test.ts:46` 稀疏数组、空和有首尾空白的 ID | `rejects 'sparse inventory rows' without modifying the input`、`rejects 'empty actor ID' on the member input`、`rejects 'actor ID with outer whitespace' on the member input`。 |
| `battle-trial-config.wave2.test.ts:58` 100% 合法、101% 拒绝、有值资源合法 | `preserves the inclusive resource-pool limits` 核精确保留 100% 和最大安全整数，`rejects 'percent MP above 100' on the member input` 核明确错误域。HP、MP 共用同一资源池 parser。 |
| `battle-trial-config.wave2.test.ts:70` 未知槽、技能 tag、重复技能 | `rejects 'unknown equipment slot' on the member input`、`rejects 'invalid skill mode' on the member input`、`rejects 'duplicate skills' on the member input`，各自保留字段路径。 |
| `battle-trial-config.wave2.test.ts:82` 五槽与 ID、音乐资源和无效模式 | `rejects 'short slots' without modifying the input` 以四槽作为临界错误，`rejects 'empty enemy slot ID' without modifying the input`、`rejects 'missing music asset ID' without modifying the input`、`rejects 'bad music tag' without modifying the input`、`rejects 'bad enemy source tag' without modifying the input`。合法含空五槽由原第一个正例保留。 |
| `battle-trial-config.wave2.test.ts:99` 合法 round-trip | 原 `preserves explicit zero/empty/silence and enemy holes; detaches actual input` 已验证返回内容、更改返回成员和库存后输入仍相同。删除依赖 parser 生成输入的较弱同义样本。 |
| `battle-trial-config.glm-runtime-resource.test.ts:14` 整数原语 | 合并到真实配置字段的 `non-numeric field ID`、`negative money`、`fractional money`、`overflow`，以及 `preserves the inclusive resource-pool limits`。任意范围 0～10 的合成调用退出。 |
| `battle-trial-config.glm-runtime-resource.test.ts:22` 布尔原语 | 原静音 fixture 保留 false，`accepts each source/resource mode and removes only zero inventory rows` 显式验证 true，`rejects 'wrong boolean' without modifying the input` 由真实 `trial.auto` 提供错误域。 |
| `battle-trial-config.glm-runtime-resource.test.ts:28` ID 原语 | 合法 ID 由同一正控，空、空白、非字符串由 `empty actor ID`、`actor ID with outer whitespace`、`missing actor ID` 的 exact path 拒绝。 |
| `battle-trial-config.glm-runtime-resource.test.ts:37` AbortError 分类 | `packages/reforge/src/battle/battle-launch-preparation.test.ts` 的 `distinguishes battle cancellations from failures at the launch boundary`，保留函数真实来源及原五种输入标签。 |

原 `battle-trial-config.test.ts` 的数量、槽位及格式正控保留。4、5、6 人拒绝的同一守卫以第 4 人临界用例承接，原最后一例的大于三人重复断言归同一个临界用例。原输入错误矩阵的业务手段保留，诊断加强到字段路径。原 `invalid ID` 行即错 `fieldId` 类型，现名为 `non-numeric field ID`。原 8 个 `rejects malformed member field %#` 按字段顺序迁入 `level below one`、`live HP in stats`、`unknown equipment slot`、`inherited skills with explicit IDs`、`duplicate skills`、`full HP with an explicit value`、`percent MP above 100`、`missing actor ID`。

## 试打宿主

`packages/reforge/src/battle-trial-host.glm-next-wave.test.ts` 的同层业务测试移动到 `packages/reforge/src/battle-trial-host.lifecycle.test.ts`。缺画布、停止并可重启、重启回调错误与最新的两条 `trial releases a prepared project face after post-read …` 原完整标题和断言保留。后两例在原 TS 文件中的代码段逐字节相同，SHA-256 `a1436e598b1d865d0cd51c90167e41810995897198b71da126a9d9481c004372`。资源泄漏修复的同路径红、绿原件仍各自保存。

原组合案例 `F5/F9 只更新状态栏存读档提示；真实战斗打到 victory 并回调 onResult(胜利)` 的前半由既有 `packages/reforge/scripts/battle-trial-host.test.ts` 的 `real host enters BattleSession, rejects F5/F9 and releases its run without constructing any SaveStore` 承接。它还断言浏览器默认键处理被拦截、正常保存调用未发生、卸载后监听释放。后半在移入文件的 `a real trial victory reports exact rewards and health in the host` 中保留真实结束与单次回调，加强金额到固定工程应得的 101。现行反控工具的脚本宿主路径和标题均无需变化。

## 准备与核验

`trial-test-organization.patch` 经 `git apply --check`。改组前以 scratch Vite 插件在原路径载入候选测试代码，四文件 56 项通过，stderr 为空。插件只把候选测试代码交给真实 Vitest、产品和真实运行配置，工作树未应用补丁。运行身份及原件见 `trial-test-scratch-vite.config.mjs` 和 `trial-organized-pre-apply.{stdout,stderr,json}`。合入后用新实际路径重测，由根更新官方覆盖率基线和候选源码锚点。
