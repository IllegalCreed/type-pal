import { execFileSync } from 'node:child_process'
import { createHash } from 'node:crypto'
import { readFileSync } from 'node:fs'
import { resolve } from 'node:path'
import { loadPalBaseline } from '/Users/zhangxu/.codex/worktrees/quality-94-102/type-pal/packages/migrate/src/migration-baseline.ts'
import { discoverProjectManagedFiles, loadProjectMigrationSnapshot } from '/Users/zhangxu/.codex/worktrees/quality-94-102/type-pal/packages/migrate/src/migration-project-io.ts'
import { createMigrationPlan } from '/Users/zhangxu/.codex/worktrees/quality-94-102/type-pal/packages/migrate/src/migration-plan.ts'
import { loadPalContentSupplySources } from '/Users/zhangxu/.codex/worktrees/quality-94-102/type-pal/packages/migrate/src/pal-content-supply-io.ts'
import { buildPalCurrentPublication, validatePalCurrentPublication } from '/Users/zhangxu/.codex/worktrees/quality-94-102/type-pal/packages/migrate/src/pal-current-publication.ts'
import { buildPalCurrentManifest } from '/Users/zhangxu/.codex/worktrees/quality-94-102/type-pal/packages/migrate/src/pal-manifest.ts'
import { validateAuthorItems, validateAuthorScenes, validateSceneIndex } from '/Users/zhangxu/.codex/worktrees/quality-94-102/type-pal/packages/content/src/index.ts'
import { inspectPalItemSchemeRoots } from '/Users/zhangxu/.codex/worktrees/quality-94-102/type-pal/packages/migrate/src/pal-item-scheme-labels.ts'

const cwd = process.cwd()
const contentChange = 'aab54db0f443b44e4b864788b25c8d583a4cde1b'
const paths = ['content/items.json', 'content/scenes/s100.json', 'content/scenes/s192.json', 'content/scenes/s273.json']
const scenePath = 'content/scenes/s273.json'
const orphanKey = 'c8-a0ab54723b62'
const baseline = loadPalBaseline(cwd)!
const sources = loadPalContentSupplySources(cwd)
const publication = buildPalCurrentPublication(baseline, sources)
const manifest = buildPalCurrentManifest(sources.assetCatalog)
const seed = new Set([...baseline.managedFiles, ...publication.managedFiles])
const project = loadProjectMigrationSnapshot(cwd, discoverProjectManagedFiles(cwd, seed))
const previous = new Map(project.files)
const digest = (bytes: Buffer) => createHash('sha256').update(bytes).digest('hex')
const recordedInputs = paths.map(path => {
  const old = execFileSync('git', ['show', contentChange + '^:projects/pal/' + path], { maxBuffer: 16_000_000 })
  const raw = readFileSync(resolve(cwd, 'projects/pal', path))
  previous.set(path, JSON.parse(old.toString()))
  const head = execFileSync('git', ['rev-parse', 'HEAD:projects/pal/' + path], { encoding: 'utf8' }).trim()
  if (!execFileSync('git', ['show', 'HEAD:projects/pal/' + path], { maxBuffer: 16_000_000 }).equals(raw)) throw new Error('non-canonical input: ' + path)
  return { path, baseBlob: head, before: digest(old), current: digest(raw) }
})
const launch = (files: typeof project.files) => {
  const plan = createMigrationPlan(baseline, { ...project, files }, publication)
  if (plan.conflicts.length) throw new Error('Unexpected conflicts: ' + JSON.stringify(plan.conflicts.slice(0, 3)))
  const validation = validatePalCurrentPublication({ publication: { ...publication, files: plan.target, managedFiles: new Set(plan.target.keys()) }, manifest, sources })
  return { summary: plan.summary, validation }
}
const tryLaunch = (files: typeof project.files) => {
  try { return { ok: launch(files) } } catch (error) { return { error: (error as Error).message } }
}
const before = tryLaunch(previous)
const current = tryLaunch(project.files)
const withoutOrphan = new Map(project.files)
const scene = structuredClone(project.files.get(scenePath)) as { entities: { id: string, pages: unknown, behaviors: { auto: Record<string, unknown>, trigger: Record<string, {flow:{stages: { body: unknown[] }[]}}> }}[] }
const entity = scene.entities.find(({ id }) => id === 'e4724')!
if (!Object.hasOwn(entity.behaviors.auto, orphanKey)) throw new Error('counter input lost the former auto scheme')
const change = { oldLabel: (entity.behaviors.auto[orphanKey] as { label: string }).label, pages: entity.pages, triggerTail: entity.behaviors.trigger['c8-f4bde04ce9f0']!.flow.stages[0]!.body.map(value => (value as {kind: string}).kind) }
delete entity.behaviors.auto[orphanKey]
if (Object.keys(entity.behaviors.auto).length === 0) delete (entity.behaviors as { auto?: unknown }).auto
withoutOrphan.set(scenePath, scene as never)
const trial = tryLaunch(withoutOrphan)
const index = validateSceneIndex(withoutOrphan.get('content/scenes/index.json'))
const graph = inspectPalItemSchemeRoots({items: validateAuthorItems(withoutOrphan.get('content/items.json')), scenes: validateAuthorScenes(index.scenes.map(entry=>withoutOrphan.get(entry.path))), expectedSchemes: 48, expectedItemRoots: 11})
if (!('ok' in before) || !('error' in current) || !current.error.includes(orphanKey) || !('error' in trial) || !trial.error.includes('48 != 49')) throw new Error(JSON.stringify({ before,current,trial }))
console.log(JSON.stringify({ execution: 'Read-only production publication plan and validation. Third case changes one in-memory JSON member; no author, baseline, reference or rule written.', basedOn: contentChange, recordedInputs, before, current, trial, authorGraphWithoutOrphan: {...graph,labels:graph.labels.filter(entry=>entry.itemId==='292')}, change },null,2))
