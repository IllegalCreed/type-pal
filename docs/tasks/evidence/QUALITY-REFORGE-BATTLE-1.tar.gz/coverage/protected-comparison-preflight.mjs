import assert from 'node:assert/strict'
import { execFileSync } from 'node:child_process'
import { createHash } from 'node:crypto'
import { existsSync, readFileSync } from 'node:fs'
import { pathToFileURL } from 'node:url'

const moduleAt = (path) => import(pathToFileURL(process.cwd() + '/' + path))
const { adjustApprovedBaseline } = await moduleAt('scripts/coverage/approved-baseline-adjustments.mjs')
const { isApprovedTestRetirement } = await moduleAt('scripts/coverage/approved-test-retirements.mjs')
const { auditScope } = await moduleAt('scripts/coverage/inventory.mjs')
const { compareCoverage } = await moduleAt('scripts/coverage/metrics.mjs')
const protectedRef = '3f1f672ab878521fa58a443a72781adc9602c187'
const baselineFile = 'scripts/coverage/baseline.fast.json'
const old = JSON.parse(execFileSync('git',['show',protectedRef + ':' + baselineFile], {maxBuffer: 20*1024*1024}))
const next = JSON.parse(readFileSync(baselineFile))
const actual = JSON.parse(readFileSync('coverage/fast/summary.json'))
const audit = auditScope(next,old)
const precise = await adjustApprovedBaseline(old, (path)=>readFileSync(path))
assert.deepEqual(precise.applied,['reforge-battle-organization-20261124'])
const comparison = compareCoverage(next,precise.baseline)
assert.deepEqual(comparison.regressions,[])
const counts = (file, snapshot) => Object.values(snapshot.packages)
  .flatMap(pkg=>pkg.fastTests.fileEntries)
  .find(entry=>entry.file===file)
const pinned = []
for(const removal of audit.removals) {
  const file = removal.value
  if (!existsSync(file)) continue
  assert.equal(removal.kind,'test-count',file)
  const fileSha256=createHash('sha256').update(readFileSync(file)).digest('hex')
  assert(isApprovedTestRetirement({removal,previous:counts(file,old),current:counts(file,next),fileSha256}),file)
  pinned.push(file)
}
assert.equal(pinned.length,2)
for (const id of Object.keys(old.packages)) {
  if(id!=='reforge') assert.deepEqual(next.packages[id],old.packages[id])
  assert.deepEqual(next.packages[id].metrics,actual.packages[id].metrics)
}
assert.deepEqual(next.total,actual.total)
assert.equal(next.testCount,20416)
assert.equal(next.sourceFileCount,841)
console.log(JSON.stringify({protectedRef,comparison,pinned,actualTestCount:next.testCount,reforge:next.packages.reforge.metrics,scopeChangeCount:audit.changes.length,retiredCurrentPaths:audit.removals.filter(r=>r.kind==='test-file').length},null,2))
