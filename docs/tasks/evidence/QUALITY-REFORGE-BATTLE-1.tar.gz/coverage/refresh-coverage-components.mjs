import { createHash } from 'node:crypto'
import { readFileSync, writeFileSync } from 'node:fs'
import { dirname, resolve } from 'node:path'
import { fileURLToPath, pathToFileURL } from 'node:url'

const scratch = dirname(fileURLToPath(import.meta.url))
const path = resolve('scripts/coverage/run.mjs')
const source = readFileSync(path, 'utf8')
const terminator = '\nmain().catch((error) => {\n'
const index = source.indexOf(terminator)
if (index === -1 || index !== source.lastIndexOf(terminator)) throw new Error('runner dispatch changed')
const code = source.slice(0, index).replace(/(from ')\.\/([^']+)(')/g, (_, before, specifier, after) =>
  before + pathToFileURL(resolve(dirname(path), specifier)).href + after)
const exported = [
  'assertToolVersions', 'collectPackage', 'coveragePackages', 'aggregateMetrics', 'printSummary',
  'readBaselineFromGit', 'assertCandidateDoesNotLowerProtectedBaseline', 'compareCoverage',
  'approvedComparisonBaseline', 'auditScope', 'assertSafeRatchetScope', 'baselineView', 'writeBaseline',
]
const generated = code + '\nexport { ' + exported.join(', ') + ' }\n'
const runnerPath = resolve(scratch, 'coverage-runner-authority.mjs')
writeFileSync(runnerPath, generated)
const runner = await import(pathToFileURL(runnerPath).href)
const read = (filename) => JSON.parse(readFileSync(filename, 'utf8'))
const prior = read(resolve(scratch, 'pre-quest-fast-summary.json'))
const outputRoot = resolve(scratch, 'coverage-quest-components')
const deltaPath = resolve(scratch, 'coverage-quest-components.json')
const finalPath = resolve(scratch, 'coverage-quest-final-summary.json')
const measured = new Set(['migrate', 'reforge'])
if (process.env.TYPE_PAL_REUSE_COVERAGE_MEASUREMENTS !== '1') {
  await runner.assertToolVersions()
  const delta = {}
  for (const config of runner.coveragePackages) {
    if (!measured.has(config.id)) continue
    delta[config.id] = await runner.collectPackage(config, outputRoot)
  }
  writeFileSync(deltaPath, JSON.stringify(delta, null, 2) + '\n')
  console.log('Official package measurements saved: ' + deltaPath)
} else {
  const delta = read(deltaPath)
  if (Object.keys(delta).join(',') !== 'migrate,reforge') throw new Error('unexpected changed packages')
  const packages = { ...prior.packages, ...delta }
  const result = {
    ...prior, packages,
    generatedAt: new Date().toISOString(),
    sourceFileCount: Object.values(packages).reduce((sum, pkg) => sum + pkg.sourceFileCount, 0),
    testCount: Object.values(packages).reduce((sum, pkg) => sum + pkg.selectedTests.testCount, 0),
    total: runner.aggregateMetrics(Object.values(packages).map(pkg => pkg.metrics)),
  }
  runner.printSummary(result)
  const baseline = read('scripts/coverage/baseline.fast.json')
  const base = process.env.TYPE_PAL_COVERAGE_BASE_REF
  if (!base) throw new Error('a Git base is required for protected preflight')
  const scope = runner.auditScope(result, baseline)
  runner.assertSafeRatchetScope(scope)
  const protectedBaseline = await runner.readBaselineFromGit(base)
  const candidate = runner.baselineView(result)
  await runner.assertCandidateDoesNotLowerProtectedBaseline(candidate, protectedBaseline)
  for (const id of Object.keys(candidate.packages).filter(id => !measured.has(id))) {
    if (JSON.stringify(candidate.packages[id]) !== JSON.stringify(baseline.packages[id])) {
      throw new Error('unmeasured package changed: ' + id)
    }
  }
  await runner.writeBaseline(result)
  writeFileSync(finalPath, JSON.stringify(result, null, 2) + '\n')
}
console.log(JSON.stringify({runnerSha256: createHash('sha256').update(source).digest('hex'), measured: [...measured], reused: Object.keys(prior.packages).filter(id => !measured.has(id))}))
