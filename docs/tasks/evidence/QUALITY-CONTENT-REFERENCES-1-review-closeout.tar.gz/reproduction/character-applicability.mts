import assert from 'node:assert/strict'
import { execFileSync } from 'node:child_process'
import { createHash } from 'node:crypto'
import { mkdtemp, readFile, readdir, rm, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { dirname, join } from 'node:path'
import { pathToFileURL } from 'node:url'

const rel = 'packages/content/src/character.ts'
const repository = process.cwd()
const base = process.argv[2] ?? '778928d199dc74768d0499d7a42081098bb2390d'
assert.match(base, /^[0-9a-f]{40}$/u)
const currentModule = (path: string) => import(pathToFileURL(join(repository, path)).href)
const {
  applySetParty, buildWorld, CONTENT_VERSION, CURRENT_PROJECT_MINIMUM_SAVE_VERSION,
} = await currentModule(rel)
const {
  validateActors, validatePoisons, validateStartWorld,
} = await currentModule('packages/content/src/validate.ts')
const { validateWorldVariableRegistryV1 } = await currentModule('packages/content/src/world-variable.ts')
const runtimeSource = join(repository, rel)
const oldBytes = execFileSync('git', ['show', `${base}:${rel}`])
const newBytes = await readFile(runtimeSource)
const hash = (value) => createHash('sha256').update(value).digest('hex')
const oldHash = hash(oldBytes)
const newHash = hash(newBytes)
assert.notEqual(oldHash, newHash)
const runtimeImports = ['actor-condition', 'author-script-core', 'world-variable']
for (const module of runtimeImports) {
  const source = 'packages/content/src/' + module + '.ts'
  assert.deepEqual(
    await readFile(join(repository, source)),
    execFileSync('git', ['show', `${base}:${source}`]),
    'The comparison must run with identical runtime dependencies: ' + source,
  )
}

const files = new Map<string, string>()
const scratch = await mkdtemp(join(tmpdir(), 'type-pal-character-predecessor.'))
try {
  const oldModule = join(scratch, 'baseline-character.mts')
  const rewritten = oldBytes.toString('utf8').replace(/\bfrom '\.\/([^']+)\.js'/g, (_match, module) =>
    'from ' + JSON.stringify(join(dirname(runtimeSource), module + '.ts')),
  )
  await writeFile(oldModule, rewritten, { flag: 'wx' })
  const predecessor = await import(pathToFileURL(oldModule).href)
  assert.equal(CONTENT_VERSION, predecessor.CONTENT_VERSION)
  assert.equal(CURRENT_PROJECT_MINIMUM_SAVE_VERSION, predecessor.CURRENT_PROJECT_MINIMUM_SAVE_VERSION)

  const project = join(repository, 'projects/pal')
  const read = async (relative: string) => {
    const bytes = await readFile(join(project, relative))
    files.set(relative, hash(bytes))
    return JSON.parse(bytes.toString('utf8'))
  }
  const manifest = await read('manifest.json')
  const actors = validateActors(await read(manifest.content.actors))
  assert(!actors.some(({ id }) => Object.hasOwn(Object.prototype, id)))
  const actorTable = Object.fromEntries(actors.map((actor) => [actor.id, actor]))
  const poisons = Object.fromEntries(validatePoisons(await read(manifest.content.poisons)).map((entry) => [entry.id, entry]))
  const variables = validateWorldVariableRegistryV1(await read(manifest.content.worldVariables))
  const parties = new Map()
  function collect(value) {
    if (!value || typeof value !== 'object') return
    if (!Array.isArray(value) && value.kind === 'setParty') {
      assert(Array.isArray(value.members) && value.members.length > 0)
      const key = JSON.stringify(value.members)
      for (const member of value.members) assert(actorTable[member]?.battler)
      parties.set(key, value.members)
    }
    for (const child of Object.values(value)) collect(child)
  }
  const scenes = await readdir(join(project,'content/scenes'))
  for (const name of scenes.filter((entry) => /^s\d+\.json$/u.test(entry))) collect(await read('content/scenes/' + name))
  collect(await read(manifest.content.sharedScripts))
  let transitions = 0
  for (const entry of manifest.entryPoints) {
    const start = validateStartWorld(entry.startWorld)
    const before = predecessor.buildWorld(start, actorTable, variables, poisons)
    const after = buildWorld(start, actorTable, variables, poisons)
    assert.deepEqual(after,before)
    for (const members of parties.values()) {
      const priorWorld = structuredClone(before)
      const nextWorld = structuredClone(after)
      predecessor.applySetParty(priorWorld, members, actorTable)
      applySetParty(nextWorld, members, actorTable)
      assert.deepEqual(nextWorld, priorWorld)
      predecessor.applySetParty(priorWorld, start.party, actorTable)
      applySetParty(nextWorld, start.party, actorTable)
      assert.deepEqual(nextWorld, priorWorld)
      transitions += 2
    }
  }
  const catalogSource = execFileSync('git', ['show', `${base}:docs/testing/catalog.json`])
  const catalog = JSON.parse(catalogSource.toString('utf8'))
  const beforeLines = oldBytes.toString('utf8').split('\n')
  const afterLines = newBytes.toString('utf8').split('\n')
  const refs = []
  for (const entry of catalog.entries) {
    for (const ref of entry.sourceRefs.filter((source) => source.path === rel)) {
      const [first, last = first] = ref.lines.split('-').map(Number)
      assert.equal(ref.sha256, oldHash)
      assert(beforeLines.slice(first - 1, last).join('\n').includes(ref.anchor))
      assert.deepEqual(afterLines.slice(first-1,last), beforeLines.slice(first-1,last))
      refs.push({ id: entry.id, lines: ref.lines, anchor: ref.anchor, role: ref.role })
    }
  }
  console.log(JSON.stringify({
    base, path:rel, beforeSha256:oldHash, afterSha256:newHash,
    contentVersion:CONTENT_VERSION, minimumSaveVersion:CURRENT_PROJECT_MINIMUM_SAVE_VERSION,
    actors:actors.length, entryPoints:manifest.entryPoints.map((entry)=>entry.id),
    partySequences:parties.size, equivalentWorldTransitions:transitions, refs,
    fixtureFiles: files.size,
    fixtureListSha256: hash(JSON.stringify([...files].sort(([a], [b]) => a.localeCompare(b)))),
    frozenCatalogSha256: hash(catalogSource),
    limitation:'Only the declared version spans and actual PAL init/party inputs are proven. This was not an E2E execution.',
  }, null, 2))
} finally {
  await rm(scratch, { recursive: true })
}
