import assert from 'node:assert/strict'
import {
  firstNewUnavailableSpriteFrame,
  spriteDefinitionFrameIndices,
  type SpriteDef,
} from '/Users/zhangxu/.codex/worktrees/quality-94-102/type-pal/packages/content/src/sprite.ts'

const layouts: SpriteDef['layout'][] = [
  { kind: 'static' },
  { kind: 'loop', frameCount: 2 },
  { kind: 'loop', frameCount: 5 },
  ...[1, 2, 3, 4].map((framesPerDir) => ({ kind: 'directional' as const, framesPerDir })),
]
const subjects = layouts.flatMap((layout) =>
  [[], [1], [3, 8], [4, 4, 12], [17, 10, 16]].map((frames) => ({
    layout,
    poses: { motion: { label: 'Motion', steps: frames.map((frame) => ({ frame, durationMs: 80 })) } },
  })),
)
let cases = 0
for (const previous of subjects) {
  const oldIndices = spriteDefinitionFrameIndices(previous)
  for (const next of subjects) {
    const newIndices = [...spriteDefinitionFrameIndices(next)]
    for (const actual of [1, 2, 4, 8, 12, 16, 20]) {
      const expected = newIndices.find((frame) => frame >= actual && !oldIndices.has(frame))
      assert.equal(firstNewUnavailableSpriteFrame(previous, next, actual), expected === undefined ? undefined : BigInt(expected))
      cases++
    }
  }
}

const count = 2 ** 52
const declared: Pick<SpriteDef, 'layout' | 'poses'> = {
  layout: { kind: 'directional', framesPerDir: count },
  poses: { existing: { label: 'Existing', steps: [{ frame: count * 4, durationMs: 80 }] } },
}
const growth = { ...declared, layout: { kind: 'directional' as const, framesPerDir: count + 1 } }
assert.equal(firstNewUnavailableSpriteFrame(declared, growth, 1), BigInt(count) * 4n + 1n)
assert.equal(firstNewUnavailableSpriteFrame(growth, declared, 1), undefined)
console.log(JSON.stringify({ finiteGrid: cases, exactWideGrowth: true, quietWideShrink: true }))
