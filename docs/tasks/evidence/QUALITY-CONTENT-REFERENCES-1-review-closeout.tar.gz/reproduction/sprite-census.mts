import { readFile } from 'node:fs/promises'
import { join } from 'node:path'
import { validateSprites } from '/Users/zhangxu/.codex/worktrees/quality-94-102/type-pal/packages/content/src/validate.ts'
import { validateBattleSprites, battleSpriteDefinitionFrameDemand } from '/Users/zhangxu/.codex/worktrees/quality-94-102/type-pal/packages/content/src/battle-sprite.ts'
import { spriteDefinitionFrameDemand } from '/Users/zhangxu/.codex/worktrees/quality-94-102/type-pal/packages/content/src/sprite.ts'
import { decodeBattleSpriteAssetBytes, decodeWorldSpriteAssetBytes } from '/Users/zhangxu/.codex/worktrees/quality-94-102/type-pal/packages/reforge/src/assets.ts'

const project = join(process.cwd(), 'projects/pal')
const read = async (relative) => JSON.parse(await readFile(join(project, relative), 'utf8'))
const catalog = await read('assets/index.json')
const world = validateSprites(await read('content/sprites.json'), catalog)
const battle = validateBattleSprites(await read('content/battle-sprites.json'), catalog)
async function measure(definitions, decode, demand) {
  const resources = new Map()
  const rows = []
  for (const definition of definitions) {
    if (!resources.has(definition.asset)) {
      const record = catalog.assets[definition.asset]
      const bytes = await readFile(join(project, record.path))
      const decoded = await decode(record, Uint8Array.from(bytes).buffer)
      resources.set(definition.asset, { actual: decoded.frames.length, slots: decoded.decode.declaredSlots })
    }
    const resource = resources.get(definition.asset)
    rows.push({ id: definition.id, asset: definition.asset, ...resource, demand: demand(definition, resource.actual) })
  }
  return {
    definitions: rows.length, resources: resources.size,
    maxActual: Math.max(...rows.map((row) => row.actual)),
    maxSlots: Math.max(...rows.map((row) => row.slots)),
    maxDemand: Math.max(...rows.map((row) => row.demand)),
    aboveCapacity: rows.filter((row) => row.demand > row.actual),
    rows,
  }
}
console.log(JSON.stringify({
  world: await measure(world, decodeWorldSpriteAssetBytes, spriteDefinitionFrameDemand),
  battle: await measure(battle, decodeBattleSpriteAssetBytes, battleSpriteDefinitionFrameDemand),
}, null, 2))
