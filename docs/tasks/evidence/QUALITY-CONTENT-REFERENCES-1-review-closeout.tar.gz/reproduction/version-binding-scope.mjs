
import assert from 'node:assert/strict'
import { execFileSync } from 'node:child_process'
import { createHash } from 'node:crypto'
import { readFileSync } from 'node:fs'

const revision = process.argv[2]
assert.match(revision, /^[a-f0-9]{40}$/u)
const digest = (value) => createHash('sha256').update(value).digest('hex')
const readBase = (path) => execFileSync('git', ['show', `${revision}:${path}`])
const path = 'packages/content/src/character.ts'
const prior = readBase(path)
const live = readFileSync(path)
const beforeHash = digest(prior), afterHash = digest(live)
assert.notEqual(beforeHash, afterHash)
const sourceLines = (source, range) => {
  const [start, end] = range.split('-').map(Number)
  assert(Number.isInteger(start) && Number.isInteger(end) && end >= start && start >= 1)
  return source.toString('utf8').split('\n').slice(start - 1, end).join('\n')
}

const catalogPath = 'docs/testing/catalog.json'
const catalogBytes = readBase(catalogPath)
const catalog = JSON.parse(catalogBytes)
const matching = catalog.entries.filter((entry) => entry.sourceRefs.some((ref) => ref.path === path))
const records = []
for (const entry of matching) {
  const bound = entry.sourceRefs.filter((ref) => ref.path === path)
  assert.equal(bound.length, 1, entry.id)
  const old = bound[0]
  assert.equal(old.sha256, beforeHash, entry.id)
  assert.match(old.role, /version/u, entry.id)
  const excerpt = sourceLines(prior, old.lines)
  assert(excerpt.includes(old.anchor), entry.id)
  assert.equal(sourceLines(live, old.lines), excerpt, entry.id)
  const canonicalPath = 'docs/testing/' + entry.canonical
  const evidencePath = 'docs/testing/' + entry.evidence
  const text = readBase(canonicalPath).toString('utf8')
  const block = /<!-- testing-meta\s*\n(\{[^\n]*\})\n-->/u.exec(text)
  assert(block, entry.id)
  const metadata = JSON.parse(block[1])
  const evidence = JSON.parse(readBase(evidencePath))
  assert.equal(metadata.id, entry.id)
  assert.equal(evidence.id, entry.id)
  assert.deepEqual(metadata.revision, entry.revision)
  assert.deepEqual(evidence.history, entry.revision.history)
  for (const record of [metadata, evidence]) assert.deepEqual(record.sourceRefs, entry.sourceRefs)
  records.push({
    id: entry.id, canonicalPath, evidencePath, reference: old, excerptSha256: digest(excerpt),
    priorHistoryEvents: entry.revision.history.length,
    reportSha256: digest(text), evidenceSha256: digest(readBase(evidencePath)),
  })
}
console.log(JSON.stringify({ revision, catalogSha256: digest(catalogBytes), sourcePath: path,
  beforeHash, afterHash, entries: records.length, metadataCarriers: 2 * records.length + 1,
  records }, null, 2))

