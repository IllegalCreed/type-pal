import assert from 'node:assert/strict'
import { execFileSync } from 'node:child_process'
import { createHash } from 'node:crypto'
import { readFileSync, writeFileSync } from 'node:fs'
import { resolve } from 'node:path'
import { pathToFileURL } from 'node:url'

const { aggregateMetrics, compareCoverage, metricNames, normalizeMetrics } = await import(
  pathToFileURL(resolve('scripts/coverage/metrics.mjs')).href
)
const { auditScope } = await import(pathToFileURL(resolve('scripts/coverage/inventory.mjs')).href)
const oldRevision = 'fabdda4504e203b526e31fa027d863cbde2bf2d4'
const mainRevision = '778928d199dc74768d0499d7a42081098bb2390d'
const baselinePath = 'scripts/coverage/baseline.fast.json'
const baselineAt = (revision) => JSON.parse(
  execFileSync('git',['show', revision + ':' + baselinePath]),
)
const [measuredPath, out] = process.argv.slice(2)
const raw = readFileSync(measuredPath)
const measured = JSON.parse(raw)
const prior = baselineAt(oldRevision)
const protectedBase = baselineAt(mainRevision)
assert.equal(measured.schemaVersion, 2)
assert.equal(measured.profile, 'fast')
assert.equal(measured.testCount, 20592)
assert.equal(measured.sourceFileCount, prior.sourceFileCount)
assert.deepEqual(measured.provider, prior.provider)
assert.deepEqual(measured.provider, protectedBase.provider)
assert.deepEqual(Object.keys(measured.packages), Object.keys(prior.packages))

const packages = Object.fromEntries(Object.entries(prior.packages).map(([id, before]) => {
  const actual = measured.packages[id]
  const { identities: _identities, ...fastTests } = actual.fastTests
  assert.deepEqual(fastTests, before.fastTests)
  for (const name of ['name','directory','include','exclude','sourceFileCount','sourceFiles','scopeDigest']) {
    assert.deepEqual(actual[name],before[name], id + '.' + name)
  }
  const metrics = normalizeMetrics(actual.metrics, id)
  if (id !== 'editor') assert.deepEqual(metrics, before.metrics)
  return [id, { ...before, metrics }]
}))
const total = aggregateMetrics(Object.values(packages).map((entry) => entry.metrics))
assert.deepEqual(measured.total,total)
const candidate = { ...prior, generatedAt: measured.generatedAt, packages, total }
const intermediate = compareCoverage(candidate, prior)
assert.deepEqual(intermediate.regressions.map((item)=>item.split(': ',1)[0]), ['editor.branches','total.branches'])
const protectedComparison = compareCoverage(candidate, protectedBase)
assert.deepEqual(protectedComparison.regressions, [])
assert.deepEqual(auditScope(candidate, prior).changes, [])
assert.deepEqual(auditScope(candidate, protectedBase).removals, [])
const selection = (snapshot)=>({
  editor: snapshot.packages.editor.metrics,
  total: snapshot.total,
})
if(out) writeFileSync(out, JSON.stringify(candidate,null,2)+'\n', {flag:'wx'})
console.log(JSON.stringify({
  measuredSha256:createHash('sha256').update(raw).digest('hex'),
  testCount:measured.testCount, sourceFileCount:measured.sourceFileCount,
  predecessor:oldRevision, protectedBase:mainRevision,
  exactCounters:{protected:selection(protectedBase), intermediate:selection(prior), measured:selection(candidate)},
  intermediate, protectedComparison,
  sourceAndTestIdentities:'The new measurement and intermediate baseline cover exactly the same original source and test scopes.',
},null,2))

