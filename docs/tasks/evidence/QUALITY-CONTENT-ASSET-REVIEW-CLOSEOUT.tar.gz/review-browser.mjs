import assert from 'node:assert/strict'
import { readFileSync } from 'node:fs'
import { createRequire } from 'node:module'
import { resolve, dirname } from 'node:path'
import { fileURLToPath, pathToFileURL } from 'node:url'

const repo = process.cwd()
const scratch = dirname(fileURLToPath(import.meta.url))
const require = createRequire(resolve(repo, 'package.json'))
const { createServer } = await import(pathToFileURL(require.resolve('vite', {
  paths: [resolve(repo, 'packages/reforge')],
})))
const { chromium } = require('playwright')
const media = readFileSync(resolve(scratch, 'review.mp4'))
const server = await createServer({
  root: repo,
  configFile: false,
  cacheDir: resolve(scratch, 'vite-cache-scoped'),
  optimizeDeps: { entries: [
    'packages/reforge/src/video-player.ts',
    'packages/reforge/src/frame-animation-player.ts',
    'packages/reforge/src/fsa-source.ts',
    'packages/editor/src/core/frame-animation-worker-client.ts',
  ] },
  server: { host: '127.0.0.1', port: 0, open: false, hmr: false, fs: { allow: [repo] } },
  plugins: [{
    name: 'review-fixtures',
    configureServer(vite) {
      vite.middlewares.use((req, res, next) => {
        if (req.url === '/__review__') {
          res.setHeader('Content-Type','text/html')
          res.end('<!doctype html><title>Type Pal resource review</title><section id="surface"></section>')
        } else if (req.url === '/review.mp4') {
          res.setHeader('Content-Type','video/mp4')
          res.setHeader('Content-Length', String(media.length))
          res.end(media)
        } else if (req.url === '/favicon.ico') {
          res.statusCode = 204
          res.end()
        } else next()
      })
    },
  }],
})
let browser
try {
  await server.listen()
  const { port } = server.httpServer.address()
  browser = await chromium.launch({ channel: 'chrome', headless: true })
  const page = await browser.newPage()
  const browserDiagnostics = []
  page.on('pageerror', error => browserDiagnostics.push(error.message))
  page.on('console', event => {
    if (['warning', 'error'].includes(event.type())) browserDiagnostics.push(event.text())
  })
  await page.goto('http://127.0.0.1:' + port + '/__review__')
  await page.evaluate(async () => {
    const { playVideo } = await import('/packages/reforge/src/video-player.ts')
    const surface = document.querySelector('#surface')
    const nativePlay = HTMLMediaElement.prototype.play
    const owner = new AbortController()
    window.videoReview = { attempts: 0, owner }
    HTMLMediaElement.prototype.play = function () {
      if (++window.videoReview.attempts <= 2)
        return Promise.reject(new DOMException('controlled playback policy', 'NotAllowedError'))
      return nativePlay.call(this)
    }
    window.videoReview.result = playVideo({
      src: '/review.mp4', containerEl: surface, signal: owner.signal, muted: true,
    }).finally(() => { HTMLMediaElement.prototype.play = nativePlay })
  })
  const prompt = page.getByText('点击屏幕开始 / Click to start', { exact: true })
  await prompt.click()
  await page.waitForFunction(() => window.videoReview.attempts === 2)
  assert.equal(await prompt.isVisible(), true)
  await prompt.click()
  await page.waitForFunction(() => {
    const video = document.querySelector('#surface video')
    return window.videoReview.attempts === 3 &&
      video?.currentTime > 0 && !document.querySelector('#surface div')
  })
  const video = await page.evaluate(async () => {
    const { attempts, owner, result } = window.videoReview
    const actual = document.querySelector('#surface video')
    const currentTime = actual.currentTime
    const geometry = { width: actual.videoWidth, height: actual.videoHeight }
    owner.abort()
    await result
    return { attempts, currentTime, geometry, children: document.querySelector('#surface').childElementCount }
  })
  assert.equal(video.attempts, 3)
  assert.ok(video.currentTime > 0)
  assert.deepEqual(video.geometry, { width: 32, height: 32 })
  assert.equal(video.children, 0)

  const resources = await page.evaluate(async () => {
    const { FrameSequenceReader, decompressFrameSequenceBlock } = await import('/packages/reforge/src/frame-animation-player.ts')
    const { fsaSource } = await import('/packages/reforge/src/fsa-source.ts')
    const { encodeFrameAnimationInWorker } = await import('/packages/editor/src/core/frame-animation-worker-client.ts')
    const seq = async red => {
      const bytes = await encodeFrameAnimationInWorker({
        width: 1, height: 1, defaultFrameMs: 40, colorTreatment: 'preserve',
        frames: [{ rgba: Uint8Array.of(red, 0, 0, 255).buffer }],
      })
      return Uint8Array.from(bytes).buffer
    }
    const first = await seq(1)
    const replacement = await seq(9)
    const started = Promise.withResolvers()
    const release = Promise.withResolvers()
    let bytes = first
    let inflations = 0
    const reader = new FrameSequenceReader({ async readBytes() { return bytes } }, async encoded => {
      if (++inflations === 1) {
        started.resolve()
        await release.promise
      }
      return decompressFrameSequenceBlock(encoded)
    })
    const previous = reader.frame('opening', 0)
    await started.promise
    bytes = replacement
    reader.invalidate('opening')
    const newFrame = await reader.frame('opening', 0)
    release.resolve()
    const oldFrame = await previous
    const visibleFrame = await reader.frame('opening', 0)
    const surface = document.createElement('canvas')
    surface.width = 1
    surface.height = 1
    const ctx = surface.getContext('2d')
    ctx.putImageData(new ImageData(new Uint8ClampedArray(visibleFrame.rgba), 1, 1), 0, 0)
    const drawn = [...ctx.getImageData(0, 0, 1, 1).data]

    const dir = await navigator.storage.getDirectory()
    const file = await dir.getFileHandle('review.txt', { create: true })
    const writer = await file.createWritable()
    await writer.write('native file resource')
    await writer.close()
    const source = fsaSource(dir)
    const [url, same] = await Promise.all([source.urlFor('review.txt'), source.urlFor('review.txt')])
    const text = await (await fetch(url)).text()
    source.dispose()
    const revoked = await fetch(url).then(() => false, () => true)
    delete window.videoReview
    return { stale: [...oldFrame.rgba], replacement: [...newFrame.rgba], drawn, text, sameUrl: url === same, revoked }
  })
  assert.deepEqual(resources, {
    stale: [1, 0, 0, 255], replacement: [9, 0, 0, 255], drawn: [9, 0, 0, 255],
    text: 'native file resource', sameUrl: true, revoked: true,
  })
  // Chrome logs ERR_FILE_NOT_FOUND when the deliberate post-dispose fetch checks revocation.
  const resourceError = browserDiagnostics.filter(value => value.includes('ERR_FILE_NOT_FOUND'))
  const gameplay = browserDiagnostics.filter(value => !value.includes('ERR_FILE_NOT_FOUND'))
  assert.deepEqual(gameplay, Array(2).fill('[video-player] play() rejected (autoplay policy?): NotAllowedError: controlled playback policy'))
  assert.ok(resourceError.length <= 1)
  console.log(JSON.stringify({ browser: browser.version(), video, resources, expectedDiagnostics: browserDiagnostics }, null, 2))
} finally {
  await browser?.close()
  await server.close()
}

