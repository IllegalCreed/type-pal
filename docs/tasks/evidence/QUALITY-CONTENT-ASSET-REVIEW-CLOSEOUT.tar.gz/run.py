import datetime
import json
from pathlib import Path
import shlex
import subprocess
import sys

run = Path(__file__).resolve().parent / sys.argv[1]
run.mkdir(exist_ok=False)
cmd = [part.replace('{run}', str(run)) for part in sys.argv[2:]]
stamp = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
cwd = str(Path.cwd())
base = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
started = stamp()
with (run/'stdout').open('wb') as out, (run/'stderr').open('wb') as err:
    result = subprocess.run(cmd, stdout=out, stderr=err)
meta = {'command': shlex.join(cmd), 'arguments': cmd, 'cwd': cwd, 'base': base,
        'startedAt': started, 'finishedAt': stamp(),
        'exitCode': result.returncode if result.returncode >= 0 else None,
        'signal': -result.returncode if result.returncode < 0 else None,
        'output': {name: (run/name).stat().st_size for name in ['stdout','stderr']}}
(run/'execution.json').write_text(json.dumps(meta, indent=2)+'\n')
print(json.dumps(meta), flush=True)
sys.exit(result.returncode)
