import assert from 'node:assert/strict'
import { execFileSync } from 'node:child_process'
import { createHash } from 'node:crypto'
import { readFileSync } from 'node:fs'
import { resolve } from 'node:path'
import { createRequire } from 'node:module'

const require = createRequire(resolve('package.json'))
const ts = require('typescript')
const path = 'packages/reforge/src/script-chunk-store.cursor-boundaries.test.ts'
const checkedTree = process.argv[2]
const before = execFileSync('git', ['show', checkedTree + ':' + path], { encoding: 'utf8' })
const current = readFileSync(path, 'utf8')
const normalize = (source) => {
  const file = ts.createSourceFile(path, source, ts.ScriptTarget.Latest, true)
  assert.equal(file.parseDiagnostics.length, 0)
  const shape = node => {
    const children = []
    node.forEachChild(child => {
      children.push(shape(child))
    })
    return children.length ? [node.kind, ...children] : [node.kind, node.getText(file)]
  }
  return JSON.stringify(shape(file))
}
const expanded = [
  "      Object.entries(chunks).map(([key, chunk]) => [",
  '        `content/scripts/chunks/${key}.json`,',
  '        chunk,',
  "      ]),",
].join('\n')
const condensed =
  '      Object.entries(chunks).map(([key, chunk]) => [`content/scripts/chunks/${key}.json`, chunk]),'
assert.equal(before.split(expanded).length, 2)
assert.equal(before.replace(expanded, condensed), current)
assert.equal(normalize(before), normalize(current))
const changed = execFileSync('git', ['diff', '--name-only', checkedTree], { encoding: 'utf8' }).trim()
assert.equal(changed, path)
const digest = value => createHash('sha256').update(value).digest('hex')
console.log(JSON.stringify({ checkedTree, path, before: digest(before), after: digest(current),
  syntaxTree: digest(normalize(current)), equalSyntax: true, exactFormattingChange: true }, null, 2))
