from pathlib import Path
import hashlib, json, re, subprocess

work=Path(__file__).resolve().parent
repo=Path.cwd()
base='c08cdc3ed1b709e92c3b3e4b8421ffdf848f03ba'
def git(*args):
    return subprocess.check_output(['git',*args])
original=repo/'scripts/coverage/run.mjs'
code=original.read_text()
assert original.read_bytes()==git('show',base+':scripts/coverage/run.mjs')
assert not git('diff', '--name-only', base, '--','packages/game','packages/shared','pnpm-lock.yaml','scripts/coverage/config.mjs','data','projects')
snapshot=(work/'ratchet-input-tree').read_text().strip()
assert not git('diff','--name-only',snapshot,'--','packages')
report_root=repo/'coverage/fast'
prior_outputs={}
old_runs=(work/'coverage-final/stdout').read_text()
evidence={name:(work/name/'execution.json').read_text() for name in ['coverage-final','game-thumbnail-final']}
assert json.loads(evidence['coverage-final'])['exitCode']==1
assert json.loads(evidence['game-thumbnail-final'])['exitCode']==0
assert 'Test timed out in 5000ms.' in (work/'coverage-final/stderr').read_text()
assert 'scene-thumbnail.test.ts' in (work/'coverage-final/stderr').read_text()
assert '6 passed (6)' in (work/'game-thumbnail-final/stdout').read_text()
record_counts={'shared':118,'content':1556,'pal-extract':368,'migrate':723,'reforge':9145}
for id,count in record_counts.items():
    segment=old_runs.split('@type-pal/'+id)[-1].split('[coverage:fast]',1)[0]
    assert f'{count} passed ({count})' in segment,id
    for path in [report_root/id/'coverage-summary.json',report_root/'.test-inventory'/f'{id}.fast.json']:
        prior_outputs[str(path.relative_to(repo))]=hashlib.sha256(path.read_bytes()).hexdigest()
inv=report_root/'.test-inventory/game.fast.json'
prior_outputs[str(inv.relative_to(repo))]=hashlib.sha256(inv.read_bytes()).hexdigest()
def repl(old,new):
    global code
    assert code.count(old)==1,old
    code=code.replace(old,new)
code=re.sub(r"from '\./([^']+)'",lambda m:"from '"+(original.parent/m[1]).as_uri()+"'",code)
repl("const [profile = '', ...flags] = process.argv.slice(2)",
     """const resume = new Set(['shared','content','pal-extract','migrate','reforge','game'])
const [profile = '', ...flags] = process.argv.slice(2)""")
repl("  await rm(outputFile, { force: true })\n  await spawnCommand(\n    'pnpm',\n    [",
     "  if (!resume.has(packageConfig.id)) {\n    await rm(outputFile, { force: true })\n    await spawnCommand(\n    'pnpm',\n    [")
repl("  const raw = await readJson(outputFile)",
     "  }\n  const raw = await readJson(outputFile)")
repl("  const reportDirectory = resolve(outputRoot, packageConfig.id)",
     """  if (packageConfig.id === 'game') {
    const baseline = await readJson(baselinePath)
    const prior = baseline.packages.game
    const now = (await listProductionSources(packageConfig)).map(normalizeRepoPath)
    if (JSON.stringify(now) !== JSON.stringify(prior.sourceFiles) ||
        fastTests.identityDigest !== prior.fastTests.identityDigest ||
        fastTests.executionDigest !== prior.fastTests.executionDigest ||
        fastTests.testCount !== prior.fastTests.testCount)
      throw new Error('Cannot reuse unchanged Game scope')
    console.log('Use the exact protected main Game report after independently rechecking the timeout.')
    return { ...prior, fastTests, selectedTests: fastTests }
  }
  const reportDirectory = resolve(outputRoot, packageConfig.id)""")
repl("  await spawnCommand('pnpm', args, { TYPE_PAL_COVERAGE_PROFILE: profile })",
     """  if (resume.has(packageConfig.id)) console.log('Use completed native package evidence: ' + packageConfig.id)
  else await spawnCommand('pnpm', args, { TYPE_PAL_COVERAGE_PROFILE: profile })""")
repl("  await rm(outputRoot, { recursive: true, force: true })",
     """  const preserved = JSON.parse(await readFile(new URL('./recovery-inputs.json', import.meta.url)))
  for (const [file, expected] of Object.entries(preserved.rawDigests)) {
    const actual = createHash('sha256').update(await readFile(resolve(repoRoot, file))).digest('hex')
    if (actual !== expected) throw new Error('Native evidence drift: ' + file)
  }
  console.log('Coverage recovery from pinned native package reports. The official first invocation exited 1.')""")
(work/'coverage-recovery.mjs').write_text(code)
(work/'recovery-inputs.json').write_text(json.dumps({
 'base':base,'sourceTree':snapshot,'gameProof':{
  'unchangedPathsChecked':['packages/game','packages/shared','data','projects','pnpm-lock.yaml','scripts/coverage/config.mjs'],
  'protectedMain':'https://github.com/IllegalCreed/type-pal/actions/runs/44527734546',
  'originalSucceededExceptOne':3810,'isolatedSameCoverageProfilePassed':6,
 },'successfulPackageCounts':record_counts,'rawDigests':prior_outputs,
 'originalRunnerSha256':hashlib.sha256(original.read_bytes()).hexdigest(),
},indent=2)+'\n')
print('Verified candidate fingerprints and five complete reporter summaries. Editor uses actual collector.')

