import assert from 'node:assert/strict'
import { execFileSync } from 'node:child_process'
import { existsSync, readFileSync } from 'node:fs'
import { resolve } from 'node:path'
import { pathToFileURL } from 'node:url'

const load = (p) => import(pathToFileURL(resolve(p)))
const { auditScope } = await load('scripts/coverage/inventory.mjs')
const { compareCoverage } = await load('scripts/coverage/metrics.mjs')
const { adjustApprovedBaseline } = await load('scripts/coverage/approved-baseline-adjustments.mjs')
const parse = (p) => JSON.parse(readFileSync(p))
const base = 'c08cdc3ed1b709e92c3b3e4b8421ffdf848f03ba'
const prior = JSON.parse(execFileSync('git',['show',base+':scripts/coverage/baseline.fast.json']))
const candidate = parse('scripts/coverage/baseline.fast.json')
const native = parse('coverage/fast/summary.json')
assert.equal(candidate.sourceFileCount, 840)
assert.equal(native.sourceFileCount, candidate.sourceFileCount)
assert.equal(native.testCount, candidate.testCount)
assert.deepEqual(compareCoverage(native, candidate), {regressions:[],improvements:[]})
assert.deepEqual(auditScope(native, candidate), {changes:[],removals:[]})
const adjusted = await adjustApprovedBaseline(prior, readFileSync)
assert.deepEqual(adjusted.applied, ['content-script-writer-retirement-20261119'])
assert.deepEqual(compareCoverage(native,adjusted.baseline).regressions,[])
const {changes,removals}=auditScope(candidate,prior)
for (const removal of removals) {
  assert.equal(removal.kind,'test-file')
  assert.equal(existsSync(removal.value),false,removal.value)
}
console.log(JSON.stringify({base,priorFastTests:prior.testCount,fastTests:candidate.testCount,
  scopeSources:candidate.sourceFileCount,scopeChanges:changes,removedPaths:removals,
  adjusted:adjusted.applied,verifiedMetrics:candidate.total},null,2))

