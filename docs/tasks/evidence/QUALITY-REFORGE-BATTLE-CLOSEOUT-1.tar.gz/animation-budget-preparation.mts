import assert from 'node:assert/strict'
import { readFile } from 'node:fs/promises'
import { resolve } from 'node:path'
import { loadCurrentProjectFrom } from '/Users/zhangxu/.codex/worktrees/quality-94-102/type-pal/packages/reforge/src/project-loader.ts'
import { loadFireSprite } from '/Users/zhangxu/.codex/worktrees/quality-94-102/type-pal/packages/reforge/src/assets.ts'
import { projectItemsView } from '/Users/zhangxu/.codex/worktrees/quality-94-102/type-pal/packages/reforge/src/runtime-project-view.ts'
import { validateSkills } from '/Users/zhangxu/.codex/worktrees/quality-94-102/type-pal/packages/content/src/validate.ts'
import { resolveSkillExecution } from '/Users/zhangxu/.codex/worktrees/quality-94-102/type-pal/packages/content/src/skill.ts'
import { checkedFireFrameDurationMs, getOffMagicTiming, playsDefensiveFire } from '/Users/zhangxu/.codex/worktrees/quality-94-102/type-pal/packages/reforge/src/battle/battle-off-magic.ts'
const root = resolve('projects/pal')
const source = {
  async readText(p: string): Promise<string> {
    try { return await readFile(resolve(root, p), 'utf8') }
    catch (error) {
      if ((error as NodeJS.ErrnoException).code === 'ENOENT') throw new DOMException(p, 'NotFoundError')
      throw error
    }
  },
  async readJson<T>(p: string): Promise<T> { return JSON.parse(await source.readText(p)) },
  async readBytes(p) {
    const bytes = await readFile(resolve(root, p))
    return new Uint8Array(bytes).buffer
  },
  async urlFor(p: string) { return resolve(root, p) },
}
const project = await loadCurrentProjectFrom(source)
const effects = Object.values(project.skills).flatMap(skill => (['player','enemy'] as const)
  .map(side => {
    const execution = resolveSkillExecution(skill, side)
    return {
      key: skill.id + '/' + side,
      animation: execution.animation,
      once: side === 'player' && playsDefensiveFire(skill.target, execution),
    }
  }))
for (const item of Object.values(projectItemsView(project.items))) {
  if (item.throw?.presentation?.kind === 'magic')
    effects.push({ key: item.id + '/throw', animation: item.throw.presentation.animation, once: false })
}
const chunks = new Map<number, number>()
for (const { animation } of effects) {
  if (animation.effectSprite === 65535 || animation.effectSprite < 0) continue
  if (!chunks.has(animation.effectSprite)) {
    const sprite = await loadFireSprite(project.assetBase, animation.effectSprite)
    chunks.set(animation.effectSprite, sprite.frames.length)
  }
}
const results = effects.flatMap(({key,animation,once}) => {
  const originalFrames = chunks.get(animation.effectSprite)
  if (!originalFrames) return []
  const timeline = once
    ? { totalFrames: originalFrames, frameDurationMs: checkedFireFrameDurationMs(originalFrames, animation.speed) }
    : getOffMagicTiming(originalFrames, animation)
  return [{ key, once, originalFrames, totalFrames: timeline.totalFrames,
    durationMs: timeline.totalFrames * timeline.frameDurationMs }]
})
assert.ok(results.length > 100)
const sample = Object.values(project.skills).find(skill=>skill.id === '296')
assert.ok(sample)
const huge = { ...sample, animation: {...sample.animation, fireDelay: 0, effectTimes: 4294967295} }
const { skills } = validateSkills({ skills: [huge], levelUp: {} })
const example = skills[0]!.animation
const exampleFrameCount = chunks.get(example.effectSprite)
assert.ok(exampleFrameCount)
assert.throws(() => getOffMagicTiming(exampleFrameCount, example), /85899345920 帧超过 1024 帧/)
const planned = 'rejected before frame construction'

console.log(JSON.stringify({
  effects: effects.length, decodedAssets: chunks.size, concreteTimelines: results.length,
  singlePassTimelines: results.filter(({ once }) => once).length,
  maxFrames: [...results].sort((a,b) => b.totalFrames - a.totalFrames)[0],
  maxDuration: [...results].sort((a,b) => b.durationMs - a.durationMs)[0],
  acceptedExample: { skill: '296', repeat: example.effectTimes, exampleFrameCount, planned },
}, null, 2))
