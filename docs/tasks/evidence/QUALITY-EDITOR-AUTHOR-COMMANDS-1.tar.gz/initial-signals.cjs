const fs = require('node:fs')
const path = require('node:path')
const ts = require(path.join(process.cwd(), 'node_modules/typescript'))
const scratch = process.argv[2]
const sourcePaths = fs.readFileSync(path.join(scratch, 'window/file-index.ndjson'), 'utf8')
  .trim().split('\n').map(JSON.parse)
  .filter((entry) => entry.after && entry.inventoryCategory === 'product')
  .map((entry) => entry.path)
const highComplexity = []
const windows = new Map()
const branchNodes = new Set([
  ts.SyntaxKind.IfStatement, ts.SyntaxKind.CaseClause,
  ts.SyntaxKind.ConditionalExpression, ts.SyntaxKind.ForStatement,
  ts.SyntaxKind.ForOfStatement, ts.SyntaxKind.ForInStatement,
  ts.SyntaxKind.WhileStatement, ts.SyntaxKind.DoStatement, ts.SyntaxKind.CatchClause,
])
const shortCircuit = new Set([
  ts.SyntaxKind.AmpersandAmpersandToken, ts.SyntaxKind.BarBarToken, ts.SyntaxKind.QuestionQuestionToken,
])
for (const file of sourcePaths) {
  const source = fs.readFileSync(file, 'utf8')
  const ast = ts.createSourceFile(file, source, ts.ScriptTarget.Latest, true)
  const functions = []
  function visit(node) {
    if (ts.isFunctionLike(node) && node.body) functions.push(node)
    ts.forEachChild(node, visit)
  }
  function complexity(node, root) {
    if (node !== root && ts.isFunctionLike(node)) return 0
    let result = Number(
      branchNodes.has(node.kind) ||
      (ts.isBinaryExpression(node) && shortCircuit.has(node.operatorToken.kind)),
    )
    ts.forEachChild(node, (child) => { result += complexity(child, root) })
    return result
  }
  visit(ast)
  for (const implementation of functions) {
    const score = complexity(implementation, implementation) + 1
    if (score <= 10) continue
    const name = implementation.name || (ts.isVariableDeclaration(implementation.parent) && implementation.parent.name)
    highComplexity.push({
      file, line: ast.getLineAndCharacterOfPosition(implementation.getStart(ast)).line + 1,
      name: name ? name.getText(ast) : '(callback)', score,
    })
  }
  const lines = source.split('\n')
  const candidates = lines.map((line, index) => ({ line: index + 1, text: line.trim() }))
    .filter(({ text }) => text && !/^(?:\/\/|\/\*|\*|[),}\];]+$)/.test(text))
  for (let i = 0; i + 9 < candidates.length; i++) {
    const block = candidates.slice(i, i + 9)
    const key = block.map((entry) => entry.text).join('\n')
    if (key.length < 230) continue
    if (!windows.has(key)) windows.set(key, [])
    windows.get(key).push({ file, line: block[0].line })
  }
}
const duplicateLocations = [...windows.values()].filter((list) => new Set(list.map((row) => row.file)).size > 1)
const r = {
  sourceCount: sourcePaths.length,
  typescriptVersion: ts.version,
  method: 'TypeScript AST decisions >10 without nested function decisions, and exact 9 substantive lines across different product files. Signals only. Metrics do not confer file credit.',
  highComplexity, duplicateLocations,
}
fs.writeFileSync(path.join(scratch, 'review-signals.json'), JSON.stringify(r,null,2) + '\n')
console.log(JSON.stringify({sourceCount:r.sourceCount, highComplexity, exactWindows:duplicateLocations.length},null,2))
