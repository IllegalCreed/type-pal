# 证据读法、整改边界与清理

Audit base: da4aefb13497330d86b7d4d1b173c4b5649e566d. File decisions attach directly to Git paths. The original 94 paths include 60 retained and 34 deleted after review. The 10 independently examined successor files, four rechecked paths, and original single review are counted separately. Initial inventory 3,870 → 3,846. The 102 touched production and test paths, including two supporting files, go from 578,883 to 489,659 bytes (−89,224). A supporting import or collateral change does not confer whole-file review. Git source at the audit base can restore all original files. The retired test paths are named in the file index, along with their current business coverage or the reason to exit.

## Read boundaries and source versions

The full-file index holds the latest candidate bytes per path and witnesses. Directive anchors resolve against the held immutable Git base or candidate. No E2E tooling, PAL content, scripts, save versions or generated resources were modified as part of the product changes. Reforge main.ts matches the Git base byte for byte. The story E2E records stay pinned to their actual versions. The E2E tool suite exercises current routes, model and capture adapters without conferring current browser recording credit.

The TypeScript AST initial signals count deviations from a straight-line function, including short-circuit operators. Duplicates are exact cross-file substantive text windows. These lead to the per-file review, with no numeric acceptance credit. ActorMode composes several panels and VarsTab manages form/history synchronization. A later extraction of whole panels is contingent on evidence of separate state ownership. The actual stat-draft undo bug is resolved in this window. The remaining levels panel and preview lifecycle can be evaluated as distinct slices after checking active owners.

## Failing runs and restoration

See executions.json and the original reporter streams, especially codec-red, codec-references-red, sprite-explicit-order-red, editor-sprite-cache-bound-red and actor-stat-draft-undo-red. Failing source-restoration probes use the prior implementation and the candidate regression at the actual public caller. Prior failed fixture attempts remain separate. For actor-level-up, the first attempt used the wrong constructor input. The final counterexample (actor-level-up-legal-red) uses the typed production signature and independently fails the three expected business assertions. The editor-author-freeze-typecheck proves the final fixtures compile. A real seed initialized battlefield rows as an empty collection during test migration. The final assertion tracks that actual seed, not the abandoned assumption. Exact failure details, test identities and execution versions are in the original outputs.

The #80 main Documentation first attempt timed out in the final strict progress report after prescribed gates had progressed. Its second attempt passed on unchanged Git main, with no candidate adjustments or reruns attributed to this window. A retained prior log and the two GitHub run identifiers distinguish the attempts.

## Finding the originals

Each included runs directory has command argv, Git base, changed file SHA-256, timestamps, exit code and stdout/stderr checksums. Vitest provides native JSON where applicable. Business failures remain intact. Console and native files describe distinct outputs of the same identified run. Selective archiving keeps the cited cases plus original failed attempts and consolidated quality gates.

## Coverage comparison boundaries

The first ratchet sampled the complete frozen source scope. It passed all selected test cases and reported five ratio regressions, including three Editor ratios. Same-tree per-file V8 analysis preserved the independently covered resources, sparse index gaps and role reference rejection as contained assertions in four existing tests (31 targeted tests passed). The 31 retain all existing full-name identities. The subsequent Editor-only receipt measures those assertions before the single complete final ratchet.
