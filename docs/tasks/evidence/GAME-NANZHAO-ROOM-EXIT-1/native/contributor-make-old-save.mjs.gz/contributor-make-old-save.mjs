import { readFileSync, writeFileSync } from 'node:fs'
import { createHash } from 'node:crypto'
import { parseSss } from '../../packages/pal-extract/src/io/sss.ts'
import { dumpAllEventObjects } from '../../packages/pal-extract/src/resources/scene.ts'
import { createInitialGameState, hydratePlayerRolesRuntime, npcFromEventObject, sliceSceneEventObjects } from '../../packages/game/src/core/game-state.ts'
import { serializeSave, parseImportedSave } from '../../packages/game/src/tools/save-io.ts'
const sha = bytes => createHash('sha256').update(bytes).digest('hex')
const rawPath='data/raw/SSS.MKF', rolesPath='/Users/zhangxu/illegal/type-pal/data/extracted/data/player-roles.json', palettePath='/Users/zhangxu/illegal/type-pal/data/extracted/data/palette/0.json'
const raw=readFileSync(rawPath),rolesBytes=readFileSync(rolesPath),paletteBytes=readFileSync(palettePath)
const sss=parseSss(raw),objects=dumpAllEventObjects(sss.scenes,sss.eventObjects)
const gs=createInitialGameState({x:928,y:816,facing:'down'})
hydratePlayerRolesRuntime(gs.PlayerRolesRuntime,JSON.parse(rolesBytes))
gs.wNumScene=287;gs.partyMembers=[1,0,4]
gs.allEventObjects=objects.eventObjects.map(e=>npcFromEventObject(e));gs.sceneEventRanges=objects.sceneRanges;gs.npcs=sliceSceneEventObjects(gs,287)
gs.palette=JSON.parse(paletteBytes);gs.basePalette=structuredClone(gs.palette)
const text=serializeSave(gs),parsed=parseImportedSave(text)
const path='build/map204-supplemental/old-native-palace.save.json'
writeFileSync(path,text)
const readout={kind:'isolated-dev-functional-old-save-fixture-not-user-save',sourceGit:'123595ac3a651957b36061eacced329369c495e5',sources:[{path:rawPath,sha256:sha(raw)},{path:rolesPath,sha256:sha(rolesBytes)},{path:palettePath,sha256:sha(paletteBytes)}],output:{path,sha256:sha(text),bytes:Buffer.byteLength(text)},validation:'serializeSave -> parseImportedSave succeeded',scene:parsed.wNumScene,party:parsed.partyMembers,position:parsed.party,partyHp:parsed.partyMembers.map(id=>({id,hp:parsed.PlayerRolesRuntime.rgwHP[id],maxHp:parsed.PlayerRolesRuntime.rgwMaxHP[id]})),objectCount:parsed.allEventObjects.length,enemy4841:parsed.allEventObjects[4841],hasExit5077:!!parsed.allEventObjects[5077],limits:['Constructed from original raw event table and current real role table; no natural story progression or reporter save inspection.','Starts at the room entry so two Down steps reach the missing exit.']}
writeFileSync('build/map204-supplemental/old-save-fixture.json',JSON.stringify(readout,null,2))
console.log(JSON.stringify(readout))
const wonPreview=parseImportedSave(readFileSync(path,'utf8'))
const beforeRows=structuredClone(wonPreview.allEventObjects)
const view=new DataView(sss.bytecode.buffer,sss.bytecode.byteOffset,sss.bytecode.byteLength)
const instr=ip=>[0,2,4,6].map(offset=>view.getUint16(ip*8+offset,true))
const hidden=[]
for(const npc of wonPreview.npcs){
 const ip=Number(npc.triggerLabel?.slice(2)??0),code=instr(ip),next=instr(ip+1)
 if(npc.sState!==2||npc.triggerMode<4||code[0]!==7||code[3]===0||next[0]!==3||next[1]!==41127)continue
 const target=wonPreview.allEventObjects[npc.id]
 target.sState=-2;target.sVanishTime=800
 // V1 serializes local and global copies; the actual loader will rebind these references.
 npc.sState=-2;npc.sVanishTime=800
 hidden.push({id:npc.id,triggerIp:ip,enemyTeam:code[1],victoryContinuation:ip+1,sharedVictoryTail:41127})
}
if(JSON.stringify(instr(41127))!==JSON.stringify([82,0,0,0]))throw new Error('ordinary victory tail drift')
const changed=wonPreview.allEventObjects.flatMap((npc,i)=>JSON.stringify(npc)===JSON.stringify(beforeRows[i])?[]:[i])
if(JSON.stringify(changed)!==JSON.stringify(hidden.map(row=>row.id)))throw new Error('unexpected NPC difference')
const wonText=serializeSave(wonPreview);parseImportedSave(wonText)
const wonPath='build/map204-supplemental/old-native-palace-already-won.save.json'
writeFileSync(wonPath,wonText)
const wonReceipt={kind:'already-won-dev-functional-preview-not-natural-combat',normalFixture:{path,sha256:sha(readFileSync(path))},output:{path:wonPath,sha256:sha(wonText),bytes:Buffer.byteLength(wonText)},validation:'serializeSave -> parseImportedSave succeeded',sourceSha256:sha(raw),hidden,changedGlobalNpcIds:changed,exactEffect:{sState:-2,sVanishTime:800},otherGlobalNpcRowsUnchanged:true,party:wonPreview.partyMembers,position:wonPreview.party,limits:['Only native ordinary-battle NPCs in the problem room with verified shared victory tail are placed into the real post-victory hidden/cooldown state.','No actual combat reward/HP progress or natural story completion is claimed; no unrelated object is changed.']}
writeFileSync('build/map204-supplemental/already-won-fixture.json',JSON.stringify(wonReceipt,null,2));console.log(JSON.stringify(wonReceipt))
