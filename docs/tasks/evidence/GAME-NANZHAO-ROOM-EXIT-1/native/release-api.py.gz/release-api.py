import subprocess,sys,json,pathlib
method=sys.argv[1]; resource=sys.argv[2]
if not resource.startswith('repos/IllegalCreed/type-pal/') or any(c in resource for c in ['\r','\n','#']):raise SystemExit('Unexpected API resource')
auth=subprocess.run(['gh','auth','token','--hostname','github.com'],capture_output=True,text=True)
if auth.returncode:raise SystemExit('GitHub authentication unavailable')
proxy=subprocess.run(['git','config','--get','http.proxy'],capture_output=True,text=True)
args=['curl','--disable','--http1.1','--silent','--show-error','--fail-with-body','--connect-timeout','8','--max-time','25','--request',method,'--header','@-','--url','https://api.github.com/'+resource]
if proxy.returncode==0 and proxy.stdout.strip():args+=['--proxy',proxy.stdout.strip().replace('socks5h://','http://')]
if len(sys.argv)>3:args+=['--data-binary','@'+str(pathlib.Path(sys.argv[3]).resolve())]
headers='Authorization: Bearer '+auth.stdout.strip()+'\nAccept: application/vnd.github+json\nContent-Type: application/json\nUser-Agent: type-pal-release\n'
for attempt in range(3):
 p=subprocess.run(args,input=headers.encode(),stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 # Writes retry only connection/handshake failures, before any HTTP request was sent.
 # Timeout/EOF after a write remains unknown and is resolved by caller read-back.
 if p.returncode not in ([7,28,35,52,56] if method=='GET' else [7,35]):break
 if '--proxy' in args:
  i=args.index('--proxy')+1
  args[i]=args[i].replace('http://','socks5h://') if args[i].startswith('http://') else args[i].replace('socks5h://','http://')
sys.stdout.buffer.write(p.stdout);sys.stderr.buffer.write(p.stderr);sys.exit(p.returncode)
