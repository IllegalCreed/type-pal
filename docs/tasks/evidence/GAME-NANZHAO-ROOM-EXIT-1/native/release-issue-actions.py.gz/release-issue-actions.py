from pathlib import Path
import subprocess,json,sys
b=Path('build/map204-release');actor=json.loads((b/'pr-created.json').read_text())['user']['login']
def api(method,path,body=None):
 args=['python3',str(b/'api.py'),method,'repos/IllegalCreed/type-pal/'+path]
 if body:args.append(str(body))
 p=subprocess.run(args,capture_output=True,text=True)
 if p.returncode:raise RuntimeError(p.stderr or p.stdout)
 return json.loads(p.stdout)
assert json.loads((b/'postflight.stdout').read_text())['passed']
assert json.loads((b/'browser-production.json').read_text())['passed']
close=b/'close-request.json';close.write_text(json.dumps({'state':'closed','state_reason':'completed'})+'\n')
for n in [24,27]:
 body=(b/f'issue{n}-draft.md').read_text().replace('PR_PLACEHOLDER','https://github.com/IllegalCreed/type-pal/pull/28')
 req=b/f'issue{n}-request.json';req.write_text(json.dumps({'body':body},ensure_ascii=False)+'\n')
 comments=api('GET',f'issues/{n}/comments?per_page=100')
 own=next((c for c in comments if c['body']==body and c['user']['login']==actor),None)
 if own is None:own=api('POST',f'issues/{n}/comments',req)
 assert own['body']==body and own['user']['login']==actor
 (b/f'issue{n}-comment.json').write_text(json.dumps(own,ensure_ascii=False,indent=2)+'\n')
 current=api('GET',f'issues/{n}')
 if current['state']!='closed' or current.get('state_reason')!='completed':api('PATCH',f'issues/{n}',close)
 final=api('GET',f'issues/{n}');assert final['state']=='closed' and final['state_reason']=='completed'
 (b/f'issue{n}-closed.json').write_text(json.dumps(final,ensure_ascii=False,indent=2)+'\n')
 print(json.dumps({'issue':n,'comment':own['html_url'],'state':final['state'],'reason':final['state_reason']}),flush=True)
