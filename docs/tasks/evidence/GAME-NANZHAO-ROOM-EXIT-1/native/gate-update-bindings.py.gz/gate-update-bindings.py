from pathlib import Path
import json,hashlib,subprocess
root=Path('.');receipt='docs/ops/evidence/GAME-NANZHAO-ROOM-EXIT-1/review.json'
scopes={
'docs/ops/board.md':'Only add the map204 and optional input-rotation rows with actual review state; preserve all unrelated tasks.',
'docs/ops/tasks/index.md':'Official task projection adds only the two current cards and their actual statuses.',
'docs/ops/audits/code-quality-file-ledger.md':'Add only the new tracked implementation/test inventory and finite feature bridges; zero new whole-file closures.',
'docs/testing/domains/phase1-runtime/README.md':'Add the optional control-rotation domain beside dependency ownership; other source/history stays scoped.',
'docs/testing/catalog.json':'Add game-input-rotation and update only game-script-corrections with independent supplemental-exit contracts and actual source refs; preserve other entries/history.',
}
changed=subprocess.check_output(['git','diff','--name-only','123595ac3a651957b36061eacced329369c495e5'],text=True).splitlines()
for p in changed:
 if p.startswith('docs/testing/indexes/'):
  scopes[p]='Official generated view adds only the input-rotation entry and projects the owned script-correction update; no runtime credit from generation.'
files={p:json.loads(p.read_text()) for p in Path('docs/phase-governance/reviews').glob('*.json')}
owner={e['path']:(p,e) for p,d in files.items() for e in d.get('entries',[])}
originals=[]; touched=set()
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def update(target,scope,artifact=False):
 if target not in owner:return
 p,e=owner[target];after=sha(target)
 if e['afterSha256']==after:return
 originals.append({'reviewFile':str(p),'path':target,'entry':json.loads(json.dumps(e))})
 e.setdefault('history',[]).append({'date':'2026-10-27','action':'map204-input-owned-delta','previousAfterSha256':e['afterSha256'],'evidence':receipt})
 e['afterSha256']=after;e['revision']['implementationSha']=after
 e['coreConclusion']=scope
 e['readMethod']='Read the owned semantic delta and actual consumer/native evidence; prior history retained, no whole-source re-audit.'
 e['reviewedLines']=scope
 maintenance={'path':receipt,'afterSha256':after,'scope':scope,'lineCount':len(Path(target).read_text().splitlines())}
 if artifact:e['evidence']['currentMaintenance']=maintenance
 else:e['evidence']=maintenance
 e['nextStep']='Local feature review only; user experience and any future PR/CI/release remain separate.'
 touched.add(p)
for target,scope in scopes.items():update(target,scope)
# Every incoming control edge gets its own current hash after its target is finalized.
# Current review graphs are acyclic; self-hash records remain forbidden.
import re
def write(p):
 data=json.dumps(files[p],ensure_ascii=False,indent=2)+'\n'
 data=re.sub(r'\[\n\s*(?:"(?:[^"\\]|\\.)*"(?:,\n\s*)?)+\n\s*\]',lambda m:json.dumps(json.loads(m.group()),ensure_ascii=False,separators=(',',':')),data)
 assert json.loads(data)==files[p]
 p.write_text(data)
 subprocess.run(['pnpm','exec','biome','format','--write',str(p)],check=True)
for p in list(touched):write(p)
# Known incoming artifact reviews are processed in dependency order.
for name in ['20261017-r93-phase-governance-artifacts.json','20261017-r94-final-machine-artifacts.json']:
 p=Path('docs/phase-governance/reviews')/name
 for e in files[p]['entries']:
  if Path(e['path']) in touched:
   update(e['path'],'Incoming SHA binding for the finite map204/input documentation delta; native envelope and all historical entries remain unchanged.',True)
 write(p) if p in touched else None
Path('build/map204-integration/binding-originals.json').write_text(json.dumps(originals,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'updated':[(str(p),p.stat().st_size) for p in sorted(touched)],'targets':[e['path'] for e in originals]},ensure_ascii=False,indent=2))
