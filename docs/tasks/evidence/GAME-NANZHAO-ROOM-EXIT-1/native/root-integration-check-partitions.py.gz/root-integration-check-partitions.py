import urllib.request,json,pathlib,hashlib,concurrent.futures
out=pathlib.Path('build/map204-integration');old=json.load(open(out/'before-asset-manifest.json'));idx={e['path']:e for e in old['files']}
paths=['events/scene-021.json','events/scene-289.json','events/shared.json']
def one(p):
 url='https://pal.illegalscreed.cn/extracted/'+p;b=urllib.request.urlopen(url,timeout=30).read();h=hashlib.sha256(b).hexdigest();assert h==idx[p]['sha256'],(p,h,idx[p]['sha256']);(out/('production-'+p.replace('/','-'))).write_bytes(b);before=json.loads(b);after=json.load(open('data/extracted/'+p));a=[c for s in before['segments'] for c in s['commands']];z=[c for s in after['segments'] for c in s['commands']];ak=[json.dumps(c,sort_keys=True,ensure_ascii=False) for c in a];zk=[json.dumps(c,sort_keys=True,ensure_ascii=False) for c in z];removed=[a[i] for i,c in enumerate(ak) if c not in zk];added=[z[i] for i,c in enumerate(zk) if c not in ak];return {'path':p,'url':url,'beforeSha256':h,'beforeCommands':len(a),'afterCommands':len(z),'removed':removed,'added':added}
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as ex:r=list(ex.map(one,paths))
(out/'partition-delta.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n')
for x in r:print(json.dumps({k:v if k not in ['removed','added'] else [{'op':c['op'],'label':c.get('label')} for c in v] for k,v in x.items()},ensure_ascii=False))
