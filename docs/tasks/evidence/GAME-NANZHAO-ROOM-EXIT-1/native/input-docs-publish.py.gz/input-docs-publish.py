from pathlib import Path
import copy,hashlib,json,subprocess
root=Path('/Users/zhangxu/illegal/type-pal')
folder=Path('docs/testing/domains/phase1-runtime/control-rotation');folder.mkdir(parents=True,exist_ok=True)
candidate='0b0ce187e70f540ec2de198d671afd82ddaa99c5'
base='123595ac3a651957b36061eacced329369c495e5'
receipt='docs/ops/evidence/GAME-INPUT-ROTATION-1/review.json'
ops='docs/ops/evidence/GAME-INPUT-ROTATION-1/'
original=json.loads((root/receipt).read_text())
assert original['contributorCandidate']==candidate
refs=[]
for path,anchor,role in [
('packages/game/src/shell/input-direction.ts','export function inputDirection','direction-rule'),
('packages/game/src/shell/input-rotation.ts','export function isInputRotated','preference-owner'),
('packages/game/src/shell/gamepad-input.ts','setRotation(rotated: boolean)','stick-owner'),
('packages/game/src/shell/touch-controls.ts','const directionButton =','pointer-owner'),
('packages/game/src/shell/game-shell.ts','const updateRotation =','visual-caller'),
('packages/game/src/shell/game-shell.css','/* 45° centers use radius','visual-geometry'),
('packages/game/src/tools/tools-panel.ts',"toggleRow(parent, '虚拟方向键 / 左摇杆顺时针旋转45°'",'setting-caller'),
('packages/game/src/localization/ui-text.ts',"'虚拟方向键 / 左摇杆顺时针旋转45°'",'display-label'),
('packages/game/src/core/scene-system.ts','const DIR_DELTA:','movement-oracle'),
('packages/game/src/shell/gamepad-input.test.ts',"it('maps the four screen diagonals clockwise",'oracle'),
('packages/game/src/shell/touch-controls.test.ts',"it('maps four clockwise touch sectors",'oracle'),
('packages/game/src/shell/input-rotation.test.ts',"it('defaults to the original layout",'oracle'),
('packages/game/src/shell/game-shell.test.ts',"it('mounts the remembered rotated pad",'integration-oracle'),
('packages/game/src/tools/tools-panel.mobile.test.ts',"it('remembers clockwise controls",'setting-oracle'),
]:
 data=Path(path).read_bytes()
 assert data==subprocess.check_output(['git','show',candidate+':'+path])
 line=next(i for i,s in enumerate(data.decode().splitlines(),1) if anchor in s)
 refs.append({'path':path,'lines':str(line),'anchor':anchor,'role':role,'sha256':hashlib.sha256(data).hexdigest()})
run=json.loads(Path('build/input-rotation/restored.run.json').read_text())
command=' '.join(run['command'])
public=[
'createGameShell(canvas).connect(KeyboardInputSource) -> bindTouchControls / startGamepadInput; pointer contacts and standard Gamepad axes -> inputDirection -> InputSnapshot.held -> scene-system pickFacing / DIR_DELTA',
'setupToolsPanel -> renderSystemTab -> toggleRow -> setInputRotated; input rotation change event updates mounted shell and input adapters',
command,
'Cua public mobile Settings checkbox/reload/language UI and NE pointer hold350ms at explicit skip-intro dev route; root browser receipt records actual observations',
]
legal=[
'Connected standard-mapping typed GamepadState with left axes in[-1,1], normal hardware buttons and multiple device indices; keyboard owns separate contacts',
'Primary PointerEvent on buttons created by createTouchButton or circular .tp-dpad; legal coordinates in a stable square bounding rectangle; ordinary pointer up/cancel/capture loss and visibility/blur events',
'Browser preference absent, explicit45/on or0/off; unknown persisted string is storage IO input; DOMException storage denial exercises failure fallback only',
'Real KeyboardInputSource snapshots and mounted shell/tools UI; jsdom substitutes only browser scheduling/layout/capture/Storage boundaries. Root browser uses real desktop pointer at844x390 and390x844; no physical gamepad/touch fixture',
]
oracle={'type':'screen-direction-and-input-contact-ownership','assertions':[
'Defaultoff preserves original mapping; one remembered optional clockwise45 setting applies jointly to virtual pad and standard left stick; storage failure preserves an effective in-memory choice',
'NE/SE/SW/NW input yields Up/Right/Down/Left; independent scene DIR_DELTA means screen NE/SE/SW/NW movement(+16,-8)/(+16,+8)/(-16,+8)/(-16,-8)',
'Rotation preserves raw gamepad entry0.35/held0.2 thresholds and circular touch center0.13/rim0.5/held0.75; pad bounds do not rotate',
'Changing setting releases old touch/stick contacts; old pointer moves do not resume and each old stick must center before new motion; keyboard/hardware Dpad/other-device ownership remains',
'Actual settings UI writes preference and renders it on tab reopen; new shell initializes saved choice; Chinese and English labels identify virtual pad/left stick scope',
'Formal quadrant mutant causes exactly one designated AssertionError(expectedLeft,gotRight), with9 neighboring passes/zero skip; exact source restoration returns60 passing assertions',
'Root browser shows two mobile layouts, on/reload/off and English/Chinese; real NE pointerhold moves visible party coordinates1312,288 to1328,280 facingup, with logs[]',
]}
dedupe={'result':'reviewed-51-retained-9-added-0-retired','against':[
'packages/game/src/shell/gamepad-input.test.ts','packages/game/src/shell/touch-controls.test.ts','packages/game/src/shell/input.test.ts','packages/game/src/shell/game-shell.test.ts','packages/game/src/shell/touch-preference.test.ts','packages/game/src/tools/tools-panel.mobile.test.ts','packages/game/src/tools/tools-panel.english.test.ts','packages/game/src/localization/shell-surfaces.test.ts'],
'notes':'The selected baseline51 file/fullName contracts remain;9 additions are preference IO2, gamepad mapping/rearm/browser wiring3, touch mapping/reset2, shell initialization/live setting1 and settings reopen1. Existing touch-slide test only moves fixture construction to directionPad; all6 snapshots remain. English case adds one label assertion, not a new test. Different callers/lifecycles distinguish these layers; no formula-mirror oracle or retired/renamed test.'}
history=[{'date':'2026-10-27','action':'initial-control-rotation-publication','base':base,'candidate':candidate,'integratedCandidate':subprocess.check_output(['git','rev-parse','ae9e3226c'],text=True).strip(),'evidence':receipt,'scope':'Reuse contributor60/native counter/static gates plus root finite browser acceptance. This documentation publication runs no product tests and grants no whole-repository,coverage,hardware,complete-story or deployment credit. Publication remains active pending unified window and user experience.'}]
revision={'currentSha':candidate,'contentVersion':22,'minimumSaveVersion':12,'versionScope':'These are the current project publication axes recorded for the paired consumer; this phase1 browser-input preference does not consume content/save schema, change compatibility or authorize phase2 execution.','history':history}
entry={
'id':'game-input-rotation','kind':'report','title':'第一阶段可选45°方向控制回归','status':'active','phase':['phase1'],'engines':['game'],'owner':'Codex','provenance':['Codex','input_rotation'],
'domain':'phase1-runtime','module':'control-rotation','canonical':'domains/phase1-runtime/control-rotation/report.md','index':'domains/phase1-runtime/control-rotation/README.md','evidence':'domains/phase1-runtime/control-rotation/evidence.json','tags':['input','mobile','gamepad','regression'],'lastVerified':'2026-10-27','reviewBy':'2026-11-27','dependsOn':[],
'sourceRefs':refs,'publicCallers':public,'legalInputs':legal,'businessOracle':oracle,'dedupe':dedupe,'revision':revision,
}
meta={'schemaVersion':2,'id':entry['id'],**{k:entry[k] for k in ['sourceRefs','publicCallers','legalInputs','businessOracle','dedupe','revision']},'evidence':entry['evidence']}
report='''# 第一阶段可选45°方向控制回归

Status: active
Owner: Codex
Last reviewed: 2026-10-27
Template: test-domain-report-v1 / 1.1.0

## Domain scope

范围为 phase1/game 的输入外壳：一个默认关闭、可记忆的“虚拟方向键 / 左摇杆顺时针旋转45°”开关，共同控制手机虚拟方向键和标准手柄左摇杆。键盘、硬件十字键、确认/取消、窗口相对透明叠加布局和引擎移动语义保持。任务状态取[任务卡](../../../../ops/tasks/GAME-INPUT-ROTATION-1.md)，测试出版状态取 [catalog](../../../catalog.json)。

实现候选为 `0b0ce187e70f540ec2de198d671afd82ddaa99c5`；根 Codex 已基于实际14文件差异、逐文件A–H与原生结果独立接收有限功能，并在本地集成 `ae9e3226c` 做浏览器验证。[接收回执与原件](../../../../ops/evidence/GAME-INPUT-ROTATION-1/review.json)为实际执行事实源。本报告仍为 active：统一窗口和用户体验尚待收口。

## Claim matrix

| claim | evidence | status | limit |
|---|---|---|---|
| 四斜向→原四方向；默认保持；原始死区/半径 | 实际GamepadState/PointerEvent→KeyboardInputSource；固定NE/SE/SW/NW oracle；正式左上错发Right反控 | runtime-backed | 45°输入分区；实际像素步进为16×8，不称投影斜率精确45° |
| 切设置释放旧触点/摇杆，等待新触点或每设备回中；其他输入Owner保留 | touch reset、gamepad rearm/browser adapter、shell live-setting 用例 | runtime-backed | 无实物手柄；浏览器API由合法typed fixture进入真实controller |
| 默认off、偏好记忆和存储失败内存生效；中英文设置入口 | preference IO/reload、实际checkbox/tab重建、English原用例补强 | runtime-backed | 浏览器本地偏好，不属于游戏存档 |
| 手机布局/命中与实际NE移动 | 根 Cua：844×390、390×844；真实NE按住350ms，1312,288→1328,280，facingup；on→刷新on→off、English→Chinese；logs[] | runtime-backed | desktop真实浏览器pointer模拟移动viewport；有限dev-functional，非自然剧情E2E/真机 |

## Inputs and fixtures

生产链为 shell连接→触控/手柄adapter→真实输入快照→既有scene方向消费；设置链为系统/设置的操作区checkbox→偏好事件→已挂载壳层与输入adapter。具体source refs、合法输入、命令与独立oracle在metadata和[配对evidence](evidence.json)相同字段中绑定到候选字节。

GamepadState为标准布局、[-1,1]左轴和正常按钮；PointerEvent为主指针和真实注册按钮/稳定圆形pad。只有浏览器layout/capture/scheduling、Storage拒绝等host边界可替代；方向/ownership不mock，oracle不重复逆旋转公式。未知存储字符串和拒绝仅证明IO默认/失败策略。共同CONTENT22/minimumSave12只是出版consumer上下文，本功能不消费这两个版本轴，也不更改任何存档schema或授予第二阶段运行信用。

## Results and gaps

复用原生9文件60项：保留51旧合同、新增9、退役0。新增为偏好2、手柄3、触控2、shell1、设置重建1。旧touch-slide仅提取建pad夹具，6个原快照断言及file/fullName不变；English既有用例只补新标签断言。偏好IO、设置caller、shell初始化、adapter状态机各有独立失败方式，未以重复纯映射测试堆数量；全部身份见原生inventory。

正式反控在完整手柄10例中令左上错发Right：恰1指定业务AssertionError、9通过、0skip；按字节恢复后60全绿。早期按名称过滤的反控1红/9filtered skips完整保留，不计正式反控信用。原始命令记录gitHead为编码基点；source hash与最终候选TS字节相同，恢复测试之后仅补CSS几何解释注释。

根浏览器另外核了默认关闭、开启后的四按钮视觉、两手机viewport、真实NE方向输入、刷新记忆、关闭恢复和双语；该实跑不是本报告新造执行。尚未执行实物触屏/手柄、完整自然剧情E2E和本窗口全仓/官方coverage/受保护门；用户体验待用户试用。有限功能验收不增加整文件治理关闭数。

## Quality gate

贡献者已有game typecheck无诊断、14文件完整Biome JSON的error/warning/info/skipped/truncation均0；显式default+json reporter保留stdout/stderr，恢复测试stderr为空。Biome stderr的JSON格式实验性CLI提示保留，不混作代码诊断或隐藏。本次只出版配对文档和生成导航，不重复运行产品/覆盖率。

精确命令、cwd、UTC起止、exit/signal/spawn、原件SHA与恢复链由接收回执的native索引及配对evidence提供；`reviewBy=2026-11-27`仅为本报告后续审查期限，不把active变为verified。统一门、用户体验和发布分别由根任务收口，不据本页静态检查推定通过。

失效条件：方向消费/接触Owner/adapter生命周期、偏好序列化/事件或设置caller变化时，定向重核相应合同；pad几何/箭头/CSS变化须真实浏览器复验；runner/reporter/规则变化须复核原生结果和日志可见性。GameShell没有destroy API，新监听沿既有page lifetime；若引入shell重建/销毁，当前生命周期结论须重核，不能继承为任意脱离DOM后的回收证明。
'''
front='---\ntestingSchema: 2\nid: '+entry['id']+'\nevidence: '+entry['evidence']+'\n---\n\n'
(folder/'report.md').write_text(front+'<!-- testing-meta\n'+json.dumps(meta,ensure_ascii=False,separators=(',',':'))+'\n-->\n\n'+report)
(folder/'README.md').write_text('''# 可选45°方向控制回归

Status: current
Owner: Codex
Last reviewed: 2026-10-27
Template: governance-index-v1 / 1.0.0

## 目的

路由第一阶段虚拟方向键/标准手柄左摇杆的可选顺时针45°设置、输入合同和已有原件。

## 范围

本页仅导航。键盘、硬件十字键、引擎步进与游戏存档均不在本设置的修改范围内。

## 当前状态

稳定出版身份 `game-input-rotation`，catalog/report/evidence为 active：有限功能已独立接收，统一窗口和用户体验待收口。本页 current 只指导航有效。

## 入口与责任

- [正式域报告](report.md)
- [配对机器evidence](evidence.json)
- [实施任务卡](../../../../ops/tasks/GAME-INPUT-ROTATION-1.md)
- [根独立接收与原件索引](../../../../ops/evidence/GAME-INPUT-ROTATION-1/review.json)

## 证据与下一步

复用60项、正式单红反控和两viewport真实浏览器pointer证据；不重复授予运行次数或coverage信用。按报告列出的caller/oracle/失效条件复验；真机手柄/触屏、完整剧情与发布未测，根任务继续统一验收及用户试用。
''')
artifact_names=['review.json','native/restored.json.gz','native/restored.run.json.gz','native/restored.stdout.gz','native/restored.stderr.gz','native/restored.inventory.json.gz','native/counter-quadrant.json.gz','native/counter-quadrant.run.json.gz','native/counter-quadrant.stderr.gz','native/counter-quadrant.manifest.json.gz','native/counter-quadrant.original.ts.gz','native/counter-quadrant.mutant.ts.gz','native/typecheck-final.run.json.gz','native/typecheck-final.stdout.gz','native/typecheck-final.stderr.gz','native/biome-final.run.json.gz','native/biome-final.stdout.gz','native/biome-final.stderr.gz','native/browser-browser.json.gz','native/browser-before-input-dom.txt.gz','native/browser-after-input-dom.txt.gz','native/browser-reloaded-settings-dom.txt.gz','native/browser-english-settings-dom.txt.gz','native/browser-settings.png','native/browser-rotated-landscape.png','native/browser-rotated-portrait.png','native/browser-unrotated-landscape.png']
artifacts=[{'path':ops+name,'sha256':hashlib.sha256((root/(ops+name)).read_bytes()).hexdigest()} for name in artifact_names]
reference=lambda name: ops+'native/'+name
claims=[
{'id':'clockwise-mapping-and-thresholds','result':'runtime-backed','evidence':[reference('restored.json.gz'),reference('counter-quadrant.json.gz')],'scope':'Real typed standard pad/pointer callers; independent literal directions and raw thresholds. No hardware claim.'},
{'id':'rotation-contact-reset-and-ownership','result':'runtime-backed','evidence':[reference('restored.json.gz'),reference('restored.inventory.json.gz')],'scope':'Fresh touch/per-device centered stick required; keyboard/Dpad/other owners retained.'},
{'id':'preference-setting-and-storage-fallback','result':'runtime-backed','evidence':[reference('restored.json.gz'),reference('browser-reloaded-settings-dom.txt.gz'),reference('browser-english-settings-dom.txt.gz')],'scope':'Defaultoff/optional persistence/failed storage memory; actual setting and shell wiring.'},
{'id':'finite-mobile-browser','result':'runtime-backed','evidence':[reference('browser-browser.json.gz'),reference('browser-before-input-dom.txt.gz'),reference('browser-after-input-dom.txt.gz'),reference('browser-rotated-landscape.png'),reference('browser-rotated-portrait.png')],'scope':'Root Cua desktop browser pointer at two mobile viewports; NE movement only live scene; logs[]. Not physical hardware or natural story E2E.'},
]
evidence={
'schemaVersion':2,'id':entry['id'],'status':'active','candidateSha':candidate,'versions':{'content':22,'minimumSave':12},'versionScope':revision['versionScope'],**{k:entry[k] for k in ['sourceRefs','publicCallers','legalInputs','businessOracle','dedupe']},'history':history,'kind':'runtime-execution','runtimeExecution':{'performed':True,'scope':'Reused contributor targeted60 tests/formal mutant/static gates and root finite mobile browser; this documentation publication performs no new product execution.','completeE2E':False,'physicalHardware':False,'officialCoverage':False,'visual':'Root finite mobile Settings/layout/pointer smoke at two viewports only'},'claims':claims,'artifacts':artifacts,
'execution':{**run,'recordScope':'Original contributor restoration run, not a new execution at documentation publication; final candidate source TS bytes matched.'},
'contractMapping':{'retained':51,'added':9,'retired':0,'renamed':0,'newByCaller':{'preferenceIO':2,'gamepad':3,'touch':2,'shell':1,'settings':1},'inventory':reference('restored.inventory.json.gz'),'notes':dedupe['notes']},
'counter':{'native':reference('counter-quadrant.json.gz'),'identity':reference('counter-quadrant.run.json.gz'),'manifest':reference('counter-quadrant.manifest.json.gz'),'passed':9,'failed':1,'skipped':0,'failure':'AssertionError: expected[Right] to deeply equal[Left]','fullName':'standard gamepad through real input snapshots maps the four screen diagonals clockwise without changing raw stick thresholds','restored':reference('restored.json.gz'),'exploratoryRunNotCredited':'Earlier name-filter counter with9filtered skips remains in canonical root native index, not counted as formal needle.'},
'findings':[],'failures':[{'kind':'expected-business-counter','artifact':reference('counter-quadrant.json.gz'),'resolvedBy':'Exact source restore;60 native passing assertions'}],
'cleanup':{'complete':True,'scope':'Mutant source restored byte-for-byte and only contributor-created dependency symlinks removed; input branch remained clean. Temporary test hosts remove listeners/input sources and restore browser boundary spies. Root browser viewport reset per its receipt.','paths':['packages/game/src/shell/input-direction.ts','node_modules','packages/game/node_modules']},
'independentAcceptance':{'receipt':receipt,'decision':original['decision'],'codeQualityBoundary':original['codeQualityBoundary']},
'invalidation':['Changes to direction semantics, adapter/input ownership, preferences/events/settings caller require related native cases; CSS/geometry requires real browser.','Changed runner/reporter/tool versions/rules require corresponding native log-visibility review.','Introducing GameShell destroy/recreation invalidates current page-lifetime assumption.'],
'notRun':original['notRun']+['User product experience acceptance and deployment']
}
(folder/'evidence.json').write_text(json.dumps(evidence,ensure_ascii=False,indent=2)+'\n')
catalogPath=Path('docs/testing/catalog.json');catalog=json.loads(catalogPath.read_text())
assert len(catalog['entries'])==19 and not any(e['id']==entry['id'] for e in catalog['entries'])
oldscope=catalog['_governance']['scope']
catalog['entries'].append(entry)
catalog['_governance']['scope']='Original eighteen published records plus the 2026-10-22 script-corrections report and the 2026-10-27 control-rotation report (20 publication entries). This is not a census of all testing files, the frozen1838 cohort, migration completion or complete E2E readiness.'
catalog['_governance']['entryReadings'].append({'id':entry['id'],'conclusion':'新增phase1/game可选45°输入报告，active等待统一窗/用户体验；复用60native、精确单红恢复与根两viewport真实pointer/刷新/双语证据；51旧合同保留、9新增、0退役，不授真机/完整剧情/覆盖率/部署信用。'})
catalog['_governance']['history'].append({'date':'2026-10-27','action':'add-control-rotation-regression-publication','scope':'One new phase1/game active report/index/evidence and its reading; preserve the other19 entries and their original status,versions,dates and execution credit. Generated views reflect20 total entries.','previousScope':oldscope,'candidate':candidate,'evidence':receipt,'runtimeExecutionPerformedByPublication':False})
catalogPath.write_text(json.dumps(catalog,ensure_ascii=False,indent=2)+'\n')
p=Path('docs/testing/domains/phase1-runtime/README.md');s=p.read_text().replace('Last reviewed: 2026-10-16','Last reviewed: 2026-10-27').replace('第一阶段 runtime 的依赖所有权入口，不把二阶段版本轴授予Game执行。','第一阶段 runtime 测试域入口：依赖所有权与玩家输入分别沿各自报告和配对evidence核验，不把二阶段版本轴授予Game执行。').replace('本页只负责 1 个原有不同目标的导航；','本页负责 2 个不同目标的导航；').replace('- [Dependency ownership](dependencies/README.md)','- [Dependency ownership](dependencies/README.md)\n- [可选45°方向控制回归](control-rotation/README.md)',1)
s=s.replace('本页只维护这些入口的用途；','2026-10-27新增输入回归入口：实际执行结论仅取该报告及根独立接收回执；本次导航改动不新增运行。\n\n本页只维护这些入口的用途；',1)
p.write_text(s)
print('published one active paired domain; original19 entries retained, total20')
