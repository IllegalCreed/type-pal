import datetime,hashlib,json,pathlib,subprocess,sys
folder=pathlib.Path(__file__).resolve().parent
name=sys.argv[1];command=sys.argv[2:]
started=datetime.datetime.now(datetime.timezone.utc).isoformat()
r=subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
(folder/(name+'.stdout')).write_bytes(r.stdout);(folder/(name+'.stderr')).write_bytes(r.stderr)
sourceFiles=['packages/pal-extract/src/cli.ts','packages/pal-extract/src/events/script-entries.ts','packages/pal-extract/src/events/script-entries.test.ts','packages/pal-extract/src/resources/scene.ts','packages/pal-extract/src/resources/scene-supplemental.test.ts','packages/pal-extract/src/events/slice.ts','packages/pal-extract/src/events/script-corrections.ts','packages/pal-extract/vitest.config.ts','scripts/coverage/config.mjs','pnpm-lock.yaml']
(folder/(name+'.run.json')).write_text(json.dumps({'command':command,'cwd':str(pathlib.Path.cwd()),'started':started,'finished':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit':r.returncode if r.returncode>=0 else None,'signal':-r.returncode if r.returncode<0 else None,'spawnError':None,'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'sha256':{p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest() for p in sourceFiles if pathlib.Path(p).is_file()}},indent=2)+'\n')
sys.stdout.buffer.write(r.stdout);sys.stderr.buffer.write(r.stderr);sys.exit(r.returncode)
