from pathlib import Path
import json,gzip,hashlib,subprocess
root=Path('.')
def sha(b):return hashlib.sha256(b).hexdigest()
counts={}
for task in ['GAME-INPUT-ROTATION-1','GAME-NANZHAO-ROOM-EXIT-1']:
 p=root/'docs/ops/evidence'/task;r=json.load(open(p/'review.json'));n=0
 for a in r['native']:
  raw=(p/a['path']).read_bytes();assert sha(raw)==a.get('archiveSha256',a.get('gzipSha256',a.get('storedSha256'))),a['path'];b=gzip.decompress(raw) if a['path'].endswith('.gz') else raw;assert sha(b)==a['sourceSha256'],a['path'];n+=1
 counts[task]=n
old=json.loads(subprocess.check_output(['git','show','5859b8b04:docs/testing/catalog.json']));now=json.load(open('docs/testing/catalog.json'))
assert [x['id'] for x in old['entries']]==[x['id'] for x in now['entries']]
assert all(a==b for a,b in zip(old['entries'],now['entries']) if a['id']!='game-script-corrections')
originals=json.load(open('build/map204-integration/binding-originals.json'));owned={(x['reviewFile'],x['path']) for x in originals};validated=0
for name in {x['reviewFile'] for x in originals}:
 before=json.loads(subprocess.check_output(['git','show','f150c4922:'+name]));after=json.load(open(name));assert list(before)==list(after)
 for a,b in zip(before['entries'],after['entries']):
  assert a['path']==b['path']
  if (name,a['path']) not in owned:assert a==b,(name,a['path'],'unowned drift')
  else:
   assert b['history'][:len(a.get('history',[]))]==a.get('history',[])
   assert b['afterSha256']==sha(Path(b['path']).read_bytes()),b['path'];validated+=1
r={'nativeArchiveRoundTrips':counts,'unchangedCatalogEntries':19,'reviewBindings':validated,'unownedEntriesAndHistoricalPrefixPreserved':True,'sourceScope':'Actual final root feature source and doc delta, no runtime rerun'}
Path('build/map204-integration/final-verification.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
