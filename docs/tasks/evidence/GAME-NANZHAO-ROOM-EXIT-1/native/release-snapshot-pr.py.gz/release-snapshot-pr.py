import subprocess,json,sys,pathlib
root=pathlib.Path.cwd(); number=int(sys.argv[1]); prefix=sys.argv[2] if len(sys.argv)>2 else 'pr'; folder=root/'build/map204-release'
def api(path):
 p=subprocess.run(['python3',str(folder/'api.py'),'GET',path],cwd=root,capture_output=True,text=True)
 if p.returncode:raise RuntimeError(p.stderr)
 return json.loads(p.stdout)
pull=api(f'repos/IllegalCreed/type-pal/pulls/{number}')
head=pull['head']['sha'];checks=api(f'repos/IllegalCreed/type-pal/commits/{head}/check-runs?per_page=100')
(folder/(prefix+'-pull.json')).write_text(json.dumps(pull,indent=2)+'\n');(folder/(prefix+'-checks.json')).write_text(json.dumps(checks,indent=2)+'\n')
required=['documentation','fast-coverage'];runs=[r for r in checks['check_runs'] if r['name'] in required and r['app']['id']==15368 and r['head_sha']==head]
latest={name:max((r for r in runs if r['name']==name),key=lambda r:r['id'],default=None) for name in required}
result={'number':number,'head':head,'base':pull['base']['sha'],'state':pull['state'],'merged':pull['merged'],'mergeable_state':pull['mergeable_state'],'requiredPassed':all(r and r['conclusion']=='success' for r in latest.values()),'checks':[{'name':r['name'],'status':r['status'],'conclusion':r['conclusion'],'app':r['app']['id'],'head':r['head_sha'],'url':r['html_url']} for r in runs]}
(folder/(prefix+'-status.json')).write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'number':number,'requiredPassed':result['requiredPassed'],'checks':[{k:r[k] for k in ['name','status','conclusion']} for r in result['checks']]}))
