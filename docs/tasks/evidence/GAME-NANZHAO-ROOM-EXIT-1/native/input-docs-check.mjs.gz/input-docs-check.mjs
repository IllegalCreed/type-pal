import { readFileSync, writeFileSync } from 'node:fs'
import { execFileSync } from 'node:child_process'
import { isDeepStrictEqual } from 'node:util'
import { resolve } from 'node:path'
import { validateCatalog, validateCanonicalEvidence, validateIndexes, validateTestingOrphans } from '../../scripts/docs/check-testing.mjs'
import { checkTemplateBody } from '../../scripts/docs/document-model.mjs'
const testing = resolve('docs/testing')
const catalog = JSON.parse(readFileSync('docs/testing/catalog.json', 'utf8'))
const previous = JSON.parse(execFileSync('git', ['show', '0b0ce187e70f540ec2de198d671afd82ddaa99c5:docs/testing/catalog.json'], { encoding: 'utf8' }))
const entry = catalog.entries.find((item) => item.id === 'game-input-rotation')
const issues = [
  ...validateCatalog(catalog, testing),
  ...validateCanonicalEvidence(entry, testing, '/Users/zhangxu/illegal/type-pal'),
  ...validateIndexes(catalog, testing),
  ...validateTestingOrphans(catalog, testing),
]
if (!isDeepStrictEqual(previous.entries, catalog.entries.slice(0, -1))) issues.push('unrelated original entry mutation')
if (!isDeepStrictEqual(previous._governance.entryReadings, catalog._governance.entryReadings.slice(0, -1))) issues.push('unrelated original reading mutation')
if (catalog.entries.length !== 20) issues.push('wrong publication count')
const registry = JSON.parse(readFileSync('docs/phase-governance/templates/registry.json', 'utf8'))
for (const [file, templateId] of [[entry.canonical,'test-domain-report-v1'],[entry.index,'governance-index-v1']]) {
  const template = registry.types.find((item) => item.templateId === templateId)
  issues.push(...checkTemplateBody(readFileSync(resolve(testing,file),'utf8'),template).map((issue)=>file+': '+issue))
}
const result = { status: issues.length ? 'failed' : 'matched', issues, scope: 'Existing consumer validates new paired metadata/source/artifacts against actual root sourceRoot; original19 entries/readings unchanged; all9 generated indexes,orphans,catalog and two Markdown template bodies. No product/runtime execution or full document-model gate.' }
writeFileSync('build/input-rotation-docs/pair-validation.json', JSON.stringify(result, null, 2)+'\n')
console.log(JSON.stringify(result, null, 2))
if (issues.length) process.exitCode = 1
