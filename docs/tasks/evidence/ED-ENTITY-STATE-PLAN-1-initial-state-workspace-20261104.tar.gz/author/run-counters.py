import pathlib,subprocess,json,difflib,hashlib
root=pathlib.Path(__file__).resolve().parents[2];out=pathlib.Path(__file__).parent
cases=[('counter-scene-slice','packages/editor/src/core/script-preview-library.ts','state?.scenes.find((candidate) => candidate.sceneId === scene.id)','state?.scenes[0]','src/core/script-preview-library.test.ts','cross-scene slices'),('counter-source-focus','packages/editor/src/ui/App.tsx','focus={initialStateReturn?.target}','focus={undefined}','src/ui/App.preview-initial-state.test.tsx','independent workspace')]
results=[]
for name,path,before,after,test,pattern in cases:
 file=root/path; original=file.read_bytes();text=original.decode();assert text.count(before)==1,(path,before)
 mutant=text.replace(before,after);(out/(name+'.patch')).write_text(''.join(difflib.unified_diff(text.splitlines(True),mutant.splitlines(True),fromfile=path,tofile=path)))
 try:
  file.write_text(mutant)
  command=['python3',str(out/'run-evidence.py'),name,'packages/editor','pnpm','exec','vitest','run',test,'-t',pattern,'--reporter=json','--outputFile='+str(out/(name+'.json'))]
  result=subprocess.run(command,cwd=root)
 finally:file.write_bytes(original)
 results.append({'name':name,'source':path,'restored':file.read_bytes()==original,'sha256':hashlib.sha256(original).hexdigest(),'exit':result.returncode})
(out/'counter-restoration.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(results))
