import datetime, hashlib, json, pathlib, subprocess, sys
root=pathlib.Path.cwd(); out=root/'build/initial-state-workspace'; name=sys.argv[1]; command=sys.argv[2:]
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
paths=['projects/pal/editor/script-preview.json','docs/tasks/cards/ED-ENTITY-STATE-PLAN-1.md','docs/tasks/board.md','docs/tasks/cards/index.md','docs/testing/e2e/contract.md','docs/phase2/specs/editor-architecture.md','docs/phase-governance/document-locations.json','scripts/docs/document-location-admission.mjs']
record={'actor':'/root','cwd':str(root),'command':command,'startedAt':now(),'candidate':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'sourceHashes':{p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths}}
with (out/(name+'.log')).open('w') as stream: result=subprocess.run(command,stdout=stream,stderr=subprocess.STDOUT)
record.update(exit=result.returncode,finishedAt=now());(out/(name+'-execution.json')).write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:v for k,v in record.items() if k!='sourceHashes'},ensure_ascii=False));sys.exit(result.returncode)
