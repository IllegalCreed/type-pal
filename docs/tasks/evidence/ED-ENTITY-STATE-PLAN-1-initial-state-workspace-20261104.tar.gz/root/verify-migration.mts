import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { execFileSync } from 'node:child_process'
import { readFile, writeFile } from 'node:fs/promises'
import { applyScriptPreviewState, parseScriptPreviewLibrary, resolveScriptPreviewBinding, scriptPreviewStateUsages } from '../../packages/editor/src/core/script-preview-library.ts'
const baseline = '8e010f78994d8f9100973140571802f22073f987'
const path = 'projects/pal/editor/script-preview.json'
const old = JSON.parse(execFileSync('git', ['show', `${baseline}:${path}`], { encoding: 'utf8' }))
const bytes = await readFile(path)
const library = parseScriptPreviewLibrary(JSON.parse(bytes.toString()))
assert.deepEqual({ ...library, version: 2, states: library.states.map(({id, name, scenes}) => { assert.equal(scenes.length, 1); return {id, name, ...scenes[0]} }) }, old)
const index = JSON.parse(await readFile('projects/pal/content/scenes/index.json', 'utf8'))
const scenes = await Promise.all(index.scenes.map(async (entry: {path:string}) => JSON.parse(await readFile(`projects/pal/${entry.path}`, 'utf8'))))
const original = JSON.stringify(scenes)
for (const state of library.states) applyScriptPreviewState(scenes, state)
assert.equal(JSON.stringify(scenes), original)
for (const binding of library.bindings) assert.equal(resolveScriptPreviewBinding(library, binding.entry).stateId, binding.stateId)
const usages = scriptPreviewStateUsages(library, scenes)
const expected = JSON.parse(await readFile('build/initial-state-workspace/baseline-identity.json', 'utf8'))
const unchanged: Record<string,string> = {}
for (const name of ['docs/testing/e2e/cross-stage/script-progress.md','projects/pal/.type-pal/save-state.json']) {
 const sha = createHash('sha256').update(await readFile(name)).digest('hex'); assert.equal(sha, expected.hashes[name]); unchanged[name] = sha
}
assert.deepEqual(execFileSync('git', ['diff', '--name-only', baseline, '--', 'projects/pal'], {encoding:'utf8'}).trim().split('\n'), [path])
const receipt = { actor:'/root', at:new Date().toISOString(), baseline, candidate:execFileSync('git',['rev-parse','HEAD'],{encoding:'utf8'}).trim(), command:'pnpm exec tsx build/initial-state-workspace/verify-migration.mts', sidecarSha256:createHash('sha256').update(bytes).digest('hex'), states:library.states.length, entityOverrides:library.states.reduce((n,s)=>n+s.scenes.reduce((n,s)=>n+s.entities.length,0),0), bindings:library.bindings.length, schemeDefaults:library.schemeDefaults.length, reverseReferences:[...usages.values()].reduce((n,a)=>n+a.length,0), canonicalScenes:scenes.length, reverseMappingExact:true, authorScenesUnchanged:true, unchanged, exit:0 }
await writeFile('build/initial-state-workspace/migration-applied.json', JSON.stringify(receipt,null,2)+'\n')
console.log(JSON.stringify(receipt,null,2))
