import { createRequire } from 'node:module'
import { readFileSync } from 'node:fs'
import { resolve } from 'node:path'

const ts = createRequire(resolve('package.json'))('typescript')
const records = readFileSync(process.argv[2], 'utf8').trim().split('\n').map((s) => JSON.parse(s))
const sources = records
  .filter((r) => r.after && !r.path.includes('/__tests__/') &&
    !r.path.includes('.test.') && /\.tsx?$/.test(r.path))
const isFunction = (n) => ts.isFunctionLike(n) && n.body !== undefined
const lexicalBranches = new Set([
  ts.SyntaxKind.IfStatement,
  ts.SyntaxKind.ConditionalExpression,
  ts.SyntaxKind.CatchClause,
  ts.SyntaxKind.ForStatement,
  ts.SyntaxKind.ForOfStatement,
  ts.SyntaxKind.ForInStatement,
  ts.SyntaxKind.WhileStatement,
  ts.SyntaxKind.DoStatement,
  ts.SyntaxKind.CaseClause,
])
const conditions = new Set([
  ts.SyntaxKind.AmpersandAmpersandToken,
  ts.SyntaxKind.BarBarToken,
  ts.SyntaxKind.QuestionQuestionToken,
])
const complexity = []
const windows = new Map()
for (const { path } of sources) {
  const raw = readFileSync(path, 'utf8')
  const source = ts.createSourceFile(path, raw, ts.ScriptTarget.ESNext, true)
  const visit = (node) => {
    if (isFunction(node)) {
      let count = 1
      const add = (child) => {
        if (isFunction(child)) return
        if (lexicalBranches.has(child.kind) ||
            (ts.isBinaryExpression(child) && conditions.has(child.operatorToken.kind))) count += 1
        ts.forEachChild(child, add)
      }
      ts.forEachChild(node.body, add)
      if (count > 10) complexity.push({
        path, name: node.name?.getText(source) ?? node.parent?.name?.getText(source) ?? 'anonymous',
        line: source.getLineAndCharacterOfPosition(node.getStart(source)).line + 1, count,
      })
    }
    ts.forEachChild(node, visit)
  }
  visit(source)
  const lines = raw.split('\n').map((line, i) => ({ line: i + 1, text: line.trim() }))
    .filter(({ text }) => /[A-Za-z0-9]/.test(text) &&
      !/^(?:import|export type|}|\/\/|\/\*|\*|<\/?[A-Z])/.test(text))
  for (let i = 0; i + 8 < lines.length; i += 1) {
    const key = lines.slice(i, i + 9).map(({ text }) => text).join('\n')
    const earlier = windows.get(key) ?? []
    earlier.push({ path, line: lines[i].line })
    windows.set(key, earlier)
  }
}
const exactBlocks = [...windows.values()].filter((hits) => new Set(hits.map(({ path }) => path)).size > 1)
console.log(JSON.stringify({
  typescript: ts.version,
  method: 'AST lexical decision count per function body; nested functions independent; exact nine substantial logical-line windows across files, with common JSX form and import lines excluded',
  scanned: sources.length, complexity, exactBlocks,
}, null, 2))
