import assert from 'node:assert/strict'
import { execFileSync, spawnSync } from 'node:child_process'
import { createHash } from 'node:crypto'
import { existsSync, readFileSync, renameSync, writeFileSync } from 'node:fs'
import { resolve } from 'node:path'
import { pathToFileURL } from 'node:url'
import { compareWorkbenchComments, file as workbenchFile } from './verify-sprite-frame-comments.mjs'

const root=process.cwd()
const local=(f)=>import(pathToFileURL(resolve(root,f)))
const { compareCoverage,aggregateMetrics }=await local('scripts/coverage/metrics.mjs')
const { auditScope }=await local('scripts/coverage/inventory.mjs')
const { adjustApprovedBaseline }=await local('scripts/coverage/approved-baseline-adjustments.mjs')
const { isApprovedTestRetirement }=await local('scripts/coverage/approved-test-retirements.mjs')
const sha=value=>createHash('sha256').update(value).digest('hex')
const baselinePath='scripts/coverage/baseline.fast.json'
const previousBytes=execFileSync('git',['show','6fabcb219:'+baselinePath])
const previous=JSON.parse(previousBytes)
const [resultPath, ...options]=process.argv.slice(2)
const collectionPath=options.find(option=>!option.startsWith('--')) ?? 'coverage/fast/summary.json'
const collectedBytes=readFileSync(collectionPath)
assert.equal(sha(collectedBytes),'abcdcd4b139b5dcfbbd40f4fd0c7b278f528ebe00dc48709775673f2809c81da')
const collected=JSON.parse(collectedBytes)
const executed=JSON.parse(readFileSync(resultPath))
assert.equal(executed.head, '6fabcb219562079129ababae68e8def6bbe54d99')
assert.equal(executed.exitCode,1)
assert.equal(executed.signal,null)
let workbenchCommentProof
for (const [path,hash] of Object.entries(executed.changedPathSha256)) {
  if (!path.startsWith('packages/')) continue
  if (hash===null) assert(!existsSync(path), 'retired input returned: '+path)
  else if (path === workbenchFile) workbenchCommentProof=compareWorkbenchComments(hash)
  else assert.equal(sha(readFileSync(path)),hash,'candidate input drift: '+path)
}
assert(workbenchCommentProof)
assert.equal(collected.schemaVersion,2)
assert.equal(collected.profile,'fast')
assert.deepEqual(collected.provider,previous.provider)
assert.equal(collected.sourceFileCount,868)
assert.equal(collected.testCount,20086)
const source=readFileSync('scripts/coverage/run.mjs','utf8')
const begin=source.indexOf('const baselineView = ')
const end=source.indexOf('\n\nasync function writeBaseline',begin)
assert(begin>=0 && end>begin)
const definition=source.slice(begin,end)
const baselineView=new Function(definition+'\nreturn baselineView')()
const next=baselineView(collected)
const strict=compareCoverage(next,previous,{allowNewPackages:true})
assert.deepEqual(strict.regressions.map(reason=>reason.split(':')[0]),[
  'editor.statements','editor.lines','total.statements','total.lines',
])
const adjustment=await adjustApprovedBaseline(previous,(file)=>readFileSync(file))
assert.deepEqual(adjustment.applied,['editor-combat-sprite-previews-20261128'])
for (const [name,entry] of Object.entries(previous.packages)) {
  if(name!=='editor') assert.deepEqual(entry.metrics, adjustment.baseline.packages[name].metrics)
}
for (const key of ['branches','functions'])
  assert.deepEqual(previous.packages.editor.metrics[key],adjustment.baseline.packages.editor.metrics[key])
const comparing=compareCoverage(next,adjustment.baseline,{allowNewPackages:true})
assert.deepEqual(comparing.regressions,[])
const drift=structuredClone(next)
drift.packages.editor.metrics.statements.covered--
drift.total=aggregateMetrics(Object.values(drift.packages).map((pkg)=>pkg.metrics))
assert.deepEqual(compareCoverage(drift,adjustment.baseline).regressions.map(x=>x.split(':')[0]),['editor.statements','total.statements'])

const scope=auditScope(next,previous)
const retiredStillPresent=[]
const testEntries=(snapshot)=>new Map(Object.values(snapshot.packages).flatMap(p=>p.fastTests.fileEntries).map(x=>[x.file,x]))
const oldTests=testEntries(previous), newTests=testEntries(next)
for (const diff of scope.removals) {
  if ((diff.kind==='source'||diff.kind==='package')&&existsSync(diff.value))
    throw new Error('active production scope removed: '+diff.value)
  if ((diff.kind==='test-count'||diff.kind==='test-file')&&existsSync(diff.value)) {
    const fileSha256=sha(readFileSync(diff.value))
    assert(isApprovedTestRetirement({
      removal:diff, previous:oldTests.get(diff.value),current:newTests.get(diff.value),fileSha256
    }),'Missing exact retirement approval: '+diff.value)
    retiredStillPresent.push(diff)
  }
}
assert.equal(retiredStillPresent.length,2)
const normalized=spawnSync('pnpm',['exec','biome','format','--stdin-file-path',baselinePath],{
  input:JSON.stringify(next,null,2)+'\n',encoding:'utf8',maxBuffer:16*1024*1024
})
assert.equal(normalized.status,0,normalized.stderr)
assert.equal(normalized.stderr,'')
assert.deepEqual(JSON.parse(normalized.stdout),next)
if (process.argv.includes('--write-baseline')) {
  assert(readFileSync(baselinePath).equals(previousBytes),'Baseline file changed during calculation')
  const tmp=baselinePath+'.review-'+process.pid
  writeFileSync(tmp,normalized.stdout,{flag:'wx'})
  renameSync(tmp,baselinePath)
}
assert.deepEqual(JSON.parse(readFileSync(baselinePath)),next)
assert.deepEqual(auditScope(collected,next).changes,[])
assert.deepEqual(compareCoverage(collected,next).regressions,[])
console.log(JSON.stringify({
  input:{canonicalCollectionSha256:sha(collectedBytes),exactProductInputPaths:Object.keys(executed.changedPathSha256).filter(x=>x.startsWith('packages/')).length},
  workbenchCommentProof,
  strictPreviousRegressions:strict.regressions,
  applied:adjustment.applied,
  checkedTestRetirements:retiredStillPresent,
  retainedProductionScopes:true,
  coverageTests:collected.testCount,
  scopeChanges:scope.changes.length,
  improvements:comparing.improvements.length,
  additionalLossNegativeControl: true,
  baselineWrittenSha256:sha(readFileSync(baselinePath)),
  recountedEditor:adjustment.baseline.packages.editor.metrics,
},null,2))
