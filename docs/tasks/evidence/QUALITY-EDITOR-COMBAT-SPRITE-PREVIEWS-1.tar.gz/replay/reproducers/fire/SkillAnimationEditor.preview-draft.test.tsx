// @vitest-environment jsdom

import type { SkillAnimation } from '@type-pal/content'
import { act, useState } from 'react'
import { createRoot } from 'react-dom/client'
import { expect, test, vi } from 'vitest'
import { installBrowserHardwarePorts } from '../__tests__/canvas-test-ports.js'
import { createFireEffectFixture } from '../__tests__/fire-effect-fixture.js'
import { installReactActEnvironment, waitForReact } from '../__tests__/react-io-wait.js'
import { fieldControlByLabel, setInputValue } from './__tests__/glm-ui-wave-kit.js'
import { SkillAnimationEditor } from './SkillAnimationEditor.js'

test('editing an invalid loop start cannot crash the playback clock', async () => {
  installBrowserHardwarePorts()
  const restoreAct = installReactActEnvironment()
  vi.useFakeTimers({ toFake: ['setInterval', 'clearInterval'] })
  const host = document.createElement('div')
  document.body.append(host)
  const root = createRoot(host)
  try {
    const fixture = await createFireEffectFixture({
      projectId: 'fire-loop-draft',
      chunk: 64,
      frames: [{ paletteIndex: 1 }],
    })
    function Draft() {
      const [animation, setAnimation] = useState<SkillAnimation>({
        effectSprite: fixture.chunk,
        fireDelay: 0,
      })
      return (
        <SkillAnimationEditor
          animation={animation}
          onChange={setAnimation}
          assetCatalog={fixture.catalog}
          assetBase={fixture.base}
          assetReader={fixture.reader}
          draftScope="skill:loop-start"
          syncToken={0}
        />
      )
    }
    await act(async () => root.render(<Draft />))
    await waitForReact(() => expect(host.querySelector('.fire-preview canvas')).not.toBeNull())
    await setInputValue(fieldControlByLabel<HTMLInputElement>(host, '循环起点'), '-1')
    const play = host.querySelector<HTMLButtonElement>('button[aria-label="播放 FIRE 特效预览"]')
    if (!play) throw new Error('The preview playback control did not mount')
    await act(async () => play.click())

    await expect(
      act(async () => {
        await vi.advanceTimersByTimeAsync(100)
      }),
    ).resolves.toBeUndefined()
  } finally {
    await act(async () => root.unmount())
    host.remove()
    restoreAct()
    vi.useRealTimers()
    vi.unstubAllGlobals()
  }
})
