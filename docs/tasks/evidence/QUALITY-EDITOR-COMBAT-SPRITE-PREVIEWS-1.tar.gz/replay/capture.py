import hashlib, json, os, subprocess, sys
from datetime import datetime, timezone
from pathlib import Path

home = Path(__file__).resolve().parent
run = home / 'runs' / sys.argv[1]
run.mkdir(exist_ok=False)
args = [arg.replace('{report}', str(run/'vitest.json')) for arg in sys.argv[2:]]
sha = lambda data: hashlib.sha256(data).hexdigest()
stamp = lambda: datetime.now(timezone.utc).isoformat()
git = lambda *parts: subprocess.check_output(['git', *parts])
paths = git('diff','--name-only','-z','HEAD') + git('ls-files','-z','--others','--exclude-standard')
inputs = {path: sha(Path(path).read_bytes()) if Path(path).is_file() else None
          for path in dict.fromkeys(paths.decode().split('\0')) if path}
meta = {
    'cwd': os.getcwd(), 'argv': args, 'startedAt': stamp(),
    'head': git('rev-parse','HEAD').decode().strip(),
    'originMain': git('rev-parse','origin/main').decode().strip(),
    'changedPathSha256': inputs,
    'explicitCoverageInputs': {
        name: os.environ[name] for name in
        ['TYPE_PAL_COVERAGE_BASE_REF','TYPE_PAL_COVERAGE_PARALLEL_EDITOR'] if name in os.environ
    }
}
with (run/'stdout').open('wb') as stdout, (run/'stderr').open('wb') as stderr:
    status = subprocess.run(args,stdout=stdout,stderr=stderr,check=False).returncode
meta.update(finishedAt=stamp(),exitCode=status if status>=0 else None,signal=-status if status<0 else None,outputs={})
for name in ('stdout','stderr','vitest.json'):
    path = run/name
    if path.is_file():
        raw = path.read_bytes()
        meta['outputs'][name] = dict(bytes=len(raw),sha256=sha(raw))
        if name!='vitest.json':
            print('['+name+']')
            print('\n'.join(raw.decode(errors='replace').splitlines()[-32:]))
(run/'result.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2)+'\n')
sys.exit(status if status>=0 else 128-status)
