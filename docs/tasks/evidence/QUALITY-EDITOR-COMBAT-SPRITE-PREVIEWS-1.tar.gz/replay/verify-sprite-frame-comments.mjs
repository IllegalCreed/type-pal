import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { readFileSync } from 'node:fs'
import { createRequire } from 'node:module'
import { resolve } from 'node:path'

export const file = 'packages/editor/src/ui/SpriteFrameWorkbench.tsx'
const importLine = "import { drawFootAlignedFrame } from './sprite-frame-canvas.js'\n"
const oldBlock = '\n/** 大世界源帧在同一编辑器内复制到动作步骤时使用的稳定 MIME。 */\n' + importLine + '\n'
const newBlock = importLine + '\n// 使用独立的 MIME 识别动作步骤收到的源帧拖拽。\n' +
  '// 目标编辑器按当前资源与帧数校验传入的资源 ID 和帧索引。\n'
export function compareWorkbenchComments(beforeHash) {
  const current = readFileSync(file, 'utf8')
  const position = current.indexOf(newBlock)
  assert(position > 0 && position === current.lastIndexOf(newBlock))
  const before = current.replace(newBlock, oldBlock)
  const digest = (text) => createHash('sha256').update(text).digest('hex')
  assert.equal(digest(before), beforeHash)
  const { transpileModule, ScriptTarget, ModuleKind, JsxEmit } = createRequire(resolve('package.json'))('typescript')
  const emit = (source) => transpileModule(source, {
    fileName: file,
    compilerOptions: { target: ScriptTarget.ESNext, module: ModuleKind.ESNext, jsx: JsxEmit.ReactJSX, removeComments: true },
  }).outputText
  assert.equal(emit(before), emit(current))
  const declaration = 'export const SPRITE_FRAME_DRAG_MIME '
  const locate = (source) => source.slice(0, source.indexOf(declaration)).split('\n').length
  assert.equal(locate(before), locate(current))
  assert.equal(before.slice(before.indexOf(declaration)), current.slice(current.indexOf(declaration)))
  return { file, beforeSha256: beforeHash, currentSha256: digest(current), importOrderUnchanged: true, emittedJsEqual: true, untouchedExecutableSuffixFromLine: locate(current) }
}
