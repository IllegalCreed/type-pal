import { execFileSync } from 'node:child_process'
import { readFileSync } from 'node:fs'
import { createRequire } from 'node:module'
import { resolve } from 'node:path'
const ts = createRequire(resolve('package.json'))('typescript')
const isTest = (path) => /\.(test|spec)\.[cm]?tsx?$/.test(path)
const entries = readFileSync(process.argv[2], 'utf8').trim().split('\n').map(JSON.parse)
function registrations(path, source) {
  const file = ts.createSourceFile(path, source, ts.ScriptTarget.ESNext, true)
  const titles = []
  const visit = (node) => {
    if (ts.isCallExpression(node)) {
      const name = node.expression.getText(file)
      const title = node.arguments[0]
      if (/^(?:it|test)(?:$|\.(?:each|for|concurrent)\b)/.test(name) &&
          title && ts.isStringLiteralLike(title)) {
        titles.push({line:file.getLineAndCharacterOfPosition(node.getStart(file)).line+1,title:title.text})
      }
    }
    ts.forEachChild(node,visit)
  }
  visit(file)
  return titles
}
const before = (item) => registrations(item.path,execFileSync('git',['show',item.before.ref+':'+item.path],{encoding:'utf8'}))
const after = (path) => registrations(path,readFileSync(path,'utf8'))
const canonical = (title) => title.replace(/^(?:C0\d-G\d{2}-\d{2}|GLM\s?[A-Z][\d-]+|K0\d-[\d-]+)\s*[:：]?\s*/i,'')
const retirements = entries.filter((item)=>item.before && item.disposition==='retired' && isTest(item.path))
  .map((item)=>{
    const targets=item.successors.filter(isTest)
    const afterDeclarations=targets.flatMap((path)=>after(path).map((info)=>({path,...info})))
    return {
      beforePath: item.path, baseline: item.before.ref, decision:item.E,
      sourceTests:before(item).map((decl)=>{
        const exact=afterDeclarations.filter((destination)=>canonical(destination.title)===canonical(decl.title))
        return {...decl, match:exact.length===1?'exact title after prefix normalization':'see contract and destination declarations', exact}
      }),
      afterDeclarations,
    }
  })
const changedRetained = entries.filter((item)=>item.before && item.after && isTest(item.path) && item.before.blob!==item.after.blob)
  .map((item)=>({
    path:item.path, before:before(item), after:after(item.path), limits:item.E,
  }))
const manualContracts = {
  'FireEffectPreview.c06-g03.cursor-r1.test.tsx': [
    { old:'01 and 07', target:'FireEffectPreview.frames.test.tsx', title:'the idle preview draws the centered first frame in the project palette' },
    { old:'02 and 05', target:'FireEffectPreview.frames.test.tsx', title:'the clock advances the first pass and loops from the configured start' },
    { old:'03', target:'FireEffectPreview.frames.test.tsx', title:'pause restores the first image and ends the running clock', note:'The previous idle effect already drew frames[0]; the old assertion only checked the image after pausing stayed fixed.' },
    { old:'04', execution:'browser-fire-final', note:'Live Skill 296 FIRE 27 to the selected FIRE 28; cache-boundaries tests independently check source/revision paint.' },
    { old:'06', target:'FireEffectPreview.resources.test.tsx', title:'selecting an unregistered FIRE number clears the previous canvas and names the missing asset', note:'Pending state goes to the sibling unresolved read test.' },
    { old:'08', target:'FireEffectPreview.frames.test.tsx', title:'changing authored speed and playback rate restarts the same frame sequence' },
    { old:'09', target:'FireEffectPreview.frames.test.tsx', title:'leaving a silent preview stops its frame clock' },
    { old:'10', target:'FireEffectPreview.frames.test.tsx', title:'the idle preview draws the centered first frame in the project palette', note:'Native PAL fixture also records footer frame count/speed.' },
    { old:'11', target:'FireEffectPreview.frames.test.tsx', title:'a smaller animation frame clears the uncovered pixels of the previous frame' },
  ],
  'FireEffectPreview.glm-large-wave.test.tsx': [
    { old:'无音效特效可播放/暂停并切换倍速，figcaption 标注帧数与实速', target:'FireEffectPreview.frames.test.tsx', title:'changing authored speed and playback rate restarts the same frame sequence', note:'Idle footer and pause assertions also remain.' },
    { old:'音效准备失败时错误可见且不进入播放', target:'FireEffectPreview.audio.test.tsx', title:'an unregistered sound surfaces its preparation error without starting the frame clock' },
    { old:'真实 fire 字节读取失败时给出失败态且无画布', target:'preview-cache-boundaries.test.tsx', title:'FIRE transient failure is not a permanent cached null for the same revision' },
    { old:'闸门未释放时保持加载态不出现画布，释放后真实解码完成挂载', target:'FireEffectPreview.resources.test.tsx', title:'an unresolved frame read shows loading until the selected FIRE canvas can paint' },
  ],
  'BattleSpriteInlinePreview.c06-g04.cursor-r1.test.tsx': [
    { old:'01 and 03', target:'BattleSpriteInlinePreview.test.tsx', title:'资源库布局完整平铺帧，并保持主画布和缩略画布比例', note:'Frame 0 pixels, followed by selecting real frame 10, which also proves aria-pressed and onFrameSelect.' },
    { old:'04 and 10', note:'sequenceKey and activeFrames were test-only inputs. The production deck retains active named row and current raw frame props; the named action and ARIA coverage follows compact and library current controls.' },
  ],
  'SpriteFrameDeletion.test.ts': [
    { old:'未配置资源缩帧产生空全集修复证明', note:'The direct empty-consumer assertion remains separately in both battle and world deletion suites.' },
    { old:'多帧行走保留引擎步序，预制动作显示完整逐帧时间线', target:'world-sprite-action-preview.test.ts', note:'Current world projection and named action timing test; raw mixed planner file no longer owns display schedule.' },
  ],
}
for (const group of Object.values(manualContracts))
  for (const record of group)
    if (record.target && record.title && !after('packages/editor/src/ui/'+record.target).some((t)=>t.title===record.title))
      throw new Error('Missing explicit contract successor '+record.target+' '+record.title)
console.log(JSON.stringify({retirements,changedRetained,manualContracts},null,2))
