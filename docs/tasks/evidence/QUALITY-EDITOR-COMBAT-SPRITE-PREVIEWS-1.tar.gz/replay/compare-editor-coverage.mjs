import {createHash} from 'node:crypto'
import {execFileSync} from 'node:child_process'
import {readFileSync} from 'node:fs'
const sha=buffer=>createHash('sha256').update(buffer).digest('hex')
const names=['statements','branches','functions','lines']
const [oldPath, fastSummaryPath='coverage/fast/summary.json', editorSummaryPath='coverage/fast/editor/coverage-summary.json']=process.argv.slice(2)
const active=JSON.parse(readFileSync(fastSummaryPath))
const oldRaw=readFileSync(oldPath)
const currRaw=readFileSync(editorSummaryPath)
const base=JSON.parse(execFileSync('git',['show','6fabcb219:scripts/coverage/baseline.fast.json']))
const old=JSON.parse(oldRaw), curr=JSON.parse(currRaw)
const current=active.packages.editor
const previous=base.packages.editor
const count=(x,key)=>x?.[key] ? {covered:x[key].covered,total:x[key].total} : {covered:0,total:0}
const norm=x=>x.slice(x.indexOf('packages/editor/'))
const enumerate=x=>new Map(Object.entries(x).filter(([key])=>key!=='total').map(([key,metric])=>[norm(key),metric]))
const oldPaths=enumerate(old)
const newPaths=enumerate(curr)
const fileSet=new Set([...oldPaths.keys(),...newPaths.keys()])
const entries=[]
const zero=()=>Object.fromEntries(names.map(key=>[key,{covered:0,total:0}]))
const totals=zero()
for (const name of names) {
  if (JSON.stringify(count(old.total,name))!==JSON.stringify(previous.metrics[name])) throw new Error('old total mismatch '+name)
  if (JSON.stringify(count(curr.total,name))!==JSON.stringify(current.metrics[name])) throw new Error('new total mismatch '+name)
}
for (const path of [...fileSet].sort()) {
  const from=oldPaths.get(path),to=newPaths.get(path)
  const metrics=Object.fromEntries(names.map((name)=>[name,{before:count(from,name),after:count(to,name)}]))
  if (!names.some((name)=>JSON.stringify(metrics[name].before)!==JSON.stringify(metrics[name].after))) continue
  for(const name of names) {
    totals[name].total+=metrics[name].after.total-metrics[name].before.total
    totals[name].covered+=metrics[name].after.covered-metrics[name].before.covered
  }
  entries.push({path,metrics})
}
for(const field of ['total','covered'])
  for (const name of names) {
    if (totals[name][field]!==current.metrics[name][field]-previous.metrics[name][field])
      throw new Error('differences do not balance '+name+' '+field)
  }
console.log(JSON.stringify({
  old:{archive:'docs/tasks/evidence/QUALITY-EDITOR-PREVIEW-LIFECYCLES-1.tar.gz',member:'candidate-editor-v8-first.json',
       sha256:sha(oldRaw),currentProtectedBaselineMatchesAllEditorCounters:true},
  candidate:{officialRun:'official-fast-ratchet',reportSha256:sha(currRaw),sourceTree:'5f0ce42580535be3a83de2c232c705a36b1dfc29',
       totalTests:active.testCount, totalSourceFiles:active.sourceFileCount},
  editorBefore:previous.metrics,editorAfter:current.metrics,
  files:entries,totals,
},null,2))
