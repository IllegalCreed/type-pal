import assert from 'node:assert/strict'
import { createRequire } from 'node:module'
import { join } from 'node:path'

const workspace = process.argv[2]
const { chromium } = createRequire(join(workspace, 'package.json'))('playwright')
const browser = await chromium.launch({ channel: 'chrome' })
const activities = []
const diagnostics = []
const unavailable = []

async function openEditor(route, configure = async () => {}) {
  const page = await browser.newPage({ viewport: { width: 1280, height: 900 } })
  page.on('pageerror', (error) => diagnostics.push({ route, error: error.message }))
  page.on('console', (message) => {
    if (message.type() === 'warning' || message.type() === 'error')
      diagnostics.push({ route, level: message.type(), message: message.text(), url: message.location().url })
  })
  page.on('response', (response) => {
    if (response.status() >= 400) unavailable.push({ route, code: response.status(), url: response.url() })
  })
  await page.addInitScript(() => {
    const ids = new WeakMap()
    const events = []
    let nextId = 1
    window.fireAudioEvents = events
    const Audio = window.AudioContext
    window.AudioContext = class extends Audio {
      constructor(...args) {
        super(...args)
        const id = nextId++
        ids.set(this, id)
        events.push({ kind: 'create', id })
      }
      async decodeAudioData(...args) {
        const id = ids.get(this)
        try {
          const buffer = await super.decodeAudioData(...args)
          events.push({ kind: 'decode', id, duration: buffer.duration })
          return buffer
        } catch (error) {
          events.push({ kind: 'decode-rejected', id, name: error.name })
          throw error
        }
      }
      async close() {
        await super.close()
        events.push({ kind: 'close', id: ids.get(this), state: this.state })
      }
    }
    const proto = window.AudioBufferSourceNode.prototype
    for (const kind of ['start', 'stop']) {
      const original = proto[kind]
      proto[kind] = function (...args) {
        original.apply(this, args)
        const id = ids.get(this.context)
        if (id !== undefined) events.push({ kind, id, duration: this.buffer?.duration })
      }
    }
  })
  await configure(page)
  await page.goto('http://127.0.0.1:6197/?ui_samples&' + route, {
    waitUntil: 'domcontentloaded',
    timeout: 20000,
  })
  return page
}

async function countEvent(page, kind, count) {
  await page.waitForFunction(
    ([expectedKind, expectedCount]) =>
      window.fireAudioEvents.filter((event) => event.kind === expectedKind).length >= expectedCount,
    [kind, count],
  )
}

async function lifecycle(route, selector, exit) {
  const page = await openEditor(route)
  try {
    const preview = page.locator(selector)
    const play = preview.getByRole('button', { name: '播放 FIRE 特效预览', exact: true })
    const pause = preview.getByRole('button', { name: '暂停 FIRE 特效预览', exact: true })
    const canvas = preview.locator('canvas')
    await canvas.waitFor({ timeout: 20000 })
    assert.ok(
      await canvas.evaluate((node) => {
        const bytes = node.getContext('2d').getImageData(0, 0, node.width, node.height).data
        return bytes.some((value, index) => index % 4 === 3 && value > 0)
      }),
    )
    const caption = await preview.locator('figcaption').innerText()
    await play.click()
    await countEvent(page, 'start', 1)
    await pause.click()
    await countEvent(page, 'close', 1)
    await play.click()
    await countEvent(page, 'start', 2)
    await exit(page)
    await countEvent(page, 'close', 2)
    const events = await page.evaluate(() => window.fireAudioEvents)
    const created = events.filter((event) => event.kind === 'create')
    assert.equal(created.length, 2)
    for (const { id } of created) {
      const session = events.filter((event) => event.id === id)
      assert.ok(session.find((event) => event.kind === 'start' && event.duration > 0))
      assert.equal(session.at(-1).kind, 'close')
      assert.equal(session.at(-1).state, 'closed')
    }
    activities.push({ route, caption, lifecycle: events })
  } finally {
    await page.close()
  }
}
async function discardDelayedSkillSound() {
  let release
  let entered
  const pending = new Promise((done) => { release = done })
  const requestEntered = new Promise((done) => { entered = done })
  const route = 'module=battle&page=skill&object=296'
  const page = await openEditor(route, (tab) =>
    tab.route('**/sounds/138.wav', async (request) => {
      const nativeResponse = await request.fetch()
      assert.equal(nativeResponse.status(), 200)
      entered()
      await pending
      await request.fulfill({ response: nativeResponse })
    }),
  )
  try {
    await page.locator('.fire-preview canvas[aria-label^="FIRE 27"]').waitFor()
    await page.getByRole('button', { name: '播放 FIRE 特效预览', exact: true }).click()
    await requestEntered
    await page.locator('.ds-catalog-row').filter({ hasText: '观音咒' }).first().click()
    await page.locator('.fire-preview canvas[aria-label^="FIRE 28"]').waitFor()
    await countEvent(page, 'close', 1)
    release()
    await page.waitForFunction(() =>
      window.fireAudioEvents.some((event) => event.kind.startsWith('decode')),
    )
    const events = await page.evaluate(() => window.fireAudioEvents)
    assert.equal(events.filter((event) => event.kind === 'start').length, 0)
    assert.equal(await page.locator('.fire-preview .cf-err').count(), 0)
    await page.getByRole('button', { name: '播放 FIRE 特效预览', exact: true }).waitFor()
    activities.push({ route, delayedCueAfterSelectionChange: events })
  } finally {
    release()
    await page.close()
  }
}

try {
  await lifecycle('module=battle&page=skill&object=296', '.fire-preview', async (page) => {
    await page.locator('.ds-catalog-row').filter({ hasText: '观音咒' }).first().click()
    await page.locator('.fire-preview canvas[aria-label^="FIRE 28"]').waitFor()
    await page.getByRole('button', { name: '播放 FIRE 特效预览', exact: true }).waitFor()
  })
  await lifecycle('module=item&page=item&object=66', '.item-throw-presentation .fire-preview', async (page) => {
    await page.getByText('法术特效演出', { exact: true }).click({ timeout: 5000 })
    await page.locator('.item-throw-presentation .fire-preview').waitFor({ state: 'detached' })
  })
  await discardDelayedSkillSound()
  // The real PAL source has no save-state record. project-save-state.ts admits this exact 404.
  const missingOptionalState = (record) =>
    record.url?.endsWith('/projects/pal/.type-pal/save-state.json') &&
    (record.code === 404 || record.message?.includes('404 (Not Found)'))
  assert.deepEqual(diagnostics.filter((record) => !missingOptionalState(record)), [])
  assert.deepEqual(unavailable.filter((record) => !missingOptionalState(record)), [])

} finally {
  console.log(JSON.stringify({ activities, diagnostics, unavailable }, null, 2))
  await browser.close()
}
