import assert from 'node:assert/strict'
import { execFileSync } from 'node:child_process'
import { createHash } from 'node:crypto'
import { readFile } from 'node:fs/promises'
import { authorProjectSource } from '../../packages/editor/scripts/author-project-source.js'
import { loadAllAuthorScenes, loadCurrentProjectFrom } from '../../packages/reforge/src/project-loader.js'
import {
  applySceneInitialState,
  loadScriptPreviewLibrary,
  parseScriptPreviewLibrary,
  resolveScriptPreviewBinding,
  scriptPreviewEntryExists,
} from '../../packages/editor/src/core/script-preview-library.js'

const beforeRevision = '2b83fc42fae6fc6d5cd7bda8e53205fe41ec65b2'
const path = 'projects/pal/editor/script-preview.json'
const beforeBytes = execFileSync('git', ['show', `${beforeRevision}:${path}`])
const before = JSON.parse(beforeBytes.toString('utf8'))
const source = await authorProjectSource('projects/pal')
const library = await loadScriptPreviewLibrary(source)
assert(library)
assert.equal(library.version, 2)
assert.deepEqual(library.states, before.states)
assert.deepEqual(library.bindings, before.bindings)
assert.deepEqual(library.schemeDefaults, [])
assert.throws(() => parseScriptPreviewLibrary(before), /version 2/)
const project = await loadCurrentProjectFrom(source)
const scenes = await loadAllAuthorScenes(project)
for (const binding of library.bindings) {
  assert(scriptPreviewEntryExists(binding.entry, scenes))
  assert.deepEqual(resolveScriptPreviewBinding(library, binding.entry), {
    stateId: binding.stateId,
    source: 'step',
  })
}
for (const state of library.states) {
  const scene = scenes.find((candidate) => candidate.id === state.sceneId)
  assert(scene)
  applySceneInitialState(scene, state)
}
const afterBytes = await readFile(path)
console.log(JSON.stringify({
  at: new Date().toISOString(),
  beforeRevision,
  currentHead: execFileSync('git', ['rev-parse', 'HEAD'], { encoding: 'utf8' }).trim(),
  path,
  beforeSha256: createHash('sha256').update(beforeBytes).digest('hex'),
  afterSha256: createHash('sha256').update(afterBytes).digest('hex'),
  states: library.states.length,
  bindings: library.bindings.length,
  schemeDefaults: library.schemeDefaults.length,
  authorScenes: scenes.length,
  conclusions: [
    'Current public loader and v2 parser read the actual migrated sidecar',
    'All state payloads and step bindings match the fixed v1 source',
    'All 42 step entries exist and retain their explicit effective state',
    'All 32 states project through the production projection function',
    'Old v1 bytes are rejected; no runtime compatibility route',
  ],
  limits: 'Read-only schema/data verification, not browser save or per-entry E2E acceptance',
}, null, 2))
