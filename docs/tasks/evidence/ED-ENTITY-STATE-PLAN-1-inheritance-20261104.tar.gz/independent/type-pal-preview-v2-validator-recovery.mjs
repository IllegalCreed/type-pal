import assert from 'node:assert/strict'
import { readFileSync, writeFileSync } from 'node:fs'
import { createHash } from 'node:crypto'
import { execFileSync } from 'node:child_process'
import { parseScriptPreviewLibrary } from '/Users/zhangxu/.codex/worktrees/script-progress-ledger/type-pal/packages/editor/src/core/script-preview-library.ts'
import { previewAuthorScene, previewLibrary } from '/Users/zhangxu/.codex/worktrees/script-progress-ledger/type-pal/packages/editor/src/core/__tests__/script-preview-fixture.ts'
import { byteHash, entryKey, inventoryScenes, previewFingerprint, reportProgress } from '/Users/zhangxu/.codex/worktrees/script-progress-ledger/type-pal/scripts/script-governance/progress.mjs'
const root='/Users/zhangxu/.codex/worktrees/script-progress-ledger/type-pal'
const revision='cfb49b3ce501b884bc633803622299051ccb1d23'
const sha=bytes=>createHash('sha256').update(bytes).digest('hex')
const identities=['packages/editor/src/core/script-preview-library.ts','packages/editor/src/core/__tests__/script-preview-fixture.ts','scripts/script-governance/progress.mjs'].map(path=>{
 const disk=readFileSync(`${root}/${path}`),blob=execFileSync('git',['show',`${revision}:${path}`],{cwd:root});assert.deepEqual(disk,blob);return {path,sha256:sha(blob)}
})
const scene=previewAuthorScene(),library=previewLibrary(),entry=library.bindings[0].entry,preview={stateId:'door',selection:'default'}
const file=Buffer.from('fixed proof bytes')
const event={id:'saved-entry',at:'2026-11-04T02:00:00Z',actor:'independent counter',entry,context:{id:'fixture-entry',description:'public typed fixture caller'},axis:'initialState',from:'unreviewed',to:'saved',sourceFingerprint:inventoryScenes([scene]).get(entryKey(entry)).sourceFingerprint,dependencies:[{path:'source.txt',sha256:byteHash(file)}],evidence:[{path:'proof.txt',sha256:byteHash(file)}],preview,previewFingerprint:previewFingerprint(entry,preview,library),note:'Independent validator counter recovery.'}
const report=lib=>reportProgress({scenes:[scene],library:lib,ledger:{kind:'type-pal-script-progress',version:1,project:'pal',scope:'scene-hooks-and-entity-behavior-steps',events:[event]},readReference:async()=>file})
const valid=await report(library);assert.equal(valid.rows.find(row=>entryKey(row.entry)===entryKey(entry)).statuses.initialState.current,'saved')
const invalid=structuredClone(library);Object.assign(invalid.states[1],{motion:{running:true}})
assert.throws(()=>parseScriptPreviewLibrary(invalid),/不支持属性 motion/)
await assert.rejects(report(invalid),/不支持属性 motion/)
assert.throws(()=>previewFingerprint(entry,preview,invalid),/不支持属性 motion/)
const {stageId,...schemeEntry}=entry
const inherited={...library,bindings:[],schemeDefaults:[{entry:schemeEntry,stateId:'door'}]}
assert.equal(previewFingerprint(entry,preview,inherited),event.previewFingerprint)
const blocked={...inherited,bindings:[{entry,stateId:null}]}
assert.equal(previewFingerprint(entry,preview,blocked),null)
assert.ok(previewFingerprint(entry,{stateId:null,selection:'default'},blocked))
assert.ok(previewFingerprint(entry,{stateId:'door',selection:'manual'},blocked))
const result={at:new Date().toISOString(),revision,node:process.version,sourceIdentity:identities,validSavedPreserved:true,editorAndReportRejectSameMalformedUnselectedState:true,defaultInheritanceEquivalent:true,explicitNullBlocks:true,manualAlternativeDoesNotClaimDefault:true,limits:['Focused recovery only; no repeated author 77 UI/core tests or E2E.']}
writeFileSync('/tmp/type-pal-preview-v2-validator-recovery.json',JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result,null,2))
