import { readFileSync, writeFileSync } from 'node:fs'
import { createHash } from 'node:crypto'
import assert from 'node:assert/strict'
import { parseScriptPreviewLibrary } from '/Users/zhangxu/.codex/worktrees/script-progress-ledger/type-pal/packages/editor/src/core/script-preview-library.ts'
import { previewAuthorScene, previewLibrary } from '/Users/zhangxu/.codex/worktrees/script-progress-ledger/type-pal/packages/editor/src/core/__tests__/script-preview-fixture.ts'
import { byteHash, entryKey, inventoryScenes, previewFingerprint, reportProgress } from '/Users/zhangxu/.codex/worktrees/script-progress-ledger/type-pal/scripts/script-governance/progress.mjs'
const root='/Users/zhangxu/.codex/worktrees/script-progress-ledger/type-pal'
const hashes=Object.fromEntries(['packages/editor/src/core/script-preview-library.ts','scripts/script-governance/progress.mjs'].map(path=>[path,createHash('sha256').update(readFileSync(`${root}/${path}`)).digest('hex')]))
const scene=previewAuthorScene(), original=previewLibrary(), entry=original.bindings[0].entry
const preview={stateId:'door',selection:'default'}
const invalid=structuredClone(original)
Object.assign(invalid.states[1],{motion:{running:true}})
let parseError=''
try {parseScriptPreviewLibrary(invalid)}catch(error){parseError=String(error)}
assert.match(parseError,/不支持属性 motion/)
const file=Buffer.from('fixed proof bytes')
const event={id:'saved-entry',at:'2026-11-04T02:00:00Z',actor:'independent counter',entry,context:{id:'fixture-entry',description:'public typed fixture caller'},axis:'initialState',from:'unreviewed',to:'saved',sourceFingerprint:inventoryScenes([scene]).get(entryKey(entry)).sourceFingerprint,dependencies:[{path:'source.txt',sha256:byteHash(file)}],evidence:[{path:'proof.txt',sha256:byteHash(file)}],preview,previewFingerprint:previewFingerprint(entry,preview,original),note:'Counter: unrelated malformed state must not make the current sidecar appear loadable.'}
const report=await reportProgress({scenes:[scene],library:invalid,ledger:{kind:'type-pal-script-progress',version:1,project:'pal',scope:'scene-hooks-and-entity-behavior-steps',events:[event]},readReference:async()=>file})
const row=report.rows.find(row=>entryKey(row.entry)===entryKey(entry))
assert.equal(row.statuses.initialState.current,'saved')
assert.deepEqual(row.statuses.initialState.issues,[])
const result={at:new Date().toISOString(),scope:'unfrozen candidate',sourceHashes:hashes,input:'Valid public typed fixture, add unsupported motion field to unselected room state; active door state, binding and proof unchanged.',editorParser:parseError,ledgerStatus:row.statuses.initialState,originalFingerprint:event.previewFingerprint,malformedFingerprint:previewFingerprint(entry,preview,invalid),finding:'The new progress preview-library validator accepts a persisted v2 document rejected by the editor current parser and retains saved credit without any issue.'}
writeFileSync('/tmp/type-pal-preview-v2-validator-counter.json',JSON.stringify(result,null,2)+'\n')
console.log(JSON.stringify(result,null,2))
