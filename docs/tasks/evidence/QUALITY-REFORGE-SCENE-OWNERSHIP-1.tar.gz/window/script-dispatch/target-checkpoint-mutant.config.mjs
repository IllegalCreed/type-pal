import assert from 'node:assert/strict'
import { readFile } from 'node:fs/promises'
import { resolve } from 'node:path'

const file = resolve(process.cwd(), 'src/automatic-target-command.ts')
const initial = 'if (!gate.eligible()) continue'

export default {
  plugins: [
    {
      name: 'probe-automatic-command-owner-recheck',
      enforce: 'pre',
      async load(id) {
        if (id !== file) return
        const text = await readFile(file, 'utf8')
        assert.equal(text.split(initial).length, 2)
        process.stderr.write('MUTATION_HIT: automatic command ignores takeover after checkpoint\n')
        return text.replace(initial, '')
      },
    },
  ],
}
