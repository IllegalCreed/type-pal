import assert from 'node:assert/strict'
import { readFile } from 'node:fs/promises'
import { resolve } from 'node:path'

const file = resolve(process.cwd(), 'src/script-host-adapter.ts')
const initial = 'if (command.wait ?? !command.loop)'
const replacement = 'if (command.wait ?? false)'

export default {
  plugins: [
    {
      name: 'probe-adapter-one-shot-wait',
      enforce: 'pre',
      async load(id) {
        if (id !== file) return
        const text = await readFile(file, 'utf8')
        assert.equal(text.split(initial).length, 2)
        process.stderr.write('MUTATION_HIT: adapter one-shot no longer waits\n')
        return text.replace(initial, replacement)
      },
    },
  ],
}
