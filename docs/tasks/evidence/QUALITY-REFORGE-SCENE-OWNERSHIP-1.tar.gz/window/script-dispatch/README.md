# 脚本派发、关口与确认请求

从 Git 基点核 file-index.json 的每条文件状态和 A–H。旧用例身份、后继及退役依据取 test-migrations.json。run-index.json 指向每次独立的命令和完整回执。stdout、stderr、Vitest JSON 各保持实际字节。

两份 Vitest 配置只替换指定源码表达式。反控分别使奖励提前，以及转手后执行越过资格。其余失败来自真实边界或记录中的测试判据问题。script-binding-and-reader-retirement 的单一失败由 Vitest 比较带 own constructor 的对象触发。终态对照两级条目序列和实际运行值。

script-governance-probe.test.ts 的两条临时探针在此归档。published-source-preview.json 复验主装配器五处引用内容。稳定候选刊发还需固定 Git 提交和相应来源绑定门。本片未执行全仓 check、正式覆盖率或 protected fast。
