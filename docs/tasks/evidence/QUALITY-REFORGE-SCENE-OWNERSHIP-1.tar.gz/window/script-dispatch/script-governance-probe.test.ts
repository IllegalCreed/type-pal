import { expect, test } from 'vitest'
import { nextTestTask } from './__tests__/deferred.js'
import { fixture } from './__tests__/save-lineage-fixture.js'
import { expectDefined } from './defined.js'
import { ScriptConfirmModalQueue } from './script-confirm-modal.js'

test('registered scene and entity names save their own selected behavior', async () => {
  const { runtime, world, scene, signal } = fixture()
  scene.id = 'constructor'
  const entity = expectDefined(scene.entities[0])
  entity.id = 'constructor'
  const script = expectDefined(world.script)
  script.behaviors.entities = {}
  await runtime.runCommands(
    [
      {
        kind: 'selectEntityBehavior',
        target: { scene: scene.id, entity: entity.id },
        channel: 'trigger',
        selection: { kind: 'disabled' },
      },
    ],
    { signal },
  )
  expect(Object.entries(script.behaviors.entities)).toStrictEqual([
    [
      scene.id,
      Object.fromEntries([[entity.id, { trigger: { selection: { kind: 'disabled' } } }]]),
    ],
  ])
})

test('after failed capture, replacing the session still settles the pending confirmation', async () => {
  const queue = new ScriptConfirmModalQueue<string>()
  const owner = new AbortController()
  const pending = queue.enqueue('frame', owner.signal)
  const result = pending.then(() => 'resolved', () => 'rejected')
  const failure = new Error('capture failure')
  try {
    expect(() =>
      queue.activateIfPossible(true, () => {
        throw failure
      }),
    ).toThrow(failure)
    queue.cancelAll()
    expect(await Promise.race([result, nextTestTask().then(() => 'still pending')])).toBe('rejected')
  } finally {
    owner.abort()
    await result
  }
})
