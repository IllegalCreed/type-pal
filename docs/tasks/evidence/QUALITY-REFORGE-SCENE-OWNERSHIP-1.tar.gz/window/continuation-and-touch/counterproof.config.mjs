import { readFileSync } from 'node:fs'
import { strictEqual } from 'node:assert'
import { resolve } from 'node:path'

const mutations = [
  [
    'script-continuation.ts',
    "if (script.self === 'required' && !inherited) throw new Error('auto resume: shared需要self')",
    '',
  ],
  [
    'latest-snapshot-transaction.ts',
    'const missing = hooks.runAtBoundary ? await hooks.runAtBoundary(attempt) : attempt()',
    'const missing = attempt()',
  ],
]
export default {
  plugins: [{
    name: 'continuation-and-snapshot-test-counterproof',
    enforce: 'pre',
    load(id) {
      const path = id.split('?')[0]
      const mutation = mutations.find(([name]) => path === resolve('src', name))
      if (!mutation) return null
      const [, before, after] = mutation
      const source = readFileSync(path, 'utf8')
      strictEqual(source.split(before).length, 2, path)
      return source.replace(before, after)
    },
  }],
  test: { maxWorkers: 1 },
}
