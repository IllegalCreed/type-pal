# 脚本续跑、资源预载和延迟触发

review-index.json 是逐文件 A–H 及源码快检指纹。test-contract-successors.json 绑定原 35 个执行身份及承接，不重录通过包级结果替代合同。目录不新增可执行入口，复验命令、失败和恢复的 stdout/stderr/native 见 run-index.json 对应文件。延迟触发产品的宿主释放时序保留 pending。

两个生产入口字节与基点相同，各自仍在活跃客栈来源登记中。定向反控的 Vite 配置只在外部读取当时的函数，不写入工作树。真实宿主和续跑相邻验证共 163 项。定向验收不扩张到作者 E2E 路线。

window/script-world/runs/script-world-e2e-source-closure/result.json 为原客栈采录依赖解析器的额外复验。按其真实入口递归确认两份新源码及共享写入条件依赖均已计入来源。
