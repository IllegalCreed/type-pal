import assert from 'node:assert/strict';
import {execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import {existsSync, readFileSync} from 'node:fs';
import {resolve} from 'node:path';
import {pathToFileURL} from 'node:url';

const importLocal = (relative) => import(pathToFileURL(resolve(relative)).href);
const {auditScope} = await importLocal('scripts/coverage/inventory.mjs');
const {compareCoverage} = await importLocal('scripts/coverage/metrics.mjs');
const {adjustApprovedBaseline} = await importLocal('scripts/coverage/approved-baseline-adjustments.mjs');
const {isApprovedTestRetirement} = await importLocal('scripts/coverage/approved-test-retirements.mjs');

const base = process.argv[2];
const baselinePath = 'scripts/coverage/baseline.fast.json';
const rawProtected = execFileSync('git', ['show', `${base}:${baselinePath}`]);
const rawUpdated = readFileSync(baselinePath);
const rawObserved = readFileSync('coverage/fast/summary.json');
const [protectedBaseline, updated, observed] = [rawProtected, rawUpdated, rawObserved].map((bytes) => JSON.parse(bytes));
const sha = (bytes) => createHash('sha256').update(bytes).digest('hex');

assert.equal(updated.schemaVersion, protectedBaseline.schemaVersion);
assert.deepEqual(updated.provider, protectedBaseline.provider);
assert.deepEqual(observed.provider, updated.provider);
assert.equal(updated.generatedAt, observed.generatedAt);
assert.deepEqual(updated.total, observed.total);
for (const [id, spec] of Object.entries(updated.packages)) {
  assert.deepEqual(spec.metrics, observed.packages[id].metrics);
}
const observedScope = auditScope(observed, updated);
const observedComparison = compareCoverage(observed, updated);
assert.deepEqual(observedScope.changes, []);
assert.deepEqual(observedComparison.regressions, []);
const {baseline: acceptedFloor, applied} = await adjustApprovedBaseline(
  protectedBaseline,
  async (path) => readFileSync(path),
);
const floorComparison = compareCoverage(updated, acceptedFloor, {allowNewPackages: true});
assert.deepEqual(floorComparison.regressions, []);
const scope = auditScope(updated, protectedBaseline);
const entry = (snapshot, path) => Object.values(snapshot.packages)
  .flatMap((item) => item.fastTests.fileEntries)
  .find((test) => test.file === path);
const approvals = [];
for (const removal of scope.removals) {
  if (!existsSync(removal.value)) continue;
  assert.ok(['test-count', 'test-file'].includes(removal.kind), JSON.stringify(removal));
  const fileSha256 = sha(readFileSync(removal.value));
  assert.ok(isApprovedTestRetirement({
    removal,
    previous: entry(protectedBaseline, removal.value),
    current: entry(updated, removal.value),
    fileSha256,
  }), JSON.stringify(removal));
  approvals.push({...removal, fileSha256});
}
process.stdout.write(JSON.stringify({
  result: 'PASS',
  scope: 'Frozen local observation and persisted ratchet baseline against protected main; GitHub independently reruns coverage:fast on the PR.',
  base,
  protectedBaselineSha256: sha(rawProtected),
  updatedBaselineSha256: sha(rawUpdated),
  observationSha256: sha(rawObserved),
  sourceFileCount: observed.sourceFileCount,
  testCount: observed.testCount,
  observedTotal: observed.total,
  protectedTotal: protectedBaseline.total,
  improvements: floorComparison.improvements,
  existingFloorAdjustments: applied,
  scopeChanges: scope.changes,
  removals: scope.removals,
  exactRetirementApprovals: approvals,
}, null, 2) + '\n');