const counters = {
  walk: [
    'entity-walk.ts',
    'const distancePerTick = Math.hypot(16, 8) * SPEED_GRID[speed]',
    'const distancePerTick = Math.hypot(16, 8) * SPEED_GRID[speed] / 2',
  ],
  touch: [
    'motion-batch.ts',
    '  hooks.commitCanonicalEndpoints()\n  hooks.commitLivePositions()\n  hooks.afterLiveCommit()\n  const touchTookOver = hooks.runTouch()',
    '  const touchTookOver = hooks.runTouch()\n  hooks.commitCanonicalEndpoints()\n  hooks.commitLivePositions()\n  hooks.afterLiveCommit()',
  ],
  owner: [
    'motion-runtime-wiring.ts',
    '      snapshot.ownerLifecycleAllowed &&\n',
    '',
  ],
  chase: [
    'save/current-structure.ts',
    "    if (targets.has(id)) fail(`${p}.target`, '追逐目标不得重复')",
    '',
  ],
  sparse: [
    'save/current-structure.ts',
    '  for (let index = 0; index < list.length; index += 1) check(list[index], `${path}[${index}]`)',
    '  list.forEach((entry, index) => check(entry, `${path}[${index}]`))',
  ],
}
const counter = process.env.TYPE_PAL_SCOPED_COUNTER
const selected = counters[counter]
if (!selected) throw new Error('unknown counterproof')
const [file, before, after] = selected
export default {
  test: { maxWorkers: 1 },
  plugins: [{
    name: 'scoped-bounded-counterproof',
    enforce: 'pre',
    transform(source, id) {
      if (!id.endsWith(`/packages/reforge/src/${file}`)) return
      if (source.split(before).length !== 2) throw new Error('counterproof anchor is not unique')
      const changed = source.replace(before, after)
      if (changed === source) throw new Error('counterproof source unchanged')
      return { code: changed, map: null }
    },
  }],
}
