import { readFileSync } from 'node:fs'
import { strictEqual } from 'node:assert'
import { resolve } from 'node:path'

const mutations = [
  ['script-flow-bindings.ts', "if (autoChanged) coordinator?.bump(entityOwner(target, 'auto'))", 'if (autoChanged) void 0'],
  ['script-world.ts', "if (!pending.ready) throw new Error('save barrier 尚未 ready，不能 release')", ''],
  ['script-conditions.ts', 'random() * 100 < condition.percent', 'random() * 100 <= condition.percent'],
]

export default {
  plugins: [{
    name: 'script-world-test-counterproof',
    enforce: 'pre',
    load(id) {
      const path = id.split('?')[0]
      const mutation = mutations.find(([file]) => path === resolve('src', file))
      if (!mutation) return null
      const [, before, after] = mutation
      const source = readFileSync(path, 'utf8')
      strictEqual(source.split(before).length, 2, path)
      return source.replace(before, after)
    },
  }],
  test: { maxWorkers: 1 },
}
