import assert from 'node:assert/strict'
import { readFileSync } from 'node:fs'
import ts from 'typescript'

const [base] = process.argv.slice(2)
const directory = 'packages/reforge/src/'
const files = ['script-world.ts', 'script-flow-bindings.ts', 'script-conditions.ts']
const printer = ts.createPrinter({ removeComments: true })
function parse(file, code) {
  const source = ts.createSourceFile(file, code, ts.ScriptTarget.Latest, true)
  assert.deepEqual(source.parseDiagnostics, [])
  return source
}
const before = parse(files[0], readFileSync(base, 'utf8'))
const after = files.map(file => parse(file, readFileSync(directory + file, 'utf8')))
const commits = new Map([
  ['beginEntityBehavior', { name: 'commitEntityBehaviorCursor', call: 'commitEntityBehaviorCursor(world, target, channel, resolved, cursor, resume);' }],
  ['beginSceneHook', { name: 'commitSceneHookCursor', call: 'commitSceneHookCursor(world, scene.id, slot, resolved, cursor);' }],
])
function declarations(source) {
  return source.statements.filter(node =>
    ts.isFunctionDeclaration(node) || ts.isClassDeclaration(node),
  )
}
function normalize(text) {
  return text.replace(/^export /, '').replace(/\bclone\(/g, 'structuredClone(')
}
function tokens(text) {
  const scanner = ts.createScanner(ts.ScriptTarget.Latest, true, ts.LanguageVariant.Standard, text)
  const parts = []
  for (let token = scanner.scan(); token !== ts.SyntaxKind.EndOfFileToken; token = scanner.scan())
    parts.push(scanner.getTokenText())
  return parts
}
function print(node) {
  return printer.printNode(ts.EmitHint.Unspecified, node, node.getSourceFile())
}
function callback(node) {
  const declaration = node.body.statements.find(s =>
    ts.isVariableStatement(s) && s.declarationList.declarations[0].name.getText() === 'lease',
  ).declarationList.declarations[0]
  return declaration.initializer.arguments[1].body
}
function withoutCallback(node, range) {
  const text = node.getText()
  const start = node.getStart()
  // Reparse the member in a temporary class so existing indentation is irrelevant.
  const replaced = text.slice(0, range.getStart() - start) + '{}' + text.slice(range.end - start)
  return print(parse('compare.ts', 'class Compare {' + replaced + '}').statements[0].members[0])
}
const prior = new Map(declarations(before).map(node => [node.name.text, node]))
assert.match(print(prior.get('clone')), /return structuredClone\(value\);/)
prior.delete('clone')
const compared = []
for (const source of after) {
  for (const node of declarations(source)) {
    const name = node.name.text
    if ([...commits.values()].some(entry => entry.name === name)) continue
    assert(prior.has(name), 'unexpected declaration ' + name)
    const old = prior.get(name)
    if (name === 'FlowRuntimeCoordinator') {
      assert.equal(node.members.length, old.members.length)
      for (const [i, member] of node.members.entries()) {
        const earlier = old.members[i]
        const slot = member.name?.getText() ?? 'constructor'
        if (!commits.has(slot)) {
          assert.deepEqual(tokens(normalize(print(member))), tokens(normalize(print(earlier))), slot)
          continue
        }
        const previousCallback = callback(earlier)
        const currentCallback = callback(member)
        assert.equal(withoutCallback(member, currentCallback), withoutCallback(earlier, previousCallback), slot)
        const { name: movedName, call } = commits.get(slot)
        assert.deepEqual(currentCallback.statements.map(print), ['beforeCommit?.();', call])
        const moved = declarations(after[1]).find(n => n.name.text === movedName)
        const normalized = previousCallback.statements.slice(1).map(
          s => normalize(print(s)).replaceAll('scene.id', 'sceneId'),
        )
        assert.deepEqual(moved.body.statements.map(print), normalized)
        assert.equal(print(previousCallback.statements[0]), 'beforeCommit?.();')
        compared.push({ moved: movedName, original: slot })
      }
    } else {
      assert.deepEqual(tokens(normalize(print(node))), tokens(normalize(print(old))), name)
    }
    compared.push({ file: source.fileName, name })
    prior.delete(name)
  }
}
assert.equal(prior.size, 0, [...prior.keys()].join(', '))
console.log(JSON.stringify({ compared, missing: [] }, null, 2))
