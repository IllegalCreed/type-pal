# Reforge 绑定、保存屏障和条件复核

本片使用同一治理分支的现行基点与上一切片已有的绑定、取消和存档证据。逐项裁定见 review-index.json。前读、后读以实际文件指纹登记，依赖读域不计原路径。test-contract-successors.json 把三份原专测的 35 个 file × fullName 逐项指向 32 个现行用例。完整执行见 run-index.json，每次保存原始 stdout、stderr 和 native 身份文件。

## 快速复验

- 旧三套在搬移实现后通过 35/35。后继套件和真实邻接共 172 项。Editor 调用方 19 项。团队历史 C85 的精确路径和替换脚本按 Git a1ac53bbea78b58ee88e5a3a53894a2fcaf595eb 复验；本窗不改旧时间点。
- 反控仅在 Vitest 的 Vite load 钩子按指定文件和唯一源码片段生效，受测工作树字节保持原样。读取 counterproof.config.mjs 和同次 result.json 即可重新触发三条业务断言，再按最终命令复跑。原生反控不会在正常测试配置加载。
- 冻结旧脚本世界用 review-index.json 的 gitHead 和 before-split.patch 恢复。将该路径导出到空的临时目录并在临时目录应用补丁。将 prove-body-equivalence.mjs 临时放在本仓根目录可解析 TypeScript，参数传已恢复的旧文件绝对路径。从仓根重放后删除临时文件。核对了原 top-level 声明和协调器成员。两个游标提交回调在实际函数契约下逐语句对照，会话检查顺序明确保留。
- 002 首次真实源码写点 census 观察少一个有效提交。生产 host 继续通过按自有键写入的模块，同时保留真实写点的局部命名，原探针恢复。进一步直接调用 inn 和 scripted defeat 两个现行变换，确认各观测只接入一次且输出 TypeScript 可解析。未运行浏览器路线。
- 最初类型检查指出 fixture 把供场景读取的 entity 与完整可含 zone 的 entity definition 混用，修正类型后两包最后 typecheck 零诊断。最终静态校验包含生产宿主与六个新旧路径。集中门和正式来源重绑留冻结窗。
