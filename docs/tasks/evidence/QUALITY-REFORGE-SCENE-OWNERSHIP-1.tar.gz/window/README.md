# Reforge scene and script slice evidence

The base is recorded in review-index.json and in each execution receipt. Candidate SHA256 values refer to workspace bytes. The main checkout was untouched. The central ledger has the publishing status.

Compare the recorded source and dependency hashes before relying on a claim. A missing or changed caller, validator, script contract, or source file invalidates the relevant claim. The underlying design judgments are in the A–H records. The hashes establish code identity only. Retired sources can be recovered with git show BASE:PATH from the recorded base. The prior review archive supplies its complete debug/placement read scope.

Each runs directory contains its original stdout, stderr, native Vitest result when applicable, and execution identity. Use the result.json argv and a fresh temporary JSON report path for a replay. The run index lists exact failure identities. Final sources can be verified independently by rerunning the preserved command with default and JSON reporters. The build had no whole-repo, coverage, protected-fast or publication result at this point.

Earlier probe and draft failures stay visible. The first item probe faced out of bounds. The first disabled-trigger probe used an invalid author field. The initial projection tests had an invalid completed cursor and incorrect goto shape, followed by an explicit fixture/result type correction. The first expanded Reforge gate proved that a cross-realm abort was mislabeled as an error. The final tests check cancellation of the actual signal and absence of the previous effect.

The old runtime-state-mutants and coverage diagnostic configs are historical. Their source substitutions and fixed test titles refer to their original source snapshot. They do not give current execution credit. The successor map is derived from actual Vitest titles.

The approved public compiler removal is tracked in REFORGE-RUNTIME-COMPILER-ENTRY-1. The three former consumers keep all 19 native test identities. The first grouped gate includes 247 checks and the interface follow-up provides 101, with intentional overlap. Reforge and Editor typechecks and the final 34-file lint check are independent execution receipts.

The initial structural branch scan is in complexity-screen.json. The review index records the exact package file delta and the dispositions for the repeated logic. A standalone behavior patch preserves the separation between the world-scratch fix and the later read-only projection refactor for the final split commits.

Documentation and the document model stop at the previous main.ts testing-source binding. Both failed outputs are preserved. All five indexed excerpts still match uniquely, as recorded in source-binding-preview.json. A frozen consolidated source commit is required before applying the exact version bridge. The independent acceptance of edited documents does not mean that the release gate passed.
