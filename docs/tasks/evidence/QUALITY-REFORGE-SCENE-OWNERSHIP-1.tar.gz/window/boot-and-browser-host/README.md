# 页面入口、启动与浏览器测试宿主

逐文件裁定见 review-index.json，原测试 file × fullName 的去向见 case-successors.json。13 个原路径含三个旧专测退出，三个后继按职责承接。运行回执 index 列明原件和两条真实失败。两个入口源保留基点字节，产品未因为整理测试改变。

两个真实红例分别出现只读观测口泄漏与失败后未释放键。修复属于测试宿主的作用域，原运行入口和正式 E2E 不变。定向及邻接 13 文件 96 例全部通过，Reforge typecheck 和 scoped Biome 无诊断。README 只作导航，正式测试身份和 stdout/stderr 取原件。
