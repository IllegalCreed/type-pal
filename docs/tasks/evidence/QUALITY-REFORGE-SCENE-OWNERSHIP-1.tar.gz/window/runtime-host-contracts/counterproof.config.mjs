import assert from 'node:assert/strict'
import { readFileSync } from 'node:fs'
import { resolve } from 'node:path'

const mutations = {
  binding: [
    'script-project-core.ts',
    `            selectEntityBehavior(
              this.world,
              entityAt(scene, command.target),
              command.target,
              command.channel,
              command.selection,
              this.coordinator,
            )`,
    '            void 0',
  ],
  lineage: [
    'script-activity-lineage.ts',
    'registration.coordinator === coordinator && coordinator.hasActiveLease(registration.lease)',
    '!latest && registration.coordinator === coordinator && coordinator.hasActiveLease(registration.lease)',
  ],
  continuation: [
    'script-continuation.ts',
    "if (script.self === 'required' && !inherited) throw new Error('auto resume: shared需要self')",
    '',
  ],
}
const rule = mutations[process.env.TYPE_PAL_RUNTIME_TEST_MUTATION]
assert(rule, 'one test mutation is required')
const [file, before, after] = rule
export default {
  plugins: [{
    name: 'runtime-contract.assertion-counterproof',
    enforce: 'pre',
    load(id) {
      const path = id.split('?')[0]
      if (path !== resolve('src', file)) return null
      const source = readFileSync(path, 'utf8')
      assert.equal(source.split(before).length, 2, path)
      return source.replace(before, after)
    },
  }],
  test: { maxWorkers: 1 },
}
