# 迁移来源投影与 Content 物品专测执行证据

基点是 #71 主线合并 `dc745c12704370975645c0992cf477c4bc8d1da3`。`source-candidate.tree` 记录覆盖率写回前的已暂存源码和测试。该身份是 Git tree，不是合并提交。最终提交和 PR 应从 Git 获取。文件候选按 `file-review.json` 的 blob、字节和行数单独定位。

## 快速复验

1. 用 `file-review.json` 的 `records[].evidence` 找 A–H 原表的实际行。98 是完成处置的原路径数。查 `review` 读取七个新增留项和解除条件。按索引及 Git 源可复验，原文件没有作为过程副本存入。
2. `test-identity-mapping.json` 来自固定主线和当前两个原生 fast 清单，列全部发生身份变化的路径。前后条目使用官方 Vitest project/fullName 算法。合同理由在原表 E 维、下节和路径重组记录。还原某个测试时，按实际指向查看对应摘要和原生报告。
3. `migrate-coverage-delta.json` 是原生计数拆解。邻接两个 summary 和必要 Migrate 命中图为实际 V8 原件。完整前后 fast 集合由独立 Vitest 文件索引采集，与主线保护值核对。执行 JSON 列出命令、工作目录、时间、退出码和信号，stdout/stderr 为完整原始输出。
4. `previous-main-ci.json` 和两个 GitHub 原始 job 日志用于 #71 当时的主线确认。后续提交的 protected fast 读取其 GitHub PR checks，不以本地对照冒称远端通过。

如当前分支不再含候选树、底层 Content 规则、原盘提取日志、PAL 当前发布调用或测试身份有改动，只复核受影响的切片。地图及精灵的 PAL 指纹仅适用于已核的来源集合。产品资产的真实演出、部署和活跃 E2E 不在本次测试信用内。

## 测试合同迁移

- 地图测试按输入轴保留固定原字、半格逐位、独立两层、行列错形、回编码和地图 ID。显示名归 `pal-map-names.test.ts`，重复编号、残差／孤立高度、零分母、UTF-8 字节计量归 `project-map-audit.test.ts`。旧字节自比退出，后继实际报告以独立 TextEncoder 计量。两个定向变体分别只击中第二逻辑行与 UTF-8。
- 主迁移计划 15→9。旧原子地图两例由 `migration-plan.maps.test.ts` 的 hash-only 规则合并承接。计数减少的剩余入口分别是 `migration-plan.files.test.ts` 的本地索引附属文件、互不干扰的作者字段、上游与作者同字段冲突、仅退役托管文件。旧 shard 形状改在当前共享脚本库验证。作者姿态和触发器与上游动画同验，裁剪资产接管、delete-modify 两方向和重放零计划继续在主计划入口。
- 物品方案边界 4→3。双路径菱形、跨场景和通道的同名、两种期望计数分别保留。旧通用输入保真与当前小组快照重复。选择图的独立六处分支来自剧本 AST 合法形状。
- 资产真盘范例由三份 `.pal.test.ts` 各自收口世界/战斗精灵、PNG/角色头像及音效。当 trace 发现世界精灵坏尾 fast 分支遗漏时恢复真实解析后到达字节门的有效覆盖，以确切总长度替代早期宽泛正则。损坏半个 RGBA 像素无法经生产解码输入。合成 loop/static 角色 alias 与重复同一实体 ID 不来自原盘投影，移出常规专测。
- 原 `pal-assets.glm-o` 与 `pal-assets-materialize.kimi-r1` 的资产目录、作者接管、重复 ID、路径、哈希、物化纪元和真实文件系统边界归各职责专测。零内容生成条目、目录与报告以实际前置校验和文件字节为 oracle。
- Content 使用/装备与资源池测试移至现行可观察入口。已证实重复的拒绝、旧素材标签和快照收敛。真实用例仍覆盖使用同种装备、扣除库存中的角色选项、空库存与有效库存隔离、己方全体、解毒仅清对应毒、奖励半恢复及六次非等级 RNG。
- 旧投影视觉身份、通用供给工具、CLI、提示来源和伤亡文案测试的逐条入口和数据在对应 A–H 表。固定旧提交是历史逐例和旧导入的恢复入口。

## 读取边界与剩余风险

原盘 SDLPal 原始位、角色图与战后成长依据 `reference/sdlpal/map.c`、`global.c`、`script.c`、`text.c` 的相关函数。提取器地图 U32、Shared 格式、当前 phase2 援引与生产输入对应逐文件 A–H 表中的调用。实际 PAL 二进制由受保护的源取得，不向仓库重复加入原盘。

未经裁决的正式反例只放执行证据：`map-word-domain-red` 和 `sprite-layout-order-red`；复验时复制同名 TS 到隔离候选的 Migrate src，使用各自执行 JSON，运行后移除测试副本。旧商店扫描、部分 bake 失败、标签后缀和活跃夹具保留 review。用户要求等待的资产诊断仍按 #71 原卡。

`map-counter-evidence.json`、`preview-fbp-pixels.json` 与 `isolated-bake-byte-evidence.json` 提供针对性业务指标，不是视觉用户验收。静态或测试阶段有早期错误时，原执行与后继执行独立记录，不覆盖原件。
