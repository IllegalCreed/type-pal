import assert from 'node:assert/strict'
import { execFileSync } from 'node:child_process'
import { createHash } from 'node:crypto'
import { existsSync, readFileSync } from 'node:fs'
import { resolve } from 'node:path'
import { pathToFileURL } from 'node:url'

const root = process.cwd()
const from = (name) => import(pathToFileURL(resolve(root, 'scripts/coverage', name)))
const { auditScope } = await from('inventory.mjs')
const { adjustApprovedBaseline } = await from('approved-baseline-adjustments.mjs')
const { compareCoverage } = await from('metrics.mjs')
const { isApprovedTestRetirement } = await from('approved-test-retirements.mjs')
const gateFile = 'scripts/coverage/baseline.fast.json'
const baseRef = execFileSync('git', ['rev-parse', 'origin/main'], { encoding: 'utf8' }).trim()
const input = JSON.parse(execFileSync('git', ['show', baseRef + ':' + gateFile]))
const output = JSON.parse(readFileSync(gateFile))
assert.deepEqual(output.provider, input.provider)
assert.equal(output.schemaVersion, input.schemaVersion)
assert.equal(output.profile, input.profile)
const adjusted = await adjustApprovedBaseline(input, (path) => readFileSync(resolve(root,path)))
const comparison = compareCoverage(output, adjusted.baseline)
assert.deepEqual(comparison.regressions, [])
const scope = auditScope(output, input)
const testEntry = (snapshot, path) => Object.values(snapshot.packages)
  .flatMap((pkg) => pkg.fastTests.fileEntries)
  .find((entry) => entry.file === path)
const checked = []
for (const removal of scope.removals) {
  if (!existsSync(resolve(root, removal.value))) continue
  const fileSha256 = createHash('sha256').update(readFileSync(removal.value)).digest('hex')
  const previous = testEntry(input, removal.value)
  const current = testEntry(output, removal.value)
  assert.ok(isApprovedTestRetirement({ removal, previous, current, fileSha256 }), removal.value)
  checked.push(removal)
}
const inventory = Object.fromEntries(Object.entries(output.packages).map(([id,pkg]) => [id, { sources: pkg.sourceFileCount, fastTests: pkg.fastTests.testCount }]))
console.log(JSON.stringify({
  baseRef, semanticGate: 'Read-only preflight of the actual ratcheted payload; GitHub fast-coverage remains the runtime gate.',
  adjustment: adjusted.applied, scope, approvedRetirements: checked, comparison, inventory,
}, null, 2))
