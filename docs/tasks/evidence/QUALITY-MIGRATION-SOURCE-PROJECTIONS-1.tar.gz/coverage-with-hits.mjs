import { execFileSync } from 'node:child_process'
import { resolve } from 'node:path'
import { pathToFileURL } from 'node:url'
const { coveragePackages, coverageExcludes, testSelection } = await import(
  pathToFileURL(resolve('scripts/coverage/config.mjs'))
)
const [, , id, out, baselineTree] = process.argv
const pkg = coveragePackages.find(candidate => candidate.id === id)
if (!pkg || !out) throw new Error('Usage: coverage-package-probe <package> <output>')
const selected = testSelection(pkg, 'fast')
const launcher = baselineTree ? resolve('node_modules/.bin/vitest') : 'pnpm'
const prefix = baselineTree ? [] : ['--filter', pkg.name, 'exec', 'vitest']
execFileSync(launcher, [
  ...prefix, 'run',
  '--reporter=default', ...selected.args,
  ...selected.excludes.flatMap(pattern => ['--exclude', pattern]),
  '--coverage', '--coverage.provider=v8', '--coverage.reportsDirectory=' + out,
  '--coverage.reporter=text-summary', '--coverage.reporter=json', '--coverage.reporter=json-summary',
  ...pkg.include.flatMap(pattern => ['--coverage.include', pattern]),
  ...coverageExcludes.flatMap(pattern => ['--coverage.exclude', pattern]),
], {stdio:'inherit', cwd:baselineTree ? resolve(baselineTree, pkg.directory) : process.cwd(), env: {...process.env, TYPE_PAL_COVERAGE_PROFILE:'fast'}})
