from hashlib import sha256
from pathlib import Path
import json
import subprocess

p=Path('docs/phase-governance/document-locations.json')
before=p.read_bytes()
subprocess.run(['pnpm','exec','biome','format','--write',str(p)],check=True)
after=p.read_bytes()
assert json.loads(before)==json.loads(after)
print(json.dumps({'file':str(p),'equalJsonValue':True,'beforeSha256':sha256(before).hexdigest(),'afterSha256':sha256(after).hexdigest()}))
