from pathlib import Path
import json
import re
import sys

scratch = Path(__file__).resolve().parent
diagnostic_patterns = {
    'reactAct': re.compile(r'not wrapped in act\(|not configured to support act\(|warn(?:ing)?.*act\(', re.I),
    'testDiagnostics': re.compile(r'^.*?\bstderr\s*\|\s*\S', re.I),
    'reportedErrors': re.compile(r'##\[error\]|(?:\bError\s+TS\d+:)|\berror\s+format:|^\s*(?:ERROR|Unhandled (?:Error|Rejection))\s*[:|]'),
    'reportedWarnings': re.compile(r'##\[warning\]|(?:Deprecation|Experimental|Security|TimeoutOverflow)Warning:|(?:^|: )\s*Warning:\s|^\s*\[warn(?:ing)?\]\s', re.I),
    'reportedDetails': re.compile(r'\b[1-9]\d* errors? / \d+ warnings? / \d+ infos?\b|\b\d+ errors? / [1-9]\d* warnings? / \d+ infos?\b|\b\d+ errors? / \d+ warnings? / [1-9]\d* infos?\b'),
}
def matches(data):
    data = re.sub(r'\x1b\[[0-?]*[ -/]*[@-~]', '', data)
    return {
        name: [j for j,line in enumerate(data.splitlines(),1) if p.search(line)]
        for name,p in diagnostic_patterns.items()
    }
gates={}
for label in sys.argv[1:]:
    f=scratch/label
    run=json.loads((f/'execution.json').read_text())
    stdout=(f/'stdout').read_bytes()
    stderr=(f/'stderr').read_bytes()
    assert run['stdoutBytes']==len(stdout) and run['stderrBytes']==len(stderr), label
    findings=matches(stdout.decode('utf-8',errors='replace'))
    stderr_hits=matches(stderr.decode('utf-8',errors='replace'))
    gates[label]={
        'execution': label+'/execution.json',
        'stdoutDiagnosticLines':{k:len(x) for k,x in findings.items()},
        'stderrDiagnosticLines':{k:len(x) for k,x in stderr_hits.items()},
        'zero': run['exitCode']==0 and not stderr and not any(findings.values()),
        'stdoutCandidates': {k:x for k,x in findings.items() if x},
    }
(scratch/'diagnostics.json').write_text(json.dumps(gates,indent=2)+'\n')
print(json.dumps(gates,indent=2))
sys.exit(0 if all(x['zero'] for x in gates.values()) else 1)
