import { expect, test } from 'vitest'
import { auditAndConvertSourceMaps } from './project-map-audit.js'

const auditWord = (lower: number) =>
  auditAndConvertSourceMaps([
    {
      mapNum: 1,
      sourceJsonBytes: 100,
      source: {
        width: 1,
        height: 1,
        tileset: 'tileset/1.rle',
        cells: [[{ lower, upper: 0 }]],
      },
    },
  ])

test('refuses an extracted lower word outside the u32 domain before auditing the map', () => {
  expect(() => auditWord(0x1_0000_0000)).toThrow('tilemap.cells[0][0].lower')
})

test('keeps the largest u32 word and reports its residual bits', () => {
  const { maps, report } = auditWord(0xffff_ffff)
  expect(maps.get(1)?.layers[0]?.tiles[0]).toEqual([511])
  expect(report.residualWords).toEqual([
    { mapNum: 1, row: 0, col: 0, sub: 0, word: 0xffff_ffff, residualBits: 0xe000_c000 },
  ])
})
