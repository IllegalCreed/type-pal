from datetime import datetime, timezone
import json
from pathlib import Path
import shlex
import subprocess
import sys

label = sys.argv[1]
work = Path(__file__).resolve().parent / label
work.mkdir(exist_ok=False)
command = [arg.replace('{run}', str(work)) for arg in sys.argv[2:]]
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
started = datetime.now(timezone.utc).isoformat()
with (work/'stdout').open('wb') as stdout, (work/'stderr').open('wb') as stderr:
    result = subprocess.run(command,stdout=stdout,stderr=stderr)
finished = datetime.now(timezone.utc).isoformat()
report = {
    'command':shlex.join(command),'arguments':command,'cwd':str(Path.cwd()),'commit':head,
    'startedAt':started,'finishedAt':finished,
    'exitCode':result.returncode if result.returncode>=0 else None,
    'signal':-result.returncode if result.returncode<0 else None,
    'stdoutBytes':(work/'stdout').stat().st_size,'stderrBytes':(work/'stderr').stat().st_size,
}
(work/'execution.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report),flush=True)
sys.exit(result.returncode)
