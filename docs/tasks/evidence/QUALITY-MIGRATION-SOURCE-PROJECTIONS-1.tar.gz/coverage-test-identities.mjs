import { createHash } from 'node:crypto'
import { readFileSync, writeFileSync } from 'node:fs'
import { fileURLToPath } from 'node:url'
const scratch = fileURLToPath(new URL('.', import.meta.url))
const root = process.cwd()
const load = (path) => JSON.parse(readFileSync(path, 'utf8'))
const base = load(root + '/scripts/coverage/baseline.fast.json')
const digest = (s) => createHash('sha256').update(s).digest('hex')
const read = (dir) => {
  const entries = load(scratch + dir + '/identities.json')
    .map(({ name, file, projectName }) => {
      const path = file.replace(/^.*?\/(packages\/)/, '$1')
      return { path, identity: path + ' :: project ' + (projectName || 'root') + ' :: ' + name }
    }).sort((a, b) => a.identity.localeCompare(b.identity))
  const totals = new Map()
  for (const e of entries) totals.set(e.identity, (totals.get(e.identity) ?? 0) + 1)
  const seen = new Map()
  const byFile = new Map()
  for (const e of entries) {
    const previous = seen.get(e.identity) ?? 0
    const total = totals.get(e.identity)
    seen.set(e.identity, previous + 1)
    const name = total === 1 ? e.identity : e.identity + ' :: occurrence ' + (previous + 1) + '/' + total
    if (!byFile.has(e.path)) byFile.set(e.path, [])
    byFile.get(e.path).push(name)
  }
  return byFile
}
const changes = []
const approvals = []
for (const pkg of ['content', 'migrate']) {
  const original = read(pkg + '-base-identities')
  const candidate = read(pkg === 'migrate' ? 'migrate-final-identities' : 'content-test-identities')
  for (const old of base.packages[pkg].fastTests.fileEntries) {
    const orig = original.get(old.file)
    if (!orig || digest(JSON.stringify(orig)) !== old.identityDigest) {
      throw new Error('Base identities disagree: ' + JSON.stringify(old))
    }
  }
  for (const p of new Set([...original.keys(), ...candidate.keys()])) {
    const before = original.get(p) ?? []
    const after = candidate.get(p) ?? []
    const remove = before.filter((name) => !after.includes(name))
    const add = after.filter((name) => !before.includes(name))
    if (remove.length || add.length) changes.push({ file: p, old: before, new: after, removed: remove, added: add })
    if (after.length > 0 && before.length > after.length) {
      approvals.push({
        file: p,
        previous: before.length,
        current: after.length,
        previousIdentityDigest: digest(JSON.stringify(before)),
        currentIdentityDigest: digest(JSON.stringify(after)),
        fileSha256: digest(readFileSync(root + '/' + p)),
      })
    }
  }
}
writeFileSync(scratch + 'test-identity-mapping.json', JSON.stringify(changes, null, 2) + '\n')
writeFileSync(scratch + 'protected-test-retirements.json', JSON.stringify(approvals, null, 2) + '\n')
console.log(JSON.stringify(approvals,null,2))
