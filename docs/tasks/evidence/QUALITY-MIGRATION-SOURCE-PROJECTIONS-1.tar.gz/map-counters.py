from hashlib import sha256
from pathlib import Path
import json
import subprocess
import sys

work = Path(__file__).resolve().parent
source = Path('packages/migrate/src/project-map-converter.ts')
original = source.read_bytes()
needles = [
    ('utf8', "return Buffer.byteLength(formatProjectMap(map), 'utf8')",
     'return formatProjectMap(map).length',
     'src/project-map-audit.test.ts', '报告按可发布地图的 UTF-8 实际字节数累计'),
    ('second-row-order', 'const targetRow = row * 2 + sub',
     'const targetRow = row * 2 + (row === 0 ? sub : 1 - sub)',
     'src/project-map-converter.boundaries.test.ts', '两行逻辑格展开为四行半格，并保留输入和每格高度'),
]
sha = lambda data: sha256(data).hexdigest()
proof = []
for name, old, new, tests, target in needles:
    assert original.count(old.encode()) == 1
    assert source.read_bytes() == original
    mutant = original.replace(old.encode(), new.encode())
    command = ['pnpm','--filter','@type-pal/migrate','exec','vitest','run','--project','unit',
               '--reporter=default','--reporter=json','--outputFile.json={run}/native.json',tests]
    try:
        source.write_bytes(mutant)
        red = subprocess.run([sys.executable,str(work/'run.py'),'map-counter-'+name,*command])
    finally:
        assert source.read_bytes()==mutant
        source.write_bytes(original)
    assert red.returncode==1
    restored = subprocess.run([sys.executable,str(work/'run.py'),'map-restored-'+name,*command])
    assert restored.returncode==0
    assert source.read_bytes()==original
    def tests_from(label):
        report=json.loads((work/label/'native.json').read_text())
        return {f'{f["name"]} :: {t["fullName"]}': t for f in report['testResults'] for t in f['assertionResults']}
    failed=tests_from('map-counter-'+name)
    green=tests_from('map-restored-'+name)
    assert failed.keys()==green.keys()
    assert all(item['status']=='passed' for item in green.values())
    nonpassing=[item for item in failed.values() if item['status']!='passed']
    assert len(nonpassing)==1 and nonpassing[0]['title']==target and nonpassing[0]['status']=='failed'
    assert any('AssertionError' in m for m in nonpassing[0]['failureMessages'])
    proof.append({'id':name,'testFile':tests,'target':target,'sourceSha256':sha(original),
                  'mutantSha256':sha(mutant),'testSha256':sha(Path('packages/migrate',tests).read_bytes()),
                  'preservedIdentities':sorted(green),'restored':True})
(work/'map-counter-evidence.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n')
