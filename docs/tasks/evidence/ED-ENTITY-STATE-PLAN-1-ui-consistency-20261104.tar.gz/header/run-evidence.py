import subprocess,json,hashlib,datetime,pathlib,sys
root=pathlib.Path(__file__).resolve().parents[2]; out=pathlib.Path(__file__).parent
name=sys.argv[1]; cwd=root/sys.argv[2]; cmd=sys.argv[3:]
paths=set(subprocess.check_output(['git','diff','--name-only','afd5342b50bfb3a8457fc551e79778e754bdbbb9'],cwd=root,text=True).splitlines())|set(subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=root,text=True).splitlines())
paths=sorted(p for p in paths if p.startswith(('packages/editor/','scripts/script-governance/','docs/phase2/specs/')))
receipt={'actor':'/root/script_progress_ledger','cwd':str(cwd),'command':cmd,'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'candidateBase':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'node':subprocess.check_output(['node','--version'],text=True).strip(),'sourceHashes':{p:hashlib.sha256((root/p).read_bytes()).hexdigest() if (root/p).is_file() else None for p in paths}}
try:
 with (out/(name+'.log')).open('w') as log:r=subprocess.run(cmd,cwd=cwd,stdout=log,stderr=subprocess.STDOUT)
 receipt.update(exit=r.returncode,signal=-r.returncode if r.returncode<0 else None,spawnError=None)
except OSError as error:receipt.update(exit=None,signal=None,spawnError=str(error))
receipt['finishedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat()
(out/(name+'-execution.json')).write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'name':name,'exit':receipt['exit'],'spawnError':receipt['spawnError']}));sys.exit(0 if receipt['exit']==0 else 1)
