import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { writeFile } from 'node:fs/promises'
import { createRequire } from 'node:module'
import { join } from 'node:path'
import { homedir } from 'node:os'
import { pathToFileURL } from 'node:url'

const scratch = process.argv[2]
const repo = process.cwd()
const require = createRequire(join(repo, 'package.json'))
const { chromium } = require('playwright')
const root = join(repo, 'packages/reforge')
const { createServer } = await import(pathToFileURL(join(root,'node_modules/vite/dist/node/index.js')))
process.env.VITE_PROJECT_ID = 'pal'
const server = await createServer({
  root,
  cacheDir: join(scratch,'browser-probe-vite'),
  logLevel: 'warn',
  server: { host: '127.0.0.1', port: 27394, strictPort: true, hmr: false },
})
let browser
try {
  await server.listen()
  const { address, port } = server.httpServer.address()
  assert.equal(address, '127.0.0.1')
  browser = await chromium.launch({
    headless: true,
    executablePath: join(homedir(), 'Library/Caches/ms-playwright/chromium_headless_shell-1228/chrome-headless-shell-mac-arm64/chrome-headless-shell'),
  })
  const context = await browser.newContext({ viewport: { width: 1280, height: 800 } })
  try {
    const authorSaveRecord = {
      kind: 'type-pal-author-save',
      version: 1,
      operationId: 'cf448da8-601d-4c9c-bbdc-235b7d61d483',
      phase: 'committed',
      planHash: 'a'.repeat(64),
    }
    let authorStateRequests = 0
    await context.route('**/projects/pal/.type-pal/save-state.json', async (route) => {
      assert.equal(route.request().method(), 'GET')
      authorStateRequests++
      await route.fulfill({ json: authorSaveRecord })
    })
    const page = await context.newPage()
    const errors = []
    const warnings = []
    const requestsWithError = []
    page.on('response', (response) => { if (response.status() >= 400) requestsWithError.push({status:response.status(),url:response.url()}) })
    const inputs = []
    page.on('pageerror', (e)=>errors.push(e.message))
    page.on('console', (e) => {
      if (e.type() === 'error') errors.push({message:e.text(),url:e.location().url})
      if (e.type() === 'warning') warnings.push(e.text())
    })
    await page.addInitScript(() => {
      const data = { nativeCompletions: 0, released: 0, txn: null, release: null }
      const result = Object.getOwnPropertyDescriptor(IDBTransaction.prototype,'oncomplete')
      Object.defineProperty(IDBTransaction.prototype,'oncomplete',{
        ...result,
        set(listener){
          const keys = [...this.objectStoreNames].sort().join(',')
          if (this.mode!=='readwrite' || keys!=='meta,payload,thumb' || data.txn) {
            result.set.call(this, listener)
            return
          }
          data.txn = { database: this.db.name, stores: keys, mode: this.mode }
          result.set.call(this, (event)=>{
            data.nativeCompletions++
            data.release = () => {
              data.release = null
              data.released++
              listener.call(this, event)
            }
          })
        },
      })
      const probe = document.createElement('canvas')
      probe.width = 78*4
      probe.height = 18*4
      const pixels = probe.getContext('2d',{willReadFrequently:true})
      const header = () => {
        const screen = document.querySelector('#screen')
        pixels.drawImage(screen, 7*4, 3*4, probe.width, probe.height, 0, 0, probe.width, probe.height)
        const { data } = pixels.getImageData(0,0,probe.width,probe.height)
        const mask = []
        for (let i=0;i<data.length;i+=4)
          if (data[i]===247 && data[i+1]===231 && data[i+2]===109 && data[i+3]===255)
            mask.push(i/4)
        return mask
      }
      window.verifyProductionSaveBrowser = { data, header }
    })
    async function key(value) {
      inputs.push(value)
      await page.keyboard.down(value)
      await frames(3)
      await page.keyboard.up(value)
      await frames(2)
    }
    async function frames(total) {
      await page.evaluate(async (n) => {
        for (let i=0;i<n;i++) await new Promise(requestAnimationFrame)
      },total)
    }
    const title = () => page.evaluate(() => window.verifyProductionSaveBrowser.header())
    const checkReady = () => {
      const r = window.__tpObserve?.readRuntime()
      return r?.sceneId==='s030' && !r.menuActive && !r.dialogue &&
        !r.scriptRunning && !r.presentationBusy && !r.ditherActive && r.fadeBlack===0
    }
    await page.goto('http://127.0.0.1:'+port+'/?entry=new-game&scene=s030', {waitUntil:'domcontentloaded'})
    await page.waitForFunction(checkReady, null, {timeout:30_000})
    for (const value of ['Escape','ArrowUp','Enter','Enter']) await key(value)
    await page.waitForFunction(()=>window.verifyProductionSaveBrowser.header().length>100)
    const saveMask = await title()
    for (const value of ['ArrowDown','ArrowDown','Enter']) await key(value)
    await page.waitForFunction(()=>window.verifyProductionSaveBrowser.data.nativeCompletions===1, null, {timeout:15_000})
    for (const value of ['Escape','ArrowDown','Enter']) await key(value)
    await page.waitForFunction((saved)=>{
      const observed = window.verifyProductionSaveBrowser.header()
      return observed.length>100 && observed.join(',')!==saved.join(',')
    }, saveMask)
    const loadBefore = await title()
    const before = await page.evaluate(()=>{
      const { data }=window.verifyProductionSaveBrowser
      return {nativeCompletions:data.nativeCompletions, released:data.released, txn:data.txn}
    })
    assert.equal(before.released,0)
    await page.evaluate(()=>window.verifyProductionSaveBrowser.data.release())
    const read = await page.evaluate(async (dbName) => {
      const db = await new Promise((resolve,reject)=>{
        const req=indexedDB.open(dbName)
        req.onsuccess=()=>resolve(req.result)
        req.onerror=()=>reject(req.error)
      })
      try {
        return await new Promise((resolve,reject)=>{
          const req=db.transaction('meta','readonly').objectStore('meta').getAll()
          req.onsuccess=()=>resolve(req.result.map(m=>m.slotId))
          req.onerror=()=>reject(req.error)
        })
      } finally { db.close() }
    }, before.txn.database)
    await frames(12)
    const loadAfter = await title()
    const hash = (arr) => createHash('sha256').update(JSON.stringify(arr)).digest('hex')
    const record = {
      chromium: browser.version(), projectId:'pal', scene:'s030',
      inputs, native:before, slotsCommitted:read,
      loadTitleMatchesAfterRelease: hash(loadBefore)===hash(loadAfter),
      pixels:{ save:{count:saveMask.length,sha256:hash(saveMask)}, loadBefore:{count:loadBefore.length,sha256:hash(loadBefore)}, loadAfter:{count:loadAfter.length,sha256:hash(loadAfter)} },
      errors,warnings,requestsWithError,authorSaveRecord,authorStateRequests,
    }
    await writeFile(join(scratch,'browser-save-proof.json'),JSON.stringify(record,null,2)+'\n')
    console.log(JSON.stringify(record))
    assert.equal(authorStateRequests,2)
    assert.deepEqual(read,['m01'])
    assert.notEqual(hash(saveMask),hash(loadBefore))
    assert.equal(hash(loadAfter),hash(loadBefore),'the actual load title must remain painted after completion')
    assert.deepEqual(errors,[])
    assert.deepEqual(warnings,[])
    assert.deepEqual(requestsWithError,[])
  } finally { await context.close() }
} finally {
  await browser?.close()
  await server.close()
}
