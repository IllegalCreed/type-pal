# 跨场景预览候选回执

Owner: /root/ui_affordances。基点72a60aaaf，隔离分支codex/cross-scene-preview；最终候选、逐文件SHA、净字节与原件校验见manifest.json。只改5个产品文件、7个真实caller测试及现行architecture；未改App、Reforge运行器/scene-transition实现、schema/save或PAL输入。root拥有卡/board/中央文档与实页裁定。

## 合同与边界

Playback拥有一次scratch world、活动scene、递增session及scene→entity overlay；起播只投影一次。资源宿主返回同步commit，load前后核AbortSignal和run身份；显式加载暂停需resume/step提交，普通step许可贯穿整条load。落点复用正式resolveSceneSpawn；无entry时宿主淡入，当前来源链收尾后runSceneHook读取scratch选择/cursor。presentation仅在running/paused显示现场，done/idle回入口投影；view保留完成诊断，但会话/待加载/计时/对话全部释放。PreviewCanvas只切资源与画布，保存/恢复起播前pan/zoom/轨迹视角，目标身份沿原DsTag，错误沿原preview-tip alert且Tag显示“预览中断”。

依据：DS-0、F.4/F.5（既有工具条/尺寸/图标）、I.4（不入Undo）、I.5（错误可见/返回/重试）、M.2–M.4（稳定画布/视口/身份与键盘）；正式main.ts loadScene及pendingOnEnter顺序、scene-transition默认/命名/临时落点；harvest W4/W5仅采用先准备后提交、旧结果失效的不变量，不复制一阶段调度。

范围限制：音乐/载具/战斗等既有日志桩、dither只模拟时长保持；没有完整游戏自动调度、存档或新增E2E信用。006只证s005/e116 legacy-001→s014及入场两段对白、隔离与恢复，不宣称渡船全演出复现。初态选用现有“渡海出发·登船前”，不串用目标hook独立绑定。源/目标定义、演员与侧车均只读。

## 逐文件A–H

路径均相对仓库；SHA见manifest。A为本轮完整代码阅读（未变大段也核职责）；architecture现行段全文及差异核读，固定quote复用前轮已接受全文证据，quote字节与基点一致。

- **core/playback.ts** — A: 全文及Workspace→Canvas真实链；B: 注释限定canonical切场与表现/诊断区分；C: 单次scratch与scene-session归控制器，资源IO经窄prepare返回commit；D: 复用ScriptProjectRuntime/runSceneHook、runtimeSceneView和正式spawn，不复制解释器；E: final149、recovery44、负控和006支持，既有控制合同保持；F: presentation/sceneSession/sceneCommitPaused明确区分作者、现场及显式暂停；G: 退休loadScene中止桩，释放每轮map/闭包/队列，仅保留末态诊断；H: 注入真实资源端口并用tick驱动时间，迟到resolve/reject可直接反证。大控制器保留统一时钟/队列Owner，未引入第二套调度器。
- **ui/PreviewCanvas.tsx** — A: 全文、scene-stage与Workspacecaller；B: 标注准备不提交与React帧交接边界；C: 原始props持作者场景，presentation持显示场景，资源仅源+当前目标两份，视角快照单一Owner；D: 共用prepareSceneAssets/renderer/DsToolbar/DsTag；E: 真实像素/资源旧回归、即时完成恢复与资源失败UI合同；F: displayScene/previewAssets/savedView表达职责；G: 不保留目标历史资源表，不新增CSS或导航；H: 真实Canvas像素及非零pan/zoom操作能拒绝遗漏恢复，错误入口可真实执行。
- **ui/scene-stage.ts** — A: 全文及SceneCanvas/PreviewCanvas加载消费者；B: 保留磁盘地图必须先读tilesetRefs的知识，prepare说明不改变画面；C: IO完整准备与React hook生命周期分离，alive仍防旧hook结果，AbortSignal防播放旧请求；D: 两消费者复用同一资源加载函数；E: 磁盘回退、SHA失效、source迟到与真实解码/像素旧回归通过；F: SceneAssetOptions/prepareSceneAssets清晰；G: 删除hook内重复加载块，无额外缓存或队列；H: 文件源/reader为现有窄IO口，loader错误可观测。
- **ui/SceneScriptWorkspace.tsx** — A: 全文，作者选择、详情返回、初态投影和stop生命周期；B: 原字段合同保持；C: 唯一差异传既有sceneIndex，不接收预览换场导航回调；D: 复用editorContext已有目录；E: 现有真实Session预览引用/返回/Undo两例与root实页；F: 显式sceneIndex接线；G: 无新状态/重复目录；H: 作者Owner不受Playback写入，真实会话用例可观察。
- **reforge/index.ts** — A: 全363行出口及scene-transition/main既有消费者；B: 现有barrel职责仍供editor复用；C: 只导出纯解析器，不导出主循环状态；D: 消除编辑器复制spawn规则的需要；E: reforge/editor typecheck及命名、临时、默认/继承方向真实播放用例；F: 使用原正式函数名；G: 一行导出，无实现修改；H: 从正式包出口调用验证，不做出口值镜像测试。
- **core/playback.scene-transition.test.ts** — A: 全文、当前typed fixture与真实PAL006数据；B: 用例名精确到切场/onEnter/回访/取消；C: 公共playCanonical/step/tick执行，prepare仅控制IO完成；D: 复用flowOf/settle及正式validator/projection；E: 7项分为正常step、回访状态/入口生命周期、加载暂停、迟到resolve/reject、失败恢复、真实006，最后结果均业务oracle；F: 场景/地址显式；G: 不增加CSS/类型镜像或重复单场景控制测试；H: 正式取消检查失效恰一AssertionError，6绿1红→7绿，源恢复哈希相同。
- **ui/PreviewCanvas.view-restoration.test.tsx** — A: 全文及真实Canvas harness；B: 标注React瞬时完成批处理风险；C: 调公开按钮/指针/滚轮和Playback，无产品核心mock；D: 复用既有合法工程、真实Canvas及IO fixtures；E: 非零pan/112%播放前后像素一致；真实目标资源缺失可见alert/中断且源可重试；F: 两例分别为视角恢复/错误反馈；G: 不堆几何镜像；H: 两例控制真实UI生命周期，错误输入只属于资源IO缺失边界。
- **core/playback.entities.test.ts** — A: 全文18例与poiPos caller；B: 旧终值镜头标题改为运行中跟随、结束/重置返回；C: 原overlay合同不变；D: 复用原fixture；E: 原有效owner跟随断言保留在wait期间，done改查入口presentation及poi清空；F: 标题匹配新用户规则；G: 数量不变、不删原运动断言；H: 真实tick结束与reset可观测。
- **core/playback.presentation.test.ts** — A: 全文7例、屏幕hold/reveal时钟；B: 旧“loadScene总结束”改为“缺目标明确失败”；C: 测试canonical缺定义错误边界；D: 原fixture和现有finalizer复用；E: 保留清hold/跳过尾命令，正常切场转新7例；F: 失败原因精确；G: 数量不变；H: 公开入口，错误非伪造内部状态。
- **core/playback.test.ts** — A: 全文12例及旧stages入口；B: 明确旧入口缺canonical定义会报错，不继续暗称所有切场都中止；C: 保留旧入口能力边界，不增加兼容切场分支；D: 原fixture；E: 原hold清理断言保持，新增精确error结果替换模糊日志包含；F: 标题与行为一致；G: 数量不变；H: 正式play公开caller。
- **ui/PreviewCanvas.test.tsx** — A: 全文4例及工具条委派/确认键盘/轨迹绘制；B: 原局部控件范围保持；C: 两个既有局部Playback替身补presentation读取协议，未冒充真实运行器；D: 复用原夹具；E: 控件契约4例保持，真实画布新合同另由无核心mock用例承担；F: getter表达同一view；G: 只补缺少的协议，不新增mock层；H: DOM键盘/动作仍可观察，不能据此授资源加载信用。
- **ui/PreviewCanvas.glm-ui-wave.test.tsx** — A: 全文4例；B: 原委派/URL/对话合同范围保持；C: 替身同一presentation协议，真实canonical首步例不mock运行器；D: 原合法工程复用；E: playback.play显式paused=false参数同步，其他暂停/恢复/reset断言保持；F: 既有历史名不因本轮窄修批量改名；G: 数量不变；H: 局部委派与真实canonical首步信用分开。
- **editor-architecture.md** — A: 现行正文全文及固定quote字节等值；B: 替换已退役“切场停止”条款，明确载具/声音/dither边界；C: 规范只维护行为与Owner，执行事实归本回执/根卡；D: 引用DS/现行E2E入口；E: 对照实现、真实006/取消/视角oracle，未写全游戏已完成；F: 区分作者选择、活动画布及诊断末态；G: 原段承接不新增平行规范；H: 每项可由已列调用/反例检查，中央文档门由root收口。

## 执行、反控与复验

环境Node v22.23.2 / pnpm10.29.2 / Vitest4.1.7；cwd均为本隔离树。`execution.json`保存final149时13文件SHA、原命令、UTC时段、exit0；`final.json/raw`为22文件149/149、零skip、显式default reporter无warning/error输出。之后仅错误Tag和其真实UI回归变更，由`error-status.json/raw`2/2与`typecheck-error-status.raw`覆盖，故最终独立用例总数150（149集合加1，不能将重跑次数相加）。最终源码见manifest，不把前一轮文件SHA冒充末轮。

最终静态：editor typecheck、reforge typecheck、目标Biome12文件、DS门103文件/2既有evidence-bound exceptions均exit0、零诊断；未改门/规则/豁免。`biome-check.raw`与后继`error-status-biome.raw`合并覆盖最终12代码文件；后者仅格式化两文件且零诊断。diff/check及暂存check另见manifest执行结果。无全仓门重复，根独立接收后集中运行。

负控`counter.json`记录源码/测试/mutant SHA、精确命令/时段/exit/signal/spawn。`mutant.patch`仅删除load请求assertCurrent的AbortSignal和代际核验；`mutant.json/raw`恰7项中6绿1个指定AssertionError：旧resolve竟提交资源(staleCommit=true)。finally按原字节恢复；`recovery.json/raw`44/44，counter source/restored SHA一致。迟到reject与新会话dialog/mode亦保持。没有修改规则、跳过用例或制造收集错误。

初始`before.json/raw`保留旧源码loadScene中止导致paused断言失败的事实；该最小新例后来增强为完整切场/目标dialog/恢复。其当时输入为本轮首个工具写入（未冻结Git），不把这份早期原件单独作为最终源码身份反控；最终有效反控以上述counter/patch为准。其他失败原件保留：typecheck-1（目标类型/scene名称）、typecheck-3（既有替身getter类型）、biome-1（key暂未消费）、core-1（旧done相机期望）、canvas-1（加载文案及委派参数旧预期）。恢复映射均在最终测试/静态，不覆写失败。

复验：核manifest所有成员SHA及候选Git diff；按需运行execution.json.command（最终集合含新增错误UI例，因此现将得到150项）或counter.json记录的四文件恢复命令。原件不代表用户最终接受、全仓静态或E2E覆盖。root实页截图/作者选择/geometry事实另由root提供，本回执不代签。

清理：本轮只有隔离分支、一个build证据目录及自有6012服务；负控文件原字节恢复，未建额外worktree/平行产品模块、未写PAL。成功中间执行暂留同目录用于原生时点追溯，不复制源码树；固定候选可由Git恢复，归档去重由root沿原任务接收后完成。无任务外资源清理。
