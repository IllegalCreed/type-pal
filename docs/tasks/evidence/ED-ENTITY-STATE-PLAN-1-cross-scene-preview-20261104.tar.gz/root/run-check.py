import datetime
import hashlib
import json
import pathlib
import subprocess
import sys

root = pathlib.Path.cwd()
out = root / 'build/cross-scene-preview'
name, command = sys.argv[1], sys.argv[2:]
paths = [
    'docs/tasks/board.md',
    'docs/tasks/cards/ED-ENTITY-STATE-PLAN-1.md',
    'docs/phase2/specs/editor-architecture.md',
    'docs/phase-governance/document-locations.json',
    'scripts/docs/document-location-admission.mjs',
]
paths += subprocess.check_output(
    ['git', 'diff', '--name-only', '72a60aaaf', '--', 'packages/editor', 'packages/reforge'],
    text=True,
).splitlines()

def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

record = {
    'actor': '/root',
    'cwd': str(root),
    'command': command,
    'startedAt': now(),
    'candidate': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
    'sourceHashes': {
        path: hashlib.sha256((root / path).read_bytes()).hexdigest()
        for path in dict.fromkeys(paths) if (root / path).is_file()
    },
}
with (out / (name + '.log')).open('w') as output:
    result = subprocess.run(command, stdout=output, stderr=subprocess.STDOUT)
record.update(exit=result.returncode, finishedAt=now())
(out / (name + '-execution.json')).write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({key: value for key, value in record.items() if key != 'sourceHashes'}))
sys.exit(result.returncode)
