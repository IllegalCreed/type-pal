import pathlib,gzip,json,hashlib,re,subprocess
root=pathlib.Path('/Users/zhangxu/.codex/worktrees/e2e-baseline-reconcile/type-pal')
base=root/'build/e2e-baseline-reconcile/editor-save-failure-20261104'
sha=lambda b:hashlib.sha256(b).hexdigest()
rows=json.loads((base/'ordinary-save-content-diff.json').read_bytes()); indexes={x['path']:x for x in rows}
patch=gzip.decompress((base/'ordinary-save-content.patch.gz').read_bytes()).decode()
assert '\\ No newline at end of file' not in patch
pieces=re.split(r'(?m)^diff --git ',patch)[1:]; findings=[]
for piece in pieces:
 lines=piece.splitlines(keepends=True); m=re.fullmatch(r'a/(.*?) b/(.*?)\n',lines[0]);assert m and m[1]==m[2];rel=m[1]
 before=(root/rel).read_bytes();assert sha(before)==indexes[rel]['beforeSHA256'],rel
 old=before.decode().splitlines(keepends=True);out=[];pos=0;i=1
 while i<len(lines):
  line=lines[i]
  if not line.startswith('@@ '):i+=1;continue
  h=re.match(r'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@',line);assert h,(rel,line)
  oldstart=int(h[1])-1;oldcount=int(h[2] or 1);newcount=int(h[4] or 1)
  assert oldstart>=pos,(rel,oldstart,pos)
  out+=old[pos:oldstart];pos=oldstart;i+=1;removed=0;added=0
  while i<len(lines) and not lines[i].startswith('@@ '):
   l=lines[i];assert l[0] in ' +-',(rel,l[:100])
   if l[0] in ' -': assert old[pos]==l[1:],(rel,pos,old[pos],l);pos+=1;removed+=1
   if l[0] in ' +':out.append(l[1:]);added+=1
   i+=1
  assert (removed,added)==(oldcount,newcount),(rel,removed,added,oldcount,newcount)
 out+=old[pos:];after=''.join(out).encode();assert sha(after)==indexes[rel]['afterSHA256'],rel
 a=json.loads(before);b=json.loads(after);equal=a==b; assert equal==indexes[rel]['equalAsJSON'],rel
 result={'path':rel,'beforeSha256':sha(before),'afterSha256':sha(after),'deepEqualJSON':equal}
 if not equal:
  assert rel=='projects/pal/content/skills.json'
  ak=a['skills'];bk=b['skills']; am={str(x['id']):x for x in ak};bm={str(x['id']):x for x in bk};assert len(am)==len(ak) and len(bm)==len(bk)
  assert {k:v for k,v in a.items() if k!='skills'}=={k:v for k,v in b.items() if k!='skills'}
  assert am==bm
  result.update(uniqueIdCount=len(am),equalByUniqueId=True,nonSkillFieldsEqual=True)
 findings.append(result)
assert len(findings)==296 and len(findings)==len(indexes)
report={'scope':'Read-only reconstruction of native ordinary Save diff against restored current bytes, no repository writes.','patchSha256':sha((base/'ordinary-save-content.patch.gz').read_bytes()),'files':len(findings),'deepEqualJSON':sum(x['deepEqualJSON'] for x in findings),'remainingByUniqueId':[x for x in findings if not x['deepEqualJSON']],'currentContentGitDiff':subprocess.check_output(['git','diff','--name-only','HEAD','--','projects/pal/content'],cwd=root,text=True).splitlines(),'allNativeBeforeAndAfterSHA256Match':True}
path=pathlib.Path('/tmp/type-pal-review-save-content-patch.json');path.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n'); print(path);print(json.dumps(report,ensure_ascii=False,indent=2))
