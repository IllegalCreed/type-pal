import fs from 'node:fs'
import path from 'node:path'
import { execFileSync } from 'node:child_process'
import { byteHash, entryKey, inventoryScenes, previewFingerprint, validateLedger } from '/Users/zhangxu/.codex/worktrees/e2e-baseline-reconcile/type-pal/scripts/script-governance/progress.mjs'
const root='/Users/zhangxu/.codex/worktrees/e2e-baseline-reconcile/type-pal'
const originalRoot='/Users/zhangxu/illegal/type-pal'
const at=new Date().toISOString(), candidateBytes=fs.readFileSync('/tmp/type-pal-preview-candidate.json'), candidate=JSON.parse(candidateBytes)
const library=JSON.parse(fs.readFileSync(path.join(root,'projects/pal/editor/script-preview.json')))
const index=JSON.parse(fs.readFileSync(path.join(root,'projects/pal/content/scenes/index.json')))
const scenes=index.scenes.map(s=>JSON.parse(fs.readFileSync(path.join(root,'projects/pal',s.path))))
const inventory=inventoryScenes(scenes), hashes=new Map(), rawIndex=[], events=[], contexts=[]
const hashFile=p=>{if(!hashes.has(p))hashes.set(p,byteHash(fs.readFileSync(p)));return hashes.get(p)}
const dep=p=>({path:p,sha256:hashFile(path.join(root,p))})
const actor='Codex /root/e2e_baseline_docs (read-only evidence assembly)'
const common=[
 'packages/reforge/src/main.ts','packages/reforge/src/script-runner-core.ts','packages/reforge/src/runtime-script-project.ts',
 'packages/reforge/src/script-project-core.ts','packages/reforge/src/entity-lifecycle.ts','packages/reforge/src/project-loader.ts',
 'scripts/e2e/script-causal-observer.mjs','scripts/e2e/opening-causal-instrumentation.mjs','scripts/e2e/opening-trace-plugin.mjs',
 'packages/editor/src/core/script-preview-library.ts','projects/pal/content/actors.json','projects/pal/content/sprites.json',
]
const additional={
 '001':['scripts/e2e/opening-matrix-observer.mjs'],
 '002':['scripts/e2e/inn-observer.mjs','scripts/e2e/inn-trace-plugin.mjs','scripts/e2e/reforge-actor-observation.mjs'],
 '003':['scripts/e2e/kitchen-observer.mjs','scripts/e2e/kitchen-trace-plugin.mjs','scripts/e2e/inn-trace-plugin.mjs','scripts/e2e/reforge-actor-observation.mjs'],
 '004':['scripts/e2e/meal-observer.mjs','scripts/e2e/meal-trace-plugin.mjs','scripts/e2e/kitchen-trace-plugin.mjs','scripts/e2e/inn-trace-plugin.mjs','scripts/e2e/reforge-actor-observation.mjs','projects/pal/content/items.json'],
 '005':['scripts/e2e/errand-observer.mjs','scripts/e2e/errand-trace-plugin.mjs','scripts/e2e/meal-trace-plugin.mjs','scripts/e2e/kitchen-trace-plugin.mjs','scripts/e2e/inn-trace-plugin.mjs','scripts/e2e/reforge-actor-observation.mjs','projects/pal/content/items.json'],
}
const bySource=new Map()
for(const suffix of ['001','002','003','004-story','005-story']){const d=JSON.parse(fs.readFileSync(`/tmp/type-pal-preview-prestates-current-${suffix}.json`));bySource.set(d.input,d)}
for(const [source,doc]of bySource){
 const reportPath=path.posix.join(path.posix.dirname(source),'report.json'), report=JSON.parse(fs.readFileSync(path.join(root,reportPath)))
 rawIndex.push({kind:'current-native-source',source,sha256:hashFile(path.join(root,source)),report:reportPath,reportSha256:hashFile(path.join(root,reportPath)),revision:report.revision,status:report.status,errors:report.errors,sourceNativeErrors:doc.nativeErrors,overflow:doc.nativeOverflow})
}
for(const row of candidate.rows){
 const doc=bySource.get(row.source), e=doc.entries.find(e=>e.order===row.order)
 if(!e)throw new Error(`missing receipt ${row.source}:${row.order}`)
 const a=e.address, entry=row.entry
 if(JSON.stringify([a.scene,a.entity??null,a.slot,a.variant,a.step])!==entryKey(entry))throw new Error('entry mismatch')
 const key=[entry.sceneId,entry.entityId??'scene',entry.channel,entry.schemeId,entry.stageId].join('/')
 const run=path.posix.basename(path.posix.dirname(row.source))
 const context={id:`${run}:v${e.sceneVisit}:run${e.runId}:command${e.order}`,description:`E2E ${row.fragment}; ${key}; native ${row.source}; sceneVisit=${e.sceneVisit}; sceneSession=${e.root.author.sceneSession}; runId=${e.runId}; firstCommandOrder=${e.order}; path=${JSON.stringify(e.firstCommandPath)}; resumeAtRunStart=${JSON.stringify(e.root.resume)}.`}
 const prefix=Number(row.fragment)>=5?['s000','s001','s003','s004','s005']:Number(row.fragment)>=2?['s000','s001','s003']:['s000','s001']
 const deps=[...new Set([...common,...additional[row.fragment],...[...new Set([...prefix,...row.externalTargets.map(t=>t.scene)])].map(s=>`projects/pal/content/scenes/${s}.json`)])].sort().map(dep)
 const reportPath=path.posix.join(path.posix.dirname(row.source),'report.json')
 const missing=row.missing.length>0, limitations=['只记录实际执行前静态NPC显示字段证据；未授脚本审查、优化、UI配置/保存/重开/播放/重置完成信用。',row.externalTargets.length?`跨场景目标 ${row.externalTargets.map(t=>`${t.scene}/${t.entity}`).join(', ')} 没有在本场景获得可视预览验收；依赖含前驱场景与明确跨场景来源。`:'',missing?`缺口：${row.missing.join(', ')} 无本入口真实pose，保持unreviewed；不能用静态默认补造。`:'',row.candidateStateId?`候选状态 ${row.candidateStateId} 只作组装定位，不是已保存证明。`:'该投影相对已观察NPC的runtime默认无差异；仍未授逐入口UI验收。'].filter(Boolean).join(' ')
 events.push({id:`e2e${row.fragment}-initial-${run}-v${e.sceneVisit}-r${e.runId}-o${e.order}`,at,actor,entry,context,axis:'initialState',from:'unreviewed',to:missing?'unreviewed':'evidence-collected',sourceFingerprint:inventory.get(entryKey(entry)).sourceFingerprint,dependencies:deps,evidence:[{path:row.source,sha256:hashFile(path.join(root,row.source)),selector:`causes: phase=command, runId=${e.runId}, order=${e.order}, sceneVisit=${e.sceneVisit}, first path=${JSON.stringify(e.firstCommandPath)}; author=${JSON.stringify(e.root.author)}; resume=${JSON.stringify(e.root.resume)}; read poses/world before command`},{path:reportPath,sha256:hashFile(path.join(root,reportPath)),selector:'status; revision; hashes; storyScope; sourceHashesStable when present'}],note:limitations})
 contexts.push({eventId:events.at(-1).id,fragment:row.fragment,entry,context,raw:row.source,order:e.order,runStartedOrder:e.runStartedOrder,sceneVisit:e.sceneVisit,runId:e.runId,firstCommandPath:e.firstCommandPath,sceneSession:e.root.author.sceneSession,resume:e.root.resume,candidateStateId:row.candidateStateId,missing:row.missing,externalTargets:row.externalTargets})
}
const archivePath='build/evidence-archive/e2e006-20261027/e2e006-20261027.tar.gz'
const technicalPath='build/evidence-archive/e2e006-technical-20261027/technical-closeout.tar.gz'
const archivePhysical=path.join(root,archivePath), technicalPhysical=path.join(originalRoot,technicalPath)
const member=(archive,name)=>execFileSync('tar',['-xOf',archive,name],{maxBuffer:10*1024*1024})
const oldLibraryBytes=member(archivePhysical,'delivery/script-preview-current.json'),oldLibrary=JSON.parse(oldLibraryBytes)
const uiBytes=member(archivePhysical,'delivery/preview-save-reopen/observations.json'),ui=JSON.parse(uiBytes)
const audit=JSON.parse(member(archivePhysical,'delivery/preview-current-audit.json'))
const verdictBytes=member(technicalPhysical,'independent/006-initial/verdict.json'),verdict=JSON.parse(verdictBytes)
const closureBytes=member(technicalPhysical,'independent/006-C1/verdict.json')
const oldNative=JSON.parse(fs.readFileSync('/tmp/type-pal-preview-prestates-archive-006.json'))
const baseline='dccd4095fff93626f16c68f8d4aca3627ff6e8e7'
const stableConsumers=['packages/editor/src/core/script-preview-library.ts','packages/editor/src/core/script-flow-preview.ts','packages/editor/src/ui/SceneScriptWorkspace.tsx','packages/editor/src/ui/SceneInitialStateEditor.tsx']
for(const p of stableConsumers)if(!execFileSync('git',['show',`${baseline}:${p}`],{cwd:root}).equals(fs.readFileSync(path.join(root,p))))throw new Error(`old consumer changed ${p}`)
const six=[]
for(const b of library.bindings.filter(b=>b.stateId.startsWith('e2e006-'))){
 const entry=b.entry, previous=oldLibrary.bindings.find(x=>entryKey(x.entry)===entryKey(entry))
 const state=library.states.find(s=>s.id===b.stateId),oldState=oldLibrary.states.find(s=>s.id===b.stateId)
 if(JSON.stringify(previous)!==JSON.stringify(b)||JSON.stringify(state)!==JSON.stringify(oldState))throw new Error('006 state/binding drift')
 const auditRow=audit.rows.find(x=>entryKey(x.entry)===entryKey(entry)),e=oldNative.entries.find(x=>x.runStartedOrder===auditRow.order)
 const key=[entry.sceneId,...(entry.entityId?[entry.entityId]:[]),entry.channel,entry.schemeId,entry.stageId].join('/'),uiIndex=ui.findIndex(x=>x.entry===key),u=ui[uiIndex]
 if(!u||!u.before.includes('本地项目')||!u.before.includes(state.name)||!u.running.includes('播放中')||!u.after.includes('text 就绪'))throw new Error(`missing actual UI receipt ${key}`)
 const poses={...e.prestate.observedActors,...e.prestate.poses},diffs=[]
 for(const obj of state.entities){const p=poses[obj.entityId].state,expect={pos:{col:p.position[0],row:p.position[1],height:p.position[2]},facing:p.facing,hidden:!p.visible,collide:!!(p.visible&&p.state>=2)};for(const[k,v]of Object.entries(expect))if(JSON.stringify(obj[k])!==JSON.stringify(v))diffs.push({entity:obj.entityId,field:k,saved:obj[k],firstCommand:v})}
 const sourcePath=`projects/pal/content/scenes/${entry.sceneId}.json`,oldScene=JSON.parse(execFileSync('git',['show',`${baseline}:${sourcePath}`],{cwd:root})),oldFp=inventoryScenes([oldScene]).get(entryKey(entry)).sourceFingerprint,newFp=inventory.get(entryKey(entry)).sourceFingerprint
 if(oldFp!==newFp)throw new Error(`006 canonical source changed ${key}`)
 const context={id:`e2e006-20261027-reused:${key}:v${e.sceneVisit}:r${e.runId}:o${e.order}`,description:`历史独立接受的006静态预览现场；native=${oldNative.archiveMember}; sceneVisit=${e.sceneVisit}; sceneSession=${e.root.author.sceneSession}; runId=${e.runId}; firstCommandOrder=${e.order}; originalAuditRunStartedOrder=${auditRow.order}; UI File/Open/Play/Reset at ${u.at}; 不代表2026-11-04新run现场或新保存操作。`}
 const sixEvent={id:`e2e006-initial-reuse-${entry.sceneId}-${entry.entityId??'scene'}-${entry.channel}-${entry.schemeId}-${entry.stageId}`,at,actor,entry,context,axis:'initialState',from:'unreviewed',to:diffs.length?'evidence-collected':'verified',sourceFingerprint:newFp,dependencies:[...new Set([...stableConsumers,sourcePath,'projects/pal/content/actors.json','projects/pal/content/sprites.json'])].sort().map(dep),evidence:[{path:archivePath,sha256:hashFile(archivePhysical),selector:`member=delivery/preview-save-reopen/observations.json sha256=${byteHash(uiBytes)}; index=${uiIndex}; entry=${key}; before/running/after; original raw member=${oldNative.archiveMember}; firstCommandOrder=${e.order}, runStartedOrder=${auditRow.order}; saved state member=delivery/script-preview-current.json sha256=${byteHash(oldLibraryBytes)}`},{path:technicalPath,sha256:hashFile(technicalPhysical),selector:`member=independent/006-initial/verdict.json sha256=${byteHash(verdictBytes)}; acceptedBoundaries area=Preview static NPC projection; reviewer=${verdict.reviewer}; member=independent/006-C1/verdict.json sha256=${byteHash(closureBytes)} preserves prior accepted scope`}],note:diffs.length?`原UI/技术接受及船体视觉判断完整保留，但旧audit取run-started；真正首命令前态有差异 ${JSON.stringify(diffs)}。本事件仅evidence-collected，需核此时点的静态初态，不重开船体视觉。`:'承接逐地址旧静态NPC初态独立接受：原另存后File/Open、Play/Reset均有原始UI收据；保留10/11配置逐值不变，当前所属scene结构指纹与已接受dccd相等，四预览消费者字节相同；旧run-started与其真正首命令NPC投影相等。仅承接此历史context及静态显示范围，不授本轮Save、完整世界恢复、脚本审查或优化信用。'}
 if(!diffs.length){sixEvent.reviewer=verdict.reviewer+' (2026-10-27 acceptance reused)';sixEvent.preview={stateId:b.stateId,selection:'default'};sixEvent.previewFingerprint=previewFingerprint(entry,sixEvent.preview,library)}
 events.push(sixEvent);six.push({eventId:sixEvent.id,entry,stateId:b.stateId,recommended:sixEvent.to,oldUiIndex:uiIndex,oldUiAt:u.at,runStartedOrder:auditRow.order,firstCommandOrder:e.order,differences:diffs,canonicalSemanticSame:true,previewConsumersByteSame:true,stateAndBindingSame:true})
}
const ledger={kind:'type-pal-script-progress',version:1,project:'pal',scope:'scene-hooks-and-entity-behavior-steps',events}
validateLedger(ledger)
fs.writeFileSync('/tmp/type-pal-progress-seed-events.json',JSON.stringify(ledger,null,2)+'\n')
const raw={createdAt:at,root,candidateSha256:byteHash(candidateBytes),ledgerFile:'type-pal-progress-seed-events.json',counts:{currentContexts:candidate.rows.length,currentEvidenceCollected:events.filter(e=>e.id.startsWith('e2e0')&&!e.id.startsWith('e2e006')&&e.to==='evidence-collected').length,currentUnreviewed:events.filter(e=>e.to==='unreviewed').length,historical006Verified:six.filter(x=>x.recommended==='verified').length,historical006EvidenceCollected:six.filter(x=>x.recommended==='evidence-collected').length},currentRawSources:rawIndex,currentContexts:contexts,historical006:six,oldArchives:[{path:archivePath,sha256:hashFile(archivePhysical),physicalPath:archivePhysical},{path:technicalPath,sha256:hashFile(technicalPhysical),physicalPath:technicalPhysical,presentInRoot:fs.existsSync(path.join(root,technicalPath))}],limits:['Seed is an append proposal, not repository state. Root adds actual save/UI progress and archives current raw evidence.','Current raw paths must be rewritten to the root-owned archive SHA/member selectors after archival; do not change native bytes.','Historical technical archive currently resolves at originalRoot; restore/link its canonical path before --check or retain explicit missing status.','No review or optimization completion events are supplied.','006 e117 has a precise run-started versus first-command discrepancy; old bounded acceptance and user boat visual judgement are retained.']}
fs.writeFileSync('/tmp/type-pal-progress-seed-raw-index.json',JSON.stringify(raw,null,2)+'\n')
console.log(JSON.stringify({at,events:events.length,...raw.counts,seedSha256:hashFile('/tmp/type-pal-progress-seed-events.json'),historical006:six.map(x=>({entry:x.entry,status:x.recommended}))},null,2))
