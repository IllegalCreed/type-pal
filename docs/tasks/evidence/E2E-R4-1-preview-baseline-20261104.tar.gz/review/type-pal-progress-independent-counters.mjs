import fs from 'node:fs/promises'
import { execFileSync } from 'node:child_process'
import {
 byteHash, entryKey, inventoryScenes, previewFingerprint, reportProgress, validateLedger
} from '/Users/zhangxu/.codex/worktrees/script-progress-ledger/type-pal/scripts/script-governance/progress.mjs'
const root='/Users/zhangxu/.codex/worktrees/script-progress-ledger/type-pal'
const scene=JSON.parse(await fs.readFile(`${root}/projects/pal/content/scenes/s001.json`,'utf8'))
const diskLibrary=JSON.parse(await fs.readFile(`${root}/projects/pal/editor/script-preview.json`,'utf8'))
const entry={sceneId:'s001',entityId:'e10',channel:'auto',schemeId:'leave-bedroom',stageId:'leave'}
const sourceFingerprint=inventoryScenes([scene]).get(entryKey(entry)).sourceFingerprint
const depPath='packages/reforge/src/script-runner-core.ts'
const depBytes=await fs.readFile(`${root}/${depPath}`)
const evidenceBytes=Buffer.from('Independent negative scenario; not a runtime or UI completion claim.\n')
const evidence={path:'review-fixture.txt',sha256:byteHash(evidenceBytes),selector:'counter scenario only'}
const readReference=async r=>r.path===depPath?depBytes:r.path===evidence.path?evidenceBytes:null
const base={at:'2026-11-04T01:00:00Z',actor:'negative-fixture-author',reviewer:'independent-fixture-reviewer',entry,context:{id:'first-departure',description:'run A: first visit after foreground release'},axis:'review',from:'unreviewed',to:'verified',sourceFingerprint,dependencies:[{path:depPath,sha256:byteHash(depBytes)}],evidence:[evidence],note:'Fixture to exercise declared context identity only.'}
const ledger=events=>({kind:'type-pal-script-progress',version:1,project:'pal',scope:'scene-hooks-and-entity-behavior-steps',events})
const uiLibrary=structuredClone(diskLibrary)
const state={id:'negative-fixture-ui-only',sceneId:'s001',name:'UI-only configured state, not yet saved',entities:[{entityId:'e10',pos:{col:60,row:-12.875,height:0},facing:'down',hidden:false,collide:true}]}
uiLibrary.states.push(state)
uiLibrary.bindings.push({entry,stateId:state.id})
const preview={stateId:state.id,selection:'default'}
const configured={...base,id:'configured-ui-only',axis:'initialState',to:'configured',reviewer:undefined,preview,previewFingerprint:previewFingerprint(entry,preview,uiLibrary),note:'Configured in UI; disk save has not succeeded.'}
const mixed=ledger([
 {...base,id:'review-run-a'},
 {...configured,id:'state-run-b',at:'2026-11-04T01:00:01Z',to:'verified',reviewer:'independent-fixture-reviewer',context:{id:'first-departure',description:'run B: different revisit and different first-command receipt'}},
])
validateLedger(mixed)
const mixedResult=await reportProgress({scenes:[scene],library:uiLibrary,ledger:mixed,readReference})
const mixedRow=mixedResult.rows.find(r=>entryKey(r.entry)===entryKey(entry))
const unsavedResult=await reportProgress({scenes:[scene],library:diskLibrary,ledger:ledger([configured]),readReference})
const unsavedRow=unsavedResult.rows.find(r=>entryKey(r.entry)===entryKey(entry))
const result={candidate:execFileSync('git',['rev-parse','HEAD'],{cwd:root,encoding:'utf8'}).trim(),scope:'Two independent negative scenarios only; no repository edits, no full test-suite rerun, no UI/runtime acceptance.',contextMismatch:{validatorAccepted:true,inputContexts:mixed.events.map(e=>e.context),reportedContext:mixedRow.context,statuses:mixedRow.statuses},configuredButUnsaved:{inputRecorded:'configured',stateExistsInUiCandidate:true,stateExistsOnDisk:diskLibrary.states.some(s=>s.id===state.id),status:unsavedRow.statuses.initialState}}
await fs.writeFile('/tmp/type-pal-progress-independent-counters.json',JSON.stringify(result,null,2)+'\n')
console.log(JSON.stringify(result,null,2))
