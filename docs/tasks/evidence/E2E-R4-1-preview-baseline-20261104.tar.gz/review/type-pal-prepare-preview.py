import json, pathlib
root=pathlib.Path('/Users/zhangxu/.codex/worktrees/e2e-baseline-reconcile/type-pal')
lib=json.loads((root/'projects/pal/editor/script-preview.json').read_text())
runtime={s['id']:s for s in json.load(open('/tmp/type-pal-runtime-scenes.json'))}
inputs=['001','002','003','004-story','005-story']
rows=[]; states=[];bindings=[];seen=set()
for no in inputs:
 p=pathlib.Path('/tmp/type-pal-preview-prestates-current-'+no+'.json')
 if not p.exists():continue
 doc=json.loads(p.read_text())
 for e in doc['entries']:
  a=e['address']
  if not a.get('kind') or e['root'].get('resume'): continue
  key=(a['scene'],a.get('entity'),a['slot'],a['variant'],a['step'])
  contextkey=(no,*key)
  if contextkey in seen:continue
  seen.add(contextkey)
  scene=json.loads((root/f"projects/pal/content/scenes/{a['scene']}.json").read_text())
  defs={x['id']:x for x in scene['entities']}
  target_ids={t['entity'] for t in e['targets'] if t['scene']==a['scene']}
  # A scene's stage context includes every observed actor; missing unrelated actors are not invented.
  observed={**e['prestate']['observedActors'], **e['prestate']['poses']}
  missing=sorted(target_ids-observed.keys())
  relevant=set(observed)-{'party'}
  projected=[]
  for ident in sorted(relevant,key=lambda s:int(s[1:])):
   if ident not in defs:continue
   d=defs[ident]; live=observed[ident]['state']; pos=live['position']; st=live.get('state')
   r={'entityId':ident,'pos':dict(zip(['col','row','height'],pos)), 'facing':live['facing'],'hidden':not live['visible'], 'collide':live['visible'] and (st>=2 if st is not None else d.get('collide',False))}
   if d.get('zBias') is not None:r['zBias']=d['zBias']
   base=next(x for x in runtime[a['scene']]['entities'] if x['id']==ident)
   default={'entityId':ident,'pos':base['pos'],'facing':base.get('facing','down'),'hidden':base.get('hidden',False),'collide':not base.get('hidden',False) and base.get('collide',False)}
   if base.get('zBias') is not None:default['zBias']=base['zBias']
   if d.get('zone'):
    r.pop('facing',None); default.pop('facing',None)
   if r!=default:projected.append(r)
  entry={'sceneId':a['scene'],'channel':a['slot'],'schemeId':a['variant'],'stageId':a['step']}
  if a.get('entity'):entry['entityId']=a['entity']
  ident='e2e'+no[:3]+'-'+a['scene']+'-'+a.get('entity','scene')+'-'+a['slot']+'-'+a['variant']+'-'+a['step']
  label=defs.get(a.get('entity'),{}).get('label',a.get('entity',scene.get('name',a['scene'])))
  state={'id':ident,'sceneId':a['scene'],'name':f"{no[:3]} {label} · {a['slot']}/{a['variant']}/{a['step']}",'entities':projected}
  rows.append({'fragment':no[:3], 'entry':entry,'candidateStateId':ident if projected else None,'source':doc['input'],'order':e['order'],'missing':missing,'externalTargets':[t for t in e['targets'] if t['scene']!=a['scene']], 'root':e['root'],'actorCount':len(projected)})
  if projected and not missing:
   states.append(state);bindings.append({'entry':entry,'stateId':ident})
dedup={}; unique=[]; aliases={}
for state in states:
 key=json.dumps([state['sceneId'],state['entities']],sort_keys=True)
 if key in dedup:aliases[state['id']]=dedup[key]
 else:dedup[key]=state['id'];unique.append(state)
seenbind=set(); defaultbind=[]
for binding in bindings:
 binding['stateId']=aliases.get(binding['stateId'],binding['stateId'])
 key=json.dumps(binding['entry'],sort_keys=True)
 if key not in seenbind:defaultbind.append(binding);seenbind.add(key)
for row in rows:
 row['candidateStateId']=aliases.get(row['candidateStateId'],row['candidateStateId'])
json.dump({'states':unique,'bindings':defaultbind,'rows':rows},open('/tmp/type-pal-preview-candidate.json','w'),ensure_ascii=False,indent=2)
print(json.dumps({'states':len(states),'entries':len(rows),'missing':[r for r in rows if r['missing']]},ensure_ascii=False))
