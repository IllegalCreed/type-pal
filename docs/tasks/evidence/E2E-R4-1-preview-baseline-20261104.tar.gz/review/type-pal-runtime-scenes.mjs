import { readFile, writeFile } from 'node:fs/promises'
import { resolve } from 'node:path'
import { createHash } from 'node:crypto'
import { loadCurrentProjectFrom, loadAllScenes } from '/Users/zhangxu/.codex/worktrees/e2e-baseline-reconcile/type-pal/packages/reforge/src/project-loader.ts'
const projectRoot = '/Users/zhangxu/.codex/worktrees/e2e-baseline-reconcile/type-pal/projects/pal'
const read = async (rel) => {
  try { return await readFile(resolve(projectRoot, rel)) }
  catch (error) { if (error.code === 'ENOENT') throw new DOMException(rel, 'NotFoundError'); throw error }
}
const source = {
  readText: async rel => (await read(rel)).toString('utf8'),
  readJson: async rel => JSON.parse((await read(rel)).toString('utf8')),
  readBytes: async rel => new Uint8Array(await read(rel)).buffer,
  urlFor: async rel => new URL(rel, `file://${projectRoot}/`).href,
}
const project = await loadCurrentProjectFrom(source)
const scenes = await loadAllScenes(project)
await writeFile('/tmp/type-pal-runtime-scenes.json', JSON.stringify(scenes))
