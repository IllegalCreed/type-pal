import fs from 'node:fs'
import { execFileSync } from 'node:child_process'
import { createSnapshotGraph } from '/Users/zhangxu/.codex/worktrees/e2e-baseline-reconcile/type-pal/scripts/e2e/snapshot-graph.mjs'

const [input, output, archiveMember] = process.argv.slice(2)
if (!input || !output) throw new Error('usage: input-file-or-tar output-json [archive-member]')
const bytes = archiveMember ? execFileSync('tar', ['-xOf', input, archiveMember], { maxBuffer: 600 * 1024 * 1024 }) : fs.readFileSync(input)
const raw = JSON.parse(bytes)
const causes = raw.evidenceFormat === 'snapshot-graph/1' ? createSnapshotGraph().unpack(raw.causes, raw.snapshotNodes) : raw.causes
if (!Array.isArray(causes)) throw new Error('missing native causes')
const actorEvents = (raw.events ?? raw.actors ?? []).filter(e => e.kind === 'actor').sort((a,b)=>a.order-b.order)
const starts = new Map(causes.filter(c => c.phase === 'run-started').map(c=>[c.runId,c]))
const groups = new Map()
for (const c of causes) {
  if (c.phase !== 'command' || c.engine !== 'reforge') continue
  const stage = c.occurrence?.path?.[0] ?? null
  const key = JSON.stringify([c.runId,stage])
  if (!groups.has(key)) groups.set(key,{ first:c, commands:[] })
  groups.get(key).commands.push(c)
}
const targetsOf = value => {
  const result = new Map()
  const walk = obj => {
    if (!obj || typeof obj !== 'object') return
    if (typeof obj.scene === 'string' && typeof obj.entity === 'string') result.set(`${obj.scene}/${obj.entity}`,obj)
    Object.values(obj).forEach(walk)
  }
  walk(value)
  return [...result.values()]
}
const entries = [...groups.values()].map(({first:c,commands})=>{
 const start=starts.get(c.runId)
 const author=start?.author ?? null
 const scene=author?.scene ?? c.occurrence?.self?.scene ?? c.scene
 const targets=targetsOf(commands.map(v=>v.occurrence?.command))
 if(c.occurrence?.self && !targets.some(t=>t.scene===c.occurrence.self.scene&&t.entity===c.occurrence.self.entity))targets.unshift(c.occurrence.self)
 const observedActors={}
 for(const e of actorEvents){
  if(e.order>c.order)break
  if(e.scene===c.scene && e.sceneVisit===c.sceneVisit)observedActors[e.id]={state:e.state,order:e.order,source:e.source}
 }
 const poses=c.poses??{}
 const unknowns=[]
 if(!start)unknowns.push('native run-started receipt absent')
 if(!c.world)unknowns.push('native world snapshot absent')
 for(const t of targets){
  if(t.scene!==c.scene) unknowns.push(`cross-scene target ${t.scene}/${t.entity}: current-scene actor pose unavailable; world stores only any persistent override`)
  else if(!poses[t.entity]&&!observedActors[t.entity])unknowns.push(`target ${t.scene}/${t.entity}: no recorded actor pose at this entry`)
 }
 return {
   address:author?.kind==='scene-hook'?{scene:author.scene,kind:'scene',slot:author.slot,variant:author.hook,step:c.occurrence?.path?.[0]}:author?.kind==='entity-behavior'?{scene:author.scene,entity:author.entity,kind:'entity',slot:author.channel,variant:author.behavior,step:c.occurrence?.path?.[0]}:{scene,author,step:c.occurrence?.path?.[0]},
   runId:c.runId,sceneVisit:c.sceneVisit,tick:c.tick,order:c.order,seq:c.seq,runStartedOrder:start?.order,
   root:start?{self:start.self,timing:start.timing,scope:start.scope,stage:start.stage,resume:start.resume,author:start.author,digest:start.digest}:null,
   firstCommandPath:c.occurrence?.path,firstCommand:c.occurrence?.command,targets,
   prestate:{poses,observedActors,world:c.world??null,lifecycle:c.lifecycle??null},unknowns,
 }
})
const out={kind:'readonly-native-entry-prestate-extract/1',input,archiveMember:archiveMember??null,evidenceFormat:raw.evidenceFormat??'ordinary-json',nativeErrors:raw.errors??null,nativeOverflow:raw.overflow??null,counts:{causes:causes.length,actorEvents:actorEvents.length,entries:entries.length},entries}
fs.writeFileSync(output,JSON.stringify(out,null,2)+'\n')
console.log(JSON.stringify({output,...out.counts,entries:entries.map(e=>({address:e.address,order:e.order,runId:e.runId,resume:!!e.root?.resume,poses:Object.keys(e.prestate.poses),observedActors:Object.keys(e.prestate.observedActors).length,targets:e.targets,unknowns:e.unknowns}))},null,2))
