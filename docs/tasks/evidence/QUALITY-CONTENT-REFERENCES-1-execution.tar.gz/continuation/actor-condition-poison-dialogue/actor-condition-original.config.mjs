import { readFileSync } from 'node:fs'
import { resolve } from 'node:path'
import { fileURLToPath } from 'node:url'

const root = process.cwd()
const modulePath = resolve(root, 'src/actor-condition.ts')
const originalPath = fileURLToPath(new URL('./actor-condition-before.ts', import.meta.url))
export default {
  root,
  plugins: [{
    name: 'actor-condition-pre-refactor',
    enforce: 'pre',
    load(id) {
      if (id === modulePath) return readFileSync(originalPath, 'utf8')
    },
  }],
  test: { include: ['src/actor-condition.test.ts', 'src/actor-condition-validation.test.ts'] },
}
