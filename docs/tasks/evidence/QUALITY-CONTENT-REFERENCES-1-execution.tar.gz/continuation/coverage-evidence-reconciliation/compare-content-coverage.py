import difflib
import json
import subprocess
import sys
from pathlib import Path

root = Path(__file__).resolve().parent
base_version = sys.argv[1]
original_dir, candidate_dir = map(Path, sys.argv[2:4])
BASE = "packages/content/"
METRICS = ("statements", "branches", "functions", "lines")

def git_text(*arguments):
    return subprocess.run(["git", *arguments], check=True, text=True, capture_output=True).stdout

def source(path, rev=None):
    return (git_text("show", f"{rev}:{BASE}{path}") if rev else Path(BASE + path).read_text()).splitlines()

def normalize_name(name):
    return name.split(BASE)[-1]

def summary(directory):
    data = json.loads((directory / "coverage-summary.json").read_text())
    return {normalize_name(k): {m: (v[m]["covered"], v[m]["total"]) for m in METRICS} for k, v in data.items()}

def lcov(directory):
    files = {}
    for entry in (directory / "lcov.info").read_text().splitlines():
        key, _, rest = entry.partition(":")
        if key == "SF":
            name = normalize_name(rest)
            files[name] = {"lines": {}, "branches": {}, "functions": {}}
        elif key == "DA":
            line, count = rest.split(",")[:2]
            files[name]["lines"][int(line)] = int(count)
        elif key == "BRDA":
            line, block, index, count = rest.split(",")
            files[name]["branches"].setdefault(int(line), []).append(0 if count == "-" else int(count))
        elif key == "FN":
            line, ident = rest.split(",", maxsplit=1)
            if "," in ident:
                number, separator, name_hint = ident.partition(",")
                if number.isdecimal():
                    ident = name_hint
            files[name]["functions"][ident] = {"line": int(line)}
        elif key == "FNDA":
            count, ident = rest.split(",", maxsplit=1)
            if ident in files[name]["functions"]:
                files[name]["functions"][ident]["count"] = int(count)
    return files

def diff_pairs(old_lines, new_lines):
    for old_line, new_line, width in difflib.SequenceMatcher(None, old_lines, new_lines, autojunk=False).get_matching_blocks():
        for relative in range(width):
            yield old_line + relative + 1, new_line + relative + 1

old_summary, new_summary = summary(original_dir), summary(candidate_dir)
old_concrete, new_concrete = lcov(original_dir), lcov(candidate_dir)
old_ref = "src/validate-refs.ts"
new_sprite = "src/sprite-references.ts"
report = {"base": base_version, "metricKeys": METRICS, "total": [old_summary["total"], new_summary["total"]], "deltas": {}, "unchangedLineLosses": [], "deletedOrChangedOldCoveredLines": []}
for path in sorted((old_summary.keys() | new_summary.keys()) - {"total"}):
    old = old_summary.get(path, {})
    new = new_summary.get(path, {})
    if old != new:
        report["deltas"][path] = {
            "before": old, "after": new,
            "difference": [[n - o for o, n in zip(old.get(metric, (0, 0)), new.get(metric, (0, 0)))] for metric in METRICS],
        }
    if path not in old_concrete:
        continue
    original_lines = source(path, base_version)
    alternatives = {}
    if path in new_concrete:
        alternatives[path] = source(path)
    if path == old_ref:
        alternatives[new_sprite] = source(new_sprite)
    mapped = {}
    for new_path, candidate_lines in alternatives.items():
        for old_line, new_line in diff_pairs(original_lines, candidate_lines):
            source_text = original_lines[old_line - 1].strip()
            if new_path == new_sprite and not 117 <= old_line <= 765:
                continue
            if old_line not in mapped or new_path == new_sprite:
                mapped[old_line] = (new_path, new_line)
    for old_line, old_hits in old_concrete[path]["lines"].items():
        if not old_hits:
            continue
        content = original_lines[old_line - 1].strip()
        if old_line not in mapped:
            report["deletedOrChangedOldCoveredLines"].append((path, old_line, old_hits, content))
            continue
        new_path, new_line = mapped[old_line]
        new_hits = new_concrete[new_path]["lines"].get(new_line)
        if new_hits == 0:
            report["unchangedLineLosses"].append((path, old_line, old_hits, new_path, new_line, content))

(root / (sys.argv[4] if len(sys.argv) > 4 else "content-coverage-comparison.json")).write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n")
print("Total", report["total"])
print("Metrics per file in order", ", ".join(METRICS))
for path, data in report["deltas"].items():
    print(path, data["difference"])
print("Unchanged mapped covered lines losing effective execution", len(report["unchangedLineLosses"]))
for row in report["unchangedLineLosses"]:
    print(*row)
print("Old covered lines deleted or changed", len(report["deletedOrChangedOldCoveredLines"]))
