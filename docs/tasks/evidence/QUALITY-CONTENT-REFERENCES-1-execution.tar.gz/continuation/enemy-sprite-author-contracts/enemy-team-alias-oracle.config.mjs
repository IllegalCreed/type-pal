import { readFileSync } from 'node:fs'
import { resolve } from 'node:path'

const root = process.cwd()
const checkedModule = resolve(root, 'src/enemy-team.ts')
const sourcePoint = 'slots: [...team.slots] as Array<string | null>'

export default {
  root,
  plugins: [{
    name: 'check-team-slot-ownership',
    enforce: 'pre',
    load(id) {
      if (id !== checkedModule) return
      const source = readFileSync(id, 'utf8')
      if (source.split(sourcePoint).length !== 2) throw new Error('Expected one team-slot copy')
      return source.replace(sourcePoint, 'slots: team.slots as Array<string | null>')
    },
  }],
  test: {
    include: ['src/enemy-team.contracts.test.ts', 'src/enemy-team.test.ts'],
  },
}
