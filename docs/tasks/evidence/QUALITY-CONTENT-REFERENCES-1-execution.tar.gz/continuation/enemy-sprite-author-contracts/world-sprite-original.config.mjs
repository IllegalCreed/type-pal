import { readFileSync } from 'node:fs'
import { resolve } from 'node:path'
import { fileURLToPath } from 'node:url'

const root = process.cwd()
const checkedModule = resolve(root, 'src/sprite.ts')
const baseline = fileURLToPath(new URL('./world-sprite-original.ts', import.meta.url))

export default {
  root,
  plugins: [{
    name: 'use-original-world-sprite-module',
    enforce: 'pre',
    load(id) {
      if (id === checkedModule) return readFileSync(baseline, 'utf8')
    },
  }],
  test: {
    include: ['src/sprite-frame-demand.contracts.test.ts', 'src/sprite-frames.test.ts'],
  },
}
