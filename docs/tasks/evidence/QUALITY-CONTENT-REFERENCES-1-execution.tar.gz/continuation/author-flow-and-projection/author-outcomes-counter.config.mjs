import { readFileSync } from 'node:fs'
import { resolve } from 'node:path'
import { fileURLToPath } from 'node:url'

const root = process.cwd()
const modulePath = resolve(root, 'src/author-script-core.ts')
const originalPath = fileURLToPath(new URL('./author-outcomes-counter.ts', import.meta.url))
export default {
  root,
  plugins: [{
    name: 'retired-cursor-outcomes-counter',
    enforce: 'pre',
    load(id) {
      if (id === modulePath) return readFileSync(originalPath, 'utf8')
    },
  }],
  test: { include: ['src/author-unified-control.test.ts'] },
}
