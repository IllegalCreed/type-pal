import { readFileSync } from 'node:fs'
import { resolve } from 'node:path'
import { fileURLToPath } from 'node:url'

const root = process.cwd()
const modulePath = resolve(root, 'src/frame-sequence.ts')
const originalPath = fileURLToPath(new URL('./frame-sequence-before.ts', import.meta.url))
export default {
  root,
  plugins: [{
    name: 'frame-sequence-pre-refactor',
    enforce: 'pre',
    load(id) {
      if (id === modulePath) return readFileSync(originalPath, 'utf8')
    },
  }],
  test: { include: ['src/frame-sequence*.test.ts'] },
}
