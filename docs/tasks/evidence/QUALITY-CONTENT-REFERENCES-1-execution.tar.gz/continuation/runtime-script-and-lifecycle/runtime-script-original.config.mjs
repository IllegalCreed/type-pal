import { readFileSync } from 'node:fs'
import { resolve } from 'node:path'
import { fileURLToPath } from 'node:url'

const root = process.cwd()
const modulePath = resolve(root, 'src/runtime-script.ts')
const originalPath = fileURLToPath(new URL('./runtime-script-before.ts', import.meta.url))
export default {
  root,
  plugins: [{
    name: 'runtime-script-pre-refactor',
    enforce: 'pre',
    load(id) {
      if (id === modulePath) return readFileSync(originalPath, 'utf8')
    },
  }],
  test: { include: ['src/runtime-script.test.ts'] },
}
