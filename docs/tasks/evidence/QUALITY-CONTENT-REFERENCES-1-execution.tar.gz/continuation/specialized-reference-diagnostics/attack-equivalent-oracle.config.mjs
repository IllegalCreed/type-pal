import { readFileSync } from 'node:fs'
import { resolve } from 'node:path'

const root = process.cwd()
const checkedModule = resolve(root, 'src/validate-refs.ts')
const sourcePoint = "if (e.attackEquivItem && !itemIds.has(e.attackEquivItem.itemId))\n      issues.push({\n        severity: 'error'"
const replacement = sourcePoint.replace("severity: 'error'", "severity: 'warn'")

export default {
  root,
  plugins: [{
    name: 'check-attack-equivalent-diagnostic',
    enforce: 'pre',
    load(id) {
      if (id !== checkedModule) return
      const source = readFileSync(id, 'utf8')
      if (source.split(sourcePoint).length !== 2) throw new Error('Expected one equivalent-item diagnostic')
      return source.replace(sourcePoint, replacement)
    },
  }],
  test: {
    include: ['src/validate-refs.glm-o.test.ts', 'src/enemy-reference-validation.test.ts'],
  },
}
