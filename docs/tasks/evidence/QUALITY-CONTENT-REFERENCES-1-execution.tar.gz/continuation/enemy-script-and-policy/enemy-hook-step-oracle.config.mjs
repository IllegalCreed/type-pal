import { readFileSync } from 'node:fs'
import { resolve } from 'node:path'

const root = process.cwd()
const checkedModule = resolve(root, 'src/enemy-script.ts')
const needle = 'if (steps > ENEMY_HOOK_MAX_SYNC_STEPS)'

export default {
  root,
  plugins: [{
    name: 'narrow-enemy-hook-limit',
    enforce: 'pre',
    load(id) {
      if (id !== checkedModule) return
      const body = readFileSync(id, 'utf8')
      if (body.split(needle).length !== 2) throw new Error('Expected one synchronous-hook bound')
      return body.replace(needle, 'if (steps >= ENEMY_HOOK_MAX_SYNC_STEPS)')
    },
  }],
  test: { include: ['src/enemy-script.test.ts'] },
}
