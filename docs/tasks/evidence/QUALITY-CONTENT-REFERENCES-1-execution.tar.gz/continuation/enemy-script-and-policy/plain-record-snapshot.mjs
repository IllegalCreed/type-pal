import assert from 'node:assert/strict'
import { pathToFileURL } from 'node:url'
import { resolve } from 'node:path'
const { deepSnapshot } = await import(
  pathToFileURL(resolve('packages/content/src/__tests__/value-snapshot.ts'))
)
const source = JSON.parse('{"__proto__":{"own":true},"constructor":"object-key"}')
const copy = deepSnapshot(source)
assert.deepEqual(copy, source)
assert.equal(Object.getPrototypeOf(copy), Object.prototype)
copy.__proto__.own = false
assert.equal(source.__proto__.own, true)
