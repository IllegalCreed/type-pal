from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import sys

scratch=Path(__file__).resolve().parent
workspace=Path.cwd()
config=sys.argv[1]
old_sha="5045b8955"
base=subprocess.check_output(['git','rev-parse',old_sha if config=='prior' else 'origin/main'],text=True).strip()
if config=='current':
 root=scratch/'main-editor-gate-source'
else:
 assert config=='prior'
 root=scratch/'prior-editor-reference-source'
 root.mkdir()
 dirs=['packages/editor','packages/reforge','packages/content','packages/shared','projects/pal','tsconfig.base.json','package.json','pnpm-workspace.yaml']
 archive=subprocess.check_output(['git','archive',base,*dirs])
 subprocess.run(['tar','-xf','-','-C',str(root)],input=archive,check=True)
 (root/'node_modules').symlink_to(workspace/'node_modules',target_is_directory=True)
 for package in ['editor','reforge','content','shared']:
  source=workspace/'packages'/package/'node_modules'
  target=root/'packages'/package/'node_modules'
  if source.is_dir():
   target.mkdir()
   for item in source.iterdir():
    if item.is_symlink():
     (target/item.name).symlink_to(os.readlink(item))
    elif item.is_dir() and item.name.startswith('@'):
     shutil.copytree(item,target/item.name,symlinks=True)
out=scratch/('window-reference-census-probe-'+config)
out.mkdir()
relative='src/core/project-reference.pal.test.ts'
cwd=root/'packages/editor'
file=cwd/relative
source=file.read_bytes()
assert source==subprocess.check_output(['git','show',f'{base}:packages/editor/{relative}'])
body=source.decode().replace('expect(', 'expect.soft(')
seam='sharedContext = await loadReferenceContext()'
assert body.count(seam)==1
body="""import { writeFileSync } from 'node:fs'
"""+body.replace(seam,seam+"""
    writeFileSync(process.env.TYPE_PAL_REFERENCE_GATE_PROBE!, JSON.stringify({
      edges: sharedContext.edges.map(({ id, ...edge }) => edge),
      addresses: sharedContext.diagnostics.entityAddressReferences,
      compact: {
        rows: sharedContext.diagnostics.projectReferences.rows.length,
        targetEdgeIds: sharedContext.diagnostics.projectReferences.targetEdgeIds.length,
        bytes: new TextEncoder().encode(JSON.stringify(sharedContext.diagnostics.projectReferences)).byteLength,
      }
    }))
""")
file.write_text(body)
args=[str(workspace/'node_modules/.bin/vitest'),'run',relative,'--reporter=default','--reporter=json',f'--outputFile.json={out/"report.json"}']
try:
 started=datetime.now(timezone.utc).isoformat()
 with (out/'stdout').open('xb') as stdout,(out/'stderr').open('xb') as stderr:
  result=subprocess.run(args,cwd=cwd,stdout=stdout,stderr=stderr,env={**os.environ,'TYPE_PAL_REFERENCE_GATE_PROBE':str(out/'graph.json')})
finally:
 file.write_bytes(source)
 assert file.read_bytes()==source
raw=json.loads((out/'report.json').read_bytes())
tests={k:raw[k] for k in ('numTotalTests','numPassedTests','numFailedTests','numPendingTests')}
first=[dict(fullName=a['fullName'],diagnostics=[v.splitlines()[0] for v in a['failureMessages']]) for f in raw['testResults'] for a in f['assertionResults'] if a['status']=='failed']
meta={'base':base,'argv':args,'cwd':str(cwd),'startedAt':started,'exit':result.returncode,'originalTestSha256':hashlib.sha256(source).hexdigest(),'restored':True,'tests':tests,'diagnostics':{'isolatedProbeFailures':len(first)},'failures':first}
(out/'execution.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(meta,ensure_ascii=False))
