from collections import Counter
from pathlib import Path
import hashlib
import json
import re
import subprocess

p=Path(__file__).resolve().parent
prior='5045b8955471d90aa6db8a8183689ae6c959e666'
current='8fce7b6a485904d2b7e2adb076989fcb94ccb027'
prefixes={
 'actors':'projects/pal/content/actors.json',
 'enemies':'projects/pal/content/enemies.json',
 'items':'projects/pal/content/items.json',
 'skills':'projects/pal/content/skills.json',
 'manifest':'projects/pal/manifest.json',
 'sharedScripts':'projects/pal/content/shared-scripts.json',
}
def source(row):
 where=row['where']
 prefix=re.split(r'\.|\[',where,1)[0]
 if prefix=='scenes':
  if where.startswith('scenes.'):
   scene=where.split('.')[1]
  else:
   owner=row['source']['owner']
   assert owner['kind'] in ('scene','scene-entity'),row
   scene=owner['id'] if owner['kind']=='scene' else owner['sceneId']
  assert scene in ('s037','s093'),row
  return f'projects/pal/content/scenes/{scene}.json'
 return prefixes[prefix]

changed=set(subprocess.check_output(['git','diff','--name-only',prior,current,'--','projects/pal'],text=True).splitlines())
inputs={config:json.loads((p/('window-reference-census-probe-'+config)/'graph.json').read_bytes()) for config in ('prior','current')}
def key(row):return json.dumps(row,ensure_ascii=False,sort_keys=True)
def compare(member):
 left,right=[Counter(map(key,inputs[config][member])) for config in ('prior','current')]
 return {'before':sum(left.values()),'after':sum(right.values()),
  'removed':[json.loads(x) for x in (left-right).elements()],
  'added':[json.loads(x) for x in (right-left).elements()]}
edges=compare('edges')
addresses=compare('addresses')
for name,values in [('edges',edges),('addresses',addresses)]:
 (p/f'editor-pal-{name}-delta.json').write_text(json.dumps(values,ensure_ascii=False,indent=2)+'\n')
source_deltas={}
for side in ('removed','added'):
 groups=Counter()
 for row in edges[side]:
  file=source(row)
  assert file in changed,(file,row['where'])
  groups[(file,row['relation']['kind'])]+=1
 source_deltas[side]=[{'file':path,'relation':kind,'count':number} for (path,kind),number in sorted(groups.items())]
def pin(raw):return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
assert (edges['before'],edges['after'],len(edges['removed']),len(edges['added']))==(25230,25241,96,107)
assert (addresses['before'],addresses['after'],len(addresses['removed']),len(addresses['added']))==(22642,22634,33,25)
assert {x['where'] for x in edges['added'] if x['relation'].get('use')=='skill-poison'}=={
 'skills[100](395).execution.enemy.effects[0].poisonId',
 'skills[81](376).execution.enemy.effects[0].poisonId',
}
saved={
 'prior':prior,'current':current,'sourceDeltas':source_deltas,
 'edgeGraphs':{x:pin((p/('window-reference-census-probe-'+x)/'graph.json').read_bytes()) for x in ('prior','current')},
 'independentContractsRetained':['deletion-blocker parity','actor collection and deletion parity','per-kind battle data parity','reference owner and source locators','exact asset ownership and independent collector parity','worker compact snapshot equality','compact byte cap','field adoptions AST census'],
 'workerCompactCounts':[{**inputs[x]['compact'],'rev':revision} for x,revision in (('prior',prior),('current',current))],
 'layout':{'file':'packages/editor/src/ui/design-system/field-layout-adoption.json','component':'ProjectOverviewPage','responsiveBefore':1,'responsiveAfter':2,'introducedBy':'39d5bf7eb080a2a569421c50b79ebe60f38eecb0','fields':['project-display-name','project-hostile-victory-transition']},
 'ownership':'The active E2E diff does not edit either of these gate carriers. Project data, validators, routes, layout implementation and test selection remain the pinned main bytes.',
 'replay':'Use probe-pal-reference-census.py in temporary snapshots. Its soft-expect diagnostic probe is limited to those snapshots, restored immediately. Authoritative main red and actual candidate green use the normal exact tests.',
}
(p/'editor-gate-repair-proof.json').write_text(json.dumps(saved,ensure_ascii=False,indent=2)+'\n')
print('Every changed logical edge traces to an authored PAL file changed on main.')
print('Edge delta by relation',Counter(x['relation']['kind'] for x in edges['removed']),Counter(x['relation']['kind'] for x in edges['added']))
