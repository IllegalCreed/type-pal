import { readFileSync } from 'node:fs'
import { resolve } from 'node:path'

const root = resolve(process.cwd())
const modulePath = resolve(root, 'src/validate-refs.ts')
const ownerLoop = 'for (const [cid, list] of Object.entries(b.levelUp)) {\n    '
const original = ownerLoop + 'if (!actorIds.has(cid))'
const mutation = ownerLoop + 'if (!actorIds.has(cid) && list.length === 0)'
export default {
  root,
  plugins: [{
    name: 'check-level-up-warning-oracle',
    enforce: 'pre',
    load(id) {
      if (id !== modulePath) return
      const source = readFileSync(id, 'utf8')
      if (source.split(original).length !== 2) throw new Error('Expected exactly one owner guard')
      return source.replace(original, mutation)
    },
  }],
  test: { include: ['src/project-data-references.test.ts'] },
}
