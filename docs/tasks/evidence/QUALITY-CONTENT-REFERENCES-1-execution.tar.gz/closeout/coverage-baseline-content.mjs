import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { readFileSync } from 'node:fs'

const runner = new URL('./base-content/scripts/coverage/run.mjs', import.meta.url)
const source = readFileSync(runner, 'utf8')
const mainStart = source.indexOf('async function main() {\n')
const invocation = source.indexOf('\nmain().catch', mainStart)
assert(mainStart >= 0 && invocation > mainStart)
const mainForContent = `async function main() {
  await assertToolVersions()
  const output = resolve(coverageRoot, profile)
  const content = coveragePackages.find((entry) => entry.id === 'content')
  if (!content) throw new Error('official content coverage configuration missing')
  const result = await collectPackage(content, output)
  console.log(JSON.stringify({ metrics: result.metrics, sourceFileCount: result.sourceFileCount, testCount: result.selectedTests.testCount }))
}
`
console.log(JSON.stringify({
  revision: '8fce7b6a485904d2b7e2adb076989fcb94ccb027',
  officialRunnerSha256: createHash('sha256').update(source).digest('hex'),
  scope: 'Main content only, unchanged official collector, no baseline or main-tree writes',
}))
const program = (source.slice(0, mainStart) + mainForContent + source.slice(invocation)).replace(
  /from '(\.\/[^']+)'/gu,
  (_, path) => `from '${new URL(path, runner).href}'`,
)
await import(`data:text/javascript;base64,${Buffer.from(program).toString('base64')}`)
