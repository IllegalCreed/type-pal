import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { readFileSync } from 'node:fs'
import { resolve } from 'node:path'
import { fileURLToPath, pathToFileURL } from 'node:url'

const runner = pathToFileURL(resolve('scripts/coverage/run.mjs'))
const source = readFileSync(runner, 'utf8')
const mainStart = source.indexOf('async function main() {\n')
const invocation = source.indexOf('\nmain().catch', mainStart)
assert(mainStart >= 0 && invocation > mainStart)
const output = fileURLToPath(new URL('./content-final-coverage', import.meta.url))
const mainForContent = `async function main() {
  await assertToolVersions()
  const content = coveragePackages.find((entry) => entry.id === 'content')
  if (!content) throw new Error('official content coverage configuration missing')
  const output = ${JSON.stringify(output)}
  const result = await collectPackage(content, output)
  await writeFile(resolve(output, 'content-package.json'), \`\${JSON.stringify(result, null, 2)}\\n\`, { flag: 'wx' })
  console.log(JSON.stringify({ metrics: result.metrics, sourceFileCount: result.sourceFileCount, testCount: result.selectedTests.testCount }))
}
`
console.log(JSON.stringify({
  officialRunnerSha256: createHash('sha256').update(source).digest('hex'),
  scope: 'Final content only, unchanged official collector, no baseline or other package writes',
}))
const program = (source.slice(0, mainStart) + mainForContent + source.slice(invocation)).replace(
  /from '(\.\/[^']+)'/gu,
  (_, path) => `from '${new URL(path, runner).href}'`,
)
await import(`data:text/javascript;base64,${Buffer.from(program).toString('base64')}`)
