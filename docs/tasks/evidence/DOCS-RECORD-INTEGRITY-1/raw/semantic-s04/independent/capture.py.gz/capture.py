from pathlib import Path
import os,sys,subprocess,signal,hashlib,datetime,time,json
p=Path(__file__).parent;name=sys.argv[1];argv=sys.argv[2:];cwd='/Users/zhangxu/.codex/worktrees/docs-integrity-readonly/type-pal'
env=os.environ.copy();env['NODE_PATH']='/Users/zhangxu/illegal/type-pal/node_modules'
start=datetime.datetime.now(datetime.timezone.utc).isoformat();t=time.monotonic();timed=False;states=[];error=None
def own_group(g):
 q=subprocess.run(['ps','-axo','pid=,ppid=,pgid=,stat=,command='],capture_output=True,text=True,timeout=5)
 return [x.strip() for x in q.stdout.splitlines() if len(x.split())>=4 and x.split()[2]==str(g)]
with (p/'raw'/(name+'.stdout')).open('wb') as out,(p/'raw'/(name+'.stderr')).open('wb') as err:
 try:
  child=subprocess.Popen(argv,cwd=cwd,env=env,stdout=out,stderr=err,start_new_session=True);pid=child.pid
  try:code=child.wait(timeout=180)
  except subprocess.TimeoutExpired:
   timed=True;states.append({'phase':'before-own-group-SIGTERM','processes':own_group(pid)});os.killpg(pid,signal.SIGTERM)
   try:code=child.wait(timeout=5)
   except subprocess.TimeoutExpired:
    states.append({'phase':'before-own-group-SIGKILL','processes':own_group(pid)});os.killpg(pid,signal.SIGKILL);code=child.wait(timeout=5)
  states.append({'phase':'after-wait','processes':own_group(pid)})
 except OSError as e:pid=None;code=None;error=repr(e)
meta={'name':name,'reviewerTask':'/root/receipt_integrity_independent','candidateCommit':'c8715c2c4ac1771a77127917812c87b53a30d676','argv':argv,'cwd':cwd,'envOverrides':{'NODE_PATH':env['NODE_PATH']},'startedAt':start,'endedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'durationSeconds':time.monotonic()-t,'pid':pid,'ownProcessGroup':pid,'exitCode':code if code is None or code>=0 else None,'signal':-code if code is not None and code<0 else None,'timedOut':timed,'spawnError':error,'processGroupStates':states}
for s in ['stdout','stderr']:
 f=p/'raw'/(name+'.'+s);b=f.read_bytes();meta[s]={'path':str(f),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
(p/'raw'/(name+'.json')).write_text(json.dumps(meta,ensure_ascii=False,indent=2)+'\n');print(json.dumps(meta,ensure_ascii=False))
