sed -n "274,285p" docs/testing/e2e/cross-stage/common-issues.md
sed -n "326,355p" docs/testing/e2e/cross-stage/common-issues.md
sed -n "1,103p" docs/ops/tasks/E2E-R4-1-route-and-checkpoint-foundation.md
