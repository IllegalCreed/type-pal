python3 - <<'PY'
from pathlib import Path
import json
c=json.loads(Path('docs/testing/catalog.json').read_text())
e=next(e for e in c['entries'] if e['id']=='e2e-common-issues')
print(json.dumps(e,ensure_ascii=False,indent=2))
p=Path('docs/testing')/e['evidence']
a=json.loads(p.read_text())
print('evidence keys',list(a))
fields=['schemaVersion','id','kind','status','candidateSha','contentVersion','minimumSaveVersion','history','runtimeExecution','sourceRefs']
print(json.dumps({k:a.get(k) for k in fields},ensure_ascii=False,indent=2))
print('pairedClaims',json.dumps(a.get('claims'),ensure_ascii=False,indent=2))
PY
rg -n "cross-stage/README.md|common-issues.md|e2e-common-issues" docs/testing/e2e/README.md docs/testing/indexes/by-stage.md docs/ops/tasks/E2E-R4-1-route-and-checkpoint-foundation.md
cat docs/phase-governance/templates/governance-index.md
shasum -a 256 docs/testing/governance.md docs/phase-governance/templates/governance-index.md pnpm-workspace.yaml
