python3 - <<'PY'
from pathlib import Path
import json,hashlib,subprocess
a=json.loads(Path('docs/testing/e2e/evidence/e2e-common-issues.json').read_text())
print('paired evidence versions',json.dumps(a['versions'],ensure_ascii=False))
src=subprocess.check_output(['git','show','dc478db11c6b52c4e50a1d1135f8a4740796418c:docs/testing/e2e/cross-stage/README.md'])
b=Path('docs/testing/e2e/cross-stage/README.md').read_bytes()
q=b.split(b'<!-- original-source-quote:start -->\n',1)[1].split(b'<!-- original-source-quote:end -->',1)[0]
d=b''.join(l[2:] if l.startswith(b'> ') else l[1:] for l in q.splitlines(keepends=True))
print(json.dumps({'sourceLines':len(src.splitlines()),'sourceBytes':len(src),'sourceSha256':hashlib.sha256(src).hexdigest(),'currentLines':len(b.splitlines()),'currentSha256':hashlib.sha256(b).hexdigest(),'quoteLines':len(q.splitlines()),'directInverseBytes':len(d),'directInverseEqualsSource':d==src,'conditionedInverseEqualsSource':d[:-1]==src,'suffixHex':d[len(src):].hex()},ensure_ascii=False,indent=2))
assert d[:-1]==src and d[len(src):]==b'\n'
p=Path('/tmp/type-pal-s04-author-20261018-p_ahi1x_')
(p/'source-readme.md').write_bytes(src);(p/'before-readme.md').write_bytes(b)
PY
