python3 - <<'PY'
from pathlib import Path
p=Path('/tmp/type-pal-s04-author-20261018-p_ahi1x_')
print((p/'08-check-docs.json').read_text())
for line in (p/'08-check-docs.stdout').read_text().splitlines():
 if line.startswith(('# tests ','# pass ','# fail ','# cancelled ','# skipped ','# todo ','docs:','document model:','testing docs:','phase/lore governance:','content review:')): print(line)
lines=(p/'08-check-docs.stderr').read_text().splitlines()
print('stderr lines',len(lines))
print('this README diagnostics',[l for l in lines if 'docs/testing/e2e/cross-stage/README.md:' in l])
PY
git diff --cached --check && git commit -m "docs: restore cross-stage issue family navigation" && git rev-parse HEAD && git diff --check f9fbf0c7c6e9b59df6c0cbe76b7b90852da76ece..HEAD && git diff --name-only f9fbf0c7c6e9b59df6c0cbe76b7b90852da76ece..HEAD && git status --short && shasum -a 256 docs/testing/e2e/README.md docs/testing/e2e/cross-stage/README.md
