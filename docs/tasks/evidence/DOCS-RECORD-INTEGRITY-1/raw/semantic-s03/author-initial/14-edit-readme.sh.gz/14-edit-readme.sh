python3 /tmp/type-pal-s03-author-20261018-al36xarv/edit-readme.py
