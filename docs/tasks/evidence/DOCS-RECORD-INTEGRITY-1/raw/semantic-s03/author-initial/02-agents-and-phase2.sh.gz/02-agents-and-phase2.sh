cat AGENTS.md docs/phase2/READ-FIRST.md
