sed -n "1,80p" projects/pal/e2e-checkpoints/README.md
sed -n "1,54p" docs/ops/tasks/E2E-R4-1-route-and-checkpoint-foundation.md
sed -n "1,50p" docs/ops/tasks/E2E-005-1-shrimp-errand-and-xianglan-news.md
sed -n "1,54p" docs/ops/tasks/E2E-006-1-inn-doctor-and-boat-to-island.md
sed -n "1,45p" docs/ops/tasks/ED-ENTITY-STATE-PLAN-1.md
cat docs/testing/indexes/README.md
rg -n "e2e/README.md|E2E 专项|e2e\)" docs/testing/README.md docs/README.md docs/ops/tasks/index.md
