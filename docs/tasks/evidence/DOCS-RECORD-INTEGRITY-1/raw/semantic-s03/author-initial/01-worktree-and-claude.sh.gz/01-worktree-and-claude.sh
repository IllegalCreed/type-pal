pwd && git status --short && git rev-parse HEAD && git branch --show-current && cat CLAUDE.md
