python3 - <<'PY'
from pathlib import Path
import json
p=Path('/tmp/type-pal-s03-author-20261018-al36xarv')
for name in ['21-lint','22-strict-content','23-progress-require-complete']:
 print(json.dumps(json.loads((p/(name+'.json')).read_text()),ensure_ascii=False))
 out=(p/(name+'.stdout')).read_text(); err=(p/(name+'.stderr')).read_text()
 print('stdout lines',len(out.splitlines()),'stderr lines',len(err.splitlines()))
 print('stdout first 3 lines',out.splitlines()[:3])
 print('README diagnostics',[l for l in err.splitlines() if 'docs/testing/e2e/README.md' in l])
PY
