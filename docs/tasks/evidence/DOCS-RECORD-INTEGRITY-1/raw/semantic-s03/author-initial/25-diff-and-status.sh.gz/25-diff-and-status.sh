git diff --check && git status --short && git diff --stat && git diff -- docs/testing/e2e/README.md
