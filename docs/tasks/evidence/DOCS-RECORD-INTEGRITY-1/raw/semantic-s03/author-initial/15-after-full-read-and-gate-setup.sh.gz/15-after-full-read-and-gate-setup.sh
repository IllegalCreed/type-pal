cat docs/testing/e2e/README.md
cat scripts/quality/lint-zero.mjs scripts/docs/check-document-model.mjs
sed -n "1,95p" scripts/docs/lib/document-model.mjs
rg -n "test:docs-tools" package.json
