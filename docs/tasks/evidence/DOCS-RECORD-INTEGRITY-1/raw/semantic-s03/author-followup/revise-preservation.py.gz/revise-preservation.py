from pathlib import Path
import hashlib,subprocess
p=Path('docs/testing/e2e/README.md')
before=p.read_bytes()
assert hashlib.sha256(before).hexdigest()=='84558465defc66b2dad8bc1a1a32242337d0b14f68c33135e5af817e5641b44a'
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()=='cafe0578acdde76405955102dd4d01427f18cffb'
old='；quote 可逆回原始 UTF-8 字节。'
new='。整个 quote 块字节保持不变；剥离每行引用前缀后，须剔除结束标记前既有分隔空行产生的恰一个 LF，再按固定 source SHA 验证原始 UTF-8 字节。这不是无条件 trim，也不表示直接 inverse 与源字节相等。'
s=before.decode()
assert s.count(old)==1
s=s.replace(old,new)
after=s.encode()
marker=b'<!-- original-source-quote:start -->'
assert before[before.index(marker):]==after[after.index(marker):]
p.write_bytes(after)
q=Path('/tmp/type-pal-s03-author-followup-20261018-2c1ksn5l')
(q/'before-cafe0578-readme.md').write_bytes(before)
(q/'after-readme.md').write_bytes(after)
print('beforeSha256',hashlib.sha256(before).hexdigest())
print('afterSha256',hashlib.sha256(after).hexdigest())
print('quoteBlockByteIdentical',True)
