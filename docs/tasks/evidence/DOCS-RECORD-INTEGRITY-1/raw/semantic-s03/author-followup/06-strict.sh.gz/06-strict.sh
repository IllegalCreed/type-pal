node scripts/docs/check-content-review.mjs --strict
