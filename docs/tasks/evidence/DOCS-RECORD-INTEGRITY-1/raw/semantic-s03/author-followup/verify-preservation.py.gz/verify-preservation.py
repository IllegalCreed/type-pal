from pathlib import Path
import hashlib,subprocess,json
sha=lambda b:hashlib.sha256(b).hexdigest()
source=subprocess.check_output(['git','show','dc478db11c6b52c4e50a1d1135f8a4740796418c:docs/testing/e2e/README.md'])
before=subprocess.check_output(['git','show','cafe0578acdde76405955102dd4d01427f18cffb:docs/testing/e2e/README.md'])
after=Path('docs/testing/e2e/README.md').read_bytes()
start=b'<!-- original-source-quote:start -->\n';end=b'<!-- original-source-quote:end -->'
oldblock=before[before.index(start):];newblock=after[after.index(start):]
assert oldblock==newblock
quote=newblock.split(start,1)[1].split(end,1)[0]
assert quote.endswith(b'\n>\n')
lines=quote.splitlines(keepends=True)
assert len(lines)==34
assert all(l.startswith(b'>') for l in lines)
direct=b''.join(l[2:] if l.startswith(b'> ') else l[1:] for l in lines)
assert len(source)==2212 and len(direct)==2213
assert direct!=source and direct.endswith(b'\n\n')
assert direct[-1:]==b'\n'
conditioned=direct[:-1]
assert conditioned==source
assert sha(source)=='310f5031be8e76964cbd1cf2d4e704c5bbfbd2cf4f6451d64a7109d93e67ca6f'
assert sha(after)=='8ddfbda4c48af97ff8c33a229f8cb45f00b1d91e5952d635def86a946be7c9e9'
print(json.dumps({'sourceBytes':len(source),'quotedLines':len(lines),'sourceLines':len(source.splitlines()),'directInverseBytes':len(direct),'directInverseSha256':sha(direct),'directInverseEqualsSource':False,'excludedSuffixHex':'0a','conditionedInverseSha256':sha(conditioned),'conditionedInverseEqualsSource':True,'quoteBlockSha256':sha(newblock),'quoteBlockByteIdentical':True,'afterSha256':sha(after),'notAnUnconditionalTrim':True},ensure_ascii=False,indent=2))
