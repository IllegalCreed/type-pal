node scripts/docs/report-governance-progress.mjs --require-complete
