import { resolve } from 'node:path'
const target = resolve('src/core/frame-animation-images.ts')
const original = 'new Uint8Array(pixels.buffer.slice(0))'
export default {
  plugins: [{
    name: 'image-frame-rgba-alias-counter',
    enforce: 'pre',
    transform(content, id) {
      if (id.split('?')[0] !== target) return
      if (content.split(original).length !== 2) throw new Error('Expected one returned RGBA copy')
      return content.replace(original, 'new Uint8Array(pixels.buffer)')
    },
  }],
}
