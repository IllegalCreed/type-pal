import { resolve } from 'node:path'
const target = resolve('src/async-intent.ts')
const original = 'capture(): number {\n    return this.serial\n  }'
export default {
  plugins: [{
    name: 'async-intent-capture-changes-owner-counter',
    enforce: 'pre',
    transform(content, id) {
      if (id.split('?')[0] !== target) return
      if (content.split(original).length !== 2) throw new Error('Expected a single capture method')
      return content.replace(original, 'capture(): number { return this.begin() }')
    },
  }],
}
