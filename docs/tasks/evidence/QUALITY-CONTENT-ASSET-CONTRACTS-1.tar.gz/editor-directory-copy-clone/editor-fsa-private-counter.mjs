import { resolve } from 'node:path'

const copy = resolve('src/core/fsa-copy.ts')
const target = 'if (isWorkspaceIdentityPath(path)) continue'
export default {
  plugins: [{
    name: 'editor-directory-identity-counter',
    enforce: 'pre',
    transform(content, id) {
      if (id.split('?')[0] !== copy) return
      if (content.split(target).length !== 2) throw new Error('Expected one private path gate')
      return content.replace(target, 'if (path === ".type-pal") continue')
    },
  }],
}
