import { resolve } from 'node:path'
import { pathToFileURL } from 'node:url'

// Run from the repository root. This file only reads the production exports.
const modulePath = resolve('packages/content/src/script-library.ts')
const { deriveScriptChunk, createScriptIndex, getScriptBody } = await import(pathToFileURL(modulePath).href)
const index = createScriptIndex({ shared: 4, global: {} })
const ids = ['s1', 's2', 's3', 's4', 's5', 's6']
const oldBuckets = ids.map((id) => deriveScriptChunk(id, index.shards))
const derived = deriveScriptChunk('s1', index.shards)
const chunks = { [String(derived)]: { version: 1, id: derived, scripts: { s1: [{ kind: 'gameOver' }] } } }
const result = {
  ids,
  oldBuckets: oldBuckets.map(String),
  oldValueDiversity: new Set(oldBuckets).size,
  realBucketForValidPrefix: deriveScriptChunk('shared/user/s1', index.shards),
  expectedChunkFromOldFixture: Object.keys(chunks),
  oldBodyLookupStillReturns: getScriptBody(index, chunks, 's1'),
}
console.log(JSON.stringify(result, null, 2))
if (oldBuckets.some((value) => value !== undefined)) process.exitCode = 1
