import { resolve } from 'node:path'
const target = resolve('src/core/frame-animation-draft.ts')
const historyCommit = 'present: draft,\n    future: [],'
const rowSpread = 'spread(x, y + 1, er, eg, eb, 5 / 16)'
export default {
  plugins: [{
    name: 'frame-draft-and-quantizer-single-contract-counters',
    enforce: 'pre',
    transform(content, id) {
      if (id.split('?')[0] !== target) return
      if (content.split(historyCommit).length !== 2 || content.split(rowSpread).length !== 2) {
        throw new Error('Expected a single history commit arm and one downward error spread')
      }
      return content.replace(historyCommit, 'present: draft,\n    future: history.future,')
        .replace(rowSpread, 'spread(x, y + 1, er, eg, eb, 0)')
    },
  }],
}
