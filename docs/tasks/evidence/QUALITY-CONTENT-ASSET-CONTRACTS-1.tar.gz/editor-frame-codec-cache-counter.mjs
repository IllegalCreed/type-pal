import { resolve } from 'node:path'
const target = resolve('src/core/frame-animation-codec.ts')
const guard = 'blockCache.size > 2'
export default {
  plugins: [{
    name: 'frame-codec-extra-cache-slot-counter',
    enforce: 'pre',
    transform(content, id) {
      if (id.split('?')[0] !== target) return
      if (content.split(guard).length !== 2) throw new Error('Expected one cache limit')
      return content.replace(guard, 'blockCache.size > 3')
    },
  }],
}
