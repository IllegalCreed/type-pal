import { resolve } from 'node:path'
const directoryPath = resolve('src/core/audio-preview-session.ts')
const release = 'if (activeOwner === owner) activeOwner = undefined'
export default {
  plugins: [{
    name: 'audio-session-stale-release-counter',
    enforce: 'pre',
    transform(content, id) {
      if (id.split('?')[0] !== directoryPath) return
      if (content.split(release).length !== 2) throw new Error('Expected one current-owner guard')
      return content.replace(release, 'void owner\n  activeOwner = undefined')
    },
  }],
}
