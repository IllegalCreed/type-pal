import { strict as assert } from 'node:assert'
import { readFileSync } from 'node:fs'
import { resolve } from 'node:path'
import { pathToFileURL } from 'node:url'

const { validateMigrationDiagnostics } = await import(
  pathToFileURL(resolve('packages/content/src/migration-diagnostic.ts')).href
)
const published = JSON.parse(readFileSync('projects/pal/content/migration-diagnostics.json', 'utf8'))
const entry = published.diagnostics.find((diagnostic: { target: { capability: string } }) => diagnostic.target.capability === 'use')
assert.ok(entry, 'PAL fixture has an item-use diagnostic')
assert.equal(validateMigrationDiagnostics({ version: 1, diagnostics: [entry] }).diagnostics[0].target.capability, 'use')
const changed = { ...entry, target: { ...entry.target, capability: ['use'] } }
const input = JSON.parse(JSON.stringify({ version: 1, diagnostics: [changed] }))
const accepted = validateMigrationDiagnostics(input)
console.log(JSON.stringify({ fixtureId: entry.id, legalControl: entry.target.capability, illegalAccepted: accepted.diagnostics[0].target.capability }))
assert.throws(() => validateMigrationDiagnostics(input), /target\.capability: 期望 equip\/use\/throw/)
