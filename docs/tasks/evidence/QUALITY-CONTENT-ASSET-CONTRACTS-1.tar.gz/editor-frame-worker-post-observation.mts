import {
  encodeFrameAnimationInWorker,
  quantizeFrameAnimationInWorker,
} from '/Users/zhangxu/.codex/worktrees/quality-94-102/type-pal/packages/editor/src/core/frame-animation-worker-client.ts'

const failure = new DOMException('Dispatch unavailable', 'OperationError')
let terminated = 0
class RejectedPlatformWorker {
  postMessage() { throw failure }
  terminate() { terminated++ }
}
Object.defineProperty(globalThis, 'Worker', { value: RejectedPlatformWorker })
const rgba = Uint8Array.of(8, 0, 0, 255).buffer
const operations = [
  () => encodeFrameAnimationInWorker({width: 1, height: 1, defaultFrameMs: 40, colorTreatment: 'preserve', frames: [{rgba}]}),
  () => quantizeFrameAnimationInWorker({width: 1, height: 1, colors: [[255, 0, 0]], mode: 'nearest', frames: [rgba]}),
]
for (const start of operations) {
  let sameFailure = false
  try { await start() } catch (cause) { sameFailure = cause === failure }
  console.log(JSON.stringify({sameFailure,terminated}))
  if (!sameFailure || terminated !== 0) process.exitCode = 1
}
