import { readFileSync } from 'node:fs'
import { resolve } from 'node:path'

const target = resolve('src/fsa-source.test.ts')
const tests = readFileSync(new URL('./fsa-url-ownership.spec.txt', import.meta.url), 'utf8')
export default {
  plugins: [{
    name: 'fsa-url-ownership-observation',
    enforce: 'pre',
    transform(source, id) {
      if (id.split('?')[0] === target) return source + tests
    },
  }],
}
