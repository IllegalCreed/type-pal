import { resolve } from 'node:path'
const target = resolve('src/scene-resources.ts')
const cap = 'const mapCacheCapacity = 16'
export default {
  plugins: [{
    name: 'scene-resource-size-counter',
    enforce: 'pre',
    transform(content, id) {
      if (id.split('?')[0] !== target) return
      if (content.split(cap).length !== 2) throw new Error('Expected one map completion limit')
      return content.replace(cap, 'const mapCacheCapacity = 17')
    },
  }],
}
