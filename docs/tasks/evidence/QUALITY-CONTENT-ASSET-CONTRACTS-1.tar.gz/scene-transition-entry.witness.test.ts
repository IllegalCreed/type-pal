import type { SceneDef } from '@type-pal/content'
import { expect, test } from 'vitest'
import { resolveSceneSpawn } from './scene-transition.js'

const scene = {
  entry: { pos: { col: 10, row: 20, height: 0 }, facing: 'down' },
  entries: { west: { pos: { col: 1, row: 2, height: 0 }, facing: 'up' } },
} satisfies Pick<SceneDef, 'entry' | 'entries'>

const constructorEntry = { pos: { col: 21, row: 31, height: 1 }, facing: 'right' } as const

test('a registered entry named constructor is resolved like any other author entry', () => {
  const withEntry = { ...scene, entries: { ...scene.entries, constructor: constructorEntry } }
  expect(resolveSceneSpawn('town', withEntry, { entryId: 'constructor' })).toEqual(constructorEntry)
})

test('an unregistered entry whose name matches a prototype key still fails as missing', () => {
  expect(() => resolveSceneSpawn('town', scene, { entryId: 'constructor' })).toThrow(
    '场景 town: 找不到命名落点 constructor',
  )
})
