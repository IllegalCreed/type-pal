import { createHash } from 'node:crypto'
import { resolve } from 'node:path'

const product = resolve('src/world-variable.ts')
const anchor = "`worldVariables.${rawId || '<empty>'}`"
export default {
  plugins: [{
    name: 'registry-entry-diagnostic-witness',
    enforce: 'pre',
    transform(source, id) {
      if (id.split('?')[0] !== product) return
      if (source.split(anchor).length !== 2) throw new Error('registry witness anchor moved')
      const patched = source.replace(anchor, '`worldVariables.${rawId}`')
      const sha = (text) => createHash('sha256').update(text).digest('hex')
      process.stdout.write(`REGISTRY_PATH_WITNESS ${sha(source)} ${sha(patched)}\n`)
      return patched
    },
  }],
}
