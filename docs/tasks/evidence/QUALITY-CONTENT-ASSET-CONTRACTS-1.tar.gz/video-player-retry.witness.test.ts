// @vitest-environment jsdom
import { expect, test, vi } from 'vitest'
import { playVideo } from './video-player.js'

test('a second gesture can retry the same video when the first gesture also failed', async () => {
  const owner = new AbortController()
  const container = document.createElement('section')
  document.body.append(container)
  const denial = new DOMException('gesture rejected', 'NotAllowedError')
  const play = vi
    .spyOn(HTMLMediaElement.prototype, 'play')
    .mockRejectedValueOnce(denial)
    .mockRejectedValueOnce(denial)
    .mockResolvedValue(undefined)
  vi.spyOn(HTMLMediaElement.prototype, 'pause').mockImplementation(() => {})
  const warn = vi.spyOn(console, 'warn').mockImplementation(() => {})
  const pending = playVideo({
    src: '/assets/opening.mp4',
    containerEl: container,
    signal: owner.signal,
  })
  try {
    await new Promise<void>((resolve) => setTimeout(resolve, 0))
    const prompt = container.querySelector('div')
    if (!prompt) throw new Error('autoplay denial did not display the gesture prompt')
    prompt.click()
    await new Promise<void>((resolve) => setTimeout(resolve, 0))
    expect(warn.mock.calls).toEqual(
      Array.from({ length: 2 }, () => [
        '[video-player] play() rejected (autoplay policy?): NotAllowedError: gesture rejected',
      ]),
    )
    expect(prompt.isConnected).toBe(true)
    prompt.click()
    await new Promise<void>((resolve) => setTimeout(resolve, 0))
    expect(play).toHaveBeenCalledTimes(3)
    expect(prompt.isConnected).toBe(false)
  } finally {
    owner.abort()
    await pending
    container.remove()
    vi.restoreAllMocks()
  }
})
