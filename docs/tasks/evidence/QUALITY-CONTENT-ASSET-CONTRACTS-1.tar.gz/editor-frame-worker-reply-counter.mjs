import { resolve } from 'node:path'
const target = resolve('src/core/frame-animation-worker-client.ts')
const guard = 'if (event.data.id !== id) return'
export default {
  plugins: [{
    name: 'frame-worker-ignore-foreign-reply-counter',
    enforce: 'pre',
    transform(content, id) {
      if (id.split('?')[0] !== target) return
      if (content.split(guard).length !== 3) throw new Error('Expected one guard per operation')
      return content.replace(guard, 'void id')
    },
  }],
}
