import { resolve } from 'node:path'
const target = resolve('src/core/frame-animation-codec.worker.ts')
const original = 'quantizeFrameAnimationRequest(request)'
export default {
  plugins: [{
    name: 'frame-worker-drop-quantization-mode-counter',
    enforce: 'pre',
    transform(content, id) {
      if (id.split('?')[0] !== target) return
      if (content.split(original).length !== 2) throw new Error('Expected one quantization dispatch')
      return content.replace(original, "quantizeFrameAnimationRequest({ ...request, mode: 'nearest' })")
    },
  }],
}
