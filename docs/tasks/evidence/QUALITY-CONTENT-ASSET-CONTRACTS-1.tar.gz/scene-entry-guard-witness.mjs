import { resolve } from 'node:path'

const source = resolve('src/script.ts')
const line = "if (safety !== 'safe')"
export default {
  plugins: [{
    name: 'scene-entry-shop-counter',
    enforce: 'pre',
    transform(content, id) {
      if (id.split('?')[0] !== source) return
      if (content.split(line).length !== 2) throw new Error(`Expected one scene entry safety check: ${id}`)
      return content.replace(line, "if (safety !== 'safe' && kind !== 'openShop')")
    },
  }],
}
