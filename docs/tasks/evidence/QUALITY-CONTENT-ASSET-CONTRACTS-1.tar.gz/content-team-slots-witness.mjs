import { createHash } from 'node:crypto'
import { resolve } from 'node:path'

const product = resolve('src/enemy-team.ts')
const guard = "    if (!Array.isArray(team.slots)) throw new Error(`${path}.slots: 期望数组`)\n"
export default {
  plugins: [{
    name: 'enemy-team-slots-diagnostic-witness',
    enforce: 'pre',
    transform(source, id) {
      if (id.split('?')[0] !== product) return
      if (source.split(guard).length !== 2) throw new Error('enemy-team witness anchor moved')
      const patched = source.replace(guard, '')
      const sha = (text) => createHash('sha256').update(text).digest('hex')
      process.stdout.write(`TEAM_SLOTS_WITNESS ${sha(source)} ${sha(patched)}\n`)
      return patched
    },
  }],
}
