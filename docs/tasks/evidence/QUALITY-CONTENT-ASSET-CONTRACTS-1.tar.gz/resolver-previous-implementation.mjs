import { execFileSync } from 'node:child_process'
import { createHash } from 'node:crypto'
const root = "/Users/zhangxu/.codex/worktrees/quality-94-102/type-pal"
const file = 'packages/reforge/src/asset-resolver.ts'
const base = '701b34334dd4b07d72c2d88180c67cb693f076fa'
export default {
  plugins: [{
    name: 'previous-asset-resolver',
    enforce: 'pre',
    transform(source, id) {
      if (id.split('?')[0] !== `${root}/${file}`) return
      const prior = execFileSync('git', ['show', `${base}:${file}`], {cwd:root,encoding:'utf8'})
      const hash = (value) => createHash('sha256').update(value).digest('hex')
      process.stdout.write(`RESOLVER_PREVIOUS_VARIANT ${hash(source)} ${hash(prior)}\n`)
      return prior
    },
  }],
}
