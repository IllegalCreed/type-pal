import { resolve } from 'node:path'

const source = resolve('src/project-image-cache.ts')
const verb = 'type: record.mediaType'
export default {
  plugins: [{
    name: 'project-image-catalog-media-type-counter',
    enforce: 'pre',
    transform(content, id) {
      if (id.split('?')[0] !== source) return
      if (content.split(verb).length !== 2) throw new Error('Expected one Blob catalog media type')
      return content.replace(verb, "type: 'image/png'")
    },
  }],
}
