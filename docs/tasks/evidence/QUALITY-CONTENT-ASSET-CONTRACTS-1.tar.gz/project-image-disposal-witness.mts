import assert from 'node:assert/strict'
import { resolve } from 'node:path'
import { pathToFileURL } from 'node:url'

const moduleAt = (file: string) => pathToFileURL(resolve('src', file)).href
const { AssetResolver } = await import(moduleAt('asset-resolver.ts'))
const { ProjectImageCache } = await import(moduleAt('project-image-cache.ts'))
const { validateAssetCatalog } = await import(moduleAt('../../content/src/index.ts'))

function deferred<T>() {
  let finish!: (value: T) => void
  const promise = new Promise<T>((resolve) => { finish = resolve })
  return { finish, promise }
}

function harness() {
  const bytes = Uint8Array.from(
    atob('R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7'),
    (char) => char.charCodeAt(0),
  )
  const asset = 'portrait.animated'
  const path = 'assets/authored/portrait.animated.gif'
  const records = validateAssetCatalog({ version: 1, assets: { [asset]: {
    kind: 'portrait', path, mediaType: 'image/gif', bytes: bytes.length,
    sha256: 'ef1955ae757c8b966c83248350331bd3a30f658ced11f387f8ebf05ab3368629', origin: { kind: 'authored' },
  } } })
  const reads: string[] = []
  const cache = new ProjectImageCache(new AssetResolver('asset-witness', records, {}, {
    async readText() { throw new Error('unexpected text read') },
    async readJson<T>(): Promise<T> { throw new Error('unexpected JSON read') },
    async urlFor() { throw new Error('unexpected URL creation') },
    async readBytes(requested: string) {
      assert.equal(requested, path)
      reads.push(requested)
      return bytes.slice().buffer
    },
  }))
  const firstEntered = deferred<Blob>()
  const secondEntered = deferred<Blob>()
  const firstDecode = deferred<ImageBitmap>()
  const secondDecode = deferred<ImageBitmap>()
  let decodes = 0
  const previous = Object.getOwnPropertyDescriptor(globalThis, 'createImageBitmap')
  Object.defineProperty(globalThis, 'createImageBitmap', {
    configurable: true,
    value: (blob: Blob) => {
      const first = ++decodes === 1
      const entered = first ? firstEntered : secondEntered
      entered.finish(blob)
      return (first ? firstDecode : secondDecode).promise
    },
  })
  const bitmap = () => {
    let closures = 0
    return { width: 1, height: 1, close() { closures++ }, get closures() { return closures } }
  }
  return { cache, bitmap, load: () => cache.load(asset, 'portrait'), firstEntered, secondEntered,
    firstDecode, secondDecode, reads,
    restore() {
      if (previous) Object.defineProperty(globalThis, 'createImageBitmap', previous)
      else Reflect.deleteProperty(globalThis, 'createImageBitmap')
    },
  }
}

const replaced = harness()
let oldClosures: number, newClosures: number
try {
  const first = replaced.load()
  await replaced.firstEntered.promise
  replaced.cache.dispose()
  const second = replaced.load()
  await replaced.secondEntered.promise
  const old = replaced.bitmap(), current = replaced.bitmap()
  replaced.firstDecode.finish(old)
  replaced.secondDecode.finish(current)
  const resumed = await Promise.all([first, second])
  assert.equal(resumed[0], old)
  assert.equal(resumed[1], current)
  assert.equal(replaced.reads.length, 2)
  replaced.cache.dispose()
  oldClosures = old.closures
  newClosures = current.closures
} finally { replaced.restore() }

const stopped = harness()
let lateClosures: number, cachedAfterStop: boolean
try {
  const first = stopped.load()
  await stopped.firstEntered.promise
  stopped.cache.dispose()
  stopped.cache.dispose()
  const late = stopped.bitmap()
  stopped.firstDecode.finish(late)
  await first.catch(() => undefined)
  lateClosures = late.closures
  // Fixed implementations may reject an obsolete result or return a freshly decoded one.
  const next = stopped.load()
  stopped.secondDecode.finish(stopped.bitmap())
  cachedAfterStop = (await next.catch(() => undefined)) === late
  stopped.cache.dispose()
} finally { stopped.restore() }

const result = { oldClosures, newClosures, lateClosures, cachedAfterStop }
console.log(JSON.stringify(result))
assert.deepEqual(result, { oldClosures: 1, newClosures: 1, lateClosures: 1, cachedAfterStop: false })
