import assert from 'node:assert/strict'
import {
  collectAssetReferences,
  validateAssetCatalog,
  validateAuthorScenes,
} from '/Users/zhangxu/.codex/worktrees/quality-94-102/type-pal/packages/content/src/index.ts'
import { collectEditorAssetDiagnostics } from '/Users/zhangxu/.codex/worktrees/quality-94-102/type-pal/packages/editor/src/core/asset-diagnostics.ts'

const scene = {
  id: 'hall',
  mapId: 'hall-map',
  entry: { pos: { col: 0, row: 0, height: 0 }, facing: 'down' },
  entities: [],
  music: 'constructor',
} as const

// This is a structurally current author scene with a dangling catalog reference.
validateAuthorScenes([scene])
const references = collectAssetReferences({
  scenes: [{ ...scene, entities: [] }],
})
const dangling = collectEditorAssetDiagnostics(validateAssetCatalog({ version: 1, assets: {} }), references)
assert.equal(dangling.length, 1)
assert.equal(dangling[0]?.code, 'kind-mismatch')
assert.equal(dangling[0]?.actualKind, undefined)
const own = validateAssetCatalog({
  version: 1,
  assets: {
    ['constructor']: {
      kind: 'music',
      path: 'assets/authored/music/hall.mid',
      mediaType: 'audio/midi',
      bytes: 3,
      sha256: 'a'.repeat(64),
      origin: { kind: 'authored' },
    },
  },
})
assert.deepEqual(collectEditorAssetDiagnostics(own, references), [])
console.log(JSON.stringify({missingOwnRecord:dangling,explicitOwnRecordIssues:[]},null,2))
