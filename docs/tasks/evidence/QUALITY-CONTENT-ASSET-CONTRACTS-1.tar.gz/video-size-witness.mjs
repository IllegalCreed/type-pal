import { execFileSync } from 'node:child_process'
import { createHash } from 'node:crypto'

const root = "/Users/zhangxu/.codex/worktrees/quality-94-102/type-pal"
const base = '701b34334dd4b07d72c2d88180c67cb693f076fa'
const directory = 'packages/editor/src/core'
const target = `${root}/${directory}/video-metadata.ts`
const needle = 'else if (size === 0) size = end - offset'
const mutation = "else if (size === 0) size = type === 'ftyp' ? 20 : end - offset"

export default {
  plugins: [{
    name: 'zero-size-ftyp-witness',
    enforce: 'pre',
    transform(code, id) {
      const file = id.split('?')[0]
      if (file === target) {
        if (code.split(needle).length !== 2) throw new Error('size witness anchor moved')
        const mutant = code.replace(needle, mutation)
        const sha256 = (text) => createHash('sha256').update(text).digest('hex')
        process.stdout.write(`VIDEO_SIZE_WITNESS_APPLIED ${sha256(code)} ${sha256(mutant)}\n`)
        return mutant
      }
      if (
        process.env.TYPE_PAL_VIDEO_SIZE_WITNESS_INPUT === 'baseline' &&
        file === `${root}/${directory}/video-metadata.test.ts`
      ) return execFileSync('git', ['show', `${base}:${directory}/video-metadata.test.ts`], {cwd:root,encoding:'utf8'})
    },
  }],
}
