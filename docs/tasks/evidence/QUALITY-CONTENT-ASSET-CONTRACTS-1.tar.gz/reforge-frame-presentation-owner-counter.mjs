import { resolve } from 'node:path'
const target = resolve('src/frame-animation-presentation.ts')
const old = 'if (!this.isCurrent(owner) || !this.#playing) return false'
export default {
  plugins: [{
    name: 'frame-presentation-late-publish-counter',
    enforce: 'pre',
    transform(content, id) {
      if (id.split('?')[0] !== target) return
      if (content.split(old).length !== 2) throw new Error('Expected only one frame publication guard')
      return content.replace(old, 'if (!this.isCurrent(owner)) return false')
    },
  }],
}
