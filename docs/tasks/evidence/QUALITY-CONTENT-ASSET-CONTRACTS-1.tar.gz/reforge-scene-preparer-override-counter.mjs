import { resolve } from 'node:path'
const target = resolve('src/scene-preparer.ts')
const ownedDef = '{ def: structuredClone(def) }'
export default {
  plugins: [{
    name: 'scene-preparer-borrowed-override-counter',
    enforce: 'pre',
    transform(content, id) {
      if (id.split('?')[0] !== target) return
      if (content.split(ownedDef).length !== 2) throw new Error('Expected one owned override definition')
      return content.replace(ownedDef, '{ def }')
    },
  }],
}
