import { resolve } from 'node:path'

const source = resolve('src/validate.ts')
const condition = 'if (!entryId) throw new Error('
export default {
  plugins: [{
    name: 'named-entry-required-id-counter',
    enforce: 'pre',
    transform(content, id) {
      if (id.split('?')[0] !== source) return
      if (content.split(condition).length !== 2) throw new Error('Expected one named-entry ID guard')
      return content.replace(condition, 'if (false) throw new Error(')
    },
  }],
}
