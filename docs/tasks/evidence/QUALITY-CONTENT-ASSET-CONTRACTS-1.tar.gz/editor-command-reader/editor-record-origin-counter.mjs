import { resolve } from 'node:path'
const target = resolve('src/core/command-asset-record.ts')
const expression = 'left.origin.ref === right.origin.ref'
export default {
  plugins: [{
    name: 'editor-record-origin-counter',
    enforce: 'pre',
    transform(content, id) {
      if (id.split('?')[0] !== target) return
      if (content.split(expression).length !== 2) throw new Error('Expected one origin reference comparison')
      return content.replace(expression, 'true')
    },
  }],
}
