import { resolve } from 'node:path'
const target = resolve('src/core/editor-asset-reader.ts')
const expression = 'pending ? pending.slice(0) :'
export default {
  plugins: [{
    name: 'editor-reader-copy-counter',
    enforce: 'pre',
    transform(content, id) {
      if (id.split('?')[0] !== target) return
      if (content.split(expression).length !== 2) throw new Error('Expected one unsaved bytes detachment')
      return content.replace(expression, 'pending ? pending :')
    },
  }],
}
