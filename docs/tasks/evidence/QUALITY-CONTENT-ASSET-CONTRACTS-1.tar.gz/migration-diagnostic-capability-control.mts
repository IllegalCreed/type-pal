import { strict as assert } from 'node:assert'
import { resolve } from 'node:path'
import { pathToFileURL } from 'node:url'

const { validateMigrationDiagnostics } = await import(
  pathToFileURL(resolve('packages/content/src/migration-diagnostic.ts')).href
)
const legal = {
  id: 'item-use:267', severity: 'warn', reason: '剧情用途仍需人工确认', category: 'story-script',
  target: { domain: 'item', objectId: '267', capability: 'use', label: '土灵珠' },
  source: { kind: 'legacy-script', label: 'L_39805', address: 39805 },
}
const valid = { version: 1, diagnostics: [legal] }
assert.equal(validateMigrationDiagnostics(valid), valid)
const changed = { ...legal, target: { ...legal.target, capability: ['use'] } }
const input = JSON.parse(JSON.stringify({ version: 1, diagnostics: [changed] }))
const accepted = validateMigrationDiagnostics(input)
console.log(JSON.stringify({ fixture: 'synthetic current sidecar schema', legalControl: legal.target.capability, illegalAccepted: accepted.diagnostics[0].target.capability }))
assert.throws(() => validateMigrationDiagnostics(input), /target\.capability: 期望 equip\/use\/throw/)
