import { resolve } from 'node:path'
const target = resolve('src/frame-animation-player.ts')
const cleanup = "target?.removeEventListener('keydown', onKey, true)"
export default {
  plugins: [{
    name: 'frame-preview-listener-lifetime-counter',
    enforce: 'pre',
    transform(content, id) {
      if (id.split('?')[0] !== target) return
      if (content.split(cleanup).length !== 2) throw new Error('Expected one preview key listener removal')
      return content.replace(cleanup, 'void target')
    },
  }],
}
