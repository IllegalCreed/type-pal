import { resolve } from 'node:path'
const target = resolve('src/core/frame-animation-draft.ts')
const cases = {
  history: ['present: draft,\n    future: [],', 'present: draft,\n    future: history.future,'],
  spread: ['spread(x, y + 1, er, eg, eb, 5 / 16)', 'spread(x, y + 1, er, eg, eb, 0)'],
}
const counterpart = Object.getOwnPropertyDescriptor(cases, process.env.TYPE_PAL_DRAFT_COUNTER)?.value
if (!counterpart) throw new Error('Choose history or spread via TYPE_PAL_DRAFT_COUNTER')
export default {
  plugins: [{
    name: 'one-frame-draft-counter-axis',
    enforce: 'pre',
    transform(content, id) {
      if (id.split('?')[0] !== target) return
      if (content.split(counterpart[0]).length !== 2) throw new Error('Expected one designated site')
      return content.replace(...counterpart)
    },
  }],
}
