import { resolve } from 'node:path'

const source = resolve('src/dialog/dialog-assets.ts')
const verb = 'if (opaque[i]) {'
export default {
  plugins: [{
    name: 'dialog-cursor-opacity-counter',
    enforce: 'pre',
    transform(content, id) {
      if (id.split('?')[0] !== source) return
      if (content.split(verb).length !== 2) throw new Error('Expected one opacity-mask branch')
      return content.replace(verb, 'if (frame.pixels[i]) {')
    },
  }],
}
