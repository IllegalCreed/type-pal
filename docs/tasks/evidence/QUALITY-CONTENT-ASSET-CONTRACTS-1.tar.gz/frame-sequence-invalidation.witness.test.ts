import { encodeFrameSequence } from '@type-pal/content'
import { expect, test } from 'vitest'
import { decompressFrameSequenceBlock, FrameSequenceReader } from './frame-animation-player.js'

async function sequenceWithPixel(red: number): Promise<ArrayBuffer> {
  const bytes = await encodeFrameSequence(
    {
      width: 1,
      height: 1,
      defaultFrameMs: 40,
      frames: [{ rgba: Uint8Array.of(red, 0, 0, 255) }],
    },
    async (raw) =>
      new Uint8Array(
        await new Response(
          new Blob([Uint8Array.from(raw).buffer])
            .stream()
            .pipeThrough(new CompressionStream('deflate')),
        ).arrayBuffer(),
      ),
  )
  return Uint8Array.from(bytes).buffer
}

test('an in-flight old revision cannot overwrite an already decoded replacement for the same asset', async () => {
  const entered = Promise.withResolvers<void>()
  const release = Promise.withResolvers<void>()
  let bytes = await sequenceWithPixel(1)
  let inflations = 0
  const reader = new FrameSequenceReader(
    { readBytes: async () => bytes },
    async (compressed) => {
      if (++inflations === 1) {
        entered.resolve()
        await release.promise
      }
      return decompressFrameSequenceBlock(compressed)
    },
  )
  const old = reader.frame('opening', 0)
  try {
    await entered.promise
    bytes = await sequenceWithPixel(9)
    reader.invalidate('opening')
    expect([...(await reader.frame('opening', 0)).rgba]).toEqual([9, 0, 0, 255])
    release.resolve()
    expect([...(await old).rgba]).toEqual([1, 0, 0, 255])
    expect([...(await reader.frame('opening', 0)).rgba]).toEqual([9, 0, 0, 255])
  } finally {
    release.resolve()
    await old.catch(() => undefined)
  }
})
