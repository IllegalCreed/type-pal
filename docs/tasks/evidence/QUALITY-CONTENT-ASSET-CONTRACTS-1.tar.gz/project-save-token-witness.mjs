import { resolve } from 'node:path'

const target = resolve('src/project-save-state.ts')
const base = 'return JSON.stringify(state)'
export default {
  plugins: [{
    name: 'save-plan-token-counter',
    enforce: 'pre',
    transform(content, id) {
      if (id.split('?')[0] !== target) return
      if (content.split(base).length !== 2) throw new Error(`Missing token return in ${id}`)
      return content.replace(base, 'return JSON.stringify(state && { ...state, planHash: undefined })')
    },
  }],
}
