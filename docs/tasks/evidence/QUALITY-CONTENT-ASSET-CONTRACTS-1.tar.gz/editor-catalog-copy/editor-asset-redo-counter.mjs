import { resolve } from 'node:path'

const source = resolve('src/core/asset-commands.ts')
const verb = 'if (references.length) throw new AssetInUseError'
export default {
  plugins: [{
    name: 'editor-asset-redo-counter',
    enforce: 'pre',
    transform(content, id) {
      if (id.split('?')[0] !== source) return
      if (content.split(verb).length !== 2) throw new Error('Expected one deletion blocker')
      return content.replace(verb, 'if (!this.oldCatalog && references.length) throw new AssetInUseError')
    },
  }],
}
