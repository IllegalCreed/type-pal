import { resolve } from 'node:path'

const source = resolve('src/core/project-copy-source.ts')
const verb = 'signatures.set(path, null)'
export default {
  plugins: [{
    name: 'editor-copy-absence-counter',
    enforce: 'pre',
    transform(content, id) {
      if (id.split('?')[0] !== source) return
      if (content.split(verb).length !== 2) throw new Error('Expected one absent-file observation')
      return content.replace(verb, 'void path')
    },
  }],
}
