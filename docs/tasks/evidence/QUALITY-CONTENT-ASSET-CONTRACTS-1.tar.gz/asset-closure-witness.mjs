import { execFileSync } from 'node:child_process'
import { createHash } from 'node:crypto'
import { join } from 'node:path'

const root = "/Users/zhangxu/.codex/worktrees/quality-94-102/type-pal"
const base = '701b34334dd4b07d72c2d88180c67cb693f076fa'
const contentPath = 'packages/content/src'
const names = new Set([
  'asset-catalog.contracts.test.ts',
  'asset-closure.contracts.test.ts',
  'asset.test.ts',
])
const product = join(root, contentPath, 'asset.ts')
const removeWarning = '  for (const id of Object.keys(catalog.assets)) {'

export default {
  plugins: [{
    name: 'closure-warning-witness',
    enforce: 'pre',
    transform(source, id) {
      const physical = id.split('?')[0]
      if (physical === product) {
        if (source.split(removeWarning).length !== 2) throw new Error('closure witness anchor moved')
        const patched = source.replace(
          removeWarning,
          "  if (issues.some(({ code }) => code === 'kind-mismatch')) return issues\n" + removeWarning,
        )
        const sha256 = (bytes) => createHash('sha256').update(bytes).digest('hex')
        process.stdout.write(`CLOSURE_WITNESS_APPLIED ${sha256(source)} ${sha256(patched)}\n`)
        return patched
      }
      if (process.env.TYPE_PAL_CLOSURE_WITNESS_INPUT !== 'baseline') return
      const path = [...names].find((name) => physical === join(root, contentPath, name))
      if (path) return execFileSync('git', ['show', `${base}:${contentPath}/${path}`], { cwd: root, encoding: 'utf8' })
    },
  }],
}
