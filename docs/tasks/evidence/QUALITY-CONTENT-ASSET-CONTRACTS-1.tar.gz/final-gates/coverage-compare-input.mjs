import { readFileSync, writeFileSync, existsSync } from 'node:fs'
import { createHash } from 'node:crypto'
import { pathToFileURL } from 'node:url'
import { resolve } from 'node:path'
import { execFileSync } from 'node:child_process'
const root = '/tmp/type-pal-content-pending.qRsITi'
const base = '701b34334dd4b07d72c2d88180c67cb693f076fa'
const { auditScope } = await import(pathToFileURL(resolve('scripts/coverage/inventory.mjs')))
const { compareCoverage, metricNames } = await import(pathToFileURL(resolve('scripts/coverage/metrics.mjs')))
const sha = (bytes) => createHash('sha256').update(bytes).digest('hex')
const read=(path)=>JSON.parse(readFileSync(path,'utf8'))
const baseline=JSON.parse(execFileSync('git',['show',`${base}:scripts/coverage/baseline.fast.json`]))
const observed=read('coverage/fast/summary.json')
const loaded=read(`${root}/main-69-coverage-native/summary.json`)
const state=(value)=>Object.fromEntries(metricNames.map(m=>[m,{covered:value[m].covered,total:value[m].total}]))
function assertSame(a,b,reason){
 if(JSON.stringify(a)!==JSON.stringify(b)) throw Error(reason)
}
const diff={}
for (const id of Object.keys(baseline.packages)) {
 const oldFile=`${root}/main-69-coverage-native/${id}/coverage-summary.json`
 const newFile=`coverage/fast/${id}/coverage-summary.json`
 const trimmed=(s)=>Object.fromEntries(Object.entries(s).filter(([p])=>p!=='total').map(([p,m])=>[p.split(`/packages/${id}/`).at(-1),state(m)]))
 const oldFull=read(oldFile), newFull=read(newFile)
 assertSame(state(oldFull.total),baseline.packages[id].metrics,`official artifact differs from protected ${id}`)
 assertSame(state(loaded.packages[id].metrics),baseline.packages[id].metrics,`CI summary differs from protected ${id}`)
 assertSame(state(newFull.total),observed.packages[id].metrics,`local per-file result differs ${id}`)
 const old=trimmed(oldFull), current=trimmed(newFull)
 diff[id]={
  files:Object.fromEntries([...new Set([...Object.keys(old),...Object.keys(current)])].sort().filter(p=>JSON.stringify(old[p])!==JSON.stringify(current[p])).map(p=>[p,{before:old[p]??null,after:current[p]??null}])),
  mainSummarySha256:sha(readFileSync(oldFile)),candidateSummarySha256:sha(readFileSync(newFile)),
 }
}
const { changes, removals }=auditScope(observed,baseline)
const sha256Map=Object.fromEntries(removals.filter(r=>r.kind==='test-count').map(r=>[r.value,sha(readFileSync(r.value))]))
const earlier=Object.values(baseline.packages).flatMap(p=>p.fastTests.fileEntries)
const afterward=Object.values(observed.packages).flatMap(p=>p.fastTests.fileEntries)
const testRetirements=removals.filter(r=>r.kind==='test-count').map(r=>({
 file:r.value,
 previous:r.previous,
 current:r.current,
 previousIdentityDigest:earlier.find(f=>f.file===r.value)?.identityDigest,
 currentIdentityDigest:afterward.find(f=>f.file===r.value)?.identityDigest,
 fileSha256:sha256Map[r.value],
}))
if(removals.some(r=>['source','package','test-file'].includes(r.kind)&&existsSync(r.value))) throw Error('an existing source/test disappeared from selection')
const comparison=compareCoverage(observed,baseline)
const report={base,artifact:'https://github.com/IllegalCreed/type-pal/actions/runs/44468724330',baselineSha256:sha(JSON.stringify(baseline)),counts:{before:baseline.testCount,after:observed.testCount},sources:{before:baseline.sourceFileCount,after:observed.sourceFileCount},beforeTotal:baseline.total,afterTotal:observed.total,comparison,scope:{changes,removals},testRetirements,diff}
writeFileSync(`${root}/window-coverage-comparison.json`,JSON.stringify(report,null,2)+'\n')
console.log(JSON.stringify({coverage:comparison,scope:changes,removals:removals.length,testRetirements},null,2))
