import assert from 'node:assert/strict'
import { execFileSync } from 'node:child_process'
import { createHash } from 'node:crypto'
import { readFileSync } from 'node:fs'
import { resolve } from 'node:path'
import { pathToFileURL } from 'node:url'

const approved = 'scripts/coverage/approved-baseline-adjustments.mjs'
const { adjustApprovedBaseline } = await import(pathToFileURL(resolve(approved)))
const sha = (bytes) => createHash('sha256').update(bytes).digest('hex')
const base = '701b34334dd4b07d72c2d88180c67cb693f076fa'
const baseline = JSON.parse(execFileSync('git', ['show', `${base}:scripts/coverage/baseline.fast.json`]))
const anchored = [
  'packages/content/src/validate.ts',
  'packages/editor/src/core/command-asset-record.ts',
  'packages/editor/src/core/clone.ts',
  'packages/editor/src/core/frame-animation-codec.ts',
  'packages/editor/src/core/frame-animation-worker-client.ts',
]
const actual = await adjustApprovedBaseline(baseline, readFileSync)
assert.deepEqual(actual.applied, ['content-assets-structural-recount-20261119'])
for (const path of anchored) {
  await assert.rejects(
    adjustApprovedBaseline(baseline, candidate =>
      candidate === path ? Buffer.concat([readFileSync(candidate), Buffer.from('\n')]) : readFileSync(candidate),
    ),
    error => error.message === `覆盖率结构调整源码已变化，拒绝沿用授权: ${path}`,
  )
}
console.log(JSON.stringify({base, approvedSha256: sha(readFileSync(approved)), active: actual.applied, pathsWithExactMismatchChecks: anchored}, null, 2))
