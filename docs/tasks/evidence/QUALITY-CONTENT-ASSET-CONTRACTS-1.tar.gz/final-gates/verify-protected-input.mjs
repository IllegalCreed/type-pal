import assert from 'node:assert/strict'
import {readFileSync,existsSync} from 'node:fs'
import {execFileSync} from 'node:child_process'
import {createHash} from 'node:crypto'
import {resolve} from 'node:path'
import {pathToFileURL} from 'node:url'
const parse=(p)=>JSON.parse(readFileSync(p))
const load=(p)=>import(pathToFileURL(resolve(p)))
const {auditScope}=await load('scripts/coverage/inventory.mjs')
const {compareCoverage}=await load('scripts/coverage/metrics.mjs')
const {adjustApprovedBaseline}=await load('scripts/coverage/approved-baseline-adjustments.mjs')
const {isApprovedTestRetirement}=await load('scripts/coverage/approved-test-retirements.mjs')
const base=execFileSync('git',['rev-parse','origin/main'],{encoding:'utf8'}).trim()
const prior=JSON.parse(execFileSync('git',['show',base+':scripts/coverage/baseline.fast.json']))
const candidate=parse('scripts/coverage/baseline.fast.json')
const fresh=parse('coverage/fast/summary.json')
const records=[[],[]]
assert.deepEqual(candidate.provider,fresh.provider)
assert.deepEqual(candidate.provider,prior.provider)
assert.equal(candidate.testCount,fresh.testCount)
assert.deepEqual(compareCoverage(fresh,candidate),{regressions:[],improvements:[]})
assert.deepEqual(auditScope(fresh,candidate),{changes:[],removals:[]})
const {baseline:floor,applied}=await adjustApprovedBaseline(prior,readFileSync)
assert.deepEqual(applied,['content-assets-structural-recount-20261119'])
assert.deepEqual(compareCoverage(candidate,floor).regressions,[])
const { changes,removals }=auditScope(candidate,prior)
const entry=(basis,p)=>Object.values(basis.packages).flatMap(v=>v.fastTests.fileEntries).find(v=>v.file===p)
for (const row of removals) {
  if(row.kind==='test-count'){
    const fileSha256=createHash('sha256').update(readFileSync(row.value)).digest('hex')
    assert.equal(isApprovedTestRetirement({removal:row,previous:entry(prior,row.value),current:entry(candidate,row.value),fileSha256}),true,row.value)
    records[0].push(row)
  }else{
    assert.equal(row.kind,'test-file',row.value)
    assert.equal(existsSync(row.value),false,row.value)
    records[1].push(row.value)
  }
}
console.log(JSON.stringify({base,priorTests:prior.testCount,candidateTests:candidate.testCount,sourceFiles:candidate.sourceFileCount,approvedAdjustments:applied,remainingRegressions:[],scopeChanges:changes,exactRetirements:records[0],removedTestPaths:records[1],verification:'read-only comparison of actual ratchet output and upstream; the GitHub official protected fast run is separate'},null,2))
