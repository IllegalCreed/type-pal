const { readFileSync, writeFileSync } = require('node:fs')
const { execFileSync } = require('node:child_process')
const path = require('node:path')
const ts = require(path.resolve('node_modules/typescript'))
const index = JSON.parse(readFileSync(process.argv[2], 'utf8'))
const names = new Set([ ...index.completed.map((row) => row.path), ...index.review ])
const kinds = new Set([
  ts.SyntaxKind.IfStatement,
  ts.SyntaxKind.ConditionalExpression,
  ts.SyntaxKind.CaseClause,
  ts.SyntaxKind.ForStatement,
  ts.SyntaxKind.ForOfStatement,
  ts.SyntaxKind.ForInStatement,
  ts.SyntaxKind.WhileStatement,
  ts.SyntaxKind.DoStatement,
  ts.SyntaxKind.CatchClause,
])
const junctions = new Set([ts.SyntaxKind.AmpersandAmpersandToken, ts.SyntaxKind.BarBarToken, ts.SyntaxKind.QuestionQuestionToken])
const complexity = []
const byFingerprint = new Map()
function tokenStream(statement) {
  if (ts.isFunctionDeclaration(statement)) return ''
  const s = ts.createScanner(ts.ScriptTarget.Latest, true, ts.LanguageVariant.Standard, statement.getText())
  const out = []
  for (let kind = s.scan(); kind !== ts.SyntaxKind.EndOfFileToken; kind = s.scan()) out.push(s.getTokenText())
  return out.join('\x00')
}
for (const name of [...names].sort()) {
  const source = ts.createSourceFile(name, execFileSync('git', ['show', index.base+':'+name], {encoding:'utf8'}), ts.ScriptTarget.Latest, true)
  const line = (node) => source.getLineAndCharacterOfPosition(node.getStart(source)).line+1
  function walk(node) {
    if (ts.isFunctionLike(node) && node.body) {
      let score = 1
      function inspect(child) {
        if (ts.isFunctionLike(child)) return
        if (kinds.has(child.kind) || ts.isBinaryExpression(child) && junctions.has(child.operatorToken.kind)) score++
        ts.forEachChild(child, inspect)
      }
      inspect(node.body)
      if (score > 10) complexity.push({path:name,line:line(node),name:node.name?.getText(source)??'(closure)',branchScore:score})
    }
    if (ts.isBlock(node) && node.statements.length>=6) {
      const tokens = node.statements.map(tokenStream)
      for (let i=0;i<=tokens.length-6;i++) {
        const slice=tokens.slice(i,i+6)
        const key=slice.join('\x01')
        if (slice.some(x=>!x) || key.length<140) continue
        const loc={path:name,line:line(node.statements[i])}
        const locations=byFingerprint.get(key)??[]
        locations.push(loc)
        byFingerprint.set(key,locations)
      }
    }
    ts.forEachChild(node,walk)
  }
  walk(source)
}
const duplicates = [...byFingerprint.values()].filter(set=>new Set(set.map(x=>x.path)).size>1)
writeFileSync(process.argv[3], JSON.stringify({tool:'TypeScript '+ts.version,base:index.base,scanned:names.size,scope:'original files only; counts decisions excluding nested functions, token-identical six consecutive statements across files, no semantic duplication claims',complexity,duplicates},null,2)+'\n')
console.log(`${names.size} original files; ${complexity.length} branch-score leads; ${duplicates.length} duplicate token windows`)
