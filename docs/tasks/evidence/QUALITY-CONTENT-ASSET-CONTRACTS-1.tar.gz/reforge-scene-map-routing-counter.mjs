import { resolve } from 'node:path'
const target = resolve('src/scene-map.ts')
const entry = '[tilesetId, await loadTileset(base, resolveTilesetAsset(tilesetId, tilesets))]'
export default {
  plugins: [{
    name: 'scene-map-pairing-counter',
    enforce: 'pre',
    transform(content, id) {
      if (id.split('?')[0] !== target) return
      if (content.split(entry).length !== 2) throw new Error('Expected one tileset binding')
      return content.replace(entry, '[tilesetId, await loadTileset(base, resolveTilesetAsset(tilesetId === "inside" && map.tilesetRefs.length === 2 ? "outside" : tilesetId === "outside" && map.tilesetRefs.length === 2 ? "inside" : tilesetId, tilesets))]')
    },
  }],
}
