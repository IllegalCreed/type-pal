from pathlib import Path
import json,gzip,hashlib,subprocess,datetime
root=Path.cwd();p=root/'docs/ops/evidence/QUALITY-DOCS-GIT-PATH-ENUMERATION-1';before=json.loads((p/'before.json').read_text());old={r['path']:gzip.decompress((p/r['snapshot']).read_bytes()) for r in before['files']};current={path:Path(path).read_bytes() for path in old};spec='scripts/quality/code-quality-inventory.test.mjs';sha=lambda b:hashlib.sha256(b).hexdigest();rows=[]
try:
 for id,src,target in [('docs-default-buffer','scripts/docs/check.mjs','actual docs index CLI'),('inventory-default-buffer','scripts/quality/code-quality-inventory.mjs','actual quality inventory CLI')]:
  row={'id':id,'source':src,'sourceSha256':sha(current[src]),'mutantSha256':sha(old[src]),'expectedFailure':target,'runs':{}}
  for phase,body in [('old',old[spec]),('current',current[spec])]:
   label=id+'.'+phase;cmd=['node','--test','--test-reporter=tap',spec];start=datetime.datetime.now(datetime.timezone.utc).isoformat()
   try:
    Path(src).write_bytes(old[src]);Path(spec).write_bytes(body);r=subprocess.run(cmd,cwd=root,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);raw=r.stdout;s=raw.decode();(p/(label+'.raw.gz')).write_bytes(gzip.compress(raw,mtime=0));record={'command':cmd,'cwd':str(root),'startedAt':start,'completedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit':r.returncode,'signal':-r.returncode if r.returncode<0 else None,'spawnError':None,'raw':label+'.raw.gz','rawBytes':len(raw),'rawSha256':sha(raw),'nativeReporter':'Node TAP full unfiltered file','fullUncutMergedStdoutStderr':True,'specSha256':sha(body)};row['runs'][phase]=record;assert '# skipped 0' in s and '# cancelled 0' in s and '# todo 0' in s
    failures=[l for l in s.splitlines() if l.startswith('not ok ')];record['failedNames']=failures
    if phase=='old':assert r.returncode==0 and not failures and '# pass 1\n' in s
    else:assert r.returncode==1 and len(failures)==1 and target in failures[0] and '# pass 2\n' in s and '# fail 1\n' in s and "name: 'AssertionError'" in s and "code: 'ERR_ASSERTION'" in s
   finally:
    Path(src).write_bytes(current[src]);Path(spec).write_bytes(current[spec]);record=row['runs'].get(phase)
    if record:record.update(sourceRestoredSha256=sha(Path(src).read_bytes()),specRestoredSha256=sha(Path(spec).read_bytes()),restored=Path(src).read_bytes()==current[src] and Path(spec).read_bytes()==current[spec])
  rows.append(row);print(id+': original1 green, new2 green/1 specified AssertionError; restored',flush=True)
finally:
 for path,body in current.items():Path(path).write_bytes(body)
 (p/'controls.json').write_text(json.dumps({'base':before['base'],'controls':rows,'restored':all(Path(path).read_bytes()==body for path,body in current.items()),'scope':'Actual complete Node TAP test file per original/current spec with one actual source maxBuffer reverted. No fake Git or subprocess replacement.'},ensure_ascii=False,indent=2)+'\n');(p/'controls-producer.py.gz').write_bytes(gzip.compress(Path('/tmp/type-pal-enumeration-controls.py').read_bytes(),mtime=0))
assert len(rows)==2
