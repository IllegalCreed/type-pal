from pathlib import Path
import json,gzip,hashlib,subprocess
root=Path.cwd();p=root/'docs/ops/evidence/QUALITY-DOCS-GIT-PATH-ENUMERATION-1';base='6fde6d86cf9754e441de948c82ac99ebc1f480c8';sha=lambda b:hashlib.sha256(b).hexdigest();before=json.loads((p/'before.json').read_text());rows=[]
for path in [r['path'] for r in before['files']]+['scripts/docs/check.test.mjs','scripts/quality/code-quality-ledger.mjs','scripts/docs/git-document-source.mjs','scripts/docs/git-document-snapshot.mjs','scripts/quality/lint-zero.mjs','docs/ops/evidence/README.md']:
 b=Path(path).read_bytes();h=sha(b);name=h[:12]+'-'+Path(path).name+'.read.gz';(p/name).write_bytes(gzip.compress(b,mtime=0));rows.append({'path':path,'sha256':h,'lines':len(b.splitlines()),'ranges':[[1,len(b.splitlines())]],'fullRead':True,'snapshot':name,'phase':'Before metadata edits for evidence README; final code/caller bytes otherwise current'})
(p/'read-boundaries.json').write_text(json.dumps({'base':base,'rows':rows,'additionalPartialReads':{'scripts/docs/terminal-namespace.mjs':[[1,95],[180,330]],'scripts/docs/terminal-codec.test.mjs':[[1,100],[870,925]],'scripts/docs/config.mjs':[[1,80]]},'scope':'Three-code-file Git enumeration module slice; read of dependencies is not their semantic closure'},ensure_ascii=False,indent=2)+'\n')
(p/'README.md').write_text('''# Git完整路径枚举容量修复

Status: recorded
Owner: Codex（单Agent，自身源码/测试核证，不冒充第三方）
Date: 2026-10-18
Base: `6fde6d86cf9754e441de948c82ac99ebc1f480c8`
Branch: `codex/code-quality-3y`

## 前提与范围

id: QUALITY-DOCS-GIT-PATH-ENUMERATION-1；schemaVersion:1；status:recorded。[任务](../../tasks/QUALITY-DOCS-GIT-PATH-ENUMERATION-1.md)因3u/3w索引生成的真实ENOBUFS准入。三代码文件和真实CLI/ledger caller全文见[读取边界](read-boundaries.json)。当前战斗自有WIP十文件及证据/草稿已完整保存，路径与SHA清单另存；没有清理main/他Owner，没有新分支或恢复旧stash。战斗源码/测试不混入本提交。

## 根因与修复

Node22.23.2实际执行；[Node22官方文档](https://nodejs.org/download/release/v22.23.3/docs/api/child_process.html)说明execFileSync默认最大输出1MiB，超限会截断并失败。实测错误发生在Git完整路径响应、文档解析前；ledger虽给外层inventory JSON32MiB，也不能修内部Git默认1MiB。

两个入口分别给原始Git枚举指定有限16MiB，保留全部原参数、NUL分割、物理存在性/代码范围过滤与错误传播；容量选择与现有docs Git blob读取一致。没有缩清单、删证据、排除、ignore、强转、改诊断级别或吞异常。终态namespace固定4MiB不是普通工作树全路径容量，其实现与overflow测试原字节保留。

## 失败反例与判别力

原inventory测试全文保留，新2例共用真实Git夹具：5000个index-only合法路径令NUL输出>1MiB，末尾真实task与带空格/中文的源码物理存在；不创建数千文件、不fake Git/核心。复制实际消费者与依赖，独立临时Git/HEAD、隔离继承Git环境，t.after精确删除自有树。

[先红](red.json)：完整3例原1绿、新2个指定业务AssertionError，0skip/cancel/todo，两个子CLI真实ENOBUFS。修复后[全3绿](green.json)：任务索引包含尾task，改成非法状态仍精确拒绝/零stdout；库存精确两个源码路径、出口、直接依赖与生产caller，不以“输出包含某串”替代完整集合。

[必要性反控](controls.json)：每次只撤回一个入口的选项，完整旧1绿→完整新2绿1指定AssertionError；另一入口继续执行通过，源码/测试finally逐字节恢复。完整Node TAP/raw、命令/cwd/时间/exit/signal/spawn、源/测SHA均保存。未删除原例或改baseline/catalog。

## 账本与门

两个原closed工具重开review、原未列pending测试转review，0新增关闭。预计3316/259closed/92review/2965pending，以[门回执](gates.json)实际ledger为准；83卡53partial/30pending/0accept不变，本片只是治理工具前置，不借工具绿关闭任何产品。

必要门为质量工具相邻、文档工具与实际消费者、lint-zero/ledger/diff；全仓check、official coverage ratchet、protected fast按用户成本规则留大任务收尾，不合main。剩余风险是普通全路径超过16MiB时仍会明确失败；未证明任意规模或其它历史CLI容量已治理。完成本片提交推送后恢复3u/3w，校对保存SHA并重基其共享元数据；原全部83卡及94–102/editor目标继续。
''')
f=Path('docs/ops/audits/code-quality-file-ledger.md');s=f.read_text();head,tail=s.split('<!-- original-source-fenced:start -->',1);lines=head.splitlines()
for path in ['scripts/docs/check.mjs','scripts/quality/code-quality-inventory.mjs']:
 i=next(i for i,l in enumerate(lines) if l.startswith('| `'+path+'` |'));assert lines[i].split('|')[3].strip()=='已验证';lines[i]=f'| `{path}` | tool | review | [Git全路径容量修复](../evidence/QUALITY-DOCS-GIT-PATH-ENUMERATION-1/README.md)；全文/真实CLI，>1MiB合法路径先红后绿 | 完整NUL枚举有限16MiB；独立4MiB namespace不改，原检查策略保留，0新关闭 |'
path='scripts/quality/code-quality-inventory.test.mjs';assert not any(l.startswith('| `'+path+'` |') for l in lines);i=next(i for i,l in enumerate(lines) if l.startswith('| 文件 |'))+2
while lines[i].startswith('|'):i+=1
lines.insert(i,f'| `{path}` | test | review | [Git全路径容量修复](../evidence/QUALITY-DOCS-GIT-PATH-ENUMERATION-1/README.md)；原1保留+2真实Git/CLI尾部合同，先1绿2红后3绿 | 两枚旧1绿新2绿1指定AssertionError，临时Git隔离；相邻/统一门范围分开，不关闭 |');head='\n'.join(lines)+'\n';assert '当前已闭合核验：261；已读但待审：89；尚未逐文件核验：2,966；合计未闭合：3,055。' in head;head=head.replace('当前已闭合核验：261；已读但待审：89；尚未逐文件核验：2,966；合计未闭合：3,055。','当前已闭合核验：259；已读但待审：92；尚未逐文件核验：2,965；合计未闭合：3,057。');f.write_text(head+'<!-- original-source-fenced:start -->'+tail)
f=Path('docs/ops/tasks/QUALITY-DOCS-GIT-PATH-ENUMERATION-1.md');s=f.read_text().replace('Status: build\n','Status: review\n',1).replace('待先红后修；结果同提交写回。','先红1绿/2指定AssertionError，修后3绿；两枚必要性反控旧1绿→新2绿/1指定红且恢复。三路径仅review，必要静态门见本卡证据gates；全仓/coverage/protected未跑。');f.write_text(s)
f=Path('docs/ops/board.md');s=f.read_text();row='| QUALITY-DOCS-GIT-PATH-ENUMERATION-1 | [Git全路径枚举容量](tasks/QUALITY-DOCS-GIT-PATH-ENUMERATION-1.md) | review | Codex / 三文件窄修，待统一门 | 两真实CLI>1MiB先红后绿，完整枚举16MiB/固定namespace4MiB不变；随后接回3u/3w |\n';s=s.replace('| QUALITY-PRE94-RETROSPECTIVE-1 |',row+'| QUALITY-PRE94-RETROSPECTIVE-1 |',1);f.write_text(s)
f=Path('docs/ops/evidence/README.md');s=f.read_text().replace('全部83张编号卡为50 partial / 33 pending / 0整卡accept；历史证据不自动升格。','全部83张编号卡的当前进度见该证据入口；历史证据不自动升格。',1);s=s.replace('## 当前证据目录（逐目录入口）\n','## 当前证据目录（逐目录入口）\n\n- [QUALITY-DOCS-GIT-PATH-ENUMERATION-1](QUALITY-DOCS-GIT-PATH-ENUMERATION-1/README.md)\n',1);f.write_text(s)
f=Path('docs/ops/tasks/QUALITY-PRE94-RETROSPECTIVE-1.md');f.write_text(f.read_text()+'''\n### 2026-10-18 Git枚举前置工具修复\n\n3u/3w自有WIP已逐字节保存；其索引生成实际触发Git默认1MiB ENOBUFS，独立QUALITY-DOCS-GIT-PATH-ENUMERATION-1修两个枚举IO容量并加真实Git尾部反例，不改文档/ledger策略或终态namespace4MiB。三代码路径仅review，0新增关闭；83卡53/30/0accept不变，工具批提交推送后恢复3u/3w并重基共享元数据。详见[工具证据](../evidence/QUALITY-DOCS-GIT-PATH-ENUMERATION-1/README.md)，完整全仓/coverage/protected留大任务收尾。\n''')
Path('docs/ops/tasks/index.md').write_bytes(subprocess.check_output(['node','scripts/docs/check.mjs','--print-task-index']))
(p/'gates.json').write_text(json.dumps({'base':base,'status':'red/green/two controls recorded; final quality/docs/lint/ledger pending','tracked':3316,'closed':259,'review':92,'pending':2965,'newClosed':0,'reopened':2,'newReview':1,'pre94Cards':{'partial':53,'pending':30,'accept':0},'notRun':['whole repository check','official coverage ratchet','protected fast','product runtime','E2E','visual'],'mergeAllowed':False},ensure_ascii=False,indent=2)+'\n')
(p/'docs-producer.py.gz').write_bytes(gzip.compress(Path('/tmp/type-pal-enumeration-docs.py').read_bytes(),mtime=0));(p/'capture.py.gz').write_bytes(gzip.compress(Path('/tmp/type-pal-enumeration-capture.py').read_bytes(),mtime=0));(p/'parked-wip-manifest.json.gz').write_bytes(gzip.compress(Path('/tmp/type-pal-finalization-park-20261018/manifest.json').read_bytes(),mtime=0));print('Tool evidence/three review records, task/board/generated index and exact navigation updated; pre94 queue unchanged.')
