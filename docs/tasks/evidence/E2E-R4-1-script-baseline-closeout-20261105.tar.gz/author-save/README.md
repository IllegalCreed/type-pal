# 增量作者保存候选回执

任务：E2E-R4-1；作者 /root/ui_affordances；独立验收与中央文档/全仓门归根。

- Base：8e7ea5b3c5396ac953f975a0b3d1c3c119392f41
- 固定候选：ae97a6635150375a339553e8d6cf76f7f9e09e4b，分支 codex/editor-incremental-save
- 逐文件 A–H、源码 SHA、caller/合同映射、命令/退出及限制：receipt.json 的 files、executions、static。
- 原件清单：manifest.json；逐成员 path/bytes/SHA256，不自嵌 manifest 哈希。
- 最终相邻回归：regression.raw.txt + regression.json，14 文件 217 passed，0 failed/pending/todo。
- 有效负控：negative.patch、negative.execution.json、negative.raw.txt + negative.json；7 例中恰 1 指定写集合 AssertionError、6 passed、0 pending/todo；原源码精确恢复，negative-restored.raw.txt + JSON 为 7 passed。
- 静态：typecheck.raw.txt、biome-final.raw.txt、design-system.raw.txt、candidate-diff.raw.txt；editor typecheck、5 文件 Biome、DS 门与冻结差异零诊断。final-static.execution.json 含末次静态的精确时间与命令。

最初产品红例、fixture 输入修复和旧恢复注入点失败分别保留 before、before-valid、first-green 原件；不把非法夹具红计作反控。runtime 证据内容对应已固定 Git 对象 0073e22da6d77d37f9ce7b4fce13c57a135ecdf3，执行当时 HEAD 为 base、改动尚未提交。最终候选只追加捕获时刻注释与两处规范范围澄清，无控制流/测试变化；不冒称在最终 HEAD 重跑217项。

本轮修复 catalog 未变的普通首笔保存、PAL 首绑误复制及 clean map 重序。catalog 不一致时原保守内容引用表刷写/恢复仍保留；空目标和 Save As 完整复制，PAL 首绑全部资源 hash/格式校验、来源夹验、作者冲突和 journal 不变。Safe Browsing 具体原因未证，也没有绕过浏览器保护。6012 自有 session73887 留给根验收；未操作6010。

集成时须同交根 R4 卡新节，project-lifecycle 的任务链接依赖该节。两篇 spec 原 quote 与 base 逐字节相等。源码由 Git 对象恢复，不复制整棵树；本目录所有原件保留至根逐成员校验归档。两个重复 raw 载体已去重净删186 bytes，恢复映射与独立执行身份见 receipt.cleanup。

快检：核 candidate/base 和 manifest 各成员哈希，再核 receipt.files 的源码哈希；读取原生 JSON 的 file×fullName/状态与负控 AssertionError。新风险或不匹配才定向重跑，不重复全仓门。本包不自签独立接受或 done。
