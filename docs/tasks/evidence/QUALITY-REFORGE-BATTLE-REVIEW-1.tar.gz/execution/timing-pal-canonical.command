pnpm exec tsx /tmp/type-pal-reforge-review.O88ecN/animation-canonical.mts 
