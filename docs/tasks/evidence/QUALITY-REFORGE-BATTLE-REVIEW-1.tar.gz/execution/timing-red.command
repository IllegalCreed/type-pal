pnpm --filter @type-pal/content exec vitest run src/skill-validation.test.ts --reporter=default --reporter=json --outputFile.json=/tmp/type-pal-reforge-review.O88ecN/timing-red.json 
