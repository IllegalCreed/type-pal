pnpm --filter @type-pal/content exec vitest run --reporter=default --reporter=json --outputFile.json=/tmp/type-pal-reforge-review.O88ecN/content-final.json 
