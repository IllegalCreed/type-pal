import { readFileSync } from 'node:fs'
import assert from 'node:assert/strict'
import { validateSkills } from '/Users/zhangxu/.codex/worktrees/quality-94-102/type-pal/packages/content/src/validate.ts'
import { buildOffMagic } from '/Users/zhangxu/.codex/worktrees/quality-94-102/type-pal/packages/reforge/src/battle/battle-anim.ts'

const input = JSON.parse(readFileSync('projects/pal/content/skills.json', 'utf8'))
const raw = input.skills.find((skill: { id: string }) => skill.id === '296')
assert.ok(raw)
const cases = [
  ['real-signed-speed', { speed: -1, fireDelay: 0, effectTimes: 1, shake: 0 }],
  ['negative-frame-time', { speed: -6, fireDelay: 0, effectTimes: 1, shake: 0 }],
  ['fractional-loop-start', { speed: -1, fireDelay: 0.5, effectTimes: 1, shake: 0 }],
  ['negative-loop-start', { speed: -1, fireDelay: -0.5, effectTimes: 1, shake: 0 }],
] as const
const proof = cases.map(([name, animation]) => {
  const document = { skills: [{ ...raw, animation: { ...raw.animation, ...animation } }], levelUp: {} }
  const [skill] = validateSkills(document).skills
  assert.ok(skill)
  const frames = buildOffMagic({
    fireFrames: 3,
    targetPos: { x: 150, y: 96 },
    fx: { placement: 'normal', xOffset: 0, yOffset: 0, wave: 0, ...animation },
  })
  return {
    name,
    validated: skill.id,
    times: frames.map((frame) => frame.durationMs),
    spriteFrames: frames.flatMap(({ overlays }) => overlays?.map(({ frameIdx }) => frameIdx) ?? []),
  }
})
assert.ok(proof[0]?.times.every((time) => time === 40))
assert.ok(proof[1]?.times.every((time) => time < 0))
assert.ok(proof[2]?.spriteFrames.some((index) => !Number.isInteger(index)))
assert.ok(proof[3]?.spriteFrames.some((index) => index < 0))
console.log(JSON.stringify(proof, null, 2))
