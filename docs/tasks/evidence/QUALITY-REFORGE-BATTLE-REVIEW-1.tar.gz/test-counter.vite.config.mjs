import base from '/Users/zhangxu/.codex/worktrees/quality-94-102/type-pal/packages/reforge/vite.config.ts'

const variants = {
  unequip: {
    file: '/packages/reforge/src/battle-trial-prepare.ts',
    before: 'if (id === null) delete member.equipment[slot]',
    after: 'if (id === null) continue',
  },
  transform: {
    file: '/packages/reforge/src/battle/enemy-closure.ts',
    before: "if (command.kind === 'effect') actions.push(command.effect)",
    after: "if (command.kind === 'effect' && command.effect.kind !== 'transform') actions.push(command.effect)",
  },
  fallback: {
    file: '/packages/reforge/src/battle/enemy-closure.ts',
    before: "if (command.kind === 'setFallback' && command.fallback)",
    after: "if (command.kind === 'setFallback' && command.fallback && false)",
  },
}
const variant = variants[process.env.TYPE_PAL_BATTLE_TEST_COUNTER]
if (!variant) throw new Error('expected a known isolation counterexample')

export default {
  ...base,
  plugins: [
    {
      name: 'battle-review-isolation-counter',
      enforce: 'pre',
      transform(source, id) {
        if (!id.endsWith(variant.file)) return
        if (source.split(variant.before).length !== 2) throw new Error('counterexample source drifted')
        return source.replace(variant.before, variant.after)
      },
    },
    ...base.plugins,
  ],
}
