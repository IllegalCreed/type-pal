import assert from 'node:assert/strict'
import { readFileSync } from 'node:fs'
import { checkThrowSpec, validateSkills } from '/Users/zhangxu/.codex/worktrees/quality-94-102/type-pal/packages/content/src/validate.ts'
import { buildOffMagic } from '/Users/zhangxu/.codex/worktrees/quality-94-102/type-pal/packages/reforge/src/battle/battle-anim.ts'

const before = JSON.parse(readFileSync('/tmp/type-pal-reforge-review.O88ecN/animation-domain.stdout', 'utf8'))
const rawSkills = JSON.parse(readFileSync('projects/pal/content/skills.json', 'utf8'))
const rawItems = JSON.parse(readFileSync('projects/pal/content/items.json', 'utf8'))
const snapshots = structuredClone({ rawSkills, rawItems })
const { skills } = validateSkills(rawSkills)
const throws = rawItems.filter((raw: { throw?: { presentation?: unknown } }) => raw.throw?.presentation)
for (const item of throws) checkThrowSpec(item.throw, 'items.' + item.id + '.throw')
const pal = skills.find(({ id }) => id === '296')
assert.ok(pal)
assert.equal(pal.animation.speed, -1)
assert.deepEqual({ rawSkills, rawItems }, snapshots)
const sequence = buildOffMagic({
  fireFrames: 3,
  targetPos: { x: 150, y: 96 },
  fx: {
    placement: 'normal', xOffset: 0, yOffset: 0, wave: 0,
    speed: pal.animation.speed, fireDelay: 0, effectTimes: 1, shake: 0,
  },
})
const durations = sequence.map(({ durationMs }) => durationMs)
const indices = sequence.flatMap(({ overlays }) => overlays?.map(({ frameIdx }) => frameIdx) ?? [])
assert.deepEqual(durations, [40, 40, 40, 40, 40, 40])
assert.deepEqual(indices, [0, 1, 2, 0, 1, 2])
assert.deepEqual(durations, before[0].times)
assert.deepEqual(indices, before[0].spriteFrames)
console.log(JSON.stringify({ currentSkills: skills.length, magicThrowAnimations: throws.length, sameSignedSpeedSequence: { durations, indices } }, null, 2))
