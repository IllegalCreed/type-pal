import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { execFileSync } from 'node:child_process'
import { mkdir, readFile, writeFile } from 'node:fs/promises'
import { existsSync, readFileSync } from 'node:fs'
import { dirname, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'
import { loadOfficialFastFunctions } from './official-coverage-functions.mjs'

const q = dirname(fileURLToPath(import.meta.url))
const baseRef = '263c45ed31948492216a1887ba0fca82e06ff78d'
const digest = (value) => createHash('sha256').update(value).digest('hex')
const raw = await readFile(resolve(q, 'first-official-coverage.json'))
const first = JSON.parse(raw)
assert.equal(digest(raw), '84b03a30ef61c8e6cfb89a21b155975421549565421788a362dac0cadef82114')
const receipt = JSON.parse(await readFile(resolve(q, 'runs/official-coverage-ratchet/result.json')))
assert.equal(receipt.head, baseRef)
assert.equal(receipt.exitCode, 1)
assert.equal(receipt.coverageInputs.TYPE_PAL_COVERAGE_BASE_REF, undefined)

const inputPaths = execFileSync('git', ['diff', '--name-only', 'HEAD', '--', 'packages', 'pnpm-lock.yaml', 'package.json'], { encoding: 'utf8' })
  .split('\n').filter(Boolean)
for (const path of inputPaths) assert(path.startsWith('packages/editor/'), 'another coverage package changed: ' + path)
for (const path of Object.keys(receipt.changes)) {
  if (path.startsWith('packages/') && !path.startsWith('packages/editor/')) {
    assert(existsSync(path) && digest(readFileSync(path)) === receipt.changes[path], path)
  }
}

const official = await loadOfficialFastFunctions(baseRef)
await official.assertToolVersions()
const output = resolve(q, 'official-editor-final')
await mkdir(output)
const editor = await official.collectPackage(official.coveragePackages.find((entry) => entry.id === 'editor'), output)
const packages = { ...first.packages, editor }
const result = {
  ...first,
  generatedAt: new Date().toISOString(),
  packages,
  sourceFileCount: Object.values(packages).reduce((n, p) => n + p.sourceFileCount, 0),
  testCount: Object.values(packages).reduce((n, p) => n + p.selectedTests.testCount, 0),
  total: official.aggregateMetrics(Object.values(packages).map((p) => p.metrics)),
}
await writeFile(resolve(q, 'coverage-final-editor-package.json'), JSON.stringify(editor, null, 2) + '\n', { flag: 'wx' })
await writeFile(resolve(q, 'coverage-final-combined.json'), JSON.stringify(result, null, 2) + '\n', { flag: 'wx' })
official.printSummary(result)
console.log(JSON.stringify({
  collection: 'Editor via exact official collectPackage; verified original results carried forward for the six unchanged packages.',
  executedCollector: 'scripts/coverage/run.mjs:collectPackage',
  collectorSha256: digest(readFileSync('scripts/coverage/run.mjs')),
  originalSummarySha256: digest(raw),
  editorSummarySha256: digest(readFileSync(resolve(output,'editor/coverage-summary.json'))),
  combinedSummarySha256: digest(readFileSync(resolve(q,'coverage-final-combined.json'))),
}, null, 2))
