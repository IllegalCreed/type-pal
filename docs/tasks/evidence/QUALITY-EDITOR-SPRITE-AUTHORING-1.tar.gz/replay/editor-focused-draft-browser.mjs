import { createRequire } from 'node:module'
import { join } from 'node:path'

const root = process.argv[2]
const { chromium } = createRequire(join(root, 'package.json'))('playwright')
const browser = await chromium.launch({ channel: 'chrome' })
const route = 'http://127.0.0.1:6198/?ui_samples&module=asset&page=sprite&domain=world&view=definition&object=li-xiaoyao'
const rows = []
const errors = []
const notices = []
const inputLabel = '最后的作者名称'
for (const kind of ['pointer-click', 'focused-activation', 'native-dialog-cancel']) {
  const page = await browser.newPage({ viewport: { width: 1280, height: 900 } })
  page.on('pageerror', (error) => errors.push({ kind, message: error.message }))
  page.on('response', (response) => {
    if (response.status() >= 400)
      notices.push({ kind, status: response.status(), path: new URL(response.url()).pathname })
  })
  try {
    await page.goto(route, { waitUntil: 'domcontentloaded', timeout: 20000 })
    const button = page.getByRole('button', { name: '新建预制动作', exact: true })
    await button.click({ timeout: 20000 })
    const create = page.getByRole('dialog', { name: '新建预制动作', exact: true })
    const name = create.locator('input[name="sprite-action-name"]')
    await name.fill(inputLabel)
    const focusedBefore = await name.evaluate((element) => document.activeElement === element)
    let keptLabel
    let discardOpen
    let createOpen
    if (kind === 'native-dialog-cancel') {
      await create.evaluate((dialog) => dialog.requestClose())
      discardOpen = await page.getByRole('alertdialog', { name: '放弃新动作？' }).isVisible()
      createOpen = await create.isVisible()
    } else {
      const confirm = create.getByRole('button', { name: '创建动作', exact: true })
      if (kind === 'pointer-click') await confirm.click()
      else await confirm.evaluate((button) => button.click())
      const edit = page.getByRole('dialog', { name: '编辑预制动作', exact: true })
      await edit.waitFor({ timeout: 5000 })
      keptLabel = await edit.locator('input[name="sprite-action-name"]').inputValue()
    }
    rows.push({ kind, focusedBefore, keptLabel, discardOpen, createOpen })
  } finally {
    await page.close()
  }
}
await browser.close()
console.log(JSON.stringify({ rows, errors, notices }, null, 2))
