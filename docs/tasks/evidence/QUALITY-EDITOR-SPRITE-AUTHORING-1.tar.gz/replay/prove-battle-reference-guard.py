from pathlib import Path
import hashlib
import json
import subprocess
import sys

scratch=Path(__file__).resolve().parent
source=Path('packages/editor/src/core/battle-sprite-commands.ts')
test=Path('packages/editor/src/ui/BattleSpriteLibrary.references.test.tsx')
before=source.read_bytes()
git_before=subprocess.check_output(['git','show','HEAD:'+str(source)])
assert before==git_before,'Only mutate the unmodified isolated source'
begin=before.index(b'export class RemoveBattleSpriteDefinitionCommand')
end=before.index(b'export class DeleteUnusedBattleSpriteAssetCommand',begin)
slice=before[begin:end]
target=b'if (references.length)'
assert slice.count(target)==1
mutated=before[:begin]+slice.replace(target,b'if (references.length > Number.MAX_SAFE_INTEGER)')+before[end:]
args=['pnpm','--filter','@type-pal/editor','exec','vitest','run',
      'src/ui/BattleSpriteLibrary.references.test.tsx','--reporter=default','--reporter=json','--outputFile.json={report}']

def run(name):
    return subprocess.run([sys.executable,str(scratch/'capture.py'),name,*args],check=False).returncode

def outcomes(name):
    native=json.loads((scratch/'runs'/name/'vitest.json').read_text())
    return {row['fullName']:row for item in native['testResults'] for row in item['assertionResults']}

digest=lambda value:hashlib.sha256(value).hexdigest()
source.write_bytes(mutated)
try:
    code=run('battle-author-reference-guard-typed-counter')
    assert code==1,code
finally:
    source.write_bytes(before)
expect='显示零引用后有脚本引用该用途时，提交前的当前作者索引拒绝删除'
counter=outcomes('battle-author-reference-guard-typed-counter')
assert len(counter)==7
assert {name for name,row in counter.items() if row['status']=='failed'}=={expect},counter.keys()
fail=counter[expect]
native_failure='\n'.join(fail['failureMessages'])
assert 'AssertionError' in native_failure and str(test.name) in native_failure
err=(scratch/'runs/battle-author-reference-guard-typed-counter/stderr').read_text()
assert 'AssertionError: expected' in err and 'to deeply equal' in err
assert 'not wrapped in act' not in err and 'Unhandled' not in err
assert source.read_bytes()==git_before
assert run('battle-author-reference-guard-typed-restore')==0
restored=outcomes('battle-author-reference-guard-typed-restore')
assert set(counter)==set(restored) and all(row['status']=='passed' for row in restored.values())
assert not (scratch/'runs/battle-author-reference-guard-typed-restore/stderr').read_bytes()
record={
 'source':str(source),'sourceSha256':digest(before),'mutantSha256':digest(mutated),
 'restoredSha256':digest(source.read_bytes()),'test':str(test),'testSha256':digest(test.read_bytes()),
 'target':'RemoveBattleSpriteDefinitionCommand.apply rejects live reference blockers',
 'counter':{'command':args,'failure':expect,'error':'AssertionError','passed':6,'failed':1},
 'restored':{'passed':7,'diagnostics':0},'testIdentityEqual':True,
}
(scratch/'battle-author-reference-counter.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(record,ensure_ascii=False,indent=2))
