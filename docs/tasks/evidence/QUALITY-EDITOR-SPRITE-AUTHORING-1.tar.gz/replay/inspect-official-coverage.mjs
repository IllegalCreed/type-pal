import { execFileSync } from 'node:child_process'
import { createHash } from 'node:crypto'
import { existsSync, readFileSync } from 'node:fs'
import { resolve } from 'node:path'
import { pathToFileURL } from 'node:url'

const here = process.cwd()
const load = async (file) => import(pathToFileURL(resolve(here, file)))
const { auditScope } = await load('scripts/coverage/inventory.mjs')
const { compareCoverage } = await load('scripts/coverage/metrics.mjs')
const digest = (data) => createHash('sha256').update(data).digest('hex')

const [rawPath, protectedRef] = process.argv.slice(2)
if (!rawPath || !protectedRef) throw new Error('Provide the official summary and fixed base ref')
const baselinePath = 'scripts/coverage/baseline.fast.json'
const old = execFileSync('git', ['show', protectedRef + ':' + baselinePath])
const before = JSON.parse(old)
const raw = readFileSync(rawPath)
const collected = JSON.parse(raw)
const comparison = compareCoverage(collected, before, { allowNewPackages: true })
const scope = auditScope(collected, before)
const item = (run, path) =>
  Object.values(run.packages).flatMap((pkg) => pkg.fastTests.fileEntries).find((entry) => entry.file === path)

console.log(JSON.stringify({
  summarySha256: digest(raw),
  baselineSha256: digest(old),
  counts: { tests: collected.testCount, sources: collected.sourceFileCount, total: collected.total },
  editor: { before: before.packages.editor.metrics, after: collected.packages.editor.metrics },
  regressions: comparison.regressions,
  improvements: comparison.improvements,
  scopeChangeCount: scope.changes.length,
  missingStillPresentSources: scope.removals.filter((x) => x.kind === 'source' && existsSync(x.value)),
  changedExistingTestScopes: scope.removals
    .filter((x) => x.kind.startsWith('test-') && existsSync(x.value))
    .map((x) => ({
      removal: x,
      previous: item(before, x.value),
      current: item(collected, x.value),
      fileSha256: digest(readFileSync(x.value)),
    })),
}, null, 2))
