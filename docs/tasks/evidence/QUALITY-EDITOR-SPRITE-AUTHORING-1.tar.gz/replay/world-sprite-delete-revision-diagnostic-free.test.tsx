// @vitest-environment jsdom
import { act } from 'react'
import { expect, test, vi } from 'vitest'
import { applyHistoryAction, clickButtonByText } from '../__tests__/cursor-asset-r1/kit.js'
import { gatedFileSource } from '../__tests__/gated-file-source.js'
import { waitForWorldSpriteResource } from '../__tests__/world-sprite-library-test-host.js'
import { setupWorldSpriteLibrarySuite, waitMeta } from '../__tests__/world-sprite-library-gestures.js'
import { loadWorldSpriteProject } from '../__tests__/world-sprite-project.js'
import { sha256Hex } from '../core/binary-signature.js'
import { UpsertAssetCommand } from '../core/commands.js'
import { assertProjectSaveValid } from '../core/project-diagnostics.js'

const suite = setupWorldSpriteLibrarySuite()
const asset = 'sprite.authored.delete-revision'
test('删除旧版本读取期间同一资产换版后，撤销不能把旧字节挂到新版记录', async () => {
  const original = await loadWorldSpriteProject('sprite-delete-revision-original', [
    { asset, label: '待删源帧', frameCount: 3, definitions: [] },
  ])
  const replacement = await loadWorldSpriteProject('sprite-delete-revision-replacement', [
    { asset, label: '换版源帧', frameCount: 4, definitions: [] },
  ])
  const oldRecord = original.state.assetCatalog.assets[asset]!
  const newRecord = replacement.state.assetCatalog.assets[asset]!
  expect(newRecord.sha256).not.toBe(oldRecord.sha256)
  const newBytes = replacement.seeded.get(asset)!.bytes
  const disk = gatedFileSource(original.source)
  const library = await suite.mount(original, { view: 'asset', focus: asset, source: disk.source })
  await waitMeta(library.host, 3, 0)
  const beforeRead = disk.calls.filter((path) => path === oldRecord.path).length
  const hold = disk.gate(oldRecord.path)
  try {
    await clickButtonByText(library.host, '删除源资源')
    expect(disk.calls.filter((path) => path === oldRecord.path)).toHaveLength(beforeRead + 1)
    expect(disk.completed.filter((path) => path === oldRecord.path)).toHaveLength(beforeRead)
    await act(async () => {
      expect(library.session.dispatch(new UpsertAssetCommand(asset, newRecord, newBytes))).toBe(true)
    })
    await waitMeta(library.host, 4, 0)
    assertProjectSaveValid(library.session.getState())
  } finally {
    await act(async () => {
      hold.resolve()
      await vi.waitFor(() => expect(library.session.getState().assetCatalog.assets[asset]).toBeUndefined())
    })
    await waitForWorldSpriteResource(library, 'sprite.generated.starter')
  }
  expect(await applyHistoryAction(library.session, 'undo')).toBe(true)
  expect(library.session.getState().assetCatalog.assets[asset]).toEqual(newRecord)
  expect(await sha256Hex(await library.reader.readBytes(asset, 'sprite'))).toBe(newRecord.sha256)
})

