import { createRequire } from 'node:module'
import { join } from 'node:path'

const { chromium } = createRequire(join(process.argv[2], 'package.json'))('playwright')
const browser = await chromium.launch({ channel: 'chrome' })
const page = await browser.newPage({ viewport: { width: 1280, height: 900 } })
const state = { errors: [], confirms: [], stages: [] }
page.on('pageerror', error => state.errors.push(error.message))
page.on('dialog', async dialog => {
  state.confirms.push(dialog.message())
  await dialog.accept()
})
try {
  await page.goto('http://127.0.0.1:6198/?ui_samples&module=asset&page=sprite&domain=world&view=definition&object=li-xiaoyao', { waitUntil: 'domcontentloaded', timeout: 20000 })
  const openNew = page.getByRole('button', { name: '新建预制动作', exact: true })
  const create = page.getByRole('dialog', { name: '新建预制动作', exact: true })
  const edit = page.getByRole('dialog', { name: '编辑预制动作', exact: true })
  await openNew.click({ timeout: 20000 })
  await create.locator('input[name="sprite-action-name"]').fill('删除回归临时动作')
  await create.getByRole('button', { name: '创建动作', exact: true }).click()
  await edit.locator('input[name="sprite-action-name"]').waitFor({ timeout: 5000 })
  state.stages.push({ name: await edit.locator('input[name="sprite-action-name"]').inputValue(), deleting: true })
  await edit.getByRole('button', { name: '删除预制动作：删除回归临时动作' }).click({ timeout: 4000 })
  const workspace = page.locator('dialog.sprite-action-dialog[open]')
  await page.locator('dialog.sprite-action-dialog').getByText('尚无预制动作。新建后可从源帧选择区添加动作步骤。').waitFor({ timeout: 3000 }).catch(error => state.stages.push({ wait: error.message.split('\n')[0] }))
  state.focusOnNew = await page.evaluate(() => document.activeElement?.textContent?.trim() === '新建预制动作')
  state.stages.push({ editOpen: await workspace.isVisible(), bodyExcerpt: (await page.locator('body').innerText()).slice(0, 350), url: page.url() })
  if (state.errors.length || !state.focusOnNew || !state.stages.at(-1).editOpen) process.exitCode = 1
} finally {
  console.log(JSON.stringify(state, null, 2))
  await browser.close()
}

