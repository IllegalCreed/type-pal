// @vitest-environment jsdom
import { act } from 'react'
import { expect, test } from 'vitest'
import { clickButtonByText, typeDraft } from '../__tests__/cursor-asset-r1/kit.js'
import {
  setupWorldSpriteLibrarySuite,
  waitMeta,
} from '../__tests__/world-sprite-library-gestures.js'
import { loadWorldSpriteProject } from '../__tests__/world-sprite-project.js'

const suite = setupWorldSpriteLibrarySuite()
const spriteId = 'action-sprite'

async function startCreate(name: string) {
  const project = await loadWorldSpriteProject(name, [
    {
      asset: 'sprite.authored.action-sprite',
      label: '动作工作台精灵',
      frameCount: 4,
      definitions: [{ id: spriteId, label: '动作精灵', layout: { kind: 'static' } }],
    },
  ])
  const library = await suite.mount(project, { focus: spriteId })
  await waitMeta(library.host, 4, 1)
  await clickButtonByText(library.host, '新建预制动作')
  const dialog = library.host.querySelector<HTMLDialogElement>(
    'dialog[aria-label="新建预制动作"]',
  )
  const nameField = dialog?.querySelector<HTMLInputElement>('[name="sprite-action-name"]')
  if (!dialog || !nameField) throw new Error('新建动作弹窗或名称字段缺失')
  await act(async () => nameField.focus())
  await typeDraft(nameField, '新动作的最终名称')
  expect(document.activeElement).toBe(nameField)
  expect(library.session.getHistoryVersion()).toBe(0)
  return { library, dialog }
}

test('名称字段仍聚焦时，创建动作提交最后键入的名称', async () => {
  const { library, dialog } = await startCreate('sprite-action-focused-confirm')
  await clickButtonByText(dialog, '创建动作')
  const definitions = library.session.getState().sprites
  expect(definitions.find((entry) => entry.id === spriteId)?.poses?.action?.label).toBe(
    '新动作的最终名称',
  )
  expect(library.session.getHistoryVersion()).toBe(1)
})

test('对话框收到取消时，仍聚焦的动作名称需要明确确认放弃', async () => {
  const { library, dialog } = await startCreate('sprite-action-focused-discard')
  await act(async () => dialog.dispatchEvent(new Event('cancel', { cancelable: true })))
  expect(library.host.querySelector('[role="alertdialog"]')?.textContent).toContain('放弃新动作')
  expect(library.session.getHistoryVersion()).toBe(0)
})
