import assert from 'node:assert/strict'
import { execFileSync } from 'node:child_process'
import { readFileSync } from 'node:fs'
import { resolve } from 'node:path'
import { pathToFileURL } from 'node:url'

export async function loadOfficialFastFunctions(baseRef) {
  const path = 'scripts/coverage/run.mjs'
  const raw = readFileSync(path)
  assert(raw.equals(execFileSync('git', ['show', baseRef + ':' + path])), 'Official runner drift')
  const source = raw.toString('utf8')
  const application = source.lastIndexOf('\nmain().catch(')
  assert(application > 0)
  const hosted = source.slice(0, application).replace(
    /from '\.\/([^']+)'/g,
    (_matched, moduleName) => "from '" + pathToFileURL(resolve('scripts/coverage', moduleName)).href + "'",
  )
  assert(!hosted.includes("from './"))
  const exported = hosted + '\nexport { assertToolVersions, collectPackage, coveragePackages, ' +
    'aggregateMetrics, compareCoverage, auditScope, assertSafeRatchetScope, assertComparableProvider, ' +
    'assertCandidateDoesNotLowerProtectedBaseline, approvedComparisonBaseline, baselineView, writeBaseline, printSummary };'
  const previousArgs = process.argv
  process.argv = [process.execPath, previousArgs[1], 'fast', '--ratchet', '--allow-scope-removal']
  try {
    return await import('data:text/javascript;base64,' + Buffer.from(exported).toString('base64'))
  } finally {
    process.argv = previousArgs
  }
}
