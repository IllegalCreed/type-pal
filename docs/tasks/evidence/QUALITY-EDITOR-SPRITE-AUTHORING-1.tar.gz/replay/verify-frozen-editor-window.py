"""Check the archived candidates against a specified checkout without any writes."""
from pathlib import Path
from hashlib import sha256
import json, subprocess, sys, tarfile
archive, candidate = sys.argv[1:] if len(sys.argv) == 3 else (sys.argv[1], 'HEAD')
def digest(raw):
    return sha256(raw).hexdigest()
def blob(rev, path):
    proc = subprocess.run(['git','show',f'{rev}:{path}'],capture_output=True)
    return proc.stdout if proc.returncode==0 else None

with tarfile.open(archive, mode='r:gz') as reader:
    members = json.load(reader.extractfile('contents.json'))
    for name, expected in members.items():
        raw = reader.extractfile(name).read()
        assert len(raw)==expected['bytes'] and digest(raw)==expected['sha256'], name
    manifest = json.load(reader.extractfile('candidate.json'))
    mismatches = []
    for encoded in reader.extractfile('file-index.ndjson'):
        row=json.loads(encoded)
        for rev,key in ((manifest['base'],'before'),(candidate,'after')):
            expected=row[key]
            actual=blob(rev,row['path'])
            if (None if actual is None else digest(actual)) != (None if expected is None else expected['sha256']):
                mismatches.append((row['path'],key))
    print(json.dumps({'checkedMembers':len(members),'candidate':candidate,'mismatches':mismatches},ensure_ascii=False))
    sys.exit(bool(mismatches))
