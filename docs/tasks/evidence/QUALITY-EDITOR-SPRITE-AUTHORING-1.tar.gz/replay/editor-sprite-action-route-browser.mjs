import { createRequire } from 'node:module'
import { join } from 'node:path'

const { chromium } = createRequire(join(process.argv[2], 'package.json'))('playwright')
const url = 'http://127.0.0.1:6198/?ui_samples&module=asset&page=sprite&domain=world&view=definition&object=sprite-35'
const browser = await chromium.launch({ channel: 'chrome' })
const results = []
try {
  for (const scenario of ['desktop-reference-return', 'narrow-action-detail']) {
    const page = await browser.newPage({ viewport: { width: scenario === 'narrow-action-detail' ? 680 : 1280, height: 900 } })
    const errors = []
    page.on('pageerror', error => errors.push(error.message))
    try {
      await page.goto(url, { waitUntil: 'domcontentloaded', timeout: 20000 })
      const open = page.getByRole('button', { name: '编辑预制动作（1）', exact: true })
      await open.click({ timeout: 20000 })
      const dialog = page.getByRole('dialog', { name: '编辑预制动作', exact: true })
      if (scenario === 'desktop-reference-return') {
        await dialog.getByRole('button', { name: '查看引用', exact: true }).click({ timeout: 10000 })
        const panel = page.locator('#world-sprite-inspector-panel-references')
        results.push({ scenario, dialogStillOpen: await dialog.isVisible(), referencesVisible: await panel.isVisible(), tab: await page.getByRole('tab', { selected: true }).allTextContents(), errors })
      } else {
        const row = dialog.getByRole('option', { name: /pal-auto-v1-9923bcc34d4284e3/ })
        await row.click({ timeout: 10000 })
        const pageSelector = dialog.locator('.sprite-action-editor-layout')
        results.push({ scenario, visiblePage: await pageSelector.getAttribute('data-mobile-page'), detailVisible: await dialog.locator('.sprite-action-detail-pane').isVisible(), listVisible: await dialog.locator('.sprite-action-directory').isVisible(), errors })
      }
    } catch (error) {
      results.push({ scenario, driverError: error.message, errors })
    } finally {
      await page.close()
    }
  }
} finally {
  await browser.close()
  console.log(JSON.stringify(results, null, 2))
}

