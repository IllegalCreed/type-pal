import hashlib
import json
import os
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

scratch = Path(__file__).resolve().parent
run = scratch / 'runs' / sys.argv[1]
run.mkdir(parents=True, exist_ok=False)
argv = [arg.replace('{report}', str(run / 'vitest.json')) for arg in sys.argv[2:]]
digest = lambda payload: hashlib.sha256(payload).hexdigest()
now = lambda: datetime.now(timezone.utc).isoformat()
git = lambda *parts: subprocess.check_output(['git', *parts], text=True)
paths = dict.fromkeys((
    git('diff', '--name-only', '-z', 'HEAD') + git('ls-files', '-z', '--others', '--exclude-standard')
).split('\0'))
result = {
    'cwd': os.getcwd(), 'argv': argv, 'startedAt': now(),
    'head': git('rev-parse', 'HEAD').strip(), 'originMain': git('rev-parse', 'origin/main').strip(),
    'changes': {p: digest(Path(p).read_bytes()) if Path(p).is_file() else None for p in paths if p},
    'coverageInputs': {k: os.environ[k] for k in ('TYPE_PAL_COVERAGE_BASE_REF','TYPE_PAL_COVERAGE_PARALLEL_EDITOR') if k in os.environ},
}
status = None
with (run/'stdout').open('wb') as out, (run/'stderr').open('wb') as err:
    try:
        status = subprocess.run(argv, stdout=out, stderr=err, check=False).returncode
    except OSError as exc:
        result['spawnError'] = str(exc)
result.update(finishedAt=now(), exitCode=status if status is not None and status >= 0 else None,
              signal=-status if status is not None and status < 0 else None, outputs={})
for name in ('stdout','stderr','vitest.json'):
    target = run / name
    if target.is_file():
        raw = target.read_bytes()
        result['outputs'][name] = {'bytes':len(raw),'sha256':digest(raw)}
        if name != 'vitest.json' and raw:
            print('[' + name + ']')
            print('\n'.join(raw.decode(errors='replace').splitlines()[-28:]))
(run/'result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2)+'\n')
sys.exit(127 if status is None else 128-status if status < 0 else status)
