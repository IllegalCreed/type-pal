from pathlib import Path
from hashlib import sha256
import json,re,subprocess

scratch = Path(__file__).resolve().parent
root = 'packages/editor/src/ui/design-system/'
base = subprocess.check_output(['git','rev-parse','origin/main'],text=True).strip()
get = lambda name: subprocess.check_output(['git','show',f'{base}:{root}{name}'])

# Targets use the final test file and a unique case-title fragment. Multiple oracle
# fragments are listed only when the retired scenario combined independent contracts.
number = 'number-inputs.test.tsx'
draftnum = 'draft-number-inputs.test.tsx'
draft = 'draft-text-inputs.test.tsx'
overlay = 'overlays.test.tsx'
field = 'field-controls.test.tsx'
select = 'select.test.tsx'
multi = 'multi-select.test.tsx'
picker = 'add-picker.test.tsx'
menu = 'menu-bar.test.tsx'
toolbar = 'toolbar.test.tsx'
header = 'list-header.test.tsx'
tabs = 'tabs.test.tsx'
list_ = 'virtual-list.test.tsx'
box = 'virtual-listbox.test.tsx'
recipes = 'recipes.test.tsx'
overflow = 'overflow-text.test.tsx'
help_ = 'help-tips.test.tsx'
buttons = 'buttons.test.tsx'
choice = 'choice-controls.test.tsx'
status = 'status-values.test.tsx'
media = 'media.test.tsx'
feedback = 'feedback.test.tsx'
card = 'card.test.tsx'

def to(*targets):
    return {'disposition':'covered', 'targets':[{'file': p if p.startswith('packages/') else root+p,'titleContains':t} for p,t in targets]}

def drop(reason, *targets):
    return {**to(*targets),'disposition':'redundant-or-invalid','reason':reason}

close_false = (overlay,'non-dismissible dialogs drop')
can_step = (draftnum,'bounded accessible stepper')
native_step = (number,'native stepper steps the controlled value')
range_reject = (draftnum,'range, integer and empty drafts')
numeric_commit = (draftnum,'commits one number on Enter')
help_escape = (help_,'associates conceptual help')
header_full = (header,'list headers own the complete')
option_type = (select,'supports portal click and keyboard selection')
select_field = (select,'the field connects its label')
placeholder = (select,'keeps placeholders distinct')
multi_toggle = (multi,'checkbox changes update controlled membership')
multi_esc = (multi,'Escape inside the dialog restores trigger focus')
multi_disabled = (multi,'disabled multiselect closes')
picker_filter = (picker,'searches label, stable id, description')
picker_scope = (picker,'closes and clears the draft when scope')
picker_esc = (picker,'Escape collapses results')
char_match = (menu,'matches single unmodified characters')
char_reject = (menu,'ignores multi-character keys and modifier chords')
toolbar_state = (toolbar,'executes real commands and renders pressed')
native_files = ('native-inputs.test.tsx','hidden upload triggers and visible pickers')
error_help = (field,'field wrappers bind author labels')
overlay_lock = (overlay,'opens once, locks scrolling')
tag = (status,'resource badges preserve')
readonly = (status,'readonly properties remain')
header_choose = (header,'overflow menu opens')
tabs_keys = (tabs,'inspector tabs use enabled roving focus')
tabs_delete = (tabs,'optional tab removal is a sibling action')
box_keys = (box,'keeps navigation on an external search')
box_size = (box,'keeps short collections fully mounted')
plain_limits = (list_,'clamps ArrowUp at the first row')

maps = {}
maps['controls.test.tsx'] = [
 to((feedback,'empty-state layout')),
 to((draft,'keeps text local through IME')),
 to((draft,'does not cancel or commit an IME draft')),
 to((draft,'drops the draft when only the object identity')),
 to(range_reject,numeric_commit),
 to((number,'derives numeric input modes')),
 to((draftnum,'keeps wheel scrolling non-blocking')),
 to(can_step),
 to((draftnum,'steps negative and fractional drafts')),
 to((draftnum,'optional bounded number fields')),
 to((number,'plain number field forwards')),
 to((number,'number field stepper follows disabled')),
 to((draftnum,'normalizes legacy domain values')),
 to((draftnum,'resyncs the canonical value when')),
 to((draft,'keeps 100 input events local')),
 to(('packages/editor/src/ui/SpriteActionEditorDialog.draft.test.tsx','动作名称按 Enter 再移到时长字段')),
 to(help_escape),
 to((help_,'keeps help bubbles in the nearest dialog')),
 to((help_,'portals icon-button tooltips outside clipping')),
 to((help_,'dismisses pointer-triggered tooltips')),
 to((buttons,'buttons and action links share geometry'),tag),
 drop('Barrel object identity does not assert author or DOM behavior.',tag,readonly),
 drop('Exact SSR strings duplicated the role and glyph surface already observed in real native markup.',tag,readonly),
 drop('Semantic cases continue at the owning controls. Controlled switch echo was independently measured in runs/native-switch-controlled-echo-browser; one combined incidental class snapshot was removed.',(choice,'a partial selection'),(choice,'group selection cannot move'),(choice,'an uncontrolled switch')),
 to(error_help,(field,'control groups preserve separate'),native_files,(number,'derives numeric input modes'),placeholder),
 to((field,'字段的低频概念说明')),
 to((field,'groups related fields')),
 to(option_type),
 to((select,'preserves full clipped copy')),
 to((select,'keeps its popup inside the nearest native dialog')),
 to((select,'surfaces an unknown controlled value')),
 to((select,'large selects search their full data')),
 to((select,'keeps its active option mounted')),
 to((select,'restores logical Tab order')),
 to((select,'Escape closes its portal')),
 to(tabs_keys,(tabs,'domain bar keeps its compact')),
 to((menu,'menu navigation is a real link')),
 to((menu,'section-grid menu exposes')),
 to((toolbar,'a toolbar activation invokes')),
 to(header_full),
 to((menu,'toggle commands expose pressed')),
 to(multi_toggle,(multi,'label, count and overflow')),
 to((multi,'uses the shared dialog-aware floating layer')),
]
maps[number] = [drop('Retire equality of public re-exports; actual numeric control takes the legal attrs.',(number,'derives numeric input modes'),(number,'plain number field forwards'))]
maps['field-layout.test.tsx'] = [to(error_help,(field,'groups related fields'),(field,'control groups preserve separate'))]
maps['number-inputs.glm-leaf-wave.test.tsx'] = [
 to(numeric_commit,range_reject),
 to((draftnum,'resyncs the canonical value when')),
 to(range_reject),
 to((draftnum,'allowEmpty commits undefined')),
 to(can_step,(draftnum,'optional bounded number fields')),
 to(native_step),
 to((number,'associates the actual number field')),
]
maps['number-overlays.c10-g04.cursor-r1.test.tsx'] = [
 to((number,'plain number field forwards'),native_step),
 to(native_step),
 to(range_reject),
 to((draftnum,'keeps a draft rejected by the caller')),
 to(numeric_commit),
 to(overlay_lock),
 to((overlay,'reference-counts document scroll lock')),
 to((overlay,'uses instance-unique title and description')),
 to(close_false),
 to(close_false),
]
maps['overlays.glm-leaf-wave.test.tsx'] = [
 to((overlay,'opens with body focus')),
 to(close_false),
 to((overlay,'keeps alertdialog role')),
 to((overlay,'focuses the footer action')),
 to(picker_esc),
 to(picker_filter,(picker,'distinguishes loading, error, empty')),
]
maps['select.glm-leaf-wave.test.tsx'] = [
 to(placeholder,(select,'surfaces an unknown controlled value')),
 to(option_type,(select,'Escape closes its portal')),
 to(option_type),
 to((select,'search mode filters by label and value')),
 to((select,'typeahead skips disabled')),
]
maps['select.c10-g02.cursor-r1.test.tsx'] = [
 to(select_field), to(select_field), to(select_field),
 to((select,'preserves full clipped copy')),
 to(placeholder), to(select_field), to(placeholder), to(placeholder),
 to(select_field), to(placeholder),
]
maps['multi-select.glm-leaf-wave.test.tsx'] = [
 to((multi,'label, count and overflow')),
 to((multi,'filter matches label, value and description')),
 to((multi,'select-all keeps prior values')),
 to((multi,'clear commits an empty value')),
 to(multi_toggle), to(multi_esc), to(multi_disabled),
]
maps['multi-add-draft.c10-g05.cursor-r1.test.tsx'] = [
 drop('Serialized private draft token is an implementation detail; preserved behavior at unchanged canonical value and changed scope.',(draft,'an external history revision'),(draft,'drops the draft when only')),
 to((draft,'an external history revision'),(draft,'drops the draft when only')),
 to((draft,'when an author transaction rejects')),
 to(multi_disabled), to(multi_esc), to(multi_toggle),
 to(picker_scope), to(picker_filter),
 drop('The old button selector missed the real option. The successor clicks the actual disabled option and proves zero selection.',(picker,'keeps disabled reasons visible')),
 to(picker_scope),
]
maps['tabs-card-feedback.test.tsx'] = [
 drop('The bundle identity and HTML string checks mixed unrelated responsibilities; standard structures are covered at each native component.',tabs_keys,(card,'groups the card heading'),(feedback,'feedback uses a live status'),(feedback,'empty-state layout')),
 to(tabs_delete),
]
maps['floating-chrome.c10-g06.cursor-r1.test.tsx'] = [
 to((card,'groups the card heading')), to(header_full),
 to((choice,'a partial selection')), to((choice,'an uncontrolled switch')),
 to(tabs_keys), to(tabs_keys), to((choice,'group selection cannot move')),
 to((overflow,'uses a zero-width guard')),
 drop('Test selector found the HelpTip trigger rather than its inserted child. Underlying valid association is verified by resolving the real described ID.',help_escape),
 to(header_choose),
]
maps['navigation.glm-leaf-wave.test.tsx'] = [
 to((menu,'opens on click, focuses the first')),
 to((menu,'arrow keys move between triggers')),
 to((menu,'sections, checkbox items, href navigation')),
 to(toolbar_state),
 to(char_match), to(char_reject),
]
maps['list-header.glm-leaf-wave.test.tsx'] = [
 to(header_choose),
 to((header,'menu keyboard cycling')),
 to((header,'disabled items stay inert')),
]
maps['virtual-list-navigation.c10-g03.cursor-r1.test.tsx'] = [
 to(char_match), to(char_reject), to(char_match),
 to(toolbar_state), to(toolbar_state), to(toolbar_state),
 to(box_keys), to(box_keys),
 drop('Twelve items exceeded the configured cutoff eight; legacy title was false. Confirm actual full mount below threshold and real 80/81 boundary.',box_size,(picker,'option boundary within the shared virtualization budget')),
 to(box_keys,box_size),
]
maps['virtual-list.glm-leaf-wave.test.tsx'] = [
 to((list_,'clamps stale scroll')),
 to(plain_limits,(list_,'virtualizes rows and supports roving')),
 to((list_,'hover moves the active row')),
 to((box,'click selects an enabled row')),
 to(box_size),
 to((box,'ignores IME composition keydown')),
]
maps['media.glm-leaf-wave.test.tsx'] = [
 to((media,'keeps fitted and explicit zoom separate')),
 to((media,'rounds the percentage')),
 to((media,'keeps both step buttons usable while fitted')),
]
maps['recipes-index.c10-g07.cursor-r1.test.tsx'] = [
 to(('collection-search.test.ts','an empty query preserves')),
 to(('collection-search.test.ts','searches the normalized query')),
 to((picker,'option boundary within the shared virtualization budget')),
 drop('Existing DS boundary guard checks the exact currently adopted 2.24.0 release value. This generic semver shape test adds no contract.',('boundary.test.ts', 'keeps inline composer density, repeat rows, and bounded number fields on public recipes')),
 to(('control-utils.test.ts','description IDs keep both'),('control-utils.test.ts','class composition preserves')),
 to(tag), to(readonly), to((feedback,'feedback uses a live status'),(feedback,'empty-state layout')),
 to((buttons,'shared action style keeps links navigable')),
 to(native_files),
 to((recipes,'sequence index gives ordered rows')),
 to((recipes,'inline composer owns default and compact density')),
 to(('icon-button.test.tsx','compact playback icon')),
 to((buttons,'frame actions use native buttons')),
 to((overlay,'opens with body focus')),
]

out = []
for filename, mapped in maps.items():
    old = get(filename)
    # These retired files use literal non-parameterized registrations.
    titles = re.findall(r"\btest\(\s*'((?:\\.|[^'\\])*)'", old.decode())
    assert len(titles)==len(mapped),(filename,len(titles),len(mapped))
    blob=subprocess.check_output(['git','rev-parse',f'{base}:{root}{filename}'],text=True).strip()
    for title,row in zip(titles,mapped):
        out.append({'sourceFile':root+filename,'sourceTitle':title,'sourceBlob':blob,'sourceSha256':sha256(old).hexdigest(),**row})
(scratch/'design-system-test-contracts.json').write_text(json.dumps({'base':base,'cases':out},ensure_ascii=False,indent=2)+'\n')
print('Mapped',len(out),'design-system tests from',len(maps),'original paths')
for row in out:
    for target in row['targets']:
        if target['titleContains'] not in Path(target['file']).read_text():
            print('anchor refinement:', target['file'], target['titleContains'])
