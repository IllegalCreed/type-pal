import assert from 'node:assert/strict'
import { execFileSync } from 'node:child_process'
import { createHash } from 'node:crypto'
import { existsSync, readFileSync } from 'node:fs'
import { matchesGlob, relative, resolve } from 'node:path'
import { pathToFileURL } from 'node:url'
import { loadOfficialFastFunctions } from './official-coverage-functions.mjs'

const [baseRef, oldRawPath, finalEditorPath, receipts, ...flags] = process.argv.slice(2)
assert(baseRef && oldRawPath && finalEditorPath && receipts, 'base, first result, final Editor result and evidence root required')
const evidence = (path) => resolve(receipts, path)
const json = (path) => JSON.parse(readFileSync(path))
const input = (path) => json(evidence(path))
const sha = (data) => createHash('sha256').update(data).digest('hex')
const baselinePath = 'scripts/coverage/baseline.fast.json'
const previousBytes = execFileSync('git', ['show', baseRef + ':' + baselinePath])
const previous = JSON.parse(previousBytes)
const beforeRaw = json(oldRawPath)
const editor = json(finalEditorPath)
const collectedAt = input('coverage-assembly.json')
const original = input('runs/official-coverage-ratchet/result.json')
const remeasure = input('runs/official-editor-coverage-remeasure/result.json')
const commentProof = input('replay/listbox-comment-invariance.json')
assert.equal(original.head, baseRef)
assert.equal(remeasure.head, baseRef)
assert.equal(original.exitCode, 1)
assert.equal(remeasure.exitCode, 0)
assert.equal(remeasure.outputs.stderr.bytes, 0)
assert.equal(sha(readFileSync(oldRawPath)), collectedAt.firstSummarySha256)
assert.equal(sha(readFileSync(finalEditorPath)), collectedAt.editorPackageSha256)
assert.equal(sha(readFileSync('scripts/coverage/run.mjs')), collectedAt.collectorSha256)
const repeated = 'packages/editor/'
const officialCoverageConfig = await import(pathToFileURL(resolve('scripts/coverage/config.mjs')))
const excludedPal = collectedAt.unselectedPalTestAfterCollection
assert.equal(excludedPal.path, 'packages/editor/tests/world-sprite-behavior.pal.test.ts')
const editorCoverage = officialCoverageConfig.coveragePackages.find((pkg) => pkg.id === 'editor')
assert(officialCoverageConfig.testSelection(editorCoverage, 'fast').excludes.some(
  (glob) => matchesGlob(relative(editorCoverage.directory, excludedPal.path), glob),
), 'The separately corrected PAL test must remain outside the official fast profile')
assert(!(await officialCoverageConfig.listProductionSources(editorCoverage)).includes(resolve(excludedPal.path)))
assert(![beforeRaw.packages.editor, editor].some(
  (pkg) => pkg.fastTests.fileEntries.some((entry) => entry.file === excludedPal.path),
))
const audited = (path) => path.startsWith('packages/') || path === 'pnpm-lock.yaml' ||
  path === 'package.json' || path === 'scripts/coverage/config.mjs'
const recorded = { ...original.changes, ...remeasure.changes }
const paths = new Set([
  ...Object.keys(recorded).filter(audited),
  ...execFileSync('git', ['diff', '--name-only', '--no-renames', baseRef, '--', 'packages',
    'pnpm-lock.yaml', 'package.json', 'scripts/coverage/config.mjs'], { encoding: 'utf8' })
    .trim().split('\n').filter(Boolean),
  ...execFileSync('git', ['ls-files', '--others', '--exclude-standard', '--', 'packages'],
    { encoding: 'utf8' }).trim().split('\n').filter(Boolean),
])
for (const path of paths) {
  const run = path.startsWith(repeated) ? remeasure : original
  if (!Object.hasOwn(run.changes, path)) {
    if (path === excludedPal.path) {
      assert.equal(sha(readFileSync(path)), excludedPal.sha256, path)
      continue
    }
    const packageObservations = path.startsWith(repeated) ? [beforeRaw.packages.editor, editor] :
      Object.values(beforeRaw.packages)
    assert(!existsSync(path), 'unmeasured coverage input still present: ' + path)
    assert(packageObservations.every((pkg) => !pkg.sourceFiles.includes(path) &&
      !pkg.fastTests.fileEntries.some((entry) => entry.file === path)),
    'rename origin appears in the native collection: ' + path)
    continue
  }
  const expected = run.changes[path]
  if (expected === null) {
    assert(!existsSync(path), 'retired path returned: ' + path)
  } else if (path === commentProof.file) {
    assert.equal(sha(readFileSync(path)), commentProof.afterSha256, path)
    assert.equal(expected, commentProof.beforeSha256, path)
    const ts = await import(pathToFileURL(resolve('node_modules/typescript/lib/typescript.js')))
    const transpile = (code) => ts.default.transpileModule(code, {
      fileName: 'virtual-listbox.tsx',
      compilerOptions: { jsx: ts.default.JsxEmit.ReactJSX, sourceMap: true, removeComments: true },
    })
    const before = readFileSync(evidence('replay/virtual-listbox-before-comment.tsx'))
    assert.equal(sha(before), expected)
    const oldOutput = transpile(before.toString('utf8'))
    const newOutput = transpile(readFileSync(path, 'utf8'))
    assert.equal(oldOutput.outputText, newOutput.outputText)
    assert.equal(oldOutput.sourceMapText, newOutput.sourceMapText)
  } else {
    assert.equal(sha(readFileSync(path)), expected, path)
  }
}
const official = await loadOfficialFastFunctions(baseRef)
const packages = { ...beforeRaw.packages, editor }
const collected = {
  ...beforeRaw,
  generatedAt: collectedAt.generatedAt,
  packages,
  sourceFileCount: Object.values(packages).reduce((n, value) => n + value.sourceFileCount, 0),
  testCount: Object.values(packages).reduce((n, value) => n + value.selectedTests.testCount, 0),
  total: official.aggregateMetrics(Object.values(packages).map((p) => p.metrics)),
}
assert.equal(sha(Buffer.from(JSON.stringify(collected, null, 2) + '\n')), collectedAt.combinedSummarySha256)
official.assertComparableProvider(collected, previous)
const strict = official.compareCoverage(collected, previous, { allowNewPackages: true })
assert.deepEqual(strict.regressions.map((issue) => issue.split(':')[0]), ['editor.branches', 'total.branches'])
const acceptedFloor = await official.approvedComparisonBaseline(previous)
for (const [name, value] of Object.entries(previous.packages)) {
  for (const [kind, counts] of Object.entries(value.metrics)) {
    const expected = name === 'editor' && kind === 'branches' ? editor.metrics.branches : counts
    assert.deepEqual(acceptedFloor.packages[name].metrics[kind], expected)
  }
}
const comparing = official.compareCoverage(collected, acceptedFloor, { allowNewPackages: true })
assert.deepEqual(comparing.regressions, [])
const scope = official.auditScope(collected, previous)
official.assertSafeRatchetScope(scope)
const protectedCandidate = official.baselineView(collected)
await official.assertCandidateDoesNotLowerProtectedBaseline(protectedCandidate, previous)
const drift = structuredClone(protectedCandidate)
drift.packages.editor.metrics.branches.covered--
drift.total = official.aggregateMetrics(Object.values(drift.packages).map((p) => p.metrics))
await assert.rejects(official.assertCandidateDoesNotLowerProtectedBaseline(drift, previous),
  /editor\.branches/)
if (flags.includes('--write-baseline')) {
  assert(readFileSync(baselinePath).equals(previousBytes), 'Baseline drift before post-collection ratchet')
  await official.writeBaseline(collected)
}
const actual = JSON.parse(readFileSync(baselinePath))
assert.deepEqual(actual, protectedCandidate)
official.assertComparableProvider(collected, actual)
await official.assertCandidateDoesNotLowerProtectedBaseline(actual, previous)
assert.deepEqual(official.auditScope(collected, actual).changes, [])
assert.deepEqual(official.compareCoverage(collected, await official.approvedComparisonBaseline(actual)).regressions, [])
official.printSummary(collected)
console.log(JSON.stringify({
  performed: flags.includes('--write-baseline') ? 'official post-collection ratchet and protected comparison' : 'official protected comparison from retained measurements',
  sourceInputs: paths.size,
  exactCoverageCollector: collectedAt.collectorSha256,
  testCount: collected.testCount,
  sourceFileCount: collected.sourceFileCount,
  strictPreviousRegressions: strict.regressions,
  remainingRegressions: comparing.regressions,
  retainedComparisonImprovements: comparing.improvements,
  scopeChanges: scope.changes.length,
  additionalLossRejected: true,
  persistedBaselineSha256: sha(readFileSync(baselinePath)),
}, null, 2))
