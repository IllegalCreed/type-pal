import assert from 'node:assert/strict'
import { mkdtemp, rmdir, unlink, writeFile } from 'node:fs/promises'
import { createRequire } from 'node:module'
import { basename, join } from 'node:path'

const { chromium } = createRequire(join(process.cwd(), 'package.json'))('playwright')
const editor = join(process.cwd(), 'packages/editor')
const scratch = await mkdtemp(join(editor, 'type-pal-switch-probe-'))
const entry = join(scratch, 'index.html')
const module = join(scratch, 'fixture.tsx')
let browser
try {
  await writeFile(entry, '<meta charset="UTF-8"><div id="fixture"></div><script type="module" src="./fixture.tsx"></script>')
  await writeFile(module, [
    'import { useState } from "react"',
    'import { createRoot } from "react-dom/client"',
    'import { DsSwitch } from "../src/ui/design-system/choice-controls.tsx"',
    'function Controlled() { const [state, set] = useState(false); return <DsSwitch label="受控预览" checked={state} onChange={(event) => set(event.currentTarget.checked)} /> }',
    'createRoot(document.getElementById("fixture")).render(<><DsSwitch label="独立预览" defaultChecked /><Controlled /></>)',
  ].join('\n'))
  browser = await chromium.launch({ channel: 'chrome' })
  const page = await browser.newPage()
  const errors = []
  page.on('pageerror', (error) => errors.push(error.message))
  await page.goto('http://127.0.0.1:6198/' + basename(scratch) + '/', { waitUntil: 'domcontentloaded' })
  await page.getByRole('switch', { name: '独立预览' }).waitFor()
  const cdp = await page.context().newCDPSession(page)
  await cdp.send('Accessibility.enable')
  async function state(name) {
    const switchNode = (await cdp.send('Accessibility.getFullAXTree')).nodes.find(
      (node) => node.role?.value === 'switch' && node.name?.value === name,
    )
    assert(switchNode, name)
    const input = page.getByRole('switch', { name })
    return {
      native: await input.isChecked(),
      ariaAttribute: await input.getAttribute('aria-checked'),
      accessible: switchNode.properties?.find(({ name: property }) => property === 'checked')?.value?.value,
    }
  }
  const controlledBefore = await state('受控预览')
  const uncontrolledBefore = await state('独立预览')
  await page.getByRole('switch', { name: '受控预览' }).click()
  await page.getByRole('switch', { name: '独立预览' }).press('Space')
  const controlledAfter = await state('受控预览')
  const uncontrolledAfter = await state('独立预览')
  console.log(JSON.stringify({ controlledBefore, controlledAfter, uncontrolledBefore, uncontrolledAfter, errors }, null, 2))
  assert.deepEqual(errors, [])
  assert.equal(controlledBefore.accessible, 'false')
  assert.equal(controlledAfter.accessible, 'true')
  assert.equal(uncontrolledBefore.accessible, 'true')
  assert.equal(uncontrolledAfter.native, false)
  if (process.argv[2] === '--fixed') assert.equal(uncontrolledAfter.accessible, 'false')
} finally {
  await browser?.close()
  for (const file of [entry, module]) await unlink(file).catch((error) => {
    if (error.code !== 'ENOENT') throw error
  })
  await rmdir(scratch)
}
