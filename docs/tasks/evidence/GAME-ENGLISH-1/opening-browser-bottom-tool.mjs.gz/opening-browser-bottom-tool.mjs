import { createHash } from 'node:crypto'
import { execFileSync } from 'node:child_process'
import { createRequire } from 'node:module'
import { existsSync, mkdirSync, readFileSync, writeFileSync, appendFileSync } from 'node:fs'
import { resolve } from 'node:path'
import { setTimeout as delay } from 'node:timers/promises'

const repo = process.env.TYPE_PAL_REPO_ROOT ?? '/Users/zhangxu/illegal/type-pal'
const out = resolve(process.env.TYPE_PAL_BROWSER_OUT ?? 'build/english-browser')
const require = createRequire(resolve(repo, 'package.json'))
const { chromium } = require('playwright')
const hash = (bytes) => createHash('sha256').update(bytes).digest('hex')
mkdirSync(out, { recursive: true })
const report = {
  task: 'GAME-ENGLISH-1',
  scope: 'Independent limited first-stage English opening browser check; no formal 001/E2E/lore/editor acceptance.',
  startedAt: new Date().toISOString(),
  baseURL: 'http://localhost:6005/',
  browser: { channel: 'chrome', headless: true, viewport: { width: 1100, height: 760 } },
  status: 'running',
  actions: [], screenshots: [], milestones: {}, console: [], pageErrors: [], requestFailures: [], httpErrors: [],
  observedHistory: [], hmrEvents: [],
}
function sourceIdentity() {
  const sourcePaths = execFileSync('git', ['ls-files', '--cached', '--others', '--exclude-standard', 'packages/game/src', 'packages/shared/src'], { cwd: repo, encoding: 'utf8' }).trim().split('\n').filter((path) => path.endsWith('.ts') && !path.includes('.test.') && !path.includes('/__tests__/') && !path.includes('fixtures') && !path.includes('test-fixtures'))
  for (const path of ['data/extracted/lookup/en.json', 'data/extracted/lookup/languages.json', 'data/extracted/events/all.json', 'data/extracted/data/font/glyphs.json']) if (existsSync(resolve(repo, path))) sourcePaths.push(path)
  const files = Object.fromEntries(sourcePaths.map((path) => [path, hash(readFileSync(resolve(repo, path)))]))
  return { head: execFileSync('git', ['rev-parse', 'HEAD'], { cwd: repo, encoding: 'utf8' }).trim(), treeSha256: hash(JSON.stringify(files)), files }
}
report.sourceBefore = sourceIdentity()
let browser
let page
const stateLog = resolve(out, 'states.jsonl')
const runtimeLog = resolve(out, 'runtime.jsonl')
writeFileSync(stateLog, '')
writeFileSync(runtimeLog, '')
const bottomOnly = process.env.TYPE_PAL_BROWSER_SCOPE === 'bottom-page'
const started = Date.now()
const maxMs = 15 * 60_000
let stateKey
let historyKey
let captures = 0
let lastVideoKey
function event(kind, value) {
  appendFileSync(runtimeLog, `${JSON.stringify({ atMs: Date.now() - started, kind, value })}\n`)
}
async function observe() {
  const state = await page.evaluate(() => {
    const gs = window.__tpgs
    const video = document.querySelector('video')
    const menu = gs?.menuStack?.at(-1)
    const ds = gs?.dialogBox
    return {
      ready: !!gs,
      frame: gs?.frameNum ?? 0,
      scene: gs?.wNumScene ?? null,
      mode: gs?.mode ?? null,
      party: gs?.party ? { x: gs.party.x, y: gs.party.y, facing: gs.party.facing } : null,
      event: gs?.eventCursor ? { ip: gs.eventCursor.ip, waiting: gs.eventCursor.waiting, localized: gs.eventCursor.localizedDialog ? { resumeIp: gs.eventCursor.localizedDialog.resumeIp, lineIndex: gs.eventCursor.localizedDialog.lineIndex, displayLineCount: gs.eventCursor.localizedDialog.lines?.length } : null } : null,
      dialog: ds ? { phase: ds.phase, style: ds.style, portrait: ds.portraitIcon, title: ds.titleText, text: ds.currentLineText, charsRevealed: ds.charsRevealed, visibleText: ds.currentLineText?.slice(0, ds.charsRevealed), shown: ds.shownLines, lineCount: ds.dialogLineCount } : null,
      menu: menu ? { kind: menu.kind, cursor: menu.state?.selection?.cursor, labels: menu.state?.selection?.items?.map((row) => row.label) } : null,
      loading: !!gs?.sceneLoading,
      suspended: !!gs?.suspendRaf,
      fading: !!(gs?.needToFadeIn || gs?.paletteFadeState || gs?.fadeState || gs?.blackScreenHold),
      video: video ? { path: new URL(video.currentSrc || video.src, location.href).pathname, paused: video.paused, currentTime: video.currentTime, duration: Number.isFinite(video.duration) ? video.duration : null, ended: video.ended } : null,
      history: gs?.dialogHistory?.map((line) => ({ map: line.map, text: line.text })) ?? [],
      language: document.documentElement.lang,
      preference: localStorage.getItem('tp-language'),
    }
  })
  const currentHistoryKey = JSON.stringify(state.history)
  if (historyKey !== currentHistoryKey) {
    for (const line of state.history) {
      const key = `${line.map}:${line.text}`
      if (!report.observedHistory.some((row) => row.key === key)) report.observedHistory.push({ key, ...line, observedAtMs: Date.now() - started })
    }
    historyKey = currentHistoryKey
  }
  const { history, frame, ...keyState } = state
  const key = JSON.stringify(keyState)
  if (key !== stateKey) {
    appendFileSync(stateLog, `${JSON.stringify({ atMs: Date.now() - started, ...state })}\n`)
    stateKey = key
  }
  if (state.video?.path !== lastVideoKey) {
    event('video-transition', { from: lastVideoKey ?? null, to: state.video })
    lastVideoKey = state.video?.path
  }
  return state
}
async function screenshot(name, state) {
  if (bottomOnly && !['06-bottom-page-unobscured', '99-stop-state'].includes(name)) return
  if (captures >= 9) return
  const path = resolve(out, `${name}.png`)
  await page.screenshot({ path })
  const entry = { path, sha256: hash(readFileSync(path)), atMs: Date.now() - started, state }
  report.screenshots.push(entry)
  captures++
  event('screenshot', { path, state })
}
async function pressEnter(reason, state) {
  const action = { key: 'Enter', reason, atMs: Date.now() - started, before: { scene: state.scene, mode: state.mode, frame: state.frame, event: state.event, dialog: state.dialog, video: state.video } }
  report.actions.push(action)
  event('input', action)
  await page.keyboard.press('Enter', { delay: 60 })
  await delay(130)
}
async function clickVisibleStartButtons() {
  for (const [selector, reason] of [['#boot-loading-enter-btn', 'normal enter-game gate'], ['text=点击屏幕开始 / Click to start', 'normal autoplay gate']]) {
    const locator = page.locator(selector)
    if (await locator.isVisible().catch(() => false)) {
      await locator.click()
      const action = { click: selector, reason, atMs: Date.now() - started }
      report.actions.push(action)
      event('input', action)
    }
  }
  const reject = page.getByRole('button', { name: /^(拒绝|Reject|Decline)$/ })
  if (await reject.isVisible().catch(() => false)) {
    await reject.click()
    report.actions.push({ click: 'Reject optional analytics', atMs: Date.now() - started })
  }
}
function controllableRoom(s) {
  return s.ready && s.scene === 2 && s.mode === 'explore' && !s.dialog && !s.event && !s.menu && !s.loading && !s.suspended && !s.fading && !s.video
}
try {
  browser = await chromium.launch({ channel: 'chrome', headless: true })
  const context = await browser.newContext({ viewport: report.browser.viewport, serviceWorkers: 'block' })
  await context.addInitScript(() => { localStorage.setItem('tp-language', 'en') })
  page = await context.newPage()
  page.on('console', (msg) => {
    const item = { type: msg.type(), text: msg.text(), location: msg.location(), atMs: Date.now() - started }
    report.console.push(item)
    event('console', item)
    if (/\[vite\].*(hot updated|page reload)/.test(item.text)) report.hmrEvents.push(item)
  })
  page.on('pageerror', (error) => { const item = { name: error.name, message: error.message, stack: error.stack, atMs: Date.now() - started }; report.pageErrors.push(item); event('pageerror', item); console.log('PAGEERROR', item.message) })
  page.on('requestfailed', (request) => { const item = { url: request.url(), method: request.method(), error: request.failure()?.errorText, atMs: Date.now() - started }; report.requestFailures.push(item); event('requestfailed', item) })
  page.on('response', (response) => { if (response.status() >= 400) { const item = { url: response.url(), status: response.status(), atMs: Date.now() - started }; report.httpErrors.push(item); event('http-error', item); console.log('HTTPERROR', JSON.stringify(item)) } })
  await page.goto(report.baseURL, { waitUntil: 'domcontentloaded', timeout: 60_000 })
  let selected = false
  let storyStarted = false
  while (Date.now() - started < maxMs) {
    await clickVisibleStartButtons()
    const s = await observe()
    if (report.hmrEvents.length) throw new Error('HMR changed source during the frozen browser check')
    if (report.pageErrors.length) throw new Error('Page runtime error; stop and report before any product edits')
    if (!selected) {
      if (s.video && ['/extracted/videos/1.mp4', '/extracted/videos/2.mp4'].includes(s.video.path)) {
        await pressEnter(`skip title prelude ${s.video.path} with normal key (outside story check)`, s)
      } else if (s.menu?.kind === 'opening') {
        if (s.menu.cursor !== 0) throw new Error('Fresh opening default is not New Game')
        if (s.language !== 'en' || s.preference !== 'en') throw new Error('English preference not applied at fresh boot')
        await screenshot('00-english-new-game', s)
        report.milestones.newGame = { atMs: Date.now() - started, state: s }
        await pressEnter('select New Game from real opening menu', s)
        selected = true
      }
    } else {
      if (s.video?.path === '/extracted/videos/3.mp4') {
        if (!report.milestones.storyVideo) report.milestones.storyVideo = { atMs: Date.now() - started, state: s }
      } else if ([1, 2].includes(s.scene) && !s.video) {
        storyStarted = true
        const ds = s.dialog
        if (!report.milestones.xiaoyaoCall && ds?.text?.toLowerCase().includes('xiaoyao') && (ds.charsRevealed ?? 0) >= ds.text.length) {
          await screenshot('01-xiaoyao-call', s)
          report.milestones.xiaoyaoCall = { atMs: Date.now() - started, state: s }
        }
        if (ds?.phase === 'waiting-page-key' || ds?.phase === 'waiting-end-key') {
          if (bottomOnly && ds.style === 'bottom') {
            await screenshot('06-bottom-page-unobscured', s)
            report.final = s
            report.milestones.bottomPage = { atMs: Date.now() - started, state: s }
            break
          }
          if (ds.title && !report.milestones.titlePage) {
            await screenshot('02-speaker-title-page', s)
            report.milestones.titlePage = { atMs: Date.now() - started, state: s }
          }
          if (ds.phase === 'waiting-page-key' && ds.shown.length >= 3 && !report.milestones.fullPage) {
            await screenshot('03-multiline-page', s)
            report.milestones.fullPage = { atMs: Date.now() - started, state: s }
          }
          const text = [...ds.shown, ds.text ?? ''].join(' ')
          if (/passage|discovered|sneak/i.test(text) && !report.milestones.secretPassage) {
            await screenshot('04-secret-passage', s)
            report.milestones.secretPassage = { atMs: Date.now() - started, state: s }
          }
          await pressEnter(`advance rendered ${ds.phase} after natural typing`, s)
        }
        if (controllableRoom(s)) {
          await screenshot('05-inn-controllable', s)
          report.final = s
          report.milestones.controllableRoom = { atMs: Date.now() - started, state: s }
          break
        }
      }
    }
    await delay(75)
  }
  if (!selected) throw new Error('Did not reach and select the normal opening menu')
  if (!storyStarted) throw new Error('Did not enter actual opening story')
  if (!report.final) { report.final = await observe(); throw new Error('15-minute limit: room control not yet returned') }
  report.status = bottomOnly ? 'limited-bottom-page-captured-visual-review-pending' : 'runtime-completed-visual-review-pending'
} catch (error) {
  report.status = 'incomplete'
  report.failure = { name: error.name, message: error.message, stack: error.stack }
  console.error(error)
  if (page) {
    report.final = await observe().catch(() => null)
    await screenshot('99-stop-state', report.final).catch(() => {})
  }
  process.exitCode = 1
} finally {
  report.finishedAt = new Date().toISOString()
  report.durationMs = Date.now() - started
  report.sourceAfter = sourceIdentity()
  report.sourceStable = report.sourceBefore.treeSha256 === report.sourceAfter.treeSha256
  if (!report.sourceStable) { report.status = 'invalidated-source-changed'; process.exitCode = 1 }
  report.rawFiles = ['states.jsonl', 'runtime.jsonl'].map((name) => ({ path: resolve(out, name), sha256: hash(readFileSync(resolve(out, name))) }))
  writeFileSync(resolve(out, 'opening-browser-runtime.json'), `${JSON.stringify(report, null, 2)}\n`)
  if (browser) await browser.close()
  console.log(JSON.stringify({ status: report.status, durationMs: report.durationMs, screenshots: report.screenshots.map((s) => s.path), historyRows: report.observedHistory.length, pageErrors: report.pageErrors.length, httpErrors: report.httpErrors.length, failedRequests: report.requestFailures.length, sourceStable: report.sourceStable, failure: report.failure }))
}
