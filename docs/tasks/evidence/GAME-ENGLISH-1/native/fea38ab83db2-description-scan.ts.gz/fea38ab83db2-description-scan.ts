import {readFileSync} from 'node:fs'
import {setGlobalEvents} from '/Users/zhangxu/illegal/type-pal/packages/game/src/core/event-system.ts'
import {getScriptDescLines} from '/Users/zhangxu/illegal/type-pal/packages/game/src/core/menu/script-desc.ts'
import {setEnglishMessages} from '/Users/zhangxu/illegal/type-pal/packages/game/src/localization/messages.ts'
import {setLanguage} from '/Users/zhangxu/illegal/type-pal/packages/game/src/localization/language.ts'
import {SMALL_FONT} from '/Users/zhangxu/illegal/type-pal/packages/game/src/present/small-font.ts'
const root='/Users/zhangxu/illegal/type-pal';const read=(path:string)=>JSON.parse(readFileSync(`${root}/data/extracted/${path}`,'utf8'))
setGlobalEvents(read('events/all.json').segments[0].commands);setEnglishMessages(read('lookup/en.json').groups);setLanguage('en')
const records=[]
for(const kind of ['items','spells'])for(const item of read(`data/${kind}.json`)){
 const lines=getScriptDescLines(item.scriptDesc);const missing=lines.flatMap((line:string)=>[...line].filter(ch=>!SMALL_FONT.has(ch.codePointAt(0)!)))
 if(missing.length)records.push({kind,id:item.id,scriptDesc:item.scriptDesc,missing,lines})
}
console.log(JSON.stringify({recordCount:records.length,characters:[...new Set(records.flatMap(r=>r.missing))],records},null,2));setLanguage('zh-CN')
