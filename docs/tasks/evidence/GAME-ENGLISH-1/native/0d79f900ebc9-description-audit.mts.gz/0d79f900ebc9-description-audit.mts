import { readFileSync } from 'node:fs'
import { wrapEnglishDialogLine } from '../../packages/game/src/localization/messages.ts'
const raw = readFileSync('data/en/win_files/m_eng.slf','utf8')
const groups = [...raw.matchAll(/\[BEGIN MESSAGE\]\s*(\d+)\r?\n([\s\S]*?)\[END MESSAGE\]\s*(\d+)/g)].map(m=>({start:+m[1]!,end:+m[3]!,lines:m[2]!.trimEnd().split(/\r?\n/).filter(l=>l!=='[CLEAR MESSAGE]')}))
const all=JSON.parse(readFileSync('data/extracted/events/all.json','utf8')).segments.flatMap(s=>s.commands)
for (const kind of ['items','spells']) {
 const table=JSON.parse(readFileSync(`data/extracted/data/${kind}.json`,'utf8'))
 const rows=[]
 for(const item of table){const ip=item.scriptDesc;if(!ip)continue;let p=ip;while(all[p]?.op!=='showDialog'&&p<ip+4)p++;const cmd=all[p];if(cmd?.op!=='showDialog')continue;const g=groups.find(g=>g.start===cmd.messageIndex);if(!g)continue;const lines=g.lines.flatMap(l=>wrapEnglishDialogLine(l,kind==='items'?240:216));rows.push({id:item.id,name:item._name,lines:lines.length,span:[g.start,g.end]}); const extra=[...new Set([...g.lines.join('')].filter(c=>c.codePointAt(0)>127))];if(extra.length)console.log('nonASCII',item.id,JSON.stringify(extra))}
 rows.sort((a,b)=>b.lines-a.lines);console.log(kind,rows.slice(0,8))
}
