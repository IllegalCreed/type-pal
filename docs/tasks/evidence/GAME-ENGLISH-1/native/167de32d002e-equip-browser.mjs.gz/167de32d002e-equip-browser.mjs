import {chromium} from 'playwright'
import {writeFile} from 'node:fs/promises'
const browser=await chromium.launch({headless:true,channel:'chrome'})
const context=await browser.newContext({viewport:{width:1100,height:760}})
await context.addInitScript(()=>{localStorage.setItem('tp-language','en');localStorage.setItem('tp-analytics-consent','denied')})
const page=await context.newPage()
const errors=[]
page.on('pageerror',e=>errors.push(String(e)))
await page.goto('http://localhost:6005/?skip-intro=1')
await page.waitForFunction(()=>window.__tpgs?.mode==='explore',{timeout:60000})
const decline=page.getByRole('button',{name:'Decline',exact:true});if(await decline.isVisible())await decline.click()
// Controlled visual fixture only: add one real Hat through the public inventory helper.
// This is not a natural story/E2E checkpoint.
await page.evaluate(async()=>{const {addItemToInventory}=await import('/src/core/inventory-state.ts');addItemToInventory(window.__tpgs,201,1)})
await page.locator('#screen').click()
const keys=['Escape','ArrowDown','ArrowDown','Enter','Enter','Enter']
for(const key of keys){await page.keyboard.press(key);await page.waitForTimeout(150)}
let state=await page.evaluate(()=>({menu:window.__tpgs.menuStack,inventory:window.__tpgs.inventory}))
console.log(JSON.stringify(state))
await page.waitForFunction(()=>window.__tpgs.menuStack.at(-1)?.state?.phase==='pick-role')
await page.screenshot({path:'build/english-integration/equip-width-english.png'})
const beforeSwitch=JSON.stringify(state)
await page.locator('#tp-tools-launcher').click()
await page.locator('.tp-tab[data-key=system]').click()
await page.locator('#tp-language').selectOption('zh-CN')
await page.locator('.tp-close').click()
await page.waitForTimeout(200)
await page.screenshot({path:'build/english-integration/equip-width-chinese.png'})
const afterSwitch=await page.evaluate(()=>({menu:window.__tpgs.menuStack,inventory:window.__tpgs.inventory}))
state={english:state,chinese:afterSwitch,sameState:beforeSwitch===JSON.stringify(afterSwitch)}
await writeFile('build/english-integration/equip-browser.json',JSON.stringify({keys,state,errors,scope:'Controlled dev-functional visual fixture; real item201 added through public helper, real UI keys to equip pick-role; not a natural story checkpoint'},null,2))
await browser.close()
