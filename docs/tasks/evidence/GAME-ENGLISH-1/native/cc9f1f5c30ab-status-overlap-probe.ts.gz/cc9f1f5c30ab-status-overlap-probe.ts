import {readFileSync} from 'node:fs'
import {openMkf,readChunk} from '/Users/zhangxu/illegal/type-pal/packages/pal-extract/src/io/mkf.ts'
import {decodeRle} from '/Users/zhangxu/illegal/type-pal/packages/pal-extract/src/io/rle.ts'
import {parseBdf} from '/Users/zhangxu/illegal/type-pal/packages/pal-extract/src/font/bdf-to-json.ts'
import {createInitialGameState,hydratePlayerRolesRuntime} from '/Users/zhangxu/illegal/type-pal/packages/game/src/core/game-state.ts'
import {createPlayerStatus} from '/Users/zhangxu/illegal/type-pal/packages/game/src/core/menu/player-status.ts'
import {drawPlayerStatus} from '/Users/zhangxu/illegal/type-pal/packages/game/src/present/menu/draw-player-status.ts'
import {createFramebuffer} from '/Users/zhangxu/illegal/type-pal/packages/game/src/present/framebuffer.ts'
import {setWordTable,setEnglishWordTable} from '/Users/zhangxu/illegal/type-pal/packages/game/src/core/word-lookup.ts'
import {setLanguage} from '/Users/zhangxu/illegal/type-pal/packages/game/src/localization/language.ts'
import {setEnglishLayout} from '/Users/zhangxu/illegal/type-pal/packages/game/src/localization/layout.ts'
const root='/Users/zhangxu/illegal/type-pal';const read=(path:string)=>JSON.parse(readFileSync(`${root}/data/extracted/${path}`,'utf8'))
const pack=read('lookup/en.json');setWordTable(read('lookup/words.json').flat);setEnglishWordTable(pack.words);setEnglishLayout(pack.layout);setLanguage('en')
const roles=read('data/player-roles.json');const items=read('data/items.json');const gs=createInitialGameState({x:0,y:0,facing:'down'});hydratePlayerRolesRuntime(gs.PlayerRolesRuntime,roles);gs.partyMembers=[4];gs.PlayerRolesRuntime.rgwEquipment[0]![4]=202
const ball=openMkf(readFileSync(`${root}/data/raw/BALL.MKF`));const itemIcons=new Map();for(const id of [202,229]){const item=items.find((i:any)=>i.id===id);const b=readChunk(ball,item.bitmap);const frame=decodeRle(b.subarray(4));itemIcons.set(item.bitmap,{width:frame.width,height:frame.height,indices:frame.pixels,opaque:frame.opaque})}
const gmap=new Map(parseBdf(readFileSync(`${root}/data/raw/unifont-cn.bdf`,'utf8')).map(g=>[g.codepoint,g]));const glyphs={get:(cp:number)=>gmap.get(cp),has:(cp:number)=>gmap.has(cp)}
const a=createFramebuffer();drawPlayerStatus({fb:a,state:createPlayerStatus([4]),gs,playerRoles:roles,items,uiSpriteFrames:[],glyphs,itemIcons})
gs.PlayerRolesRuntime.rgwEquipment[1]![4]=229
const b=createFramebuffer();drawPlayerStatus({fb:b,state:createPlayerStatus([4]),gs,playerRoles:roles,items,uiSpriteFrames:[],glyphs,itemIcons})
const lost=[];for(let y=40;y<56;y++)for(let x=101;x<181;x++){const i=y*320+x;if(a.indices[i]===0xbe&&b.indices[i]!==0xbe)lost.push({x,y,before:a.indices[i],after:b.indices[i]})}
console.log(JSON.stringify({role:4,head:202,headName:pack.words['202'],shoulder:229,shoulderName:pack.words['229'],bothEquipable:items.find((i:any)=>i.id===202).flags.equipableBy[4]&&items.find((i:any)=>i.id===229).flags.equipableBy[4],lostNamePixels:lost.length,examples:lost.slice(0,12)},null,2));setLanguage('zh-CN')
