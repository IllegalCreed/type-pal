import { spawn } from 'node:child_process'
import { createHash } from 'node:crypto'
import { cpSync, existsSync, mkdirSync, mkdtempSync, readFileSync, rmSync, symlinkSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { resolve } from 'node:path'
import ts from 'typescript'
import { preciseCoverageEnvironment } from '../../scripts/coverage/environment.mjs'
const root=process.cwd()
const out=resolve(root,'build/english-test-boundaries')
const hash=bytes=>createHash('sha256').update(bytes).digest('hex')
const run=async(name,args,cwd)=>{
 const startedAt=new Date().toISOString()
 const child=spawn(process.execPath,args,{cwd,env:preciseCoverageEnvironment()})
 let stdout='',stderr='',spawnError=null
 child.stdout.setEncoding('utf8').on('data',data=>stdout+=data)
 child.stderr.setEncoding('utf8').on('data',data=>stderr+=data)
 child.on('error',error=>spawnError=String(error))
 const result=await new Promise(done=>child.on('close',(exit,signal)=>done({exit,signal})))
 writeFileSync(`${out}/${name}-stdout.txt`,stdout)
 writeFileSync(`${out}/${name}-stderr.txt`,stderr)
 const receipt={command:process.execPath,args,cwd,startedAt,endedAt:new Date().toISOString(),...result,spawnError}
 writeFileSync(`${out}/${name}-command.json`,`${JSON.stringify(receipt,null,2)}\n`)
 return receipt
}
const counters=[
 {
  name:'premature-cleanup', file:'src/cli.ts', testFile:'src/cli-localization.test.ts',
  rowToRemove:["  ['another flag as source path', '--unknown', '--english-slf requires a file path'],\n", "  [\n    'faithful extraction with an English source',\n    'source.slf',\n    '--faithful cannot use --english-slf',\n  ],\n"],
  mutate(text){
   const begin=text.indexOf('  // No existing output is removed until source identity')
   const end=text.indexOf("\n  writeJson(resolve(OUT, 'script-corrections.json')",begin)
   if(begin<0||end<0) throw Error('cleanup anchor missing')
   const cleanup=text.slice(begin,end)
   const removed=text.slice(0,begin)+text.slice(end)
   return removed.replace('  const englishOption = process.argv.indexOf',cleanup+'\n  const englishOption = process.argv.indexOf')
  }
 },
 {
  name:'unused-alias',file:'src/localization/build-language-pack.ts',testFile:'src/localization/build-language-pack.test.ts',
  rowToRemove:["  ['wrong-span', 'English message range 20:22 mismatch'],\n"],
  mutate(text){
   const guard="  if (usedAliases.size !== Object.keys(revisions.aliases).length)\n    throw new Error('Unused English message alias')\n"
   if(!text.includes(guard)) throw Error('alias anchor missing')
   return text.replace(guard,'')
  }
 }
]
const receipts=[]
for(const counter of counters){
 const tree=mkdtempSync(resolve(tmpdir(),'pal-english-counter-'))
 const pkg=resolve(tree,'packages/pal-extract')
 const sourcePath=resolve(root,'packages/pal-extract',counter.file)
 const original=readFileSync(sourcePath)
 const originalTest=readFileSync(resolve(root,'packages/pal-extract',counter.testFile),'utf8')
 let restored=false
 try{
  mkdirSync(pkg,{recursive:true})
  symlinkSync(resolve(root,'node_modules'),resolve(tree,'node_modules'),'dir')
  cpSync(resolve(root,'packages/pal-extract/src'),resolve(pkg,'src'),{recursive:true})
  cpSync(resolve(root,'packages/pal-extract/package.json'),resolve(pkg,'package.json'))
  symlinkSync(resolve(root,'packages/pal-extract/node_modules'),resolve(pkg,'node_modules'),'dir')
  const ast=ts.createSourceFile(counter.testFile,originalTest,ts.ScriptTarget.Latest,true,ts.ScriptKind.TS)
  let narrowed=ast.statements.filter(statement=>{
   const text=statement.getText(ast)
   return !text.startsWith('test(') && (!text.startsWith('test.each(')||text.includes('before replacing previous output')||text.includes('without mutating source text'))
  }).map(statement=>statement.getFullText(ast)).join('')
  for(const row of counter.rowToRemove){
   if(!narrowed.includes(row)) throw Error('counter row anchor missing')
   narrowed=narrowed.replace(row,'')
  }
  writeFileSync(resolve(pkg,counter.testFile),narrowed)
  const mutation=counter.mutate(original.toString())
  if(mutation===original.toString()) throw Error('vacuous mutation')
  writeFileSync(resolve(pkg,counter.file),mutation)
  const args=(phase)=>[resolve(root,'node_modules/vitest/vitest.mjs'),'run',counter.testFile,'--reporter=default','--reporter=json',`--outputFile=${out}/${counter.name}-${phase}-native.json`]
  const mutantRun=await run(counter.name+'-mutant',args('mutant'),pkg)
  writeFileSync(resolve(pkg,counter.file),original)
  restored=readFileSync(resolve(pkg,counter.file)).equals(original)
  const restoredRun=await run(counter.name+'-restored',args('restored'),pkg)
  receipts.push({name:counter.name,sourcePath,testPath:resolve(root,'packages/pal-extract',counter.testFile),sourceSha256:hash(original),mutantSha256:hash(mutation),originalTestSha256:hash(originalTest),narrowedTestSha256:hash(narrowed),narrowing:'retain original imports/fixtures and exact test.each callback, selecting one authored row; no -t/skip/pending',mutantRun,restoredRun,restored,repositorySourceUnchanged:readFileSync(sourcePath).equals(original),tree})
 }finally{
  rmSync(tree,{recursive:true,force:true})
  if(receipts.at(-1)?.tree===tree) receipts.at(-1).temporaryTreeRemoved=!existsSync(tree)
 }
}
writeFileSync(`${out}/counters.json`,`${JSON.stringify(receipts,null,2)}\n`)
console.log(JSON.stringify(receipts.map(({name,mutantRun,restoredRun,restored,repositorySourceUnchanged,temporaryTreeRemoved})=>({name,mutantExit:mutantRun.exit,restoredExit:restoredRun.exit,restored,repositorySourceUnchanged,temporaryTreeRemoved})),null,2))
