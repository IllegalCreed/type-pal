import { createHash } from 'node:crypto'
import { existsSync, readFileSync, writeFileSync, mkdirSync, statSync, readdirSync } from 'node:fs'
import { basename, resolve } from 'node:path'
import { gzipSync } from 'node:zlib'
const root=process.cwd(),dest='docs/ops/evidence/GAME-ENGLISH-1/native'
mkdirSync(dest,{recursive:true})
const sha=v=>createHash('sha256').update(v).digest('hex')
const candidates=new Set()
const scan=value=>{if(typeof value==='string'&&value.includes('/build/')&&existsSync(value)&&statSync(value).isFile())candidates.add(value);else if(Array.isArray(value))value.forEach(scan);else if(value&&typeof value==='object')Object.values(value).forEach(scan)}
for(const name of ['text-review','canvas-independent-review','equip-width-source-review','integration-review','dialog-clear-review','text-boundary-review','dialog-literal-review','root-canvas-review'])scan(JSON.parse(readFileSync(`docs/ops/evidence/GAME-ENGLISH-1/${name}.json`)))
const local=readdirSync('build/english-integration').filter(name=>/[.](?:json|txt|log|mjs|mts|ts|patch|info)$/.test(name))
for(const name of local){const path=resolve('build/english-integration',name);if(existsSync(path))candidates.add(path)}
for(const folder of ['/Users/zhangxu/.codex/worktrees/english-dialog/type-pal/build/english-dialog-clear','/Users/zhangxu/.codex/worktrees/english-text/type-pal/build/english-test-boundaries','/Users/zhangxu/.codex/worktrees/english-dialog/type-pal/build/english-dialog-literal','/Users/zhangxu/.codex/worktrees/english-dialog/type-pal/build/root-canvas-followup']){
 for(const name of readdirSync(folder)){
  const path=resolve(folder,name)
  if(/[.](?:json|txt|log|mjs|mts|ts|patch|info)$/.test(name)&&statSync(path).isFile())candidates.add(path)
 }
}
for(const file of ['coverage/fast/summary.json','coverage/fast/game/lcov.info','coverage/fast/pal-extract/lcov.info']){
 if(existsSync(file))candidates.add(resolve(file))
}
const entries=[]
for(const file of [...candidates].sort()){
 if(file.endsWith('/en.json')||!/[.](?:json|txt|log|mjs|mts|ts|patch|info)$/.test(file))continue
 const data=readFileSync(file),hash=sha(data),path=`${dest}/${hash.slice(0,12)}-${basename(file)}.gz`
 const compressed=gzipSync(data)
 writeFileSync(path,compressed)
 entries.push({originalPath:file,publishedPath:path,bytes:data.length,sha256:hash,compressedSha256:sha(compressed)})
}
writeFileSync('docs/ops/evidence/GAME-ENGLISH-1/native-publication.json',JSON.stringify({kind:'lossless-native-publication',task:'GAME-ENGLISH-1',date:'2026-10-22',owner:'Codex',readCommand:'gzip -cd <publishedPath>',scope:'Original bytes including failed/calibration runs; no raw SLF/English pack/binary resources or screenshots bundled. Claims remain bounded by contributor/root review.',entries},null,2)+'\n')
console.log({published:entries.length,bytes:entries.reduce((n,e)=>n+e.bytes,0)})
