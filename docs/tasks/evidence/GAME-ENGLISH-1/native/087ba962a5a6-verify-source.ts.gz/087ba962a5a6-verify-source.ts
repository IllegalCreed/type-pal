import {createHash} from 'node:crypto'
import {readFileSync,writeFileSync} from 'node:fs'
import {parseSss} from '../../packages/pal-extract/src/io/sss.js'
import {parseMessages} from '../../packages/pal-extract/src/io/msg.js'
import {parseSlf} from '../../packages/pal-extract/src/io/slf.js'
import {disasm} from '../../packages/pal-extract/src/events/disasm.js'
import {correctScripts} from '../../packages/pal-extract/src/events/script-corrections.js'
import {buildLanguagePack} from '../../packages/pal-extract/src/localization/build-language-pack.js'
import {englishRevisions} from '../../packages/pal-extract/src/localization/english-revisions.js'
import {parseBdf} from '../../packages/pal-extract/src/font/bdf-to-json.js'
const root='/Users/zhangxu/illegal/type-pal'
const hash=(bytes:Uint8Array)=>createHash('sha256').update(bytes).digest('hex')
const source=readFileSync(`${root}/data/en/win_files/m_eng.slf`)
const sssBytes=readFileSync(`${root}/data/raw/SSS.MKF`)
const messageBytes=readFileSync(`${root}/data/raw/M.MSG`)
const sss=parseSss(sssBytes)
const corrected=correctScripts(sss,hash(sssBytes),parseMessages(messageBytes,sss.messageOffsets))
const pack=buildLanguagePack(parseSlf(new TextDecoder('utf-8',{fatal:true}).decode(source)),disasm(corrected.sss.bytecode,corrected.messages),{slfSha256:hash(source),scriptSha256:hash(corrected.sss.bytecode),messageSha256:hash(messageBytes)},englishRevisions)
const text=[...Object.values(pack.words),...pack.groups.flatMap(group=>group.lines.filter(line=>line!==null))].join('')
const glyphs=new Set(parseBdf(readFileSync(`${root}/data/raw/unifont-cn.bdf`,'utf8')).map(glyph=>glyph.codepoint))
const missing=[...new Set([...text].filter(ch=>!glyphs.has(ch.codePointAt(0)!)))];if(missing.length)throw new Error(`Missing glyphs: ${JSON.stringify(missing)}`)
const longWords=Object.entries(pack.words).filter(([,word])=>word.length>10);if(longWords.length)throw new Error(`Words exceed 10 columns: ${JSON.stringify(longWords)}`)
writeFileSync('build/english-text/en.json',JSON.stringify(pack))
console.log(JSON.stringify({source:pack.source,wordCount:Object.keys(pack.words).length,groupCount:pack.groups.length,clearBoundaries:pack.groups.flatMap(g=>g.lines).filter(l=>l===null).length,missingGlyphs:missing,longWords,supplementWords:Object.keys(englishRevisions.words).length,supplementGroups:Object.keys(englishRevisions.groups).length,aliases:pack.groups.filter(g=>[12749,12866].includes(g.start)),opening:pack.groups.find(g=>g.start===0),ordinaryDialog:pack.groups.find(g=>g.start===6640)},null,2))
