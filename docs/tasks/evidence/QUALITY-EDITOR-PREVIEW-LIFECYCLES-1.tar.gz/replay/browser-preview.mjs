import assert from 'node:assert/strict'
import { createRequire } from 'node:module'
import { dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'
const projectRoot = process.argv[2]
const { chromium } = createRequire(join(projectRoot, 'package.json'))('playwright')
const scratch = dirname(fileURLToPath(import.meta.url))
const browser = await chromium.launch({ channel: 'chrome' })
const diagnostics = { console: [], pageErrors: [], unsuccessfulResponses: [] }
const activities = []
const log = (result) => activities.push(result)
async function pageAt(route, viewport) {
  const width = viewport?.width ?? 1280
  const page = await browser.newPage({ viewport: { width, height: 900 } })
  page.on('pageerror', (error) => diagnostics.pageErrors.push({ route, message: error.message }))
  page.on('console', (message) => {
    if (message.type() === 'warning' || message.type() === 'error')
      diagnostics.console.push({ route, level: message.type(), message: message.text(), location: message.location().url })
  })
  page.on('response', (response) => {
    if (response.status() >= 400) diagnostics.unsuccessfulResponses.push({ route, status: response.status(), url: response.url() })
  })
  await page.goto('http://127.0.0.1:6197/?ui_samples&'+route, { waitUntil: 'domcontentloaded', timeout: 20000 })
  return page
}

try {
  for (const width of [1280, 900]) {
    const page = await pageAt('module=actor&page=workspace&object=li-xiaoyao', { width })
    try {
      await page.getByRole('button', { name: '管理成长', exact: true }).click({ timeout: 20000 })
      const editor = page.locator('.actor-leveling-editor')
      await editor.waitFor()
      const overflow = await editor.evaluate((element) => element.scrollWidth - element.clientWidth)
      assert.ok(overflow <= 1, 'growth controls do not overflow their panel')
      await editor.getByRole('button', { name: /编辑曲线/ }).click()
      const chart = page.locator('.level-curve-chart')
      await chart.waitFor()
      const box = await chart.boundingBox()
      assert.ok(box?.height > 0 && box.width > 0)
      const count = page.getByLabel('级数', { exact: true })
      const originalCount = Number(await count.inputValue())
      assert.ok(originalCount > 20)
      await page.mouse.move(box.x + box.width * 0.97, box.y + box.height * 0.5)
      await page.mouse.wheel(0, -120)
      await page.locator('.level-curve-toolbar').getByText(/^L\d+–\d+$/).waitFor()
      await count.fill('2')
      await count.press('Enter')
      await page.waitForFunction(() => document.querySelectorAll('.level-curve-point').length === 2)
      assert.equal(await page.locator('.level-curve-toolbar').getByText(/^L\d+–\d+$/).count(), 0)
      await count.blur()
      await page.keyboard.press('Meta+z')
      await page.waitForFunction((expected) => document.querySelectorAll('.level-curve-point').length > 2 && document.querySelector('input#level-curve-count')?.value === String(expected), originalCount)
      log({ width, chart: 'native wheel, resize to 2 and editor undo', originalCount, overflow })
    } finally {
      await page.close()
    }
  }

  const audio = await pageAt('module=asset&page=sound&object=sound.pal.255')
  try {
    const player = audio.locator('.audio-player')
    await player.getByText('就绪', { exact: true }).waitFor({ timeout: 20000 })
    assert.ok((await player.locator('svg line').count()) > 1)
    await player.getByRole('button', { name: '播放', exact: true }).click()
    await player.getByText('正在播放', { exact: true }).waitFor()
    await player.getByRole('button', { name: '停止', exact: true }).click()
    await player.getByText('就绪', { exact: true }).waitFor()
    assert.equal(await player.locator('input[type=range]').inputValue(), '0')
    log({ audio: 'real AudioContext decode, play and stop', clock: await player.locator('output').innerText() })
  } finally {
    await audio.close()
  }

  const videoPage = await pageAt('module=asset&page=cutscene&object=video.pal.004')
  try {
    const video = videoPage.locator('.cutscene-video-stage video')
    const metadata = (element) => ({ width: element.videoWidth, height: element.videoHeight, source: element.getAttribute('src') })
    await videoPage.waitForFunction(() => document.querySelector('.cutscene-video-stage video')?.videoWidth > 0, undefined, { timeout: 20000 })
    const old = await video.evaluate(metadata)
    assert.notEqual(old.width, 80)
    await videoPage.locator('.cutscene-main').getByRole('button', { name: '替换', exact: true }).click()
    await videoPage.locator('input[accept="video/mp4,video/webm"]').nth(1).setInputFiles(join(scratch,'replacement-video.mp4'))
    await videoPage.waitForFunction(() => document.querySelector('.cutscene-video-stage video')?.videoWidth === 80)
    const replaced = await video.evaluate(metadata)
    assert.equal(replaced.height, 60)
    assert.notEqual(replaced.source, old.source)
    assert.match(videoPage.url(), /object=video.pal.004/)
    await videoPage.keyboard.press('Meta+z')
    await videoPage.waitForFunction((expected) => document.querySelector('.cutscene-video-stage video')?.videoWidth === expected, old.width)
    const restored = await video.evaluate(metadata)
    assert.equal(restored.height,old.height)
    assert.notEqual(restored.source,replaced.source)
    log({ video: 'browser-native same-ID MP4 replacement and undo', old: [old.width, old.height], replaced: [replaced.width, replaced.height] })
  } finally {
    await videoPage.close()
  }
  assert.deepEqual(diagnostics.pageErrors, [])
} finally {
  console.log(JSON.stringify({ activities, diagnostics }, null, 2))
  await browser.close()
}
