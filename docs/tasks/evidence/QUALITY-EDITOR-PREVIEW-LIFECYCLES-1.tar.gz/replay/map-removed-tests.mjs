import { readFileSync } from 'node:fs'
import { execFileSync } from 'node:child_process'
import { createRequire } from 'node:module'
import { resolve } from 'node:path'

const ts = createRequire(resolve('package.json'))('typescript')
const tests = (path) => /\.(test|spec)\.[cm]?tsx?$/.test(path)

function registrations(path, source) {
  const file = ts.createSourceFile(path, source, ts.ScriptTarget.ESNext, true)
  const values = []
  function walk(node) {
    if (ts.isCallExpression(node) && node.arguments.length) {
      const call = node.expression.getText(file)
      const literal = node.arguments[0]
      if (/^(?:test|it)(?:$|\.(?:each|concurrent|for)\b)/.test(call) &&
          (ts.isStringLiteralLike(literal) || ts.isTemplateExpression(literal))) {
        const line = file.getLineAndCharacterOfPosition(node.getStart(file)).line + 1
        values.push({ line, title: ts.isStringLiteralLike(literal) ? literal.text : literal.getText(file) })
      }
    }
    ts.forEachChild(node, walk)
  }
  walk(file)
  return values
}
const records = readFileSync(process.argv[2], 'utf8').trim().split('\n').map(JSON.parse)
const entries = records.filter((item) => item.before && !item.after && tests(item.path)).map((row) => ({
  beforePath: row.path,
  ref: row.before.ref,
  registrations: registrations(
    row.path,
    execFileSync('git', ['show', row.before.ref + ':' + row.path], { encoding: 'utf8' }),
  ),
  disposition: row.E,
  paths: row.successors.filter(tests),
}))
const references = [...new Set(entries.flatMap((entry) => entry.paths))]
  .map((path) => ({ path, registrations: registrations(path, readFileSync(path, 'utf8')) }))
console.log(JSON.stringify({
  description: 'Static registration anchors. Data-driven registrations are listed as the original source expression; executions.json contains actual runtime test identities. Per-file E states the consolidation/oracle, not automatic one-to-one certificate.',
  entries,
  references,
}, null, 2))
