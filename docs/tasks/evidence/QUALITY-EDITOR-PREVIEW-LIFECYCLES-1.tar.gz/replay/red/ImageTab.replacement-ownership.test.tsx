// @vitest-environment jsdom

import { act } from 'react'
import { expect, test, vi } from 'vitest'
import { waitForReact } from '../__tests__/react-io-wait.js'
import { sha256Hex } from '../core/binary-signature.js'
import { assertProjectSaveValid } from '../core/project-diagnostics.js'
import { clickButton, deferred, loadFilesIntoInput } from './__tests__/glm-ui-wave-kit.js'
import { installImageWorkbenchTestHost, seedImage } from './__tests__/image-workbench-test-host.js'
import { pngFileOf, pngRgba, solidRgba } from './__tests__/kimi-editor-workflows/kit.js'

const { host, mountTab, replacePng, waitPreviewSize, fileInputAt } = installImageWorkbenchTestHost()

test('interleaved replacements cannot associate undo bytes with a different revision', async () => {
  const id = 'portrait.replaced'
  const original = pngRgba(2, 1, solidRgba(2, 1, [240, 180, 12, 255]))
  const first = pngRgba(3, 1, solidRgba(3, 1, [5, 240, 60, 255]))
  const second = pngRgba(4, 1, solidRgba(4, 1, [13, 75, 220, 255]))
  const { session } = await mountTab({
    focus: id,
    async prepare(mounted) {
      await seedImage(mounted, { id, kind: 'portrait', label: '英雄', png: original })
    },
  })
  await waitPreviewSize('2 × 1')
  const firstFile = pngFileOf('first.png', first)
  const bytes = await firstFile.arrayBuffer()
  const gate = deferred<ArrayBuffer>()
  const firstRead = vi.spyOn(firstFile, 'arrayBuffer').mockReturnValue(gate.promise)
  const secondSha = await sha256Hex(second)
  const version = session.getHistoryVersion()
  try {
    await clickButton(host, '替换')
    await loadFilesIntoInput(fileInputAt(1), [firstFile])
    await waitForReact(() => expect(firstRead).toHaveBeenCalledTimes(1))
    await replacePng('second.png', second)
    await waitForReact(() => expect(session.getHistoryVersion()).toBe(version + 1))
    expect(session.getState().assetCatalog.assets[id]?.sha256).toBe(secondSha)
  } finally {
    await act(async () => gate.resolve(bytes))
  }
  await waitForReact(() =>
    expect(
      session.getHistoryVersion() > version + 1 ||
      Boolean(host.querySelector('.image-library-outliner .cf-err')),
    ).toBe(true),
  )
  await act(async () => expect(session.undo()).toBe(true))
  const state = session.getState()
  const restored = state.assetCatalog.assets[id]
  expect(restored).toBeDefined()
  expect(await sha256Hex(state.assetBlobs[restored!.path]!)).toBe(restored!.sha256)
  assertProjectSaveValid(state)
})
