from pathlib import Path
import json,hashlib,subprocess,copy,gzip
base='0bc82025928b4fe13dce0f34c3a8696507d04032';root=Path.cwd();p=Path('docs/ops/evidence/QUALITY-PRE94-RETROSPECTIVE-1/quality-standard');prefix=Path('docs/phase-governance/reviews');sha=lambda b:hashlib.sha256(b).hexdigest();blob=lambda path:subprocess.check_output(['git','show',base+':'+str(path)]);dump=lambda path,d:Path(path).write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
# Machine route binds the actual AGENTS row and checks the new guide's template body.
f=Path('docs/phase-governance/routing.json');routing=json.loads(blob(f));routing['routes'].insert(1,{'operation':'开发、修改、重构或审查代码','required':['docs/ops/code-quality.md','docs/ops/agent-workflow.md']});routing['migratedDocuments'].append({'path':'docs/ops/code-quality.md','templateId':'guide-runbook-v1'});assert f.read_bytes()==blob(f) or json.loads(f.read_text())==routing;dump(f,routing)
f=Path('docs/phase-governance/document-registry.json');registry=json.loads(blob(f));registry['entries'].append({'path':'docs/ops/code-quality.md','phase':'ops','docType':'guide-runbook','templateId':'guide-runbook-v1','templateVersion':'1.0.0','templateCompliance':'template-compliant','reviewStatus':'content-reviewed','reviewRecord':'20261004-semantic-current-batch.json'});s=registry['summary'];s['total']+=1;s['byPhase']['ops']+=1;s['byType']['guide-runbook']+=1;s['reviewStatus']['content-reviewed']+=1;s['templateCompliance']['template-compliant']+=1;assert f.read_bytes()==blob(f) or json.loads(f.read_text())==registry;dump(f,registry)
# Review only changed document content, retain old evidence/provenance in dated history.
targets={
 '20261004-semantic-current-batch.json':['docs/ops/agent-workflow.md','docs/ops/README.md','docs/ops/templates/README.md','docs/ops/board.md'],
 '20261017-r58-task-template-sources.json':['docs/ops/templates/TASK-template.md','docs/ops/templates/TASK-lite-template.md'],
 '20261015-agent-first-routing-batch.json':['docs/phase-governance/templates/README.md'],
 '20261017-r62-template-sources.json':['docs/phase-governance/templates/task-card.md'],
}
conclusions={
 'docs/ops/agent-workflow.md':'All code work now enters the canonical eight-axis standard; implementation, independent code review and done gates consume evidence freshness and distinct review/remediation/integration decisions. Existing risk/visual/test/ownership rules retained.',
 'docs/ops/README.md':'Current Ops navigation links the cross-phase engineering standard without copying task progress or eight-axis clauses.',
 'docs/ops/templates/README.md':'Full/lite task forms share canonical quality and recheck requirements. Task type/status/required sections unchanged; compact references allowed.',
 'docs/ops/board.md':'Only pre94 next-step assignment changes: Codex establishes permanent standard, GLM pilot remains read-only;83 states and all other rows unchanged.',
 'docs/ops/templates/TASK-template.md':'User-authorized full task source now prompts per-file eight-axis evidence, issue disposition, identity/invalidation, read-only fast recheck and actual gate limits. Copyable task headings/status preserved; historical byte-preservation claim does not certify new bytes.',
 'docs/ops/templates/TASK-lite-template.md':'Lite task source receives the same quality recording prompts, with compact references and non-code applicability; existing high-risk upgrade rule and state machine preserved.',
 'docs/phase-governance/templates/README.md':'Registry navigation identifies permanent quality obligations in task acceptance; no docType/status/requiredSections or schema version change.',
 'docs/phase-governance/templates/task-card.md':'Generic task-card acceptance links the canonical quality/recheck contract, so direct generic-template users receive the same requirements as Ops variants; existing structural contract unchanged.',
}
records=[]
def advance(d,path,record,kind='content'):
 r=next(r for r in d['entries'] if r['path']==path);old=copy.deepcopy(r);before=blob(path);body=Path(path).read_bytes();assert r['afterSha256']==sha(before),(path,r['afterSha256'],sha(before));h=sha(body)
 history={'revision':base,'date':'2026-10-18','action':'User-authorized permanent engineering-quality standard integration','previousAfterSha256':r['afterSha256'],'scope':conclusions.get(path,'Bounded incoming metadata binding only, no unrelated verdict/history change.'),'evidence':str(p/'README.md'),'notRun':['product runtime','whole repository check','official coverage ratchet','protected fast','E2E','visual']}
 if kind=='content':
  history['previousCoreConclusion']=r['coreConclusion'];history['previousEvidence']=r['evidence'];r['coreConclusion']=conclusions[path];r['readMethod']='Full current Markdown and exact authorized delta read; actual route/template consumers checked';r['reviewNotes']=str(r.get('reviewNotes',''))+'\n2026-10-18: Codex read current authorized delta. Prior non-author/provenance applies only to its historical SHA. No new third-party or product execution credit.';r['evidence']={'kind':'authorized-engineering-quality-contract-content-review','path':str(p/'README.md'),'afterSha256':h,'lineCount':len(body.decode().splitlines()),'scope':'Documentation content/entry/template integration only; no product or old code acceptance.'}
 r['revision']['history'].insert(0,history);r['afterSha256']=h;r['reviewedLines']='1-'+str(len(body.decode().splitlines()))
 for k in ['implementationSha','afterSha256']:
  if k in r['revision']:r['revision'][k]=h
 if isinstance(r.get('evidence'),dict):
  if 'afterSha256' in r['evidence']:r['evidence']['afterSha256']=h
  if 'lineCount' in r['evidence']:r['evidence']['lineCount']=len(body.decode().splitlines())
 if kind=='content':
  if 'candidateSha256' in r:r['candidateSha256']=h
  if 'documentStatus' in r:r['documentStatus']='current' if kind=='content' else r['documentStatus']
 records.append({'review':str(record),'target':path,'previousAfterSha256':sha(before),'afterSha256':h,'lines':len(body.decode().splitlines()),'kind':kind})
for name,paths in targets.items():
 f=prefix/name;assert f.read_bytes()==blob(f);d=json.loads(f.read_text())
 for path in paths:advance(d,path,f)
 if name=='20261004-semantic-current-batch.json':
  path='docs/ops/code-quality.md';raw=Path(path).read_bytes();h=sha(raw);guide={'path':path,'contentReviewStatus':'content-reviewed','docType':'guide-runbook','templateId':'guide-runbook-v1','template':'docs/phase-governance/templates/guide-runbook.md','templateVersion':'1.0.0','templateCompliance':'template-compliant','readMethod':'Full new Markdown, user decisions and direct entry/process/template consumer deltas read','reviewDepth':'deep-semantic','coreConclusion':'Permanent cross-phase engineering contract applies to all new features/fixes/refactors/tests/tools. Eight axes, justified structural changes, per-file evidence, cheap freshness checks and Codex/contributor/user responsibilities are explicit; review/remediation/integration are distinct and no old code is accepted by this documentation change.','truthAnchors':['AGENTS.md:操作与必读','docs/ops/agent-workflow.md','docs/ops/templates/TASK-template.md','docs/ops/templates/TASK-lite-template.md','User decisions in current quality conversation,2026-10-18'],'unresolved':['No general tool can automatically certify all design semantics; this is a delivery contract, not a claim that such a universal checker is implemented.'],'nextStep':'GLM first RLE three-file read-only pilot; Codex independently calibrates evidence/quality before granting implementation scope.','phase':'ops','module':'engineering-quality','capability':'eight-axis-development-and-acceptance','owner':'Codex','provenance':['2026-10-18 explicit user instructions','Codex authored and fully read current contract','Existing workflow/test governance and direct route/template consumers'],'sourceSha256':h,'afterSha256':h,'publicCallers':['AGENTS.md code operation route','CLAUDE.md shared collaboration rules','docs/ops/agent-workflow.md','Ops full/lite and generic task-card templates'],'legalInputs':['All authorized cross-phase code work; task-specific scope/risk controls remain'],'businessOracle':{'type':'semantic-contract-and-real-document-consumers','assertions':['A-H each require file-specific evidence and unknown/N/A handling; functionality alone does not close files','New feature behavior changes follow actual authorization; governance-only freezes are not global product policy','Identity/freshness/raw results and semantic judgement remain distinct; fast checks do not auto-certify design','Contributor execution does not substitute Codex code review; no fixed multi-model signatures','No product code, test, baseline, static rule or ledger closure changes']},'dedupe':{'result':'One canonical standard; current task and entrypoints reference instead of maintaining a second quality definition','against':['docs/ops/agent-workflow.md','docs/testing/governance.md','docs/ops/tasks/QUALITY-PRE94-RETROSPECTIVE-1.md']},'revision':{'currentSha':base,'implementationSha':h,'history':[{'revision':base,'date':'2026-10-18','action':'First permanent quality-contract edition under explicit user authorization','evidence':str(p/'README.md'),'notRun':['runtime','E2E','visual','coverage']}]},'evidence':{'kind':'current-engineering-contract-review','path':str(p/'README.md'),'afterSha256':h,'lineCount':len(raw.decode().splitlines())},'history':[{'date':'2026-10-18','action':'Initial current engineering-quality standard; no inherited old-file or model-identity credit'}],'supersedes':[],'stopLine':'Unknown critical premise, important unresolved issue, stale evidence, nonzero diagnostics or unauthorized scope does not receive acceptance.','reviewedLines':'1-'+str(len(raw.decode().splitlines()))}
  d['entries'].append(guide)
 dump(f,d);subprocess.run(['pnpm','exec','biome','format','--write',str(f)],check=True,stdout=subprocess.PIPE)
# Bounded incoming metadata edges; update after serialization of their targets.
for name,paths in {
 '20261017-r93-phase-governance-artifacts.json':[str(prefix/name) for name in targets],
 '20261017-r94-final-machine-artifacts.json':[str(prefix/'20261017-r93-phase-governance-artifacts.json'),'docs/phase-governance/document-registry.json','docs/phase-governance/routing.json'],
}.items():
 f=prefix/name;assert f.read_bytes()==blob(f);d=json.loads(f.read_text())
 for path in paths:advance(d,path,f,'binding')
 dump(f,d);subprocess.run(['pnpm','exec','biome','format','--write',str(f)],check=True,stdout=subprocess.PIPE)
dump(p/'review-bindings.json',{'base':base,'rows':records,'newGuide':'docs/ops/code-quality.md','note':'Only named rows advance. Prior evidence and conclusions copied into dated history for content changes; old raw and unrelated rows remain byte-equivalent as structured values.'})
(p/'metadata-producer.py.gz').write_bytes(gzip.compress(Path('/tmp/type-pal-quality-norm-metadata.py').read_bytes(),mtime=0))
print('Registered one current guide, one actual code route and template-body consumer; bounded content and incoming review bindings updated.')
