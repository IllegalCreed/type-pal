from pathlib import Path
import json,gzip,hashlib,subprocess
base='9c2c5eabe143bc81ad8df1c9234aa741b130aabc';prefix=Path('docs/phase-governance/reviews');p=Path('docs/ops/evidence/QUALITY-PRE94-RETROSPECTIVE-1/3u-state-factory');records=[]
targets={'20261004-semantic-current-batch.json':['docs/ops/board.md'],'20261016-historical-cards-d.json':['docs/ops/audits/code-quality-file-ledger.md'],'20261017-r93-phase-governance-artifacts.json':[str(prefix/'20261004-semantic-current-batch.json'),str(prefix/'20261016-historical-cards-d.json')],'20261017-r94-final-machine-artifacts.json':[str(prefix/'20261017-r93-phase-governance-artifacts.json')]}
for name,paths in targets.items():
 f=prefix/name;assert f.read_bytes()==subprocess.check_output(['git','show',base+':'+str(f)]);d=json.loads(f.read_text())
 for path in paths:
  r=next(r for r in d['entries'] if r['path']==path);raw=Path(path).read_bytes();old=subprocess.check_output(['git','show',base+':'+path]);h=hashlib.sha256(raw).hexdigest();assert r['afterSha256']==hashlib.sha256(old).hexdigest()
  r['revision']['history'].insert(0,{'revision':base,'date':'2026-10-18','action':'Bounded CODE3u factory test quality review','previousAfterSha256':r['afterSha256'],'scope':'Only two existing factory specs changed; implementation916 lines fully read but bytes unchanged. Remove one self-counted runtime enum and merge duplicate player snapshot with exact conservation control; replace manual JSON with real seeded ownership;14+4 to14+3. Six whole old-green/new-single-AssertionError controls plus separate old/current snapshot one-failure conservation. Actual module283=direct17+adjacent266; source/raw/native hashes and exact owned restoration. Two old test closures reopen review, source remains review;3316/253closed/98review/2965pending,0newclosed.83cards55partial/28pending/0accept unchanged; only3u current evidence pointer changes. No baseline/retirement registry/rules/schema/save/assets/API/product execution change. Four review files incoming chain only, no native verdict rewrite.','evidence':str(p/'README.md'),'notRun':['whole repository check','official coverage ratchet','protected fast','original game runtime','E2E','visual']})
  r['afterSha256']=h;r['reviewedLines']='1-'+str(len(raw.decode().splitlines()))
  for k in ['implementationSha','afterSha256']:
   if k in r['revision']:r['revision'][k]=h
  if isinstance(r.get('evidence'),dict):
   if 'afterSha256' in r['evidence']:r['evidence']['afterSha256']=h
   if 'lineCount' in r['evidence']:r['evidence']['lineCount']=len(raw.decode().splitlines())
  records.append({'review':str(f),'target':path,'previousAfterSha256':hashlib.sha256(old).hexdigest(),'currentSha256':h,'lines':len(raw.decode().splitlines())})
 f.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n');subprocess.run(['pnpm','exec','biome','format','--write',str(f)],check=True,stdout=subprocess.PIPE)
(p/'review-chain.json').write_text(json.dumps({'base':base,'bindings':records},ensure_ascii=False,indent=2)+'\n');(p/'chain-producer.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0));print('Four review files, five precise incoming bindings; original verdicts and other rows preserved.')
