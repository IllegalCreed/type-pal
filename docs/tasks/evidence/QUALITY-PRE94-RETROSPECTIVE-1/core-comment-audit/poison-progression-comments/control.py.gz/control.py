# -*- coding: utf-8 -*-
from pathlib import Path
import gzip,hashlib,json,subprocess,sys,datetime
root=Path.cwd();out=root/'docs/ops/evidence/QUALITY-PRE94-RETROSPECTIVE-1/core-comment-audit/poison-progression-comments';phase=sys.argv[1]
source=root/'packages/game/src/core/battle/battle-progression.ts';spec=root/'packages/game/src/core/battle/battle-progression.glm-next-wave.test.ts';original=source.read_bytes()
needle='    if (leveled) {\n      rt.rgwHP[roleId] = rt.rgwMaxHP[roleId]!\n      rt.rgwMP[roleId] = rt.rgwMaxMP[roleId]!\n    }'
assert original.decode().count(needle)==1
mutant=original.decode().replace(needle,needle.replace('    if (leveled) {','    if (leveled) {\n      rng.rangeInclusive(1, 2)'),1).encode();report=Path('/tmp/type-pal-progression-'+phase+'.vitest.json')
cmd=['pnpm','--filter','@type-pal/game','exec','vitest','run','src/core/battle/battle-progression.glm-next-wave.test.ts','--maxWorkers=1','--reporter=default','--reporter=json','--outputFile='+str(report)]
start=datetime.datetime.now(datetime.timezone.utc).isoformat();error=None
try:
 source.write_bytes(mutant)
 try:
  result=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);raw=result.stdout;code=result.returncode
 except OSError as e: error=str(e);raw=str(e).encode();code=None
finally:
 source.write_bytes(original)
assert source.read_bytes()==original
(out/(phase+'.raw.gz')).write_bytes(gzip.compress(raw,mtime=0));d=json.loads(report.read_bytes());(out/(phase+'.vitest.json.gz')).write_bytes(gzip.compress(report.read_bytes(),mtime=0))
failed=[a for r in d['testResults'] for a in r['assertionResults'] if a['status']=='failed'];unselected=[a for r in d['testResults'] for a in r['assertionResults'] if a['status'] in ('pending','skipped','todo')]
row={'command':cmd,'cwd':str(root),'startedAt':start,'completedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit':code,'signal':-code if code is not None and code<0 else None,'spawnError':error,'raw':phase+'.raw.gz','rawBytes':len(raw),'rawSha256':hashlib.sha256(raw).hexdigest(),'fullUncutMergedStdoutStderr':True,'sourceSha256':hashlib.sha256(original).hexdigest(),'mutantSha256':hashlib.sha256(mutant).hexdigest(),'specSha256':hashlib.sha256(spec.read_bytes()).hexdigest(),'restoredSourceSha256':hashlib.sha256(source.read_bytes()).hexdigest(),'sourceRestoredByteForByte':True,'passed':d['numPassedTests'],'failed':d['numFailedTests'],'pending':len(unselected),'execution':[{'file':r['name'],'name':a['fullName'],'status':a['status']} for r in d['testResults'] for a in r['assertionResults']],'failureMessages':[m for a in failed for m in a.get('failureMessages',[])],'runtimeCheck':'Require five actual assertion results, no pending; exact new failed target and only AssertionError; raw retained, no missing runtime-count field treated as numeric zero.'}
(out/(phase+'.json')).write_text(json.dumps(row,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:row[k] for k in ['exit','passed','failed','pending','sourceRestoredByteForByte']},ensure_ascii=False))
assert len(row['execution'])==5 and not unselected
if phase=='control-old': assert code==0 and d['numPassedTests']==5 and not failed
else:
 assert code==1 and d['numPassedTests']==4 and len(failed)==1
 assert '主升级成立 → 隐藏涨点后' in failed[0]['fullName']
 assert row['failureMessages'] and all('AssertionError' in m for m in row['failureMessages'])
