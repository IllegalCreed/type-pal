from pathlib import Path

def once(s,a,b):
 assert s.count(a)==1,(a,s.count(a));return s.replace(a,b)
p=Path('packages/game/src/core/palette-fade.ts');s=p.read_text();a=s.index(' * 两种 ramp 数学');z=s.index(' */',a);s=s[:a]+''' * 两类 ramp:
 *   - 'lerp':FadeIn/Out 与 SceneFade 按整数亮度系数量化;PaletteFade 用32步/31整数截断。
 *     时间进度只负责选步骤,不是逐帧连续浮点插值。
 *   - 'approach':TS 每通道饱和移动至多 increment*stepN。FadeToRed 的原 C 也显式钳制;
 *     ColorFade 的原 C 直接 ±4,仅在起终值差为4倍数时可用同样的饱和直算。
 *
 * PAL_GetPalette 用 v6<<2,ColorFade 正常输入位于4的倍数网格;其64步后还会补终值。
 * pal-extract 用 (v6<<2)|(v6>>4) 展开到0..255,可出现非4倍数;TS 对它们饱和收敛,
 * 不能宣称任意8位输入逐步等价或视觉1:1,也不能把原 C 人工非网格输入的往返当作正常域缺陷。
'''+s[z:]
s=once(s,'/** 深拷 256 色(快照 start/target,避免别名 gs.basePalette / gs.palette)。 */','/** 深拷调用方色表(生产 fade 为256色),避免快照别名 gs.basePalette / gs.palette。 */')
s=once(s,' * night 且该 palette 有 nightColors(实测 PAT.MKF 仅 #0/#5 含夜间半,见 pal-extract decodePalette)\n * → 用 nightColors;否则白天 colors。fade target 用它选淡入目标(夜场淡入到夜色)。',' * night 且提供 nightColors 时采用夜色,否则采用 colors;缺 palette 时造全黑色表。\n * fade caller 用它选目标,数据是否带夜色由 pal-extract decodePalette 解析。')
s=once(s,'/** approach 单通道:朝 target 移动至多 maxDelta(sdlpal ±step 收敛,达 target 停)。 */','/** TS 饱和单通道移动;ColorFade 原 C 无钳制,等价范围见模块说明。 */')
s=once(s,' * target 由调用方算(PAL_GetPalette(numPalette, newNight);夜间色值未提取 → 暂 = 白天 base)。',' * target 由调用方在切换 night 后经 resolveNightColors 选取;有夜色用夜色,缺失才回白天。')
s=once(s,' * 0x8C ColorFade:approach ±4,64 步(sdlpal palette.c:507-541 / 549-583)。',' * 0x8C ColorFade:TS 饱和 approach ±4,64 步;原 C 无钳制(palette.c:507-541 / 549-583)。\n * 原 C 的正常 palette 来自4倍数网格;本项目展开色值的逐步差异见模块说明。')
s=once(s,'/** fade 完成:把 `colors` 精确设为 target(skipIndex 不动)。waiting handler 结束 fade 时调。 */','/** 收尾:一般补精确 target,SceneFade-in保留63/64量化终值;skipIndex不动。宿主或waiting handler调用。 */')
p.write_text(s)
p=Path('packages/game/src/core/palette-fade.test.ts');s=p.read_text();s=once(s,'    expect(b[255]).toEqual([0, 0, 0])','    expect(b[255]).toEqual([0, 0, 0])\n    b[0]![0] = 99\n    expect(b[255]).toEqual([0, 0, 0]) // 每个通道行独立\n    expect(blackColors()[0]).toEqual([0, 0, 0]) // 下一份快照独立')
a=s.index("  it('!fFrom:");z=s.index("  it('fFrom:",a);part=s[a:z].replace('const base = fill([100, 100, 100])','const base = fill([101, 81, 40])').replace('base[7] = [40, 40, 40] // bColor=7','base[7] = [40, 101, 40] // VGA [25,20,10]与[10,25,10]经decodePalette展开').replace('[100, 100, 100]','[101, 81, 40]').replace('[40, 40, 40]','[40, 101, 40]').replace('// start = base(100),target = solid base[7]=(40)','// 同时含下降/上升/不变通道;输入按生产提取器8位展开值,不假称C原始网格').replace('// progress=1 → stepN=64 → maxDelta=256 → 全收敛到 40','// step64饱和到选定色;C若被人工喂101→40会往返,但它正常取色不会产101').replace('// 中途:progress 让 stepN=5 → maxDelta=20 → moveToward(100,40,20)=80','// step5:下降101→81,上升81→101,第三通道不动').replace('[80, 80, 80]','[81, 101, 40]');s=s[:a]+part+s[z:]
a=s.index("  it('fFrom:");z=s.index("\ndescribe('buildFadeToRed",a);part=s[a:z].replace('fill([100, 100, 100])','fill([100, 20, 40])').replace('base[3] = [20, 20, 20]','base[3] = [20, 100, 40]').replace('[20, 20, 20]','[20, 100, 40]').replace('[100, 100, 100]','[100, 20, 40]');part=once(part,'    expect(pf.targetColors[0]).toEqual([100, 20, 40])','    expect(pf.targetColors[0]).toEqual([100, 20, 40])\n    const colors = blackColors()\n    stepPaletteFade(colors, pf, 500) // step5:上升/下降各20,第三通道不动\n    expect(colors[0]).toEqual([40, 80, 40])\n    expect(colors[3]).toEqual([20, 100, 40]) // 选定色自身不动\n    stepPaletteFade(colors, pf, 500) // 同时刻重绘从快照推导,不得再积累一步\n    expect(colors[0]).toEqual([40, 80, 40])\n    finalizePaletteFade(colors, pf)\n    expect(colors[0]).toEqual([100, 20, 40])');s=s[:a]+part+s[z:]
s=once(s,"it('lum 上限 clamp 255'","it('最大合法8位RGB计算目标255,不据此声称可辨删除clamp'")
p.write_text(s)
