from pathlib import Path
import json,gzip,tempfile,shutil,subprocess,hashlib,datetime,re
root=Path.cwd();out=root/'docs/ops/evidence/QUALITY-PRE94-RETROSPECTIVE-1/core-comment-audit/palette-approach-tests';sha=lambda b:hashlib.sha256(b).hexdigest();text=(root/'reference/sdlpal/palette.c').read_text();m=re.search(r'(?m)^PAL_ColorFade\(',text);start=text.rfind('\n',0,text.rfind('\n',0,m.start()))+1;brace=text.index('{',m.end());depth=0
for i in range(brace,len(text)):
 if text[i]=='{':depth+=1
 if text[i]=='}':
  depth-=1
  if depth==0:end=i+1;break
body=text[start:end]+'\n';prefix='''#include <stdint.h>
#include <stdio.h>
#include <string.h>
typedef int INT;
typedef int BOOL;
typedef uint8_t BYTE;
#define VOID void
#define PAL_LARGE
#define FALSE 0
#define TRUE 1
typedef struct { BYTE r,g,b,a; } SDL_Color;
static SDL_Color palette[256];
static struct { INT wNumPalette; BOOL fNightPalette; } storage;
static void *unused;
#define gpGlobals (&storage)
static int emitted;
static SDL_Color *PAL_GetPalette(INT p,BOOL n) { (void)p;(void)n;return palette; }
static void UTIL_Delay(INT delay) { (void)delay; }
static void VIDEO_SetPalette(SDL_Color *p) {
 if(emitted++) printf(",");
 printf("[");
 for(int i=0;i<256;i++) {if(i)printf(",");printf("[%u,%u,%u]",p[i].r,p[i].g,p[i].b);}
 printf("]");
}
'''.replace('static void *unused;\n','')
main='''int main(void) {
 printf("[");
 for(int c=0;c<3;c++) {
  if(c)printf(",");
  for(int i=0;i<256;i++)palette[i]=(c==2?(SDL_Color){101,81,40,0}:(SDL_Color){100,20,40,0});
  palette[7]=(c==2?(SDL_Color){40,101,40,0}:(SDL_Color){20,100,40,0});
  emitted=0;printf("{\\"case\\":%d,\\"frames\\":[",c);PAL_ColorFade(1,7,c==1);printf("]}");
 }
 printf("]\\n");return 0;
}
''';source=(prefix+body+main).encode();(out/'native-color-fade.c.gz').write_bytes(gzip.compress(source,mtime=0));tmp=Path(tempfile.mkdtemp(prefix='type-pal-colorfade-'));runs=[]
def run(label,cmd):
 started=datetime.datetime.now(datetime.timezone.utc).isoformat();p=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);raw=p.stdout;(out/(label+'.raw.gz')).write_bytes(gzip.compress(raw,mtime=0));runs.append({'label':label,'command':[str(s) for s in cmd],'cwd':str(root),'startedAt':started,'completedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit':p.returncode,'signal':-p.returncode if p.returncode<0 else None,'spawnError':None,'raw':label+'.raw.gz','rawBytes':len(raw),'rawSha256':sha(raw),'fullUncutMergedStdoutStderr':True});assert p.returncode==0,(label,raw.decode()[:1000]);return raw
try:
 (tmp/'color.c').write_bytes(source);native=[]
 for opt in ['O0','O2']:
  exe=tmp/opt;run('native-compile-'+opt,['clang','-std=c11','-'+opt,'-Wall','-Wextra','-Werror',str(tmp/'color.c'),'-o',str(exe)]);native.append(json.loads(run('native-'+opt,[str(exe)])))
 assert native[0]==native[1];assert all(len(c['frames'])==65 for c in native[0]);assert [f[0][0] for f in native[0][2]['frames'][-3:]]==[41,37,40]
 paths=[str(root/'packages/game/src/core/palette-fade.ts'),str(root/'packages/pal-extract/src/resources/palette.ts')]
 ts='import { buildColorFade,blackColors,stepPaletteFade,finalizePaletteFade } from '+json.dumps(paths[0])+';\nimport {decodePalette} from '+json.dumps(paths[1])+''';
const fill=(c:[number,number,number]):[number,number,number][]=>Array.from({length:256},()=>[c[0],c[1],c[2]]);
const series=(base:[number,number,number][],from:boolean)=>{const pf=buildColorFade(base,7,from,6400,0),colors=blackColors(),frames=[];for(let k=1;k<=64;k++){stepPaletteFade(colors,pf,k*100);frames.push(structuredClone(colors));}finalizePaletteFade(colors,pf);frames.push(structuredClone(colors));return frames;};
const grid=fill([100,20,40]);grid[7]=[20,100,40];
const raw=new Uint8Array(768);for(let i=0;i<256;i++)raw.set([25,20,10],i*3);raw.set([10,25,10],7*3);const decoded=decodePalette(raw).colors;
console.log(JSON.stringify({gridForward:series(grid,false),gridReverse:series(grid,true),decodedForward:series(decoded,false),decoded:[decoded[0],decoded[7]],rawGrid:[[100,80,40],[40,100,40]],scope:'Actual decodePalette and game helpers; synthetic legal768-byte input, no asset generation or original EXE run.'}));
''';(tmp/'color.mts').write_text(ts);(out/'ts-color-fade.mts.gz').write_bytes(gzip.compress(ts.encode(),mtime=0));data=json.loads(run('typescript',['pnpm','exec','tsx',str(tmp/'color.mts')]));assert data['gridForward']==native[0][0]['frames'] and data['gridReverse']==native[0][1]['frames'];assert data['decoded']==[[101,81,40],[40,101,40]] and data['decodedForward'][-2][0]==[40,101,40];print('Original full C function O0/O2: 65 captured frames; same-grid forward/reverse exactly match TS. Non-grid synthetic C final loop red37 then final40; actual TS decoded palette converges40.',flush=True)
finally:
 shutil.rmtree(tmp);(out/'native-oracle.json').write_text(json.dumps({'base':'9cc4b3fd4f4c6754cf2f727890c7f228b0b8e4f2','scope':'Full original PAL_ColorFade body with typed SDL_Color/globals and palette/video/delay stubs. Canonical GetPalette grid proven statically, no same-byte original-vs-expanded palette identity/visual claim.','primary':{'path':'reference/sdlpal/palette.c','sha256':sha((root/'reference/sdlpal/palette.c').read_bytes()),'ranges':[[text[:start].count('\n')+1,text[:end].count('\n')+1]],'bodySha256':sha(body.encode())},'sourceSha256':sha(source),'runs':runs,'tempDirectory':str(tmp),'tempRemoved':not tmp.exists()},ensure_ascii=False,indent=2)+'\n')
