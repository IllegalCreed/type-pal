from pathlib import Path
import json,gzip,hashlib,subprocess,collections
p=Path('docs/ops/evidence/QUALITY-PRE94-RETROSPECTIVE-1/core-comment-audit/tools-thumbnail-hotkeys');base='5d55e2c49a1eb517d4bd51b2814df840dd49052a';sha=lambda b:hashlib.sha256(b).hexdigest();m=json.loads((p/'before.json').read_text());c=json.loads((p/'controls.json').read_text());assert len(c['controls'])==3 and c['restored'] and c['tempDirectoryRemoved']
for r in c['controls']:assert sha(Path(r['source']).read_bytes())==r['sourceSha256'] and sha(Path(r['spec']).read_bytes())==r['runs']['current']['specSha256']
full=[r['path'] for r in m['files']]+['packages/game/src/tools/minimap.test.ts','packages/game/src/tools/tools-panel.test-fixtures.ts','packages/game/src/tools/speedrun/index.ts','packages/game/src/core/scene-identity.ts','packages/game/src/shell/bootstrap-load.test.ts','packages/game/src/shell/bootstrap.glm-next-wave.test.ts','packages/pal-extract/src/resources/map.ts','docs/ops/tasks/CODE-QUALITY-57-game-bootstrap-thumbnail-seam-boundary.md','docs/ops/archive/tasks/done/CODE-QUALITY-56-game-minimap-thumbnail-lifecycle.md','docs/ops/archive/tasks/done/CODE-QUALITY-58-game-tools-panel-audit.md']
partial={'reference/sdlpal/map.c':[[102,130]],'reference/sdlpal/main.c':[[35,47]],'packages/game/src/main.ts':[[35,len(Path('packages/game/src/main.ts').read_bytes().splitlines())]],'packages/game/src/present/draw-tilemap.ts':[[14,16],[87,145]],'docs/phase1/engineering-notes.md':[[93,118],[137,145]],'packages/game/src/core/scene-system.ts':[[1,34],[56,75]]};assert partial['packages/game/src/main.ts'][0][1]<=88
rows=[]
for path in full:
 b=Path(path).read_bytes();row={'path':path,'sha256':sha(b),'lines':len(b.splitlines()),'ranges':[[1,len(b.splitlines())]],'scope':'Full base read plus own delta; only finite conclusions below, no whole-file acceptance inferred.'}
 if path in [r['path'] for r in m['files']]:
  name=sha(b)[:12]+'-'+Path(path).name+'.current.gz';(p/name).write_bytes(gzip.compress(b,mtime=0));row['snapshot']=name
 rows.append(row)
for path,ranges in partial.items():assert all(1<=a<=b<=len(Path(path).read_bytes().splitlines()) for a,b in ranges),(path,ranges)
(p/'read-boundaries.json').write_text(json.dumps({'base':base,'fullReads':rows,'partialReads':[{'path':path,'sha256':sha(Path(path).read_bytes()),'lines':len(Path(path).read_bytes().splitlines()),'ranges':ranges,'scope':'Only listed caller/primary/policy ranges, not whole-file audit.'} for path,ranges in partial.items()],'newClosed':0,'limits':['SDLPal has no matching minimap/tool-panel UI. C only anchors map dimensions and splash constants; project bootstrap/index supply feature contract.','Three implementations are comments-only. No thumbnail closure/real tileset pixels/seam repair or original-EXE/visual acceptance.','bootstrap public-helper tests do not drive full bootstrap/thumbnail. CODE57 remains review and scopeConfirmed=false.','Main minimap.test.ts still uses incomplete GameState/NpcState casts; its historical legal-input closure revoked, no code edit here.','npcs reference cache does not observe in-place labels/global script replacement; classifier is a bounded heuristic, not a full script interpreter.','Save/import errors/schema, full bootstrap async/modal lifecycle and interface refactors remain outside this batch.','Repeated DOM code and duplicated640 wiring are future refactor candidates; no automatic common abstraction or asset/public API change.','Title mapping and six test slots retained; official protected identity/coverage reconciliation deferred.']},ensure_ascii=False,indent=2)+'\n')
r=c['controls'][0];mapping=[{'old':a['fullName'],'current':b['fullName'],'reason':'Replace a duplicate primitive geometry slot with real base-crop discrimination, or narrow persistence title to actual oracle.'} for a,b in zip(r['runs']['old']['cases'],r['runs']['current']['cases']) if a['fullName']!=b['fullName']];assert len(mapping)==2;(p/'test-title-mappings.json').write_text(json.dumps({'file':r['spec'],'before':6,'current':6,'mappings':mapping,'baselineEdited':False,'retirementEdited':False,'officialIdentityGate':'not run; exact mapping retained for large-task closeout'},ensure_ascii=False,indent=2)+'\n')
# Precise live-only status deltas; old source fence remains byte-identical.
f=Path('docs/ops/audits/code-quality-file-ledger.md');live,hist=f.read_text().split('<!-- original-source-fenced:start -->',1);a='当前已闭合核验：265；已读但待审：77；尚未逐文件核验：2,973；合计未闭合：3,050。';assert live.count(a)==1;live=live.replace(a,'当前已闭合核验：261；已读但待审：82；尚未逐文件核验：2,972；合计未闭合：3,054。');lines=live.splitlines();link='[工具缩略图/快捷键返工](../evidence/QUALITY-PRE94-RETROSPECTIVE-1/core-comment-audit/tools-thumbnail-hotkeys/README.md)';reasons={
 'packages/game/src/tools/minimap.ts':('product','487行原源全文；640底图/96 picker、相机与DPR/crop事实纠正','只改注释，AST/JS相同；撤销95%覆盖率/各档降采样与标签缓存不变夸大；旧关闭转review'),
 'packages/game/src/tools/tools-panel.ts':('product','1106行原源全文/真实bootstrap与minimap/index caller','640接线与battleSig仅选定字段说明修正；保存/文件IO/完整UI仍未验，旧关闭转review'),
 'packages/game/src/tools/minimap.glm-phase1-leaves.test.ts':('test','189行原测全文；独立手算RGBA、底图crop、NPC/宝物分开反证与自有宿主清理','6例保持；三枚各旧6绿→新5绿1指定AssertionError，精确恢复；旧手算/隔离/坏zoom声明撤回review'),
 'packages/game/src/tools/minimap.test.ts':('test','140行只读全文；原合法GameState/NPC/Command声明与实际as强转矛盾','collectEventKinds/collectMinimapData用缺字段核心状态，旧合法输入关闭撤回review；本批未改，下一优先补齐'),
}
for path,(kind,ev,why) in reasons.items():
 ix=[i for i,l in enumerate(lines) if l.startswith('| `'+path+'` |')];assert len(ix)==1;lines[ix[0]]=f'| `{path}` | {kind} | review | {link}；{ev} | {why} |'
path='packages/game/src/shell/bootstrap.ts';assert not any(l.startswith('| `'+path+'` |') for l in lines);insert=next(i for i,l in enumerate(lines) if l.startswith('| `packages/game/src/shell/bootstrap-resources.ts` |'));lines.insert(insert,f'| `{path}` | product | review | {link}；1944行原源全文/两公开helper测试/真实main与tools caller；尺寸/F8-F4-F2/过时stub说明修正 | 原未列pending转review；AST/JS不变，CODE57 seam/色板/完整启动生命周期仍review，不授关闭 |')
f.write_text('\n'.join(lines)+'\n<!-- original-source-fenced:start -->'+hist)
# One card finite partial only, keep all original historical payloads and scopeConfirmed=false.
f=Path('docs/ops/evidence/QUALITY-PRE94-RETROSPECTIVE-1/all-cards.json');(p/'all-cards.json.before.gz').write_bytes(gzip.compress(f.read_bytes(),mtime=0));d=json.loads(f.read_text());r=next(r for r in d['cards'] if r['id']=='57');assert r['currentReview']=='pending' and not r['currentAcceptance'] and not r['scopeConfirmed'];r['currentReview']='partial';r['evidence']=str(p/'README.md');d['currentReviewCounts']=dict(collections.Counter(r['currentReview'] for r in d['cards']));assert d['currentReviewCounts']=={'partial':51,'pending':32};f.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
f=Path('docs/ops/evidence/QUALITY-PRE94-RETROSPECTIVE-1/all-cards.md');(p/'all-cards.md.before.gz').write_bytes(gzip.compress(f.read_bytes(),mtime=0));s=f.read_text();assert s.count('partial=50，pending=33')==1;s=s.replace('partial=50，pending=33','partial=51，pending=32');lines=s.splitlines();i=next(i for i,l in enumerate(lines) if l.startswith('| [CODE-QUALITY-57]'));assert '| review | pending |' in lines[i];lines[i]=lines[i].replace('| review | pending | 待全文核定真实交付文件及当前caller/oracle','| review | partial | [工具/thumbnail有限切片](core-comment-audit/tools-thumbnail-hotkeys/README.md)：1944行宿主与两helper测试全文，注释/接线已核；未驱动thumbnail，seam/色板/视觉仍review');f.write_text('\n'.join(lines)+'\n')
f=Path('docs/ops/board.md');s=f.read_text();assert s.count('83卡50partial/33pending/0accept')==1;s=s.replace('83卡50partial/33pending/0accept','83卡51partial/32pending/0accept');a='八组注释已修，余两组/数值风险/两UI差异继续';assert s.count(a)==1;s=s.replace(a,'十组已列错注已纠正；minimap主测/数值与毒列表/两UI仍待');f.write_text(s)
# Preserve prior report bytes, only narrow their currently usable conclusions.
for n,title,notice in [('56-minimap','CODE56 minimap','旧“手算像素/合法核心夹具/完整隔离/坏zoom已核”信用撤回：L18使用被测变换与颜色常量生成oracle、重复primitive几何且未清rAF/window/DOM；主测仍有缺字段核心强转。本片L18已用独立精确RGBA/crop与自有宿主补强，主测只读重开review待修，20绿不作整文件证据。'),('58-tools-panel','CODE58 tools-panel','头注仍把小地图写成96，bootstrap实际传640；battleSig只拼选定字段，不能当完整实时checksum。源事实注释已修并保持AST/JS相同，旧源关闭转review；已有58测试宿主修复保留原范围，不新授save/完整UI信用。')]:
 f=Path('docs/ops/evidence/QUALITY-PRE94-RETROSPECTIVE-1')/n/'README.md';(p/(n+'-report.before.gz')).write_bytes(gzip.compress(f.read_bytes(),mtime=0));s=f.read_text();heading,rest=s.split('\n',1);f.write_text(heading+'\n\n> 2026-10-18 当前更正：'+notice+'详见[当前有限返工](../core-comment-audit/tools-thumbnail-hotkeys/README.md)。旧原件保留，历史门不恢复。\n\n'+rest.lstrip('\n'))
f=Path('docs/ops/evidence/QUALITY-PRE94-RETROSPECTIVE-1/core-comment-audit/README.md');f.write_text(f.read_text()+'''\n当前[工具缩略图/快捷键返工](tools-thumbnail-hotkeys/README.md)全文核三源与两bootstrap helper测试，纠正已列最后两组96/256/640及F10/F8坏注，并清理可直接证明的旧stub/资源说明。L18六例用独立RGBA/crop与宿主清理补强，三旧绿新单红；主minimap测缺字段核心强转只读重开。已列十组错注已纠正不等于整文件/整卡验收；法术数值、毒列表、两UI及CODE57 seam/色板/视觉继续pending/review。\n''')
f=Path('docs/ops/tasks/QUALITY-PRE94-RETROSPECTIVE-1.md');s=f.read_text();a='当前复审队列已推进为50张partial、33张pending';assert s.count(a)==1;s=s.replace(a,'当前复审队列已推进为51张partial、32张pending');a='83卡当前全量accept=0、50partial/33pending';assert s.count(a)==1;s=s.replace(a,'83卡当前全量accept=0、51partial/32pending');s+='''\n### 2026-10-18 工具缩略图尺寸/快捷键与L18测试返工\n\n有限白名单四改动文件：minimap.ts、tools-panel.ts、bootstrap.ts仅事实注释，minimap leaves测试补oracle/排重/隔离。原487/1106/1944/189行全文；main→bootstrap→tools→minimap、相机/drawTilemap/parseMap与C维度、speedrun/index实际F8/F4/F2接线已核。旧96/256小地图、各档皆降采样、95%分类率、标签缓存不变、AVI stub与DOS结局音乐/叠加/等待未做等注释纠正；三源parsedTS及去注释JS相同。父卡准入只覆盖注释/测试，不解锁CODE57 seam/色板/完整启动产品实现。\n\nL18保持6例：移除按被测worldToThumb/DOT_COLORS生成oracle的自证，手算固定RGBA中心点；NPC/宝物开关独立反证；重复primitive例换成真实底图crop。自有宿主保留实际canvas与控制器，call-through监听精确移除、自有rAF自然停止后断言0，再恢复偏好/地图号/全局/DOM；Image等待可观察实例代替六次盲microtask。三反控各完整旧6绿→新5绿1指定AssertionError，精确source/spec/mutant/raw/nativeJSON/finally恢复；6恢复/50相邻/typecheck零诊断。\n\n只读主minimap.test.ts与旧“合法GameState/NPC”声明矛盾：两个collector用缺字段核心状态强转，撤回关闭，下一批优先修；本批不越四代码改动文件。另三旧关闭转review；bootstrap原pending列入review。机器计数待提交前复核为261closed/82review/2972pending，0新增closed。CODE57已全文核范围与两公开helper测试，但未驱动thumbnail闭包，仅pending→partial；83卡51partial/32pending/0accept，scopeConfirmed仍false，不把读文件或helper绿当像素验收。\n\n证据见[本片](../evidence/QUALITY-PRE94-RETROSPECTIVE-1/core-comment-audit/tools-thumbnail-hotkeys/README.md)，原56/58过度信用已在当前报告撤回，旧原件/卡历史保留。docs/lint看最终回执；全仓check、官方coverage/protected、完整boot与视觉/E2E本批未跑。已列十组注释纠正不等于专项完成；数值160/161等裁决、毒列表与两UI、CODE57等继续。重复DOM构建/640接线的抽象候选未证统一owner与生命周期，不强提公共模块。无下一位Agent提示词，Codex继续pre94主minimap测试夹具。\n''';f.write_text(s)
(p/'README.md').write_text('''# pre94 工具缩略图、快捷键与L18真实像素测试返工

Status: recorded
Owner: Codex（单Agent，自身源码核证，不冒充第三方）
Date: 2026-10-18
Base: `5d55e2c49a1eb517d4bd51b2814df840dd49052a`
Branch: `codex/code-quality-3y`

## 身份、准入与范围

id: QUALITY-PRE94-RETROSPECTIVE-1 / tools-thumbnail-hotkeys；schemaVersion:1；status:recorded。[父卡](../../../../tasks/QUALITY-PRE94-RETROSPECTIVE-1.md)低风险注释/测试准入。四代码改动文件全文：minimap487、tools-panel1106、bootstrap1944及GLM专测189原行；[实际边界](read-boundaries.json)区分只读主测/实际caller与primary。三实现仅注释，TS语法及JS同字节，[证明](emit-identity.json)不代替逐文件审查。CODE57只读/像素停止线保留，未改seam、palette、资源管线、save/schema、UI形态或公共接口。

## Caller与primary

main的互斥启动分支→bootstrap→setupToolsPanel→唯一setupMinimap；场景tab mount280CSSpx、widget180CSSpx，backing按DPR上限2配置。bootstrap标准map width64/height128产生2080×2080离屏图，picker默认96宽，小地图传640；缓存键含map/outW、并发2、临时tileset RLE不写游戏LRU。C map加载循环和本地parseMap只支持标准维度事实，SDLPal没有本工具UI，不能伪造其颜色/布局真值。speedrun/index按enabled门实际绑定F8暂停恢复、F4重置、F2覆盖层；tools快捷键页已同此口径，错在bootstrap注释。

源码撤销已列最后两组尺寸/快捷键错注，并修可直接证明的旧AVI stub、DOS splash块号、结局音乐/精灵叠加/等待按键未做、PNG/RLE说明；静态JSON cast不是运行时校验、分类95%无证、同数组原地标签不监听、battleSig非完整checksum也已如实说明。读取完整宿主不等于验证所有异步modal、保存、错误传播或完整启动；未知继续review。

## 测试oracle、排重与隔离

旧L18所谓手算使用被测worldToThumb、玩家颜色也从被测DOT_COLORS取；NPC开关漏反证，另worldToThumb primitive与主测重复。现6例保持：320画布用独立手算定位(156,156)/(233,79)/(79,233)，固定精确RGBA，不用±60容差或整图扫色。NPC/宝物分别关闭时另一类仍在。重复primitive例改自有640canvas的(100,120,320,320)窗口→64canvas，样本(5,5)必须蓝色，误画整图时为暗底。未增加同义弱测试。

控制器保留真实getGs稳定实例与setupMinimap、真实canvas，仅模拟Image IO/帧时钟；call-through监听不替换行为。禁用自有controller、移除自有DOM、消费一次pending rAF后断言0，再精确解绑/恢复偏好/地图号/全局与时钟。等待Image构造是可观察边界，不靠六次盲microtask；坏URL仅用于明确decode失败反例。getter/存储不冒充widget可见性，坏zoom并未验证，旧头注信用撤回。

[三反控](controls.json)分别改玩家颜色、忽略底图crop、忽略NPC toggle；各完整未过滤旧6绿→新5绿1指定业务AssertionError，0skip/pending/unhandled。source/spec/mutant/完整nativeJSON与raw/恢复SHA/精确临时树清理随片，复原后6绿。[两个身份映射](test-title-mappings.json)保留；未改baseline/retirement，不为数量保弱例。

## 当前状态、门与限制

6定向、8文件50相邻、game typecheck零诊断；[最终门回执](gates.json)与完整未裁剪gzip原件列命令/时间/exit/signal/spawn及实际诊断。docs125及全部消费者、lint、ledger以最终回执为准。全仓check、官方coverage ratchet、protected fast按用户成本规则留大任务收尾；未跑完整boot/thumbnail闭包、真实tileset/原EXE/视觉/E2E，不合main。

主minimap.test.ts只读：collector夹具经asGameState/asNpcState隐藏缺字段，旧“合法输入”账与代码矛盾，review待下一批；不把相邻14绿当合法核心输入证据。四旧关闭转review，bootstrap原未列pending转review；261closed/82review/2972pending，0新closed。CODE57完整范围和两helper测试已读，仅记partial，当前83卡51partial/32pending/0accept；scopeConfirmed=false及seam/色板/视觉未知保留，其他82对象与历史源SHA不改。

## 交接与下一步

三个comments-only与一个测试改动先同3y提交推送，fetch确认0behind，不合main。已列十组坏注已分批纠正，但整个专项未完成；法术数值/毒列表/两UI风险继续。下一优先主minimap测试合法夹具与分类/几何判别力，再继续83卡其余范围；94–102/editor后置。DOM helper/640常量复用候选先核owner与生命周期，不借提取扩大接口。无下一位Agent提示词。
''')
for name,path in [('comments-producer.py.gz','/tmp/type-pal-tools-comments.py'),('test-source.ts.gz','/tmp/type-pal-tools-minimap-test.ts'),('capture.py.gz','/tmp/type-pal-tools-capture.py'),('controls-producer.py.gz','/tmp/type-pal-tools-controls.py'),('emit-proof.cjs.gz','/tmp/type-pal-tools-emit.cjs')]: (p/name).write_bytes(gzip.compress(Path(path).read_bytes(),mtime=0))
print('Four old closures ->review; bootstrap pending->review; CODE57 finite partial only, no acceptance.')
