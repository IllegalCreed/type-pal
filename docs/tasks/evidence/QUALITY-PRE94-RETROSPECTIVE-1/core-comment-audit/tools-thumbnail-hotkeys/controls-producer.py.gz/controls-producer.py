# coding: utf-8
from pathlib import Path
import json,gzip,hashlib,subprocess,tempfile,shutil,datetime
root=Path.cwd();out=root/'docs/ops/evidence/QUALITY-PRE94-RETROSPECTIVE-1/core-comment-audit/tools-thumbnail-hotkeys';sha=lambda b:hashlib.sha256(b).hexdigest();before=json.loads((out/'before.json').read_text());oldspec={r['path']:gzip.decompress((out/r['snapshot']).read_bytes()) for r in before['files']};source='packages/game/src/tools/minimap.ts';spec='packages/game/src/tools/minimap.glm-phase1-leaves.test.ts'

def once(s,a,b):
 assert s.count(a)==1,(a,s.count(a));return s.replace(a,b)

controls=[
 ('player-color-oracle-follows-source',source,spec,6,'暗底占位 + 玩家白点',lambda s:once(s,"player: { fill: '#ffffff', stroke: '#a01e1e' }","player: { fill: '#ff00ff', stroke: '#a01e1e' }")),
 ('base-crop-ignored',source,spec,6,'非全图 view',lambda s:once(s,'ctx.drawImage(base, sx, sy, sw, sw, 0, 0, W, W)','ctx.drawImage(base, 0, 0, BASE_PX, BASE_PX, 0, 0, W, W)')),
 ('npc-toggle-ignored',source,spec,6,'暗底占位 + 玩家白点',lambda s:once(s,'if (toggles.showNpc) {','if (true) {')),
]
allPaths={r['path'] for r in before['files']};current={s:(root/s).read_bytes() for s in allPaths};tmp=Path(tempfile.mkdtemp(prefix='type-pal-tools-controls-'));results=[]
try:
 for label,source,spec,n,target,mutate in controls:
  mutant=mutate(current[source].decode()).encode();assert mutant!=current[source];(out/(label+'.mutant.gz')).write_bytes(gzip.compress(mutant,mtime=0));row={'id':label,'source':source,'spec':spec,'sourceSha256':sha(current[source]),'mutantSha256':sha(mutant),'expectedNewFailureNameContains':target,'runs':{}}
  for phase,body in [('old',oldspec[spec]),('current',current[spec])]:
   rawfile=out/(label+'.'+phase+'.raw.gz');report=tmp/(label+'.'+phase+'.json');cmd=['pnpm','--filter','@type-pal/game','exec','vitest','run',spec.removeprefix('packages/game/'),'--reporter=verbose','--reporter=json','--outputFile.json='+str(report)];started=datetime.datetime.now(datetime.timezone.utc).isoformat()
   try:
    (root/source).write_bytes(mutant);(root/spec).write_bytes(body);proc=subprocess.run(cmd,cwd=root,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);raw=proc.stdout;rawfile.write_bytes(gzip.compress(raw,mtime=0));native=report.read_bytes() if report.exists() else b''
    if native:(out/(label+'.'+phase+'.vitest.json.gz')).write_bytes(gzip.compress(native,mtime=0))
    record={'command':cmd,'cwd':str(root),'startedAt':started,'completedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit':proc.returncode,'signal':-proc.returncode if proc.returncode<0 else None,'spawnError':None,'raw':rawfile.name,'rawBytes':len(raw),'rawSha256':sha(raw),'fullUncutMergedStdoutStderr':True,'specSha256':sha(body),'nativeReport':label+'.'+phase+'.vitest.json.gz'};row['runs'][phase]=record
    assert native,'native report missing';data=json.loads(native);cases=[a for f in data['testResults'] for a in f['assertionResults']];failed=[a for a in cases if a['status']=='failed'];record.update({'passed':data['numPassedTests'],'failed':data['numFailedTests'],'pending':data['numPendingTests'],'cases':[{'file':f['name'],'fullName':a['fullName'],'status':a['status']} for f in data['testResults'] for a in f['assertionResults']]})
    assert len(cases)==n and data['numPendingTests']==0 and not data.get('unhandledErrors',[]);assert all(a['status'] in ['passed','failed'] for a in cases)
    if phase=='old':assert proc.returncode==0 and not failed and data['numPassedTests']==n
    else:assert proc.returncode==1 and len(failed)==1 and data['numPassedTests']==n-1 and target in failed[0]['fullName'] and all('AssertionError' in m for m in failed[0]['failureMessages']);record['failureMessages']=failed[0]['failureMessages']
   finally:
    (root/source).write_bytes(current[source]);(root/spec).write_bytes(current[spec]);record=row['runs'].get(phase)
    if record:record.update({'sourceRestoredSha256':sha((root/source).read_bytes()),'specRestoredSha256':sha((root/spec).read_bytes()),'sourceRestoredByteForByte':(root/source).read_bytes()==current[source],'specRestoredByteForByte':(root/spec).read_bytes()==current[spec]})
  results.append(row);print(label+': old'+str(n)+' green; current'+str(n-1)+' green /1 specified AssertionError',flush=True)
finally:
 for path,body in current.items():(root/path).write_bytes(body)
 shutil.rmtree(tmp);summary={'base':before['base'],'owner':'Codex single agent','scope':'Each mutant runs one whole unfiltered old/current file. This is source mutation discrimination, not native game or UI acceptance.','controls':results,'tempDirectory':str(tmp),'tempDirectoryRemoved':not tmp.exists(),'restored':all((root/k).read_bytes()==v for k,v in current.items())};(out/'controls.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
assert len(results)==len(controls) and summary['restored']
