# -*- coding: utf-8 -*-
from pathlib import Path
import gzip,json,subprocess,hashlib,datetime
root=Path.cwd();out=root/'docs/ops/evidence/QUALITY-PRE94-RETROSPECTIVE-1/core-comment-audit';prod=Path('packages/game/src/core/scene-system-search.ts');spec=Path('packages/game/src/core/scene-system-search.test.ts');original=prod.read_bytes();current=spec.read_bytes();old=gzip.decompress((out/'search-spec-before.test.ts.gz').read_bytes());sha=lambda b:hashlib.sha256(b).hexdigest()
gate='if (mode * 6 - 4 < i) continue'
variants=[('near-upper',gate,'if ((mode === 1 ? 3 : mode * 6 - 4) < i) continue'),('normal-lower',gate,'if ((mode === 2 ? 7 : mode * 6 - 4) < i) continue'),('normal-upper',gate,'if ((mode === 2 ? 9 : mode * 6 - 4) < i) continue'),('far-truncated',gate,'if ((mode === 3 ? 0 : mode * 6 - 4) < i) continue'),('range-middle-row','cells.push({ x: x + 2 * xOffset, y })','cells.push({ x: x + 2 * xOffset, y: i === 1 ? y + yOffset : y })'),('array-order-over-checkpoint','return npc','return npcs[0]')]
rows=[]
try:
 for name,before,after in variants:
  assert original.decode().count(before)==1;mutant=original.decode().replace(before,after).encode();prod.write_bytes(mutant)
  for version,blob in [('old',old),('new',current)]:
   spec.write_bytes(blob);label='search-'+name+'-'+version;report=Path('/tmp')/(label+'.json');cmd=['pnpm','--filter','@type-pal/game','exec','vitest','run','src/core/scene-system-search.test.ts','--maxWorkers=1','--reporter=default','--reporter=json','--outputFile='+str(report)];started=datetime.datetime.now(datetime.timezone.utc).isoformat();p=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);raw=p.stdout;v=json.loads(report.read_text());fail=[a for f in v['testResults'] for a in f['assertionResults'] if a['status']=='failed'];(out/(label+'.raw.gz')).write_bytes(gzip.compress(raw,mtime=0));(out/(label+'.vitest.json.gz')).write_bytes(gzip.compress(report.read_bytes(),mtime=0));rows.append({'id':name,'version':version,'command':cmd,'cwd':str(root),'startedAt':started,'completedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit':p.returncode,'signal':-p.returncode if p.returncode<0 else None,'spawnError':None,'before':before,'after':after,'sourceSha256':sha(original),'mutantSha256':sha(mutant),'specSha256':sha(blob),'passed':v['numPassedTests'],'failed':v['numFailedTests'],'pending':v['numPendingTests'],'runtimeErrorSuites':v.get('numRuntimeErrorTestSuites',0),'fileFullNames':[{'file':f['name'],'name':a['fullName'],'status':a['status']} for f in v['testResults'] for a in f['assertionResults']],'failureMessages':[m for a in fail for m in a['failureMessages']],'raw':label+'.raw.gz','rawSha256':sha(raw),'rawBytes':len(raw),'fullUncutMergedStdoutStderr':True})
   if version=='old':assert p.returncode==0 and v['numPassedTests']==10 and v['numFailedTests']==0
   else:assert p.returncode==1 and v['numPassedTests']==11 and v['numFailedTests']==1 and len(fail)==1 and v['numPendingTests']==0 and v.get('numRuntimeErrorTestSuites',0)==0 and 'AssertionError' in fail[0]['failureMessages'][0]
   print(label,v['numPassedTests'],v['numFailedTests'],flush=True)
finally:
 prod.write_bytes(original);spec.write_bytes(current)
 (out/'search-controls.json').write_text(json.dumps({'scope':'Six same-mutant comparisons: complete old10 green; complete new12 has exactly one business AssertionError, no skipped/pending/runtime error. No production repair.','originalSourceSha256':sha(original),'restoredSourceSha256':sha(prod.read_bytes()),'originalSpecSha256':sha(current),'restoredSpecSha256':sha(spec.read_bytes()),'rows':rows},ensure_ascii=False,indent=2)+'\n')
print('source/spec restored byte-for-byte',flush=True)
