const fs = require('node:fs'); const zlib = require('node:zlib'); const crypto = require('node:crypto'); const ts = require(process.cwd() + '/node_modules/typescript');
const dir = 'docs/ops/evidence/QUALITY-PRE94-RETROSPECTIVE-1/core-comment-audit/';
const before = zlib.gunzipSync(fs.readFileSync(dir + 'search-source-before.ts.gz')).toString(); const after = fs.readFileSync('packages/game/src/core/scene-system-search.ts', 'utf8');
const emit = text => ts.transpileModule(text, { compilerOptions: { target: ts.ScriptTarget.ESNext, module: ts.ModuleKind.ESNext, removeComments: true } }).outputText;
const a=emit(before), b=emit(after); if(a!==b) throw new Error('Search executable emit changed');
console.log(JSON.stringify({ scope:'Exact TypeScript removeComments emit equality only; no behavioral or whole-file acceptance beyond comment-only source delta', typescriptVersion:ts.version, equal:true, emittedSha256:crypto.createHash('sha256').update(a).digest('hex'), beforeSourceSha256:crypto.createHash('sha256').update(before).digest('hex'), afterSourceSha256:crypto.createHash('sha256').update(after).digest('hex') }));
