# coding: utf-8
from pathlib import Path
import json,gzip,hashlib,subprocess,tempfile,shutil,datetime
root=Path.cwd();out=root/'docs/ops/evidence/QUALITY-PRE94-RETROSPECTIVE-1/core-comment-audit/shop-layout-tests';sha=lambda b:hashlib.sha256(b).hexdigest();before=json.loads((out/'before.json').read_text());oldspec={r['path']:gzip.decompress((out/r['snapshot']).read_bytes()) for r in before['files']};shop='packages/game/src/present/menu/draw-shop.ts';host='packages/game/src/present/menu/draw-menu.ts';leaf='packages/game/src/present/menu/draw-shop.glm-phase1-leaves.test.ts';hosts='packages/game/src/present/menu/draw-menu.glm-phase1-leaves.test.ts'
def once(s,a,b):
 assert s.count(a)==1,(a,s.count(a));return s.replace(a,b)
def region(s,fn):
 a=s.index("    case 'shop-sell': {");b=s.index('\n// ── In-Game hub',a);return s[:a]+fn(s[a:b])+s[b:]
def no_grid(s):
 def f(x):
  a=x.index('      drawInventoryMenu({');b=x.index('      drawSellOverlay({',a);return x[:a]+x[b:]
 return region(s,f)
controls=[
 ('owned-first-member',shop,leaf,4,'ownedCount = 库存2',lambda s:once(s,'for (const role of gs.partyMembers)', 'for (const role of gs.partyMembers.slice(0, 1))')),
 ('owned-slot-as-role',shop,leaf,4,'ownedCount = 库存2',lambda s:once(s,'for (const role of gs.partyMembers)', 'for (const role of gs.partyMembers.map((_, index) => index))')),
 ('owned-all-roles',shop,leaf,4,'ownedCount = 库存2',lambda s:once(s,'for (const role of gs.partyMembers)', 'for (const role of [0, 1, 2, 3, 4, 5])')),
 ('empty-store-catalog-fallback',shop,leaf,4,'空店铺列表',lambda s:once(s,'const selItem = sel ? items.find((it) => it.id === sel.id) : undefined','const selItem = sel ? items.find((it) => it.id === sel.id) : items[0]')),
 ('unsellable-price-digit',shop,leaf,4,'光标项非 sellable',lambda s:once(s,"if (item?.flags.sellable) {\n    renderText(fb, '售价', SELL_PRICE_BOX.x + 10, SELL_PRICE_BOX.y + 10, 0, glyphs, false)","if (item) {\n    if (item.flags.sellable) renderText(fb, '售价', SELL_PRICE_BOX.x + 10, SELL_PRICE_BOX.y + 10, 0, glyphs, false)")),
 ('host-description-forwarding',host,hosts,5,'shop-sell 栈项',lambda s:region(s,lambda x:once(x,'noDesc: true,','noDesc: false,'))),
 ('host-icon-forwarding',host,hosts,5,'shop-sell 栈项',lambda s:region(s,lambda x:once(x,'itemIcons: extra?.itemIcons,','itemIcons: undefined,'))),
 ('host-grid-delegation',host,hosts,5,'shop-sell 栈项',no_grid),
]
allPaths={r['path'] for r in before['files']}|{host};current={s:(root/s).read_bytes() for s in allPaths};tmp=Path(tempfile.mkdtemp(prefix='type-pal-shop-controls-'));results=[]
try:
 for label,source,spec,n,target,mutate in controls:
  mutant=mutate(current[source].decode()).encode();assert mutant!=current[source];(out/(label+'.mutant.gz')).write_bytes(gzip.compress(mutant,mtime=0));row={'id':label,'source':source,'spec':spec,'sourceSha256':sha(current[source]),'mutantSha256':sha(mutant),'expectedNewFailureNameContains':target,'runs':{}}
  for phase,body in [('old',oldspec[spec]),('current',current[spec])]:
   rawfile=out/(label+'.'+phase+'.raw.gz');report=tmp/(label+'.'+phase+'.json');cmd=['pnpm','--filter','@type-pal/game','exec','vitest','run',spec.removeprefix('packages/game/'),'--reporter=verbose','--reporter=json','--outputFile.json='+str(report)];started=datetime.datetime.now(datetime.timezone.utc).isoformat()
   try:
    (root/source).write_bytes(mutant);(root/spec).write_bytes(body);proc=subprocess.run(cmd,cwd=root,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);raw=proc.stdout;rawfile.write_bytes(gzip.compress(raw,mtime=0));native=report.read_bytes() if report.exists() else b''
    if native:(out/(label+'.'+phase+'.vitest.json.gz')).write_bytes(gzip.compress(native,mtime=0))
    record={'command':cmd,'cwd':str(root),'startedAt':started,'completedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit':proc.returncode,'signal':-proc.returncode if proc.returncode<0 else None,'spawnError':None,'raw':rawfile.name,'rawBytes':len(raw),'rawSha256':sha(raw),'fullUncutMergedStdoutStderr':True,'specSha256':sha(body),'nativeReport':label+'.'+phase+'.vitest.json.gz'};row['runs'][phase]=record
    assert native,'native report missing';data=json.loads(native);cases=[a for f in data['testResults'] for a in f['assertionResults']];failed=[a for a in cases if a['status']=='failed'];record.update({'passed':data['numPassedTests'],'failed':data['numFailedTests'],'pending':data['numPendingTests'],'cases':[{'file':f['name'],'fullName':a['fullName'],'status':a['status']} for f in data['testResults'] for a in f['assertionResults']]})
    assert len(cases)==n and data['numPendingTests']==0 and not data.get('unhandledErrors',[]);assert all(a['status'] in ['passed','failed'] for a in cases)
    if phase=='old':assert proc.returncode==0 and not failed and data['numPassedTests']==n
    else:assert proc.returncode==1 and len(failed)==1 and data['numPassedTests']==n-1 and target in failed[0]['fullName'] and all('AssertionError' in m for m in failed[0]['failureMessages']);record['failureMessages']=failed[0]['failureMessages']
   finally:
    (root/source).write_bytes(current[source]);(root/spec).write_bytes(current[spec]);record=row['runs'].get(phase)
    if record:record.update({'sourceRestoredSha256':sha((root/source).read_bytes()),'specRestoredSha256':sha((root/spec).read_bytes()),'sourceRestoredByteForByte':(root/source).read_bytes()==current[source],'specRestoredByteForByte':(root/spec).read_bytes()==current[spec]})
  results.append(row);print(label+': old'+str(n)+' green; current'+str(n-1)+' green /1 specified AssertionError',flush=True)
finally:
 for path,body in current.items():(root/path).write_bytes(body)
 shutil.rmtree(tmp);summary={'base':before['base'],'owner':'Codex single agent','scope':'Each mutant runs one whole unfiltered old/current file. This is source mutation discrimination, not native game or UI acceptance.','controls':results,'tempDirectory':str(tmp),'tempDirectoryRemoved':not tmp.exists(),'restored':all((root/k).read_bytes()==v for k,v in current.items())};(out/'controls.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
assert len(results)==len(controls) and summary['restored']
