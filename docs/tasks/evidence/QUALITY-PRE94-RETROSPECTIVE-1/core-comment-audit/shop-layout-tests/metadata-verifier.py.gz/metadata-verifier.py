# coding: utf-8
from pathlib import Path
import json,gzip,hashlib,re,subprocess,collections
p=Path('docs/ops/evidence/QUALITY-PRE94-RETROSPECTIVE-1/core-comment-audit/shop-layout-tests');base='206b18563e07569414f4ec90f08597c5b8ac66de';sha=lambda b:hashlib.sha256(b).hexdigest();meta=json.loads((p/'before.json').read_text());selected={r['path'] for r in meta['files']}
for r in meta['files']:
 b=gzip.decompress((p/r['snapshot']).read_bytes());assert b==subprocess.check_output(['git','show',base+':'+r['path']]);assert sha(b)==r['sha256'] and len(b.splitlines())==r['lines'] and r['readRanges']==[[1,r['lines']]]
reads=json.loads((p/'read-boundaries.json').read_text());names=[]
for r in reads['fullReads']:
 b=Path(r['path']).read_bytes();assert sha(b)==r['sha256'] and len(b.splitlines())==r['lines'],r['path']
 if 'snapshot' in r:assert gzip.decompress((p/r['snapshot']).read_bytes())==b;names.append(r['snapshot'])
assert len(names)==len(set(names))
for r in reads['partialReads']:
 b=Path(r['path']).read_bytes();assert sha(b)==r['sha256'] and len(b.splitlines())==r['lines'];assert all(1<=a<=z<=r['lines'] for a,z in r['ranges'])
pairs=set()
def scan(x):
 if isinstance(x,list):
  for v in x:scan(v)
 elif isinstance(x,dict):
  if isinstance(x.get('raw'),str) and 'rawSha256' in x:
   b=gzip.decompress((p/x['raw']).read_bytes());assert sha(b)==x['rawSha256'] and len(b)==x['rawBytes'];pairs.add(x['raw'])
  for v in x.values():scan(v)
for f in p.glob('*.json'):scan(json.loads(f.read_text()))
counts={}
for label,n,files in [('baseline',22,3),('direct',22,3),('restored',22,3),('adjacent',35,6)]:
 d=json.loads(gzip.decompress((p/(label+'.vitest.json.gz')).read_bytes()));cases=[a for f in d['testResults'] for a in f['assertionResults']];assert len(d['testResults'])==files and len(cases)==d['numPassedTests']==n and d['numFailedTests']==d['numPendingTests']==0 and not d.get('unhandledErrors',[]) and all(a['status']=='passed' for a in cases)
 raw=gzip.decompress((p/(label+'.raw.gz')).read_bytes()).decode();assert not re.search(r'^stderr\s*\||not wrapped in act|not configured to support act|Unhandled Errors|Unhandled Rejection|Uncaught Exception|Not implemented:',raw,re.M|re.I);counts[label]={'files':files,'passed':n,'diagnostics':0}
c=json.loads((p/'controls.json').read_text());assert len(c['controls'])==8 and c['restored'] and c['tempDirectoryRemoved'] and not Path(c['tempDirectory']).exists()
for control in c['controls']:
 assert sha(Path(control['source']).read_bytes())==control['sourceSha256'];assert sha(gzip.decompress((p/(control['id']+'.mutant.gz')).read_bytes()))==control['mutantSha256']
 for phase,run in control['runs'].items():
  assert run['sourceRestoredByteForByte'] and run['specRestoredByteForByte'] and run['sourceRestoredSha256']==control['sourceSha256'];d=json.loads(gzip.decompress((p/run['nativeReport']).read_bytes()));cases=[a for f in d['testResults'] for a in f['assertionResults']];bad=[a for a in cases if a['status']=='failed'];assert all(a['status'] in ('passed','failed') for a in cases) and d['numPendingTests']==0 and not d.get('unhandledErrors',[])
  assert run['cases']==[{'file':f['name'],'fullName':a['fullName'],'status':a['status']} for f in d['testResults'] for a in f['assertionResults']]
  if phase=='old':assert run['exit']==0 and not bad;oldrow=next(r for r in meta['files'] if r['path']==control['spec']);assert run['specSha256']==oldrow['sha256']
  else:assert run['exit']==1 and len(bad)==1 and control['expectedNewFailureNameContains'] in bad[0]['fullName'] and all('AssertionError' in x for x in bad[0]['failureMessages']);assert run['specSha256']==sha(Path(control['spec']).read_bytes())
assert len(json.loads((p/'test-title-mapping.json').read_text())['mapping'])==3
for r in json.loads((p/'emit-identity.json').read_text())['rows']:assert r['currentSha256']==sha(Path(r['path']).read_bytes()) and r['byteIdentical'] and r['parsedTypeScriptWithoutCommentsIdentical']
marker='<!-- original-source-fenced:start -->';path='docs/ops/audits/code-quality-file-ledger.md';old=subprocess.check_output(['git','show',base+':'+path]).decode();cur=Path(path).read_text();assert old.split(marker,1)[1]==cur.split(marker,1)[1]
def statuses(s):return {m.group(1):m.group(2).strip() for l in s.split(marker,1)[0].splitlines() if (m:=re.match(r'^\| `([^`]+)` \| [^|]+ \| ([^|]+) \|',l))}
a,b=statuses(old),statuses(cur);changed={k:(a.get(k),b.get(k)) for k in set(a)|set(b) if a.get(k)!=b.get(k)};assert changed=={r:('已验证','review') for r in selected if 'shop-preview-pixels' not in r}
assert Path('docs/testing/catalog.json').read_bytes()==subprocess.check_output(['git','show',base+':docs/testing/catalog.json'])
cohort=json.loads(Path('docs/ops/evidence/QUALITY-PRE94-RETROSPECTIVE-1/all-cards.json').read_text());progress=dict(collections.Counter(c['currentReview'] for c in cohort['cards']));assert len(cohort['cards'])==83 and progress=={'partial':50,'pending':33} and not any(c['currentAcceptance'] for c in cohort['cards'])
paths=subprocess.check_output(['git','diff','--name-only']).decode().splitlines();assert {s for s in paths if s.startswith(('packages/','scripts/'))}==selected
print(json.dumps({'rawPairs':len(pairs),'snapshots':'Exact206b Git source and unique current snapshots','readBoundaries':'Current SHA/actual EOF/ranges match','runtime':counts,'controls':{'total':8,'old':'whole file green','current':'one specified business AssertionError each','skipsOrRuntimeErrors':0,'restored':True},'syntax':'Source TypeScript and JS unchanged beyond comments','ledgerStatusChanges':changed,'historicalLedger':'Exact','catalog':'Byte-identical','cohort':{'total':83,**progress,'accept':0},'newClosed':0},ensure_ascii=False))
