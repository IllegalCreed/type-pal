# -*- coding: utf-8 -*-
from pathlib import Path
import json,gzip,hashlib,re
p=Path('docs/ops/evidence/QUALITY-PRE94-RETROSPECTIVE-1/core-comment-audit/queue-approved-fix')
count=0

def walk(x):
 global count
 if isinstance(x,list):
  for v in x: walk(v)
 elif isinstance(x,dict):
  if isinstance(x.get('raw'),str) and 'rawSha256' in x:
   raw=gzip.decompress((p/x['raw']).read_bytes())
   assert hashlib.sha256(raw).hexdigest()==x['rawSha256'],x['raw']
   if 'rawBytes' in x: assert len(raw)==x['rawBytes'],x['raw']
   count+=1
  for v in x.values(): walk(v)
for f in sorted(p.glob('*.json')): walk(json.loads(f.read_text()))
print('Raw receipt/hash pairs verified:',count)
for f in sorted(p.glob('*.vitest.json.gz')):
 d=json.loads(gzip.decompress(f.read_bytes()))
 if f.name.startswith(('direct','adjacent','red')):
  print(f.name, {k:d.get(k) for k in ['numRuntimeErrorTestSuites','numTotalTests','numPassedTests','numPendingTests','numFailedTests']})
for label in ['direct','direct-current','adjacent','typecheck-current','docs','lint']:
 d=json.loads((p/(label+'.json')).read_text());raw=gzip.decompress((p/d['raw']).read_bytes()).decode()
 counts={name:len(re.findall(pattern,raw,re.I|re.M)) for name,pattern in [('stderr_block',r'^stderr \|'),('react_act',r'not wrapped in act|not configured to support act'),('environment',r'unsupported.*environment|jsdom.*not implemented'),('unhandled',r'Unhandled Errors|Unhandled Rejection|Uncaught Exception')]}
 print(label,'exit',d['exit'],'runtime diagnostic matches',counts)
 assert d['exit']==0 and not any(counts.values()),label
 if label=='lint': assert '0 errors / 0 warnings / 0 infos' in raw
b=json.loads((p/'read-boundaries.json').read_text())
for row in b['fullReads']:
 raw=Path(row['path']).read_bytes()
 assert hashlib.sha256(raw).hexdigest()==row['sha256'],row['path']
 assert len(raw.splitlines())==row['lines'],row['path']
for row in b['partialReads']:
 raw=Path(row['path']).read_bytes()
 assert hashlib.sha256(raw).hexdigest()==row['sha256'],row['path']
 assert all(1<=a<=z<=len(raw.splitlines()) for a,z in row['ranges']),row['path']
print('Read boundaries: all actual hash/line/range matches')
