from pathlib import Path
import json,gzip,hashlib,tempfile,shutil,subprocess,datetime
out=Path('docs/ops/evidence/QUALITY-PRE94-RETROSPECTIVE-1/core-comment-audit/formula-numeric-audit');original=gzip.decompress((out/'native-counter.c.gz').read_bytes()).decode();prefix=original[:original.index('int main(void)')]
main='''int main(void) {
 Magic magics[1]={{50,1}};
 Field fields[1]={{{0,0,0,0,0}}};
 WORD resistance[5]={0,2,4,6,8};
 gpGlobals->g.lprgMagic=magics; gpGlobals->g.lprgBattleField=fields;
 for (int i=1;i<=5;i++) {
   sample=0; calls=0; magics[0].wElemental=(WORD)i;
   SHORT damage=PAL_CalcMagicDamage(100,50,resistance,0,1,1);
   printf("%d %d %d\\n",i,damage,calls);
 }
 magics[0].wElemental=0;magics[0].wBaseDamage=0;sample=INT_MAX/2;
 printf("midpoint %d\\n",PAL_CalcMagicDamage(100,0,resistance,0,1,1));
 return 0;
}
''';source=(prefix+main).encode();(out/'mapping-oracle.c.gz').write_bytes(gzip.compress(source,mtime=0));tmp=Path(tempfile.mkdtemp(prefix='type-pal-formula-map-'));rows=[]
def run(label,cmd):
 started=datetime.datetime.now(datetime.timezone.utc).isoformat();p=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);raw=p.stdout;(out/(label+'.raw.gz')).write_bytes(gzip.compress(raw,mtime=0));rows.append({'label':label,'command':[str(x) for x in cmd],'cwd':str(Path.cwd()),'startedAt':started,'completedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit':p.returncode,'signal':-p.returncode if p.returncode<0 else None,'spawnError':None,'raw':label+'.raw.gz','rawBytes':len(raw),'rawSha256':hashlib.sha256(raw).hexdigest(),'fullUncutMergedStdoutStderr':True});assert p.returncode==0,raw.decode();return raw
try:
 (tmp/'map.c').write_bytes(source)
 for opt in ['O0','O2']:
  exe=tmp/opt;run('map-compile-'+opt,['clang','-std=c11','-'+opt,'-Wall','-Wextra','-Werror','-ffp-contract=off',str(tmp/'map.c'),'-o',str(exe)]);raw=run('map-native-'+opt,[str(exe)]);assert raw==b'1 160 1\n2 128 1\n3 96 1\n4 64 1\n5 32 1\nmidpoint 52\n'
finally:
 shutil.rmtree(tmp);(out/'mapping-oracle.json').write_text(json.dumps({'scope':'Same extracted C functions and typed minimal context as numeric-counter.json; one independent hand/native oracle for existing legal five-element and midpoint leaf cases. Not full gameplay.','sourceSha256':hashlib.sha256(source).hexdigest(),'runs':rows,'tempDirectory':str(tmp),'tempRemoved':not tmp.exists()},indent=2)+'\n')
print('native O0/O2 exact five-element matrix [160,128,96,64,32], midpoint52; zero compiler diagnostics')
