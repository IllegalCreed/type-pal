from pathlib import Path
import json,gzip,hashlib,subprocess,tempfile,shutil,datetime
root=Path.cwd();out=root/'docs/ops/evidence/QUALITY-PRE94-RETROSPECTIVE-1/3w-settlement';sha=lambda b:hashlib.sha256(b).hexdigest();before=json.loads((out/'before-sources.json').read_text());spec='packages/game/src/core/battle/battle-settlement.glm-next-wave.test.ts';source='packages/game/src/core/battle/battle-settlement.ts';oldspec=subprocess.check_output(['git','show',before['base']+':'+spec])
def once(s,a,b):
 assert s.count(a)==1,(a,s.count(a));return s.replace(a,b)
def skip_active(s):
 assert s.count(' || gs.dialogBox')==2;return s.replace(' || gs.dialogBox','')
def first_role(s):
 start=s.index('export function writeBackBattleRolesToRuntime(');end=s.index('\n/**',start);return s[:start]+once(s[start:end],'for (const roleId of partyMembers)','for (const roleId of partyMembers.slice(0, 1))')+s[end:]
controls=[
 ('reverse-party-screens',source,'按[1,0]队伍',lambda s:once(s,'for (const r of results)','for (const r of [...results].reverse())')),
 ('boss-timeout-wiring',source,'isBoss=true:',lambda s:once(s,'const timeoutMs = settlementScreenTimeoutMs(screen)',"const timeoutMs = screen.kind === 'exp-cash' ? 3000 : settlementScreenTimeoutMs(screen)")),
 ('held-key-is-new-press',source,'每屏首tick吞残键',lambda s:once(s,'const anyKey = input.pressed.size > 0','const anyKey = input.pressed.size > 0 || input.held.size > 0')),
 ('active-dialog-not-held',source,'真实战后脚本仅执行一次',skip_active),
 ('runtime-context-not-released','packages/game/src/core/battle/battle-finalization.ts','真实战后脚本仅执行一次',lambda s:once(s,'  clearBattleRuntimeContext(gs)\n','')),
 ('only-first-party-writeback','packages/game/src/core/game-state.ts','先回写战斗HP/MP',first_role),
]
current={path:(root/path).read_bytes() for path in {spec,*[c[1] for c in controls]}};tmp=Path(tempfile.mkdtemp(prefix='type-pal-settlement-controls-'));results=[]
try:
 for label,src,target,mutate in controls:
  mutant=mutate(current[src].decode()).encode();assert mutant!=current[src];(out/(label+'.mutant.gz')).write_bytes(gzip.compress(mutant,mtime=0));row={'id':label,'source':src,'spec':spec,'sourceSha256':sha(current[src]),'mutantSha256':sha(mutant),'expectedNewFailureNameContains':target,'expectedOldCount':5,'expectedCurrentCount':8,'runs':{}}
  for phase,body in [('old',oldspec),('current',current[spec])]:
   report=tmp/(label+'.'+phase+'.json');cmd=['pnpm','--filter','@type-pal/game','exec','vitest','run',spec.removeprefix('packages/game/'),'--reporter=verbose','--reporter=json','--outputFile.json='+str(report)];started=datetime.datetime.now(datetime.timezone.utc).isoformat();n=5 if phase=='old' else 8
   try:
    (root/src).write_bytes(mutant);(root/spec).write_bytes(body);proc=subprocess.run(cmd,cwd=root,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);raw=proc.stdout;(out/(label+'.'+phase+'.raw.gz')).write_bytes(gzip.compress(raw,mtime=0));native=report.read_bytes() if report.exists() else b''
    if native:(out/(label+'.'+phase+'.vitest.json.gz')).write_bytes(gzip.compress(native,mtime=0))
    record={'command':cmd,'cwd':str(root),'startedAt':started,'completedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit':proc.returncode,'signal':-proc.returncode if proc.returncode<0 else None,'spawnError':None,'raw':label+'.'+phase+'.raw.gz','rawBytes':len(raw),'rawSha256':sha(raw),'fullUncutMergedStdoutStderr':True,'specSha256':sha(body),'nativeReport':label+'.'+phase+'.vitest.json.gz','nativeSha256':sha(native)};row['runs'][phase]=record
    assert native;data=json.loads(native);cases=[a for f in data['testResults'] for a in f['assertionResults']];failed=[a for a in cases if a['status']=='failed'];record.update({'passed':data['numPassedTests'],'failed':data['numFailedTests'],'pending':data['numPendingTests'],'cases':[{'file':f['name'],'fullName':a['fullName'],'status':a['status']} for f in data['testResults'] for a in f['assertionResults']]})
    assert len(data['testResults'])==1 and data['testResults'][0]['name']==str(root/spec)
    assert len(cases)==n and data['numPendingTests']==0 and data['numTodoTests']==0 and not data.get('unhandledErrors',[]) and all(a['status'] in ['passed','failed'] for a in cases)
    assert 'stderr |' not in raw.decode()
    if phase=='old':assert proc.returncode==0 and not failed and data['numPassedTests']==n
    else:
     assert proc.returncode==1 and len(failed)==1 and data['numPassedTests']==n-1 and target in failed[0]['fullName'] and failed[0]['failureMessages'] and all('AssertionError:' in m for m in failed[0]['failureMessages']);record['failureMessages']=failed[0]['failureMessages']
   finally:
    (root/src).write_bytes(current[src]);(root/spec).write_bytes(current[spec]);record=row['runs'].get(phase)
    if record:record.update({'sourceRestoredSha256':sha((root/src).read_bytes()),'specRestoredSha256':sha((root/spec).read_bytes()),'sourceRestoredByteForByte':(root/src).read_bytes()==current[src],'specRestoredByteForByte':(root/spec).read_bytes()==current[spec]})
  results.append(row);print(label+': old5 passed; current7 passed/1 specified AssertionError',flush=True)
finally:
 for path,body in current.items():(root/path).write_bytes(body)
 shutil.rmtree(tmp);summary={'base':before['base'],'owner':'Codex single agent','scope':'Whole unfiltered old/current test file per one source mutant. Supplementary typecheck is separate; no original game/visual/coverage acceptance.','controls':results,'tempDirectory':str(tmp),'tempDirectoryRemoved':not tmp.exists(),'restored':all((root/k).read_bytes()==v for k,v in current.items())};(out/'controls.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n');(out/'controls-producer.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
assert len(results)==6 and summary['restored']
