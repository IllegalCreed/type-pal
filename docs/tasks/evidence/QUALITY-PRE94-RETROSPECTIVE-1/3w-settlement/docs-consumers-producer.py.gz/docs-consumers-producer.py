import subprocess,json,sys
commands=[['node','scripts/docs/check.mjs'],['node','scripts/docs/check-document-model.mjs'],['node','scripts/docs/check-testing.mjs'],['node','scripts/docs/check-phase-lore-governance.mjs'],['node','scripts/docs/check-content-review.mjs','--strict']]
for command in commands:
 print(json.dumps({'command':command,'scope':'Actual consumer replay; unchanged125 docs-tool tests reused from37e2cd7c9, not rerun in this slice'}),flush=True)
 p=subprocess.run(command)
 if p.returncode:sys.exit(p.returncode)
