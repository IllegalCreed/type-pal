import { afterEach, beforeAll, expect, it, vi } from 'vitest'
import { indexedPng, installLoadAll, loadAllScript } from '../__tests__/grok-render-r1/legal-host.js'
import { drawNumber } from '../present/draw-number.js'
import { createFramebuffer } from '../present/framebuffer.js'
import { loadAll } from './loader.js'

let pngs: Map<number, Uint8Array>
const frames = Array.from({ length: 71 }, (_, id) => id)
beforeAll(async () => {
  pngs = new Map()
  for (const id of frames) {
    pngs.set(id, await indexedPng(6, 8, Array.from({ length: 48 }, () => [id, 0, 0, 255]).flat()))
  }
})
afterEach(() => { vi.unstubAllGlobals(); vi.restoreAllMocks() })
it('healthy manifest keeps the yellow digit 1 at SPRITEUI frame 20', async () => {
  const warn = vi.spyOn(console, 'warn').mockImplementation(() => {})
  installLoadAll(loadAllScript({ uiFrames: frames }), pngs)
  const assets = await loadAll(7)
  const fb = createFramebuffer(40, 12)
  drawNumber(fb, 1, 1, { x: 6, y: 2 }, 'yellow', 'left', assets.uiSpriteFrames)
  expect(warn).not.toHaveBeenCalled()
  expect(fb.indices[2 * 40 + 6]).toBe(20)
})
it('missing frame 19 must not replace the yellow digit 1 with frame 21', async () => {
  const warn = vi.spyOn(console, 'warn').mockImplementation(() => {})
  installLoadAll(loadAllScript({ uiFrames: frames, fail: { uiFrames: [19] } }), pngs)
  const assets = await loadAll(7)
  expect(warn).toHaveBeenCalledExactlyOnceWith(
    'assets: ui-sprite frame 19 load failed:',
    new Error('assets: fetch /extracted/images/ui/frame-19.png failed (404)'),
  )
  const fb = createFramebuffer(40, 12)
  drawNumber(fb, 1, 1, { x: 6, y: 2 }, 'yellow', 'left', assets.uiSpriteFrames)
  expect(fb.indices[2 * 40 + 6]).toBe(20)
})
