import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import { createHash } from 'node:crypto'
import { execFileSync } from 'node:child_process'
import { createRequire } from 'node:module'
import { fileURLToPath, pathToFileURL } from 'node:url'
const root=process.cwd(),folder=path.dirname(fileURLToPath(import.meta.url)),target='6a29b455fc51664df85334bc177d0994348a7987'
const json=p=>JSON.parse(fs.readFileSync(p)),hash=b=>createHash('sha256').update(b).digest('hex'),ts=createRequire(root+'/package.json')('typescript')
const execution=json(folder+'/integrated-ratchet-r2.execution.json');assert.equal(execution.exit,0);assert.equal(execution.signal,null);assert.equal(fs.readFileSync(folder+'/integrated-ratchet-r2.stderr.raw','utf8'),'')
assert.deepEqual(execution.args,['VITEST_MAX_WORKERS=1','TYPE_PAL_COVERAGE_BASE_REF='+target,'pnpm','coverage:ratchet','--allow-scope-removal'])
const actual=json(root+'/coverage/fast/summary.json'),baseline=json(root+'/scripts/coverage/baseline.fast.json')
const source=fs.readFileSync(root+'/scripts/coverage/run.mjs','utf8'),ast=ts.createSourceFile('run.mjs',source,ts.ScriptTarget.Latest,true,ts.ScriptKind.JS)
const projectionNode=ast.statements.filter(ts.isVariableStatement).flatMap(s=>s.declarationList.declarations).find(d=>d.name.getText(ast)==='baselineView')?.initializer;assert(projectionNode)
const projection=Function('return ('+projectionNode.getText(ast)+')')();assert.deepEqual(projection(actual),baseline)
const {compareCoverage}=await import(pathToFileURL(root+'/scripts/coverage/metrics.mjs')),{auditScope}=await import(pathToFileURL(root+'/scripts/coverage/inventory.mjs')),{adjustApprovedBaseline}=await import(pathToFileURL(root+'/scripts/coverage/approved-baseline-adjustments.mjs'))
const strict=compareCoverage(actual,baseline),scope=auditScope(actual,baseline);assert.deepEqual(strict.regressions,[]);assert.deepEqual(scope.changes,[])
const protectedBytes=execFileSync('git',['show',target+':scripts/coverage/baseline.fast.json']),protectedBaseline=JSON.parse(protectedBytes),adjusted=await adjustApprovedBaseline(protectedBaseline,p=>fs.promises.readFile(p)),protectedMetrics=compareCoverage(baseline,adjusted.baseline),protectedScope=auditScope(baseline,protectedBaseline)
assert.deepEqual(protectedMetrics.regressions,[])
const {isApprovedTestRetirement}=await import(pathToFileURL(root+'/scripts/coverage/approved-test-retirements.mjs'))
const testEntry=(snapshot,file)=>Object.values(snapshot.packages).flatMap(p=>p.fastTests.fileEntries).find(e=>e.file===file)
assert.equal(protectedScope.removals.length,1)
for(const removal of protectedScope.removals){assert.equal(removal.kind,'test-count');assert.equal(removal.value,'packages/game/src/assets/loader.test.ts');assert(isApprovedTestRetirement({removal,previous:testEntry(protectedBaseline,removal.value),current:testEntry(baseline,removal.value),fileSha256:hash(fs.readFileSync(root+'/'+removal.value))}))}

for (const [name,bytes] of [['integrated-summary.json',JSON.stringify(actual,null,2)+'\n'],['integrated-baseline.after.json',fs.readFileSync(root+'/scripts/coverage/baseline.fast.json')]])fs.writeFileSync(folder+'/'+name,bytes,{flag:'wx'})
const report={target,head:execution.head,testCount:actual.testCount,sourceFileCount:actual.sourceFileCount,summarySha256:hash(fs.readFileSync(root+'/coverage/fast/summary.json')),baselineBeforeSha256:hash(execFileSync('git',['show',target+':scripts/coverage/baseline.fast.json'])),baselineAfterSha256:hash(fs.readFileSync(root+'/scripts/coverage/baseline.fast.json')),projectionSha256:hash(projectionNode.getText(ast)),runnerSha256:hash(source),strict,scope,protectedMetrics,protectedScope,approvalsApplied:adjusted.applied,limits:'Strict protected fast check of the single official report;no second coverage collection and no rule/baseline mutation by verifier'}
fs.writeFileSync(folder+'/integrated-protected-report.json',JSON.stringify(report,null,2)+'\n',{flag:'wx'})
console.log(JSON.stringify({testCount:actual.testCount,sourceFileCount:actual.sourceFileCount,regressions:strict.regressions,scopeChanges:scope.changes,protectedRegressions:protectedMetrics.regressions,protectedRemovals:protectedScope.removals}))
