from pathlib import Path
import json,gzip,hashlib,subprocess
root=Path.cwd();p=Path('docs/ops/evidence/QUALITY-PRE94-RETROSPECTIVE-1/3w-post-scripts');base='599d35717d8a5213802f76535eb14ba187f709e5';h=lambda b:hashlib.sha256(b).hexdigest()
a=json.loads((p/'controls-first-five.json').read_text());b=json.loads((p/'control-six.json').read_text());assert len(a['controls'])==5 and len(b['controls'])==1
(p/'controls.json').write_text(json.dumps({'base':base,'controls':a['controls']+b['controls'],'runs':['controls-first-five.json','control-six.json'],'temporaryRootsRemoved':a['temporaryRootRemoved'] and b['temporaryRootRemoved'],'canonicalSourcesUnchanged':a['canonicalSourcesUnchanged'] and b['canonicalSourcesUnchanged'],'scope':'Five completed controls plus one focused replay. Initial mirror tsconfig collection failure earns zero credit. Sixth first replay did produce the expected sole business failure but harness failed to match Vitest +0 formatting; preserved original raw/native and replayed only sixth, no product/spec change.'},ensure_ascii=False,indent=2)+'\n')
archives=[]
for label in ['before','direct','direct-corrected','module','module-final']:
 f=Path('/tmp/type-pal-post-'+label+'.json');raw=f.read_bytes();dest=label+'.vitest.json.gz';(p/dest).write_bytes(gzip.compress(raw,mtime=0));assert gzip.decompress((p/dest).read_bytes())==raw;d=json.loads(raw);archives.append({'label':label,'path':dest,'sha256':h(raw),'bytes':len(raw),'files':len(d['testResults']),'passed':d['numPassedTests'],'failed':d['numFailedTests']});f.unlink()
(p/'native-archives.json').write_text(json.dumps(archives,ensure_ascii=False,indent=2)+'\n')
rows=[]
def read(path,ranges,scope):
 raw=Path(path).read_bytes();n=len(raw.decode().splitlines());assert all(1<=a<=b<=n for a,b in ranges),(path,n,ranges);name=f'read-{len(rows)}.source.gz';(p/name).write_bytes(gzip.compress(raw,mtime=0));rows.append({'path':path,'sha256':h(raw),'lines':n,'ranges':ranges,'fullRead':ranges==[[1,n]],'scope':scope,'snapshot':name})
for r in json.loads((p/'source-inputs-final.json').read_text())['files']:read(r['path'],[[1,r['currentLines']]],'Selected test/helper full read, real hydrated host, assertions, isolation and dedupe')
read('packages/game/src/core/battle/battle-settlement.ts',[[1,249]],'Implementation full read, unchanged in this slice; PhaseE caller/context and restoration')
for path,ranges,scope in [
 ('packages/game/src/core/battle/battle-system.ts',[[180,355],[392,530],[2168,2242],[3070,3098]],'start/won/hold/turnStart actual runner/terminal dispatch only; not full-file acceptance'),
 ('packages/game/src/core/event-system.ts',[[848,865],[968,1070],[2910,3175],[4240,4256],[4468,4510]],'BattleCtx, real runner and probability/narration handling only'),
 ('packages/game/src/core/game-state.ts',[[1700,1765]],'Actual postBattleResume entry/owner choice only'),
 ('packages/game/src/core/battle/__tests__/battle-system.test.ts',[[1410,1494]],'Neighbor dedupe; not full-file acceptance'),
 ('reference/sdlpal/battle.c',[[710,805],[991,1373],[1600,1645],[1770,1858]],'Primary init/won/PhaseE all slots/local result return; no original game execution'),
 ('reference/sdlpal/script.c',[[2557,2562],[2605,2611],[3235,3310],[3388,3434]],'Primary 0x89/0x90/random/narration'),
 ('reference/sdlpal/fight.c',[[735,765]],'KO-only awards'),
 ('reference/sdlpal/global.h',[[190,251]],'OBJECT_ENEMY/SCRIPTENTRY binary fields'),
 ('reference/sdlpal/global.c',[[1090,1130]],'Count0 becomes1 inventory semantics')]:read(path,ranges,scope)
(p/'read-boundaries.json').write_text(json.dumps({'base':base,'owner':'Codex single agent','rows':rows,'rawAssets':'asset-census.json','priorSameSourceEvidence':'../3w-settlement/read-boundaries.json','limit':'Only explicit ranges carry fresh read credit; current raw asset census is static, not external-save/visual/original-runtime acceptance.'},ensure_ascii=False,indent=2)+'\n')
# Only current live ledger rows, retain historical duplicate table unchanged.
f=Path('docs/ops/audits/code-quality-file-ledger.md');s=f.read_text();s=s.replace('当前 tracked 清单：3,317。','当前 tracked 清单：3,318。').replace('已读但待审：101；','已读但待审：102；').replace('合计未闭合：3,066。','合计未闭合：3,067。');start=s.index('| 文件 |');end=s.index('\n\n',start);table=s[start:end];ep='[3w战后脚本复审](../evidence/QUALITY-PRE94-RETROSPECTIVE-1/3w-post-scripts/README.md)'
updates={
 'packages/game/src/core/battle/battle-settlement.ts':f'| `packages/game/src/core/battle/battle-settlement.ts` | product | review | {ep}；249行全文、原SSS与153敌对象静态对照、C PhaseE/真实caller | 当前15对象10leaf和特殊结局影响域已限定；执行未变，任意扩展脚本/异常/视觉未全验 |',
 'packages/game/src/core/battle/battle-settlement.glm-next-wave.test.ts':f'| `packages/game/src/core/battle/battle-settlement.glm-next-wave.test.ts` | test | review | {ep}；347→379行全文、原八合同保留、两概率边界与三特殊接回 | 8→13；六旧绿新单业务红反控中两枚在本文件；16直接221相邻仅有限信用，不关闭 |',
 'packages/game/src/core/battle/battle-system.glm-next-wave.test.ts':f'| `packages/game/src/core/battle/battle-system.glm-next-wave.test.ts` | test | review | {ep}；123→153行全文、三原例保持、真实turnStart/won/PhaseE/dialog/finalize | DL23补活敌双脚本/零击杀奖励/槽caster/掉落一次；四旧3绿新2绿1指定红，不冒充原盘result3可达 |'}
for path,row in updates.items():
 lines=table.splitlines();ids=[i for i,l in enumerate(lines) if l.startswith('| `'+path+'` |')];assert len(ids)==1;lines[ids[0]]=row;table='\n'.join(lines)
new=f'| `packages/game/src/core/battle/battle-lifecycle.test-fixtures.ts` | test | review | {ep}；96行全文、两测原重复准备合并，正式hydrate/projection/startBattle与五槽typed资源 | 新测试专用helper；不复制phase/脚本/奖励算法，不计独立运行时合同或closed |'
table+='\n'+new;s=s[:start]+table+s[end:];f.write_text(s)
f=Path('docs/ops/board.md');s=f.read_text().replace('state两测与settlement合法宿主/六反控补证','3w原盘影响域/特殊胜利与六反控补证');f.write_text(s)
f=Path('docs/ops/evidence/QUALITY-PRE94-RETROSPECTIVE-1/all-cards.json');d=json.loads(f.read_text());r=next(r for r in d['cards'] if r['id']=='3w');assert r['currentReview']=='partial' and not r['scopeConfirmed'];r['evidence']=str(p/'README.md');f.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
f=Path('docs/ops/evidence/QUALITY-PRE94-RETROSPECTIVE-1/README.md');f.write_text(f.read_text()+'\n- 2026-10-18：[3w战后脚本/特殊结局](3w-post-scripts/README.md)——原SSS15对象/10leaf与四0x89静态域；两测试共享正式宿主、原11合同保留→16，六有效反控，237恢复/相邻与TC零诊断，0关闭。当前3318/251closed/102review/2965pending；83卡55/28/0accept不变。统一门仍待；随后先处理用户补审三项提取输出/入口/注释。\n')
f=Path('docs/ops/tasks/QUALITY-PRE94-RETROSPECTIVE-1.md');f.write_text(f.read_text()+'''\n### 2026-10-18 CODE3w战后脚本/特殊结局交付\n\n三测试代码96/379/153行全文，settlement249全文，生产caller/C读域与原SSS全站点核对见[本片](../evidence/QUALITY-PRE94-RETROSPECTIVE-1/3w-post-scripts/README.md)。15对象10leaf仅掉落/叙述及可选概率；四0x89全0、三0x90仅turnStart，不把合法result3测试称当前剧情可达。产品执行冻结；真实PhaseE双活敌槽/掉落一次、零击杀奖励与0/1/FFFF接回补强，两份重复开战准备提取测试专用helper。原11合同保留→16；六完整旧绿/新指定单AssertionError，恢复8文件237（16直接/221相邻）与game typecheck零诊断。两测试草稿误读optional defeated/runner端口及tuple类型红、首镜像收集失败、末反控+0名称匹配失败全部保留原件，不冒充产品先红。\n\n工作树曾在只读阶段由外部移除，未有新WIP；同一路径/同3y/同599d恢复，无新分支，无主树修改，离线依赖自有安装。两既有测试/源保持review、新helper review，机器3318/251closed/102review/2965pending，0新增closed；83卡55partial/28pending/0accept，仅3w指针更新。未知任意脚本/异常、精确跨平台随机流、极端域、非队员Extra及视觉继续待核。最终docs/lint/ledger见gates，不跑全仓check/official coverage/protected，留大任务收尾，不合main。推送本片后，先核修用户最新GLM补审：视频输出链接穿透、CLI链接路径直执行、raw检查失实注释；其它pre94继续，不转去94–102/editor。\n''')
print('updated finite metadata; needs staged ledger and final consumers')
