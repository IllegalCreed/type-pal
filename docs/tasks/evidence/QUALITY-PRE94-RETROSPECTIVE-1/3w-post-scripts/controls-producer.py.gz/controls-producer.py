from pathlib import Path
import json,gzip,hashlib,subprocess,tempfile,shutil,datetime
root=Path.cwd();p=root/'docs/ops/evidence/QUALITY-PRE94-RETROSPECTIVE-1/3w-post-scripts';base='599d35717d8a5213802f76535eb14ba187f709e5';sha=lambda b:hashlib.sha256(b).hexdigest();game='packages/game/';sysSpec=game+'src/core/battle/battle-system.glm-next-wave.test.ts';settleSpec=game+'src/core/battle/battle-settlement.glm-next-wave.test.ts'
def once(s,a,b):
 assert s.count(a)==1,(a,s.count(a));return s.replace(a,b)
def rate(s):
 a=s.index('    case OP_JUMP_BY_RATE: {');b=s.index('\n    case ',a+10);return s[:a]+once(s[a:b],'>= rate','> rate')+s[b:]
def terminate(s):
 a=s.index('    case OP_SET_BATTLE_RESULT: {');b=s.index('\n    case ',a+10);return s[:a]+once(s[a:b],'state.terminatedByEnemyEscape = true','state.terminatedByEnemyEscape = false')+s[b:]
controls=[
 ('live-won-host-not-built',game+'src/core/battle/battle-system.ts',sysSpec,3,3,'敌 A turnStart 0x89 [3] won',lambda s:once(s,'if (!state.settlement) buildBattleWonSettlement(gs, state, res)','if (!state.settlement && state.enemies.every(e => e.defeated)) buildBattleWonSettlement(gs, state, res)')),
 ('live-enemy-end-skipped',game+'src/core/battle/battle-settlement.ts',sysSpec,3,3,'敌 A turnStart 0x89 [3] won',lambda s:once(s,'if (!en || (en.scriptOnBattleEnd ?? 0) <= 0) continue','if (!en || !en.defeated || (en.scriptOnBattleEnd ?? 0) <= 0) continue')),
 ('end-caster-forced-slot0',game+'src/core/battle/battle-settlement.ts',sysSpec,3,3,'敌 A turnStart 0x89 [3] won',lambda s:once(s,"caster: { type: 'enemy', idx: ei }","caster: { type: 'enemy', idx: 0 }")),
 ('zero-quantity-drop-ignored',game+'src/core/event-system.ts',sysSpec,3,3,'敌 A turnStart 0x89 [3] won',lambda s:once(s,'addItemToInventory(battleCtx.gs, cmd.itemId, cmd.count)','if (cmd.count > 0) addItemToInventory(battleCtx.gs, cmd.itemId, cmd.count)')),
 ('rate-equality-not-skipped',game+'src/core/event-system.ts',settleSpec,8,13,'roll=22',rate),
 ('terminated-resumes-as-fled',game+'src/core/battle/battle-opcodes.ts',settleSpec,8,13,'result=0不跑',terminate),
]
original={path:(root/path).read_bytes() for path in {sysSpec,settleSpec,game+'src/core/battle/battle-lifecycle.test-fixtures.ts',*[r[1] for r in controls]}};tmp=Path(tempfile.mkdtemp(prefix='type-pal-post-controls-')).resolve();mirror=tmp/'packages/game';mirror.mkdir(parents=True);shutil.copytree(root/game/'src',mirror/'src')
for f in ['package.json','vitest.config.ts','vitest.setup.ts','tsconfig.json']:shutil.copy2(root/game/f,mirror/f)
shutil.copy2(root/'tsconfig.base.json',tmp/'tsconfig.base.json');(tmp/'node_modules').symlink_to(root/'node_modules',target_is_directory=True);(mirror/'node_modules').symlink_to(root/game/'node_modules',target_is_directory=True)
results=[];currentSources=[]
for i,path in enumerate(sorted({r[1] for r in controls})):
 b=original[path];name=f'control-input-{i}.source.gz';(p/name).write_bytes(gzip.compress(b,mtime=0));currentSources.append({'path':path,'snapshot':name,'sha256':sha(b)})
try:
 for label,source,spec,oldN,newN,target,mutate in controls:
  mutant=mutate(original[source].decode()).encode();(p/(label+'.mutant.gz')).write_bytes(gzip.compress(mutant,mtime=0));row={'id':label,'source':source,'spec':spec,'sourceSha256':sha(original[source]),'mutantSha256':sha(mutant),'expectedOldCount':oldN,'expectedCurrentCount':newN,'expectedNewFailureNameContains':target,'runs':{}}
  src=mirror/source.removeprefix(game);test=mirror/spec.removeprefix(game)
  for phase,body in [('old',subprocess.check_output(['git','show',base+':'+spec])),('current',original[spec])]:
   n=oldN if phase=='old' else newN;report=tmp/(label+'.'+phase+'.json');cmd=[str(root/'node_modules/.bin/vitest'),'run',spec.removeprefix(game),'--reporter=verbose','--reporter=json','--outputFile.json='+str(report)];record={};started=datetime.datetime.now(datetime.timezone.utc).isoformat()
   try:
    src.write_bytes(mutant);test.write_bytes(body);proc=subprocess.run(cmd,cwd=mirror,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);raw=proc.stdout;(p/(label+'.'+phase+'.raw.gz')).write_bytes(gzip.compress(raw,mtime=0));native=report.read_bytes() if report.exists() else b''
    if native:(p/(label+'.'+phase+'.vitest.json.gz')).write_bytes(gzip.compress(native,mtime=0))
    record={'command':cmd,'cwd':str(mirror),'startedAt':started,'completedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit':proc.returncode,'signal':-proc.returncode if proc.returncode<0 else None,'spawnError':None,'specSha256':sha(body),'raw':label+'.'+phase+'.raw.gz','rawBytes':len(raw),'rawSha256':sha(raw),'fullUncutMergedStdoutStderr':True,'nativeReport':label+'.'+phase+'.vitest.json.gz','nativeSha256':sha(native)};row['runs'][phase]=record;assert native;d=json.loads(native);cases=[a for f in d['testResults'] for a in f['assertionResults']];bad=[a for a in cases if a['status']=='failed'];record['cases']=[{'file':f['name'],'fullName':a['fullName'],'status':a['status']} for f in d['testResults'] for a in f['assertionResults']]
    assert len(d['testResults'])==1 and d['testResults'][0]['name']==str(test) and len(cases)==n and d['numPendingTests']==d['numTodoTests']==0 and not d.get('unhandledErrors',[]) and all(a['status'] in ['passed','failed'] for a in cases) and 'stderr |' not in raw.decode()
    if phase=='old':assert proc.returncode==0 and d['numPassedTests']==n and not bad
    else:assert proc.returncode==1 and d['numPassedTests']==n-1 and len(bad)==1 and target in bad[0]['fullName'] and bad[0]['failureMessages'] and all('AssertionError:' in m for m in bad[0]['failureMessages']);record['failureMessages']=bad[0]['failureMessages']
   finally:
    src.write_bytes(original[source]);test.write_bytes(original[spec]);record.update({'mirrorSourceRestoredSha256':sha(src.read_bytes()),'mirrorSpecRestoredSha256':sha(test.read_bytes()),'mirrorRestoredByteForByte':src.read_bytes()==original[source] and test.read_bytes()==original[spec],'canonicalSourcesUnchanged':all((root/path).read_bytes()==b for path,b in original.items())})
  results.append(row);print(f'{label}: old{oldN}green/current{newN-1}green+1 specified AssertionError',flush=True)
finally:
 shutil.rmtree(tmp);summary={'base':base,'owner':'Codex single agent','scope':'Exact copied game/src plus actual dependencies, whole unfiltered test file per experiment. Product worktree sources never mutated; no new git branch/worktree. Shared dependency sources unchanged.','controls':results,'sourceInputs':currentSources,'temporaryRoot':str(tmp),'temporaryRootRemoved':not tmp.exists(),'canonicalSourcesUnchanged':all((root/path).read_bytes()==b for path,b in original.items())};(p/'controls.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n');(p/'controls-producer.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
assert len(results)==6 and summary['canonicalSourcesUnchanged']
