from pathlib import Path
import json,subprocess,hashlib
base='170edee4444fc87731308ec179d93fad93882704';p=Path('docs/ops/evidence/QUALITY-PRE94-RETROSPECTIVE-1/rle/calibration-20261018');blob=lambda x:subprocess.check_output(['git','show',base+':'+str(x)]);sha=lambda b:hashlib.sha256(b).hexdigest()
changed=subprocess.check_output(['git','diff','--name-only',base]).decode().splitlines();allowed=['docs/ops/audits/code-quality-file-ledger.md','docs/ops/board.md','docs/ops/evidence/QUALITY-PRE94-RETROSPECTIVE-1/rle/README.md','docs/ops/tasks/QUALITY-PRE94-RETROSPECTIVE-1.md','docs/ops/tasks/QUALITY-RLE-COMMAND-TRUTH-1.md','docs/phase-governance/reviews/20261004-semantic-current-batch.json','docs/phase-governance/reviews/20261016-historical-cards-d.json','docs/phase-governance/reviews/20261017-r93-phase-governance-artifacts.json','docs/phase-governance/reviews/20261017-r94-final-machine-artifacts.json'];assert set(changed)==set(allowed),changed
subprocess.run(['git','diff','--exit-code',base,'--','packages','scripts','AGENTS.md','CLAUDE.md','docs/ops/evidence/QUALITY-PRE94-RETROSPECTIVE-1/all-cards.md'],check=True)
f=Path('docs/ops/board.md');a=blob(f).decode().splitlines();b=f.read_text().splitlines();assert len(a)==len(b);assert [(x,y) for x,y in zip(a,b) if x!=y] and all(x.startswith('| QUALITY-PRE94-RETROSPECTIVE-1 |') and y.startswith('| QUALITY-PRE94-RETROSPECTIVE-1 |') for x,y in zip(a,b) if x!=y)
f=Path('docs/ops/audits/code-quality-file-ledger.md');header='| 文件 | 类别 | 状态 | 证据 / 验证 | 备注 |'
def split(s):
 head,rest=s.split(header,1);table,tail=rest.split('\n\n',1);return head,{x.split('|')[1].strip().strip('`'):x for x in table.splitlines()[2:] if x.startswith('|')},tail
a=split(blob(f).decode());b=split(f.read_text());assert a[2]==b[2];assert set(a[1])==set(b[1]);ledger_changes=[k for k in a[1] if a[1][k]!=b[1][k]];assert sorted(ledger_changes)==['packages/shared/src/rle.test.ts','packages/shared/src/rle.ts'];assert all(a[1][k].split('|')[3].strip()=='已验证' and b[1][k].split('|')[3].strip()=='review' for k in ledger_changes)
bindings=json.loads((p/'review-bindings.json').read_text());allowed_rows={}
for r in bindings['rows']:allowed_rows.setdefault(r['review'],set()).add(r['path'])
for name,paths in allowed_rows.items():
 a=json.loads(blob(name));b=json.loads(Path(name).read_text());assert set(a)==set(b);assert {k:v for k,v in a.items() if k!='entries'}=={k:v for k,v in b.items() if k!='entries'};assert len(a['entries'])==len(b['entries'])
 for old,new in zip(a['entries'],b['entries']):
  assert old['path']==new['path']
  if old['path'] not in paths:assert old==new
  else:
   assert old['revision']['history']==new['revision']['history'][1:];assert new['afterSha256']==sha(Path(new['path']).read_bytes());assert old.get('history')==new.get('history')
report={'base':base,'trackedChangedPaths':changed,'productTestsScriptsRulesAnd83QueueUnchanged':True,'onlyTwoLiveLedgerRowsChanged':ledger_changes,'historicalLedgerTailUnchanged':True,'onlyCurrentBoardAssignmentChanged':True,'boundedReviewRows':bindings['rows'],'allUnrelatedEntriesAndPriorHistoryPreserved':True,'limitations':'Scope/integrity proof only; no semantic certification of remaining ledger candidates or product files.'}
(p/'scope-verification.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');subprocess.run(['pnpm','exec','biome','format','--write',str(p/'scope-verification.json')],check=True,stdout=subprocess.PIPE)
print('PASS: product/tests/scripts/rules/83 queue unchanged; exactly two live retractions restored; historical ledger tail and unrelated metadata retained.')
