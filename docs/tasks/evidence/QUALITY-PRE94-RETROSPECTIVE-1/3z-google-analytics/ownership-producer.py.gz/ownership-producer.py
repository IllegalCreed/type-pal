from pathlib import Path
import subprocess,gzip,json,hashlib,tempfile,shutil,datetime
root=Path.cwd();out=root/'docs/ops/evidence/QUALITY-PRE94-RETROSPECTIVE-1/3z-google-analytics';before=json.loads((out/'before.json').read_text());spec=root/before['files'][1]['path'];old=gzip.decompress((out/before['files'][1]['snapshot']).read_bytes()).decode();current=spec.read_text();tmp=Path(tempfile.mkdtemp(prefix='ga-owner-proof-',dir=spec.parent));sha=lambda b:hashlib.sha256(b).hexdigest();rows=[]
seed="""
const ownerKeys = ['dataLayer', 'gtag', 'ga-disable-G-FOREIGN']
const originals = ownerKeys.map(key => Object.getOwnPropertyDescriptor(window, key))
const foreignLayer = ['foreign owner']
const foreignGtag = vi.fn()
for (const [key, value] of [['dataLayer', foreignLayer], ['gtag', foreignGtag], ['ga-disable-G-FOREIGN', true]])
  Object.defineProperty(window, String(key), { value, writable: true, configurable: true, enumerable: false })
const expected = ownerKeys.map(key => Object.getOwnPropertyDescriptor(window, key))
const marker = document.createElement('meta')
marker.name = 'unrelated-owner'
document.head.append(marker)
afterAll(() => {
  marker.remove()
  for (const key of Object.getOwnPropertyNames(window).filter(key => key.startsWith('ga-disable-'))) Reflect.deleteProperty(window, key)
  ownerKeys.forEach((key, index) => {
    const descriptor = originals[index]
    if (descriptor) Object.defineProperty(window, key, descriptor)
    else Reflect.deleteProperty(window, key)
  })
})
"""
outer="""
it('outer owner descriptors and global head survive the complete analytics cohort', () => {
  expect(marker.isConnected).toBe(true)
  expect(ownerKeys.map(key => Object.getOwnPropertyDescriptor(window, key))).toEqual(expected)
  expect(Reflect.get(window, 'dataLayer')).toBe(foreignLayer)
  expect(Reflect.get(window, 'gtag')).toBe(foreignGtag)
})
"""
try:
 for phase,body,n in [('old',old,9),('current',current,10)]:
  # Parse imports, preserving the complete original suite and all test identities beneath one owned cohort.
  script="const ts=require('typescript');const fs=require('node:fs');const s=fs.readFileSync(0,'utf8');const f=ts.createSourceFile('probe.ts',s,ts.ScriptTarget.Latest,true);let end=0;for(const st of f.statements){if(ts.isImportDeclaration(st))end=st.end;else break;}process.stdout.write(String(end))"
  end=int(subprocess.check_output(['node','-e',script],input=body.encode(),cwd=root));imports=body[:end].replace("'./","'../");rest=body[end:];imports=imports.replace("import { ","import { afterAll, ",1);assert "vi } from 'vitest'" in imports
  wrapped=imports+'\n'+seed+"\ndescribe('owned complete analytics cohort', () => {\n"+rest+'\n})\n'+outer;casefile=tmp/(phase+'.test.ts');casefile.write_text(wrapped);(out/('ownership.'+phase+'.test.ts.gz')).write_bytes(gzip.compress(wrapped.encode(),mtime=0));report=tmp/(phase+'.json');cmd=['pnpm','--filter','@type-pal/game','exec','vitest','run',str(casefile.relative_to(root/'packages/game')),'--reporter=verbose','--reporter=json','--outputFile.json='+str(report)];started=datetime.datetime.now(datetime.timezone.utc).isoformat();proc=subprocess.run(cmd,cwd=root,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);raw=proc.stdout;native=report.read_bytes();d=json.loads(native);cases=[a for f in d['testResults'] for a in f['assertionResults']];failed=[a for a in cases if a['status']=='failed'];stem='ownership.'+phase;(out/(stem+'.raw.gz')).write_bytes(gzip.compress(raw,mtime=0));(out/(stem+'.vitest.json.gz')).write_bytes(gzip.compress(native,mtime=0));r={'phase':phase,'command':cmd,'cwd':str(root),'startedAt':started,'completedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit':proc.returncode,'signal':None,'spawnError':None,'raw':stem+'.raw.gz','rawBytes':len(raw),'rawSha256':sha(raw),'nativeReport':stem+'.vitest.json.gz','nativeSha256':sha(native),'fullUncutMergedStdoutStderr':True,'originalSpecSha256':sha(body.encode()),'wrappedSpecSha256':sha(wrapped.encode()),'passed':d['numPassedTests'],'failed':d['numFailedTests'],'pending':d['numPendingTests'],'cases':[{'fullName':a['fullName'],'status':a['status']} for a in cases]};rows.append(r)
  assert len(cases)==n and d['numPendingTests']==0 and not d.get('unhandledErrors',[]) and 'stderr |' not in raw.decode()
  if phase=='old':
   assert proc.returncode==1 and len(failed)==1 and d['numPassedTests']==8 and failed[0]['fullName']=='outer owner descriptors and global head survive the complete analytics cohort' and all('AssertionError' in m for m in failed[0]['failureMessages']);r['failureMessages']=failed[0]['failureMessages']
  else:assert proc.returncode==0 and not failed and d['numPassedTests']==10
  print(phase+': '+str(r['passed'])+' passed / '+str(r['failed'])+' failed',flush=True)
finally:
 shutil.rmtree(tmp);(out/'ownership.json').write_text(json.dumps({'scope':'Actual complete old/current main spec wrapped beneath an owned cohort, plus one explicit outer-owner assertion. No SUT replacement, no product execution mutation, no browser/network claim.','runs':rows,'tempDirectory':str(tmp),'tempDirectoryRemoved':not tmp.exists(),'originalCurrentSpecUnchanged':spec.read_text()==current},ensure_ascii=False,indent=2)+'\n');(out/'ownership-producer.py.gz').write_bytes(gzip.compress(Path('/tmp/type-pal-ga-isolation.py').read_bytes(),mtime=0))
assert len(rows)==2 and spec.read_text()==current
