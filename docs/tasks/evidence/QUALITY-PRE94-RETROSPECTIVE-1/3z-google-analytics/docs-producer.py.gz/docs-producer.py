from pathlib import Path
import json,gzip,hashlib,subprocess
root=Path.cwd();p=root/'docs/ops/evidence/QUALITY-PRE94-RETROSPECTIVE-1/3z-google-analytics';base='4b86b04b790eb6b83f93a10f4ac07102c608b39b';sha=lambda b:hashlib.sha256(b).hexdigest();before=json.loads((p/'before.json').read_text());new=before['plannedNewFixture']
f=Path('/tmp/type-pal-ga-module-20261018.json');native=f.read_bytes();d=json.loads(native);assert d['numPassedTests']==25 and d['numFailedTests']==d['numPendingTests']==0 and len(d['testResults'])==6;(p/'module-final.vitest.json.gz').write_bytes(gzip.compress(native,mtime=0));f.unlink()
full=[r['path'] for r in before['files']]+[new,'packages/game/src/analytics/install-analytics.ts','packages/game/src/analytics/analytics-consent.ts','packages/game/src/analytics/analytics-consent-ui.ts','packages/game/src/main.ts','packages/game/src/analytics/install-analytics.test.ts','packages/game/src/analytics/analytics-consent-ui.test.ts','packages/game/src/analytics/analytics-consent.test.ts','packages/game/src/analytics/analytics-consent.boundaries.test.ts','docs/ops/archive/tasks/done/CODE-QUALITY-3z-game-google-analytics.md'];prior=json.loads(Path('docs/ops/evidence/QUALITY-PRE94-RETROSPECTIVE-1/3y-analytics-consent/read-boundaries.json').read_text());rows=[]
for path in full:
 b=Path(path).read_bytes();h=sha(b);name=h[:12]+'-'+Path(path).name+'.read.gz';(p/name).write_bytes(gzip.compress(b,mtime=0));rows.append({'path':path,'sha256':h,'lines':len(b.splitlines()),'ranges':[[1,len(b.splitlines())]],'fullRead':True,'snapshot':name,'scope':'Actual current SUT/caller/oracle read; adjacent files not accepted or authorized for product changes'})
for path in ['docs/ops/archive/tasks/done/OPS-GA4-consent-pageviews.md','docs/ops/archive/tasks/done/TEST-GAME-HOST-BOUNDARIES-1-privacy-timer.md','docs/ops/tasks/CODE-QUALITY-109-game-analytics-install-review.md']:
 r=next(r for r in prior['rows'] if r['path']==path);b=Path(path).read_bytes();assert sha(b)==r['sha256'];name=r['snapshot'];(p/name).write_bytes(gzip.compress(b,mtime=0));rows.append({**r,'readingProvenance':'Same SHA as actual prior-turn full reading in 3y consent evidence; not a newly repeated full read'})
(p/'read-boundaries.json').write_text(json.dumps({'base':base,'rows':rows,'phase':'First-stage optional project analytics extension; no SDLPal counterpart and no phase2 scope','limits':'Full reads support bounded findings, not whole-file closure, real Google traffic, UI visual or legal/privacy certification'},ensure_ascii=False,indent=2)+'\n')
transfers=[
 {'from':'main1 no-prod/invalid ID','to':'main1','retained':'Both original inputs and no-script/no-dataLayer; adds no-gtag.'},
 {'from':'main2 unset/denied title but only grant executed','to':'main2','retained':'Two grants, exact one script and original path/location; adds actual unset/denied before grant and exact title/payload.'},
 {'from':'main3 URL','to':'main3','retained':'Exact original complete input/output string unchanged.'},
 {'from':'main4 pathname/scene/revoke','to':'main4','retained':'All original events and paths, exact manual event plus per-transition counts make individual behavior distinguishable.'},
 {'from':'main5 Google-or-URL exception title','to':'main5 plus separate initialization-probe','retained':'Same malformed URL followed by legal page, noThrow and one event; withdraw unproved SDK-failure credit, preserve true product counter separately.'},
 {'from':'main6 reuse','to':'main6','retained':'Existing external gtag/script and page call; adds exact identities and full payload.'},
 {'from':'main7 retry','to':'main7','retained':'Actual error, replacement script, count1 and one page; removes optional no-op dispatch, adds complete js/config/event command count.'},
 {'from':'main8 arguments shape','to':'main8','retained':'Actual queue and config ID retained; strengthens non-array to exact Arguments tag for every entry, Date and send_page_view:false.'},
 {'from':'H05 idempotent stop title with no ID boundary','to':'H05 ID case','retained':'Lowercase normalization and two actual stops retained; adds project-local 6/20 acceptance and 5/21 rejection.'},
 {'from':'H05 UTM boundaries','to':'H05 UTM case','retained':'64/65/leading-minus and uppercase Up input retained; uppercase expectation corrected to up, adds forbidden term and exact complete search/origin/path.'},
 {'from':'H05 no-page-subscription','to':'H05 no-page-subscription','retained':'Grant1, deny/regrant2, deny/stop/grant2 original sequence and counts unchanged.'},
 {'from':'H05 disable flag','to':'H05 disable flag','retained':'Exact normalized key, granted false/denied true, real stop preserved.'},
 {'from':'new missing subscription teardown axis','to':'new main9','retained':'No original whole case retired; actual stop followed by page and consent source emissions proves both ports inert before fixture cleanup.'}
]
(p/'assertion-transfers.json').write_text(json.dumps({'base':base,'oldCounts':{'main':8,'boundaries':4},'currentCounts':{'main':9,'boundaries':4},'netTests':1,'wholeCasesRetired':0,'sharedFixture':'Only duplicated SDK/Document/event-source test ownership; SUT unchanged','transfers':transfers},ensure_ascii=False,indent=2)+'\n')
(p/'README.md').write_text('''# CODE-QUALITY-3z Google Analytics当前复审

Status: recorded
Owner: Codex（单Agent，自身源码/测试核证，不冒充独立第三方）
Date: 2026-10-18
Base: `4b86b04b790eb6b83f93a10f4ac07102c608b39b`
Branch: `codex/code-quality-3y`

## 范围与真实读取

id: QUALITY-PRE94-RETROSPECTIVE-1 / 3z-google-analytics；schemaVersion:1；status:recorded。[父卡](../../../tasks/QUALITY-PRE94-RETROSPECTIVE-1.md)只准事实注释与测试治理。原实现139、主测169、H05 121行及真实install/consent/UI/main、四相邻测试与旧3z卡全文；当前四代码文件也已全文核读。[读取边界](read-boundaries.json)有实际SHA/行数/完整gzip；三份此前已读历史卡只按相同SHA复用，不假称本次重新全文阅读。未以旧done或包绿补签。

## Primary与caller

第一阶段项目可选统计扩展，SDLPal没有此功能。正式main隔离安装异常；installer先建UI、再startGA，真实window/storage/事件输入，未传subscribePage。GA启用且ID符合项目格式才读同意并建立订阅；granted先初始化、URL合法且pathname变化才发送，deny重置去重并置disable，stop退两订阅。script.onerror仅移除自身标签，重授再注入；不是SDK同步初始化错误的回滚。

Google官方[安装](https://developers.google.com/tag-platform/gtagjs)给出arguments队列及js/config；[API](https://developers.google.com/tag-platform/gtagjs/reference)支持send_page_view:false；[隐私设置](https://developers.google.com/tag-platform/security/guides/privacy)说明ga-disable-ID须在命令前设置。仅核这几个SDK命令轴，不为项目ID六至二十字符、四字段UTM/64字符、pathname去重背书；这些来自本地合同。旧disable链接跳到概览/UA退休页，未把重定向当技术证据。未下载/执行Google SDK、发送真实统计或声明隐私合规。

## 真缺陷停止线

[真实安装清理反例](initialization-probe.json)：原12绿，额外1个指定AssertionError；外部gtag合法函数端口在js命令抛错，install没有返回句柄，却残留真实consent订阅。恢复SDK后实际write deny/grant会排队一次page_view，未重发js/config。只证明再次明确授权后的无owner订阅，不声称未经同意采集或游戏启动失败。原生game jsdom Storage/EventTarget，实际install/consent/SUT，自有无浏览上下文Document、窄SDK异常端口；临时树和监听器终于清理、探针时三源字节不改。

已开[GAME-ANALYTICS-FAILED-INSTALL-OWNERSHIP-1](../../../tasks/GAME-ANALYTICS-FAILED-INSTALL-OWNERSHIP-1.md) draft，产品修复待用户选择失败撤销/刷新重试，或保留完整controller重试。未批准前执行冻结。源码仅纠正发送catch不能覆盖初始initialize/readPage的过强注释，[parsedTS/JS](emit-identity.json)相同。本批不把这个红反例算作绿门。

## 测试质量与复用

旧两套harness重复、清空全局head、删除SDK而不恢复，H05 fetch替身不能拦script加载，强转隐藏端口。新增test-only fixture统一自有无浏览上下文Document、SDK属性描述符保存/恢复、公开订阅输入与stop归属；不触全局head/body/fetch，正常stop总调用真实stop，断言前不由宿主代清订阅。没有新增强转、ignore或规则放宽。正式UI/installer相邻测试仍有各自旧宿主不足，未纳本片验收。

[隔离反证](ownership.json)把完整旧/新主测包在同一cohort内，加一个cohort外的真实所有者断言：旧8绿加1指定红，新9绿加外部断言全10绿。实际外部head节点与SDK同一引用/描述符得到恢复；不是只比helper源码。

[逐断言迁移](assertion-transfers.json)保留12原合同，主8→9、H05仍4；只新增真实stop后双端口不再回调，其他补强原case。修正“Google或URL错误”过度标题、“大写UTM丢弃”坏注和“ID边界”无边界事实；精确payload、实际deny、UTM白名单/6与20边界、重试初始化命令和Arguments均有独立oracle。没有整例退役、baseline或测试catalog状态变化。

[五枚反控](controls.json)每轮跑完整未过滤旧/新测试文件：自动pageview/漏page退订/重试重置初始化，各旧主8绿→新8绿1指定AssertionError；泄漏utm_term/拒收六字符，各旧H05 4绿→新3绿1指定AssertionError。完整native file/fullName、raw、命令/退出/信号/时间、源/测试/mutantSHA和finally恢复均保留；不是产品TDD。正常恢复13直接、12相邻（6文件25绿），game typecheck零诊断。

## 账本、门与未验域

原三个tracked路径未列live表，pending→review；新增fixture按fixture类别登记review，机器应为3316 tracked /261 closed /89 review /2966 pending，实际以[门回执](gates.json)ledger为准。0新增关闭；只旧3z pending→partial，83卡53partial/30pending/0accept，scopeConfirmed/currentAcceptance仍false，其他82对象与旧SHA不改。原历史卡不改为当前accept。

本片仅定向/相邻、必要typecheck、文档/静态与ledger；全仓check、official coverage ratchet和protected fast按用户成本规则留大任务收尾，不声称统一门完成，不合main。raw完整未裁剪gzip保留；所有已知红counter与反控exit1单列，没有抹成exit0。

跨window/realm、多property共享script/gtag、异步真实SDK/CSP/网络与真实浏览器、UI完整卸载及失败策略继续review。未改游戏机制、GA/隐私政策、UI布局、schema/save、资源或公共接口。下一步回pre94 40/41或3u/3w未核切片；数值/毒列表/两UI与本卡产品停止线继续保留，94–102/editor后置。无下一位Agent提示词，Codex继续。
''')
# Live table delta only; existing rows and historical fence exact.
f=Path('docs/ops/audits/code-quality-file-ledger.md');s=f.read_text();lines=s.splitlines();i=next(i for i,l in enumerate(lines) if l.startswith('| 文件 |'))+2
while lines[i].startswith('|'):i+=1
rows=[
f'| `{before["files"][0]["path"]}` | product | review | [pre94 GA复审](../evidence/QUALITY-PRE94-RETROSPECTIVE-1/3z-google-analytics/README.md)；139行及真实installer/main/同意caller、官方命令合同 | 执行冻结，仅改catch范围注释；真实初始化泄漏另卡draft，0关闭 |',
f'| `{before["files"][1]["path"]}` | test | review | [pre94 GA复审](../evidence/QUALITY-PRE94-RETROSPECTIVE-1/3z-google-analytics/README.md)；169行原测与9例当前全文，精确payload/Arguments/stop/重试 | 三旧8绿→新8绿1指定红，隔离外owner旧单红新绿；未知SDK/浏览器不关闭 |',
f'| `{before["files"][2]["path"]}` | test | review | [pre94 GA复审](../evidence/QUALITY-PRE94-RETROSPECTIVE-1/3z-google-analytics/README.md)；121行原测与当前4例，项目ID6/20与UTM白名单、真实订阅 | 两旧4绿→新3绿1指定红；坏注/伪fetch隔离撤回，13直接/12相邻只是有限证据 |',
f'| `{new}` | fixture | review | [pre94 GA复审](../evidence/QUALITY-PRE94-RETROSPECTIVE-1/3z-google-analytics/README.md)；新增测试专用共享宿主全文，真实SUT/自有Document与属性描述符 | 完整cohort外owner断言旧8/1红→新10绿；stop断言前不代清；不改公共接口/不关闭 |']
lines[i:i]=rows;s='\n'.join(lines)+'\n';assert s.count('当前 tracked 清单：3,315。')==1;s=s.replace('当前 tracked 清单：3,315。','当前 tracked 清单：3,316。');s=s.replace('当前已闭合核验：261；已读但待审：85；尚未逐文件核验：2,969；合计未闭合：3,054。','当前已闭合核验：261；已读但待审：89；尚未逐文件核验：2,966；合计未闭合：3,055。');f.write_text(s)
f=Path('docs/ops/evidence/QUALITY-PRE94-RETROSPECTIVE-1/all-cards.json');q=json.loads(f.read_text());r=next(r for r in q['cards'] if r['id']=='3z');assert r['currentReview']=='pending' and not r['scopeConfirmed'] and not r['currentAcceptance'];r['currentReview']='partial';r['evidence']=str(p.relative_to(root)/'README.md');q['currentReviewCounts']={'partial':53,'pending':30};f.write_text(json.dumps(q,ensure_ascii=False,indent=2)+'\n')
f=Path('docs/ops/evidence/QUALITY-PRE94-RETROSPECTIVE-1/all-cards.md');s=f.read_text();assert s.count('partial=52，pending=31')==1;s=s.replace('partial=52，pending=31','partial=53，pending=30');lines=s.splitlines();i=next(i for i,l in enumerate(lines) if l.startswith('| [CODE-QUALITY-3z]'));assert '| done | pending |' in lines[i];lines[i]='| [CODE-QUALITY-3z](../../archive/tasks/done/CODE-QUALITY-3z-game-google-analytics.md) | done | partial | [GA四文件](3z-google-analytics/README.md)：共享宿主/五反控，13直接12相邻；初始化泄漏另卡draft，实网/统一门仍待 |';f.write_text('\n'.join(lines)+'\n')
f=Path('docs/ops/board.md');s=f.read_text();assert s.count('83卡52partial/31pending/0accept；consent三文件补证；')==1;s=s.replace('83卡52partial/31pending/0accept；consent三文件补证；','83卡53partial/30pending/0accept；GA四文件补证；');line='| GAME-ANALYTICS-FAILED-INSTALL-OWNERSHIP-1 | [GA失败安装归属](tasks/GAME-ANALYTICS-FAILED-INSTALL-OWNERSHIP-1.md) | draft | Codex / 真实反例已证，产品冻结等裁决 | 旧12绿＋真实install清理单红；无返回controller仍响应重授，未改生产执行 |\n';s=s.replace('| GAME-MAGIC-NUMERIC-ASSIGNMENT-1 |',line+'| GAME-MAGIC-NUMERIC-ASSIGNMENT-1 |',1);f.write_text(s)
f=Path('docs/ops/tasks/QUALITY-PRE94-RETROSPECTIVE-1.md');s=f.read_text().replace('当前复审队列已推进为52张partial、31张pending','当前复审队列已推进为53张partial、30张pending',1).replace('83卡当前全量accept=0、52partial/31pending','83卡当前全量accept=0、53partial/30pending',1);s+='''\n本片交付：原139/169/121行与真实caller、当前四代码文件全文；只校正catch范围注释，parsedTS/JS一致。两重复测试harness合并到自有Document/SDK描述符/typed订阅宿主，外owner完整cohort反证旧8绿1红→新10绿。原12合同逐断言保留，主8→9、H05仍4；五反控旧全绿新指定单AssertionError，恢复13直接12相邻/TC零诊断。三未列pending→review、新fixture review，机器3316/261closed/89review/2966pending，0关闭；只3z pending→partial，83卡53/30/0accept，scopeConfirmed=false。真实初始化失败后无owner订阅counter另开GAME-ANALYTICS-FAILED-INSTALL-OWNERSHIP-1 draft等裁决，产品执行冻结；反例exit1与旧12绿均完整保存。详见[GA证据](../evidence/QUALITY-PRE94-RETROSPECTIVE-1/3z-google-analytics/README.md)，全仓check/coverage/protected留大任务收尾，不合main。下一步回pre94 40/41或3u/3w，94–102/editor后置，无下一位Agent提示词。\n''';f.write_text(s)
f=Path('docs/ops/evidence/QUALITY-PRE94-RETROSPECTIVE-1/README.md');s=f.read_text();s=s.replace('全83卡52partial/31pending/0accept（2026-10-18 consent复审；下文数字均按各片原时点）','全83卡53partial/30pending/0accept（2026-10-18 GA复审；下文数字均按各片原时点）',1);s+='''\n最新[3z GA复审](3z-google-analytics/README.md)：原三文件/真实caller及新增共享fixture全文，五旧绿新指定单红，外owner隔离旧单红新绿；13直接12相邻/TC零诊断，0新closed。三pending转review加fixture，3316/261/89/2966，83卡53partial/30pending/0accept。真实初始化泄漏另卡draft待裁决，产品执行冻结；统一门/实网未跑，下一步pre94其它未核切片。\n''';f.write_text(s)
index=subprocess.check_output(['node','scripts/docs/check.mjs','--print-task-index']);Path('docs/ops/tasks/index.md').write_bytes(index)
(p/'docs-producer.py.gz').write_bytes(gzip.compress(Path('/tmp/type-pal-ga-docs.py').read_bytes(),mtime=0));(p/'capture.py.gz').write_bytes(gzip.compress(Path('/tmp/type-pal-ga-capture.py').read_bytes(),mtime=0));(p/'emit-producer.cjs.gz').write_bytes(gzip.compress(Path('/tmp/type-pal-ga-emit.cjs').read_bytes(),mtime=0));print('Bounded four-file evidence, ledger, one queue object, draft-card board and generated task index updated; no new closure.')
