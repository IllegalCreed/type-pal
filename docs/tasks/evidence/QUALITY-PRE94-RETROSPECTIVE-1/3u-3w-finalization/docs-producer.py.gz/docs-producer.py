from pathlib import Path
import json,gzip,hashlib,subprocess
root=Path.cwd();p=root/'docs/ops/evidence/QUALITY-PRE94-RETROSPECTIVE-1/3u-3w-finalization';base='6fde6d86cf9754e441de948c82ac99ebc1f480c8';sha=lambda b:hashlib.sha256(b).hexdigest();before=json.loads((p/'before.json').read_text())
for label,path,n in [('module-final','/tmp/type-pal-finalization-module-20261018.json',275),('restored-direct','/tmp/type-pal-finalization-restored-20261018.json',9)]:
 f=Path(path);b=f.read_bytes();d=json.loads(b);assert d['numPassedTests']==n and d['numFailedTests']==d['numPendingTests']==0;(p/(label+'.vitest.json.gz')).write_bytes(gzip.compress(b,mtime=0));f.unlink()
full=[r['path'] for r in before['files']]+['packages/game/src/core/__tests__/stats/stats-test-fixtures.ts','packages/game/src/core/battle/battle-settlement.ts','packages/game/src/core/battle/battle-settlement.glm-next-wave.test.ts','packages/game/src/core/battle/__tests__/battle-state.test.ts','docs/ops/archive/tasks/done/CODE-QUALITY-3u-game-battle-state-runtime.md','docs/ops/archive/tasks/done/CODE-QUALITY-3w-game-battle-settlement-finalization.md']
partial={
 'packages/game/src/core/battle/battle-state.ts':[[1,125],[678,918]],
 'packages/game/src/core/battle/battle-system.ts':[[180,355],[380,540]],
 'packages/game/src/core/game-state.ts':[[360,455],[1390,1450],[1550,1780]],
 'packages/game/src/core/game-state.test.ts':[[825,883]],
 'packages/game/src/core/battle/__tests__/battle-system.test.ts':[[1400,1585],[1838,1890],[2020,2100],[4150,4270]],
 'packages/game/src/core/player-poison-state.ts':[[130,147]],
 'packages/game/src/core/equipment-state.ts':[[339,401]],
 'packages/game/src/core/equip-effect.ts':[[245,278]],
 'packages/game/src/core/event-system.ts':[[4390,4475]],
 'packages/game/src/present/dialog-box.ts':[[301,373]],
 'reference/sdlpal/battle.c':[[1800,1860]],
 'reference/sdlpal/global.c':[[1555,1618],[2300,2350]],
 'reference/sdlpal/script.c':[[3310,3340]],
 'docs/phase1/game-mechanics.md':[[1529,1589]],
}
rows=[]
for path in full+list(partial):
 b=Path(path).read_bytes();h=sha(b);name=h[:12]+'-'+Path(path).name+'.read.gz';(p/name).write_bytes(gzip.compress(b,mtime=0));rows.append({'path':path,'sha256':h,'lines':len(b.splitlines()),'ranges':[[1,len(b.splitlines())]] if path in full else partial[path],'fullRead':path in full,'snapshot':name,'scope':'Actual bounded read; full-file test execution does not imply all adjacent source/test semantics read or accepted'})
(p/'read-boundaries.json').write_text(json.dumps({'base':base,'owner':'Codex single agent','rows':rows,'limits':'No original-game runtime, browser, E2E, phase2, whole-card or unified quality closeout. Extra off-party reachability remains unknown.'},ensure_ascii=False,indent=2)+'\n')
(p/'assertion-transfers.json').write_text(json.dumps({'base':base,'oldCounts':{'finalization':2,'runtime':3},'currentCounts':{'finalization':6,'runtime':3},'wholeCasesRetired':0,'netTests':4,'transfers':[
 {'from':'old cleanup world/status/wave/resource case','to':'current nine-status/world case','retained':'All world booleans, dialog removal, shake, exact7/-3 wave, explore, state/resource/runner release; <=999 and >999 comparisons retained. Original seven-slot invalid BattleState/dialog casts replaced by full factories; persistent counters1000/32760 moved onto legal good-status slots, two last slots and non-party row added.'},
 {'from':'old cleanup fled resume case','to':'current cursor handoff case','retained':'Real outcome fled/ip33,event mode, released state/resources and consumed resume retained; zero snapshot wave retained. Added actual cursor-assignment observation of release timing and injected-runner release, real command domain covers11/22/33.'},
 {'from':'runtime exact resource/live roles and hidden key identity','to':'same case','retained':'All exact identities and existing hidden resource property retained via Reflect instead of cast; actual second GameState install must not overwrite first owner.'},
 {'from':'runtime override/undefined and cleanup cases','to':'same two cases','retained':'All original fallback/injected identity and own-property/delete semantics retained, function types use real RunScriptFn generic; released live roles adds one getter result.'},
 {'from':'previously untested direct finalizer caller wiring','to':'lost, player flee, enemy termination and forced watchdog branches','retained':'Separate actual finalizeBattle composition layer, not duplicate resume helper calls. Lost writes zero HP and exact MP for reversed party[2,0], consumes dialogue queue; three other mutually distinct production exits choose expected resume IP. Watchdog is TS policy, not claimed SDLPal mechanism.'}
]},ensure_ascii=False,indent=2)+'\n')
(p/'README.md').write_text('''# CODE3u/3w finalization与runtime-context复审

Status: recorded
Owner: Codex（单Agent，自身核读/测试，不冒充第三方）
Date: 2026-10-18
Base: `6fde6d86cf9754e441de948c82ac99ebc1f480c8`
Branch: `codex/code-quality-3y`

## 准入与读取

id: QUALITY-PRE94-RETROSPECTIVE-1 / 3u-3w-finalization；schemaVersion:1；status:recorded。按[父卡](../../../tasks/QUALITY-PRE94-RETROSPECTIVE-1.md)低风险白名单：原67/80/98/75行四文件全文，当前两源与两测也已核读；不恢复旧done/固定三签。真实startBattle/tickBattle/settlement、resume/writeback、BattleState与对话factory、SDL和机制文档的实际范围列于[读取边界](read-boundaries.json)，完整gzip只是字节快照，不把局部读取的邻接大文件记为全文。

## 真值、caller与实现

这是第一阶段。SDL battle.c:1822–1857与global.c:2311–2339支持全角色九状态<=999清、>999装备常驻保留、波场恢复；script.c:3315–3333支持战斗结果接回脚本的分支。TS startBattle保存世界波、安装资源/可选runner，tickBattle lost/fleed或自有watchdog调用finalize，胜利settlement半血后调cleanup；resume消费postBattleResume并写eventCursor。watchdog无SDL对应，不把它的forced won策略当原版真值。

finalize先回写HP/MP再cleanup；cleanup清持久状态、在队毒/Extra、自动战斗/对话/震屏，恢复波→explore→丢state→释放runtime→接回脚本。runtime资源由GameState独立stash，引用精确、undefined不覆盖runner，clear保留resource自有undefined属性并删除runner。它的playerRoles实际可写，旧“只读资源表”注释已改；cleanup注释不再承诺C全role与TS party完全等价。两源只有事实注释变化，[parsedTS/去注释JS](emit-identity.json)相同，生产执行/公共接口/状态ownership结构未改。

### 未决高风险边界

[非队员Extra](../../../tasks/GAME-BATTLE-NONPARTY-EXTRA-CLEANUP-1.md) draft：C全role/TS party循环差异真实，但startBattle/updateAllEquipments全量重建，setParty也重建并清毒；C解毒对离队role自行return。未找到绕过这些重建的合法生产写入链，不能凭手塞Extra直调cleanup制造剧情bug。本片冻结行为，只记录unknown；毒键/复活/用户装备常驻裁决都不改变。

## 测试质量、复用和排重

原finalization只有2例，核心BattleState/对话/runner用强转，七状态数组不完整，第二例只看终态却宣称接回之前已释放。现用真实GameState→hydrate→战斗投影→createBattleState及startDialogLine；复用已全文核读的stats-test-fixtures纯构造器，不复制角色/敌人字段，不mock核心。两个原case的有效比较逐条保留，永久计数移到合法好状态，扩至九槽和未在队角色；公开eventCursor的保值getter/setter只观察真实resume写入，不替换resume/cleanup。

新增四个合同是finalize到cleanup/resume的实际组合层：lost按角色写零HP/精确MP且不复活，玩家逃、敌逃terminated、TS watchdog分别选正确分支；没有再直接测一遍resume helper。runtime3例保持，去runner和stash强转、补第二GameState安装隔离与释放live roles。[迁移表](assertion-transfers.json)保留原全部有效断言；无整例退役、baseline或catalog状态变更。原state主测的枚举长度/JSON与settlement大例质量未纳本片签收，仍是后续3u/3w范围。

[七反控](controls.json)完整文件未过滤：末两状态漏清、接回早于runtime释放、lost/forced/termination接错分支、仅写role0，各旧final2绿→新5绿1指定AssertionError；跨owner安装串写旧runtime3绿→新2绿1指定AssertionError。原件/native身份、时间、源/测/mutant SHA与finally恢复完整保留。首driver在第四枚的fullName匹配漏引号失败，三枚完整记录保留，第四native/raw原件另存但不授完整元数据信用；只重跑其后四枚，见[恢复说明](control-driver-recovery.json)，没有改产品/测试来使反控通过。

正式6文件275绿（9直接/266相邻），typecheck零诊断；最后四反控后两直接文件9例再绿，逐字节恢复与相同正式身份核对。相邻包绿只证明执行结果，不签收其整文件语义。完整未裁剪raw/nativeJSON及[实际门](gates.json)保留。

## 当前状态与限制

四原已关闭条目重新review，0新增关闭，机器应为3316 tracked /257 closed /93 review /2966 pending；以实际ledger回执为准。只有3u/3w各pending→partial，83卡55partial/28pending/0accept，scopeConfirmed/currentAcceptance仍false；其它81对象/原卡历史SHA不改。两卡剩余state/settlement完整合同、毒/Extra可达性、视觉和统一门均未收口。

全仓check、official coverage ratchet、protected fast按用户成本规则留大任务收尾；本片不跑全game包、pal.exe/浏览器/E2E或二阶段，不合main、不改schema/save/资源/产品行为。下一步3u state工厂与主/GLM测试或40/41未核切片，94–102/editor后置。无下一位Agent提示词，Codex继续。
''')
# Existing live rows only. Historical fence payload is untouched.
f=Path('docs/ops/audits/code-quality-file-ledger.md');s=f.read_text();head,tail=s.split('<!-- original-source-fenced:start -->',1);lines=head.splitlines()
notes=[('battle-finalization.ts','product','67行全文，真实tick/settlement/resume与C；只修等价范围注释','非队员Extra生产可达性另卡draft；两源parsedTS/JS相同，不改机制，不关闭'),('battle-finalization.test.ts','test','80行原测全文，真实factory/hydrate/dialog，九状态与实际cursor交接观察','2→6补真实finalize出口；六旧2绿→新5绿1指定红；9直接/266相邻仅有限信用'),('battle-runtime-context.ts','product','98行全文、真实start/finalize及资源/可写投影/runner归属','只修“只读表”坏注；公开stash结构不改，跨owner反控支持有限隔离，整卡未闭合'),('battle-runtime-context.test.ts','test','75行原测全文，3例保持、去强转、精确属性语义与双GameState owner','旧3绿→新2绿1指定红；原身份/runner/释放断言保留，0新增关闭')]
for name,category,evidence,note in notes:
 path='packages/game/src/core/battle/'+name;indices=[i for i,l in enumerate(lines) if l.startswith('| `'+path+'` |')];assert len(indices)==1;i=indices[0];assert lines[i].split('|')[3].strip()=='已验证';lines[i]=f'| `{path}` | {category} | review | [pre94 finalization/runtime复审](../evidence/QUALITY-PRE94-RETROSPECTIVE-1/3u-3w-finalization/README.md)；{evidence} | {note} |'
head='\n'.join(lines)+'\n';old='当前已闭合核验：261；已读但待审：89；尚未逐文件核验：2,966；合计未闭合：3,055。';assert old in head;head=head.replace(old,'当前已闭合核验：257；已读但待审：93；尚未逐文件核验：2,966；合计未闭合：3,059。');f.write_text(head+'<!-- original-source-fenced:start -->'+tail)
f=p.parent/'all-cards.json';q=json.loads(f.read_text())
for id in ['3u','3w']:
 r=next(r for r in q['cards'] if r['id']==id);assert r['currentReview']=='pending' and not r['scopeConfirmed'] and not r['currentAcceptance'];r['currentReview']='partial';r['evidence']=str(p.relative_to(root)/'README.md')
q['currentReviewCounts']={'partial':55,'pending':28};f.write_text(json.dumps(q,ensure_ascii=False,indent=2)+'\n')
f=p.parent/'all-cards.md';s=f.read_text();assert s.count('partial=53，pending=30')==1;s=s.replace('partial=53，pending=30','partial=55，pending=28');lines=s.splitlines()
for id,oldname in [('3u','CODE-QUALITY-3u-game-battle-state-runtime.md'),('3w','CODE-QUALITY-3w-game-battle-settlement-finalization.md')]:
 i=next(i for i,l in enumerate(lines) if l.startswith('| [CODE-QUALITY-'+id+']'));assert '| done | pending |' in lines[i];lines[i]=f'| [CODE-QUALITY-{id}](../../archive/tasks/done/{oldname}) | done | partial | [清理/运行时切片](3u-3w-finalization/README.md)：七反控与275相邻执行，九直接恢复；state/settlement余项/Extra可达性/统一门仍待 |'
f.write_text('\n'.join(lines)+'\n')
f=Path('docs/ops/board.md');s=f.read_text();assert '83卡53partial/30pending/0accept；GA四文件补证；' in s;s=s.replace('83卡53partial/30pending/0accept；GA四文件补证；','83卡55partial/28pending/0accept；清理/runtime四文件补证；');row='| GAME-BATTLE-NONPARTY-EXTRA-CLEANUP-1 | [非队员Extra可达性](tasks/GAME-BATTLE-NONPARTY-EXTRA-CLEANUP-1.md) | draft | Codex / 只读核完整生产写入链 | C全role/TS party不同，但开战换队全量重建；未证剧情缺陷，不改行为 |\n';s=s.replace('| GAME-ANALYTICS-FAILED-INSTALL-OWNERSHIP-1 |',row+'| GAME-ANALYTICS-FAILED-INSTALL-OWNERSHIP-1 |',1);f.write_text(s)
f=Path('docs/ops/tasks/QUALITY-PRE94-RETROSPECTIVE-1.md');s=f.read_text().replace('当前复审队列已推进为53张partial、30张pending','当前复审队列已推进为55张partial、28张pending',1).replace('83卡当前全量accept=0、53partial/30pending','83卡当前全量accept=0、55partial/28pending',1);s+='''\n本片交付：四文件全文，两实现只纠正“只读资源表”与C全role/TS party等价范围注释，parsedTS/JS相同。两原测试用真实factory/类型去强转，final2→6、runtime3保持；保留原有效oracle，九状态/接回瞬间释放/四种finalize分支/双GameState隔离补证。七旧全文件绿→新指定单AssertionError，初driver引号匹配失败原件与只重跑四枚说明保留；恢复9直接和266相邻（6文件275）、TC零诊断。四旧closed重开review，机器3316/257closed/93review/2966pending，0新关闭；3u/3w pending→partial，83卡55/28/0accept，其它81对象与旧SHA不动。非队员Extra只证静态差异，真实开战/换队重建是强替代解释，另卡draft核可达性、无伪反例/行为修复。见[清理/runtime证据](../evidence/QUALITY-PRE94-RETROSPECTIVE-1/3u-3w-finalization/README.md)，静态门以gates为准，全仓check/coverage/protected留大任务收尾，不合main。下一步3u state/两专测或40/41，94–102/editor后置；无下一位Agent提示词。\n''';f.write_text(s)
f=p.parent/'README.md';s=f.read_text().replace('全83卡53partial/30pending/0accept（2026-10-18 GA复审；下文数字均按各片原时点）','全83卡55partial/28pending/0accept（2026-10-18 清理/runtime复审；下文数字均按各片原时点）',1);s+='''\n最新[3u/3w清理/runtime复审](3u-3w-finalization/README.md)：真实factory替换强转，九状态/释放时序/实际终态接线与跨GameState隔离；七旧绿新指定单红，9直接/266相邻和TC零诊断。四旧closed重开review，0新关闭，3316/257/93/2966；83卡55partial/28pending/0accept。非队员Extra生产可达性另卡draft，未把静态差异当剧情bug；统一门仍待，后续state或40/41。\n''';f.write_text(s)
Path('docs/ops/tasks/index.md').write_bytes(subprocess.check_output(['node','scripts/docs/check.mjs','--print-task-index']))
# Real receipts must exist before documents link to them; final static checks are explicitly pending.
rows=[]
for label,n in [('baseline',5),('current',9),('module-final',275),('restored-direct',9),('typecheck',None)]:
 r=json.loads((p/(label+'.json')).read_text());raw=gzip.decompress((p/r['raw']).read_bytes()).decode();assert r['exit']==0 and not any(k in raw for k in ['stderr |','not wrapped in act','Unhandled Errors','Unhandled Rejection']);row={'label':label,'receipt':label+'.json','exit':0,'diagnostics':{'stderrBlocks':0,'reactAct':0,'environmentWarning':0,'unhandledErrors':0}}
 if n is not None:row['passed']=n
 if label=='current':row['scope']='Earlier nine-test candidate before final enemy-resource fixture alignment; final candidate is module275/restored9'
 if label=='module-final':row.update(files=6,direct=9,adjacent=266,nativeReport='module-final.vitest.json.gz',scope='Candidate before last four controls; byte-identical restoration and restored-direct after all controls recorded')
 rows.append(row)
(p/'gates.json').write_text(json.dumps({'base':base,'status':'275 candidate/9 restored/typecheck recorded; docs/lint/ledger pending','rows':rows,'tracked':3316,'closed':257,'review':93,'pending':2966,'newClosed':0,'reopened':4,'cards':{'partial':55,'pending':28,'accept':0},'mergeAllowed':False,'productExecutionChanged':False,'notRun':['whole repository check','official coverage ratchet','protected fast','full game package test','original game runtime','browser visual','E2E']},ensure_ascii=False,indent=2)+'\n')
for source,target in [('/tmp/type-pal-finalization-docs.py','docs-producer.py.gz'),('/tmp/type-pal-finalization-capture.py','capture.py.gz'),('/tmp/type-pal-finalization-emit.cjs','emit-producer.cjs.gz')]: (p/target).write_bytes(gzip.compress(Path(source).read_bytes(),mtime=0))
print('Four live records reopened; two queue cards partial; exact reads, paired raw and draft reachability card indexed.')
