from pathlib import Path
import collections, difflib, gzip, hashlib, json, re, subprocess

base='37e2cd7c9a54b29766a87d17ffed90e4dae465dd'
codebase='6fde6d86cf9754e441de948c82ac99ebc1f480c8'
p=Path('docs/ops/evidence/QUALITY-PRE94-RETROSPECTIVE-1/3u-3w-finalization')
def sha(b): return hashlib.sha256(b).hexdigest()
def load(n): return json.loads((p/n).read_text())
def blob(path,rev=base): return subprocess.check_output(['git','show',rev+':'+str(path)])
def unpack(n): return gzip.decompress((p/n).read_bytes())
def receipt(r):
    b=unpack(r['raw']);assert len(b)==r['rawBytes'] and sha(b)==r['rawSha256']
    assert r['fullUncutMergedStdoutStderr'] and r['signal'] is None and r['spawnError'] is None
    return b

before=load('before.json');assert before['base']==codebase and len(before['files'])==4
for row in before['files']:
    b=unpack(row['snapshot']);assert b==blob(row['path'],codebase)==blob(row['path'])
    assert sha(b)==row['sha256'] and len(b.decode().splitlines())==row['lines']
for row in load('read-boundaries.json')['rows']:
    b=Path(row['path']).read_bytes();n=len(b.decode().splitlines())
    assert sha(b)==row['sha256'] and n==row['lines'] and unpack(row['snapshot'])==b,row['path']
    assert all(1<=a<=z<=n for a,z in row['ranges']),row['path']
    if row['fullRead']: assert row['ranges']==[[1,n]]
emit=load('emit-identity.json');assert len(emit['rows'])==2
for row in emit['rows']:
    assert row['byteIdentical'] and row['parsedTypeScriptWithoutCommentsIdentical']
    assert row['currentSha256']==sha(Path(row['path']).read_bytes())

canonical=load('controls.json');assert len(canonical['controls'])==7
assert sum(r['id'].endswith('-v2') for r in canonical['controls'])==6
assert canonical['controls'][-1]['id']=='owner-alias-on-install-v3'
def check_control(row,equivalent=False):
    assert row['sourceSha256']==sha(Path(row['source']).read_bytes())
    assert sha(unpack(row['id']+'.mutant.gz'))==row['mutantSha256']
    for phase,r in row['runs'].items():
        raw=receipt(r);n=unpack(r['nativeReport']);assert sha(n)==r['nativeSha256'];d=json.loads(n)
        count=row['expectedOldCount'] if phase=='old' else row['expectedCurrentCount']
        failing=(phase=='old') if equivalent else (phase=='current')
        assert d['numTotalTests']==count and d['numFailedTests']==int(failing)
        assert d['numPassedTests']==count-int(failing) and d['numPendingTests']==d['numTodoTests']==0
        assert r['exit']==int(failing) and d['success']==(not failing)
        results=d['testResults'];assert len(results)==1 and results[0]['name'].endswith(row['spec'])
        cases=results[0]['assertionResults'];assert len(cases)==count
        assert [{'file':results[0]['name'],'fullName':a['fullName'],'status':a['status']} for a in cases]==r['cases']
        failed=[a for a in cases if a['status']=='failed'];assert len(failed)==int(failing)
        if failing:
            needle=row['expectedOldFailureNameContains'] if equivalent else row['expectedNewFailureNameContains']
            assert needle in failed[0]['fullName']
            assert failed[0]['failureMessages'] and all('AssertionError:' in m for m in failed[0]['failureMessages'])
        assert not re.search(rb'(stderr \||Unhandled Error|Unhandled Rejection|Runtime Error)',raw)
        assert r['specSha256']==sha(blob(row['spec'],codebase) if phase=='old' else Path(row['spec']).read_bytes())
        assert r['sourceRestoredByteForByte'] and r['specRestoredByteForByte']
        assert r['sourceRestoredSha256']==sha(Path(row['source']).read_bytes())
        assert r['specRestoredSha256']==sha(Path(row['spec']).read_bytes())
for row in canonical['controls']: check_control(row)
eq=load('private-shape-metamorphism.json');assert len(eq['controls'])==1
check_control(eq['controls'][0],True)
for doc in [canonical,eq]:
    assert doc['restored'] and doc['tempDirectoryRemoved'] and not Path(doc['tempDirectory']).exists()
    for row in doc['controls']:
        for run in row['runs'].values():
            output=next(c.split('=',1)[1] for c in run['command'] if c.startswith('--outputFile.json='))
            assert not Path(output).exists()

# Every full capture and native archive is checked, including historical candidates.
for f in p.glob('*.json'):
    d=json.loads(f.read_text())
    if isinstance(d,dict) and 'rawBytes' in d: receipt(d)
g=load('gates.json');assert (g['tracked'],g['closed'],g['review'],g['pending'])==(3316,255,96,2965)
assert not g['mergeAllowed'] and not g['productExecutionChanged'] and g['newClosed']==0
for label in ['module-current','typecheck-current','docs-consumers-current','lint-current','ledger']:
    r=load(label+'.json');raw=receipt(r);assert r['exit']==0
    assert not re.search(rb'(stderr \||Warning:|Unhandled Error|Unhandled Rejection|error TS\d)',raw),label
d=json.loads(unpack('module-current.vitest.json.gz'))
assert d['success'] and d['numTotalTests']==d['numPassedTests']==275 and d['numFailedTests']==d['numPendingTests']==d['numTodoTests']==0
assert len(d['testResults'])==6
direct=[f for f in d['testResults'] if any(f['name'].endswith(r['path']) for r in before['files'] if r['path'].endswith('.test.ts'))]
assert len(direct)==2 and sum(len(f['assertionResults']) for f in direct)==9
for f in d['testResults']: assert all(a['status']=='passed' for a in f['assertionResults'])
for row in canonical['controls']:
    current=row['runs']['current']['cases'];formal=next(f for f in direct if f['name'].endswith(row['spec']))
    assert [a['fullName'] for a in current]==[a['fullName'] for a in formal['assertionResults']]
lint=receipt(load('lint-current.json')).decode();assert 'error=0 warning=0 info=0' in lint or 'errors=0 warnings=0 infos=0' in lint or re.search(r'0 errors.*0 warnings.*0 infos',lint)

# Four live ledger rows only; archived historical ledger below the live fence unchanged.
ledger=Path('docs/ops/audits/code-quality-file-ledger.md');old=blob(ledger).decode();new=ledger.read_text()
diff=list(difflib.ndiff(old.splitlines(),new.splitlines()))
removed=[s[2:] for s in diff if s.startswith('- ')];added=[s[2:] for s in diff if s.startswith('+ ')]
assert len(removed)==len(added)==5
for row in before['files']:
    assert sum(r.startswith('| `'+row['path']+'`') and '| 已验证 |' in r for r in removed)==1
    assert sum(r.startswith('| `'+row['path']+'`') and '| review |' in r for r in added)==1

queue=Path('docs/ops/evidence/QUALITY-PRE94-RETROSPECTIVE-1/all-cards.json')
original=json.loads(blob(queue));current=json.loads(queue.read_text())
assert current['count']==83 and current['currentAccepted']==0
assert current['currentReviewCounts']=={'partial':55,'pending':28}
assert collections.Counter(r['currentReview'] for r in current['cards'])==collections.Counter({'partial':55,'pending':28})
for a,b in zip(original['cards'],current['cards']):
    if a['id'] not in ['3u','3w']: assert a==b
    else:
        assert a['currentReview']=='pending' and b['currentReview']=='partial'
        assert not b['scopeConfirmed'] and not b['currentAcceptance']
        assert {k:v for k,v in a.items() if k not in ['currentReview','evidence']}=={k:v for k,v in b.items() if k not in ['currentReview','evidence']}
        assert Path(b['path']).read_bytes()==blob(b['path'])
assert {k:v for k,v in original.items() if k not in ['cards','currentReviewCounts']}=={k:v for k,v in current.items() if k not in ['cards','currentReviewCounts']}
chain=load('review-chain.json');assert chain['base']==base and len(chain['bindings'])==6
byreview=collections.defaultdict(list)
for r in chain['bindings']:
    b=Path(r['target']).read_bytes();assert r['currentSha256']==sha(b) and r['lines']==len(b.decode().splitlines())
    assert r['previousAfterSha256']==sha(blob(r['target']));byreview[r['review']].append(r['target'])
for path,targets in byreview.items():
    old=json.loads(blob(path));cur=json.loads(Path(path).read_text())
    assert {k:v for k,v in cur.items() if k!='entries'}=={k:v for k,v in old.items() if k!='entries'}
    for a,b in zip(old['entries'],cur['entries']):
        if a['path'] not in targets: assert a==b
        else:
            assert b['afterSha256']==sha(Path(a['path']).read_bytes())
            assert b['revision']['history'][1:]==a['revision']['history']
            assert b['revision']['history'][0]['revision']==base
for path in ['docs/ops/evidence/README.md','scripts/docs/check.mjs','scripts/quality/code-quality-inventory.mjs','scripts/quality/code-quality-inventory.test.mjs']:
    assert Path(path).read_bytes()==blob(path)
assert not subprocess.check_output(['git','diff',base,'--','docs/ops/evidence/QUALITY-DOCS-GIT-PATH-ENUMERATION-1'])
allowed={r['path'] for r in before['files']}|{str(ledger),'docs/ops/board.md',str(queue),str(queue.with_suffix('.md')),'docs/ops/tasks/index.md','docs/ops/tasks/QUALITY-PRE94-RETROSPECTIVE-1.md',str(queue.parent/'README.md')}|set(byreview)
changed=set(subprocess.check_output(['git','diff','--name-only',base]).decode().splitlines())
assert changed==allowed,(changed-allowed,allowed-changed)
untracked=subprocess.check_output(['git','ls-files','--others','--exclude-standard']).decode().splitlines()
assert all(f.startswith(str(p)+'/') or f=='docs/ops/tasks/GAME-BATTLE-NONPARTY-EXTRA-CLEANUP-1.md' for f in untracked)
print(json.dumps({'scope':'Four-file lifecycle review only; no whole-card or unified-gate acceptance','selectedFiles':4,'newClosed':0,'reopenedReview':4,'regressionControls':7,'equivalentShapeControl':1,'direct':9,'adjacent':266,'total':275,'tracked':3316,'closed':255,'review':96,'pending':2965,'partialCards':55,'pendingCards':28,'acceptedCards':0,'reviewFiles':len(byreview),'rawNativeHashesAndRestores':'verified','status':'pass'},ensure_ascii=False))
