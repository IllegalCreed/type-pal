from pathlib import Path
import json,gzip,hashlib,subprocess,copy,re
root=Path.cwd();p=Path('docs/ops/evidence/QUALITY-EXTRACT-OUTPUT-BOUNDARY-1/entrypoint-followup');base='298136f19c9b5acb51867a5d96275fe5438c06a7';sha=lambda b:hashlib.sha256(b).hexdigest();load=lambda n:json.loads((p/n).read_text());uz=lambda n:gzip.decompress((p/n).read_bytes());blob=lambda s:subprocess.check_output(['git','show',base+':'+s])
for f in p.glob('*.json'):
 d=json.loads(f.read_text())
 if isinstance(d,dict) and 'rawBytes' in d:
  raw=uz(d['raw']);assert len(raw)==d['rawBytes'] and sha(raw)==d['rawSha256'] and d['signal'] is None and d['spawnError'] is None
for r in load('before-sources.json')['files']:
 b=uz(r['snapshot']);assert sha(b)==r['sha256'] and len(b.decode().splitlines())==r['lines']
 if 'cli-entrypoint-paths.test' not in r['path']:assert b==blob(r['path'])
 else:assert b==Path(r['path']).read_bytes()
for r in load('read-boundaries.json')['rows']:
 b=Path(r['path']).read_bytes();assert b==uz(r['snapshot']) and sha(b)==r['sha256'] and len(b.decode().splitlines())==r['lines'] and r['fullRead'] and r['ranges']==[[1,r['lines']]]
red=json.loads(uz('red.vitest.json.gz'));green=json.loads(uz('module.vitest.json.gz'));assert red['numPassedTests']==5 and red['numFailedTests']==3 and red['numTotalTests']==8;assert green['numPassedTests']==green['numTotalTests']==41 and len(green['testResults'])==7
for d in [red,green]:assert d['numPendingTests']==d['numTodoTests']==0 and not d.get('unhandledErrors',[]) and all(a['status'] in ['passed','failed'] for f in d['testResults'] for a in f['assertionResults'])
for f in red['testResults']:
 g=next(x for x in green['testResults'] if x['name']==f['name']);assert [a['fullName'] for a in f['assertionResults']]==[a['fullName'] for a in g['assertionResults']]
 for a in f['assertionResults']:
  if a['status']=='failed':assert a['failureMessages'] and all('AssertionError:' in m for m in a['failureMessages']) and ('video entrypoint refuses shared' in a['fullName'] or 'absolute CLI entrypoint' in a['fullName'])
assert load('red.json')['exit']==1
for name in ['module','typecheck','docs-consumers','ledger','lint']:
 r=load(name+'.json');raw=uz(r['raw']);assert r['exit']==0 and not re.search(rb'(stderr \||Warning:|Unhandled Error|Unhandled Rejection|error TS\d)',raw),name
assert b'3319 files; 251 closed / 103 review / 2965 pending' in uz('ledger.raw.gz');assert b'0 errors / 0 warnings / 0 infos; complete report' in uz('lint.raw.gz')
# Comment-only ownership helper has identical emitted JS.
helper='packages/pal-extract/src/output-boundary.ts';js="import ts from 'typescript';import{createHash}from'node:crypto';let s='';for await(const b of process.stdin)s+=b;console.log(JSON.stringify(JSON.parse(s).map(x=>createHash('sha256').update(ts.transpileModule(x,{compilerOptions:{target:ts.ScriptTarget.ESNext,module:ts.ModuleKind.ESNext,removeComments:true}}).outputText).digest('hex'))));"
hashes=json.loads(subprocess.check_output(['node','--input-type=module','-e',js],input=json.dumps([blob(helper).decode(),Path(helper).read_text()]).encode()));assert hashes[0]==hashes[1]
ledger='docs/ops/audits/code-quality-file-ledger.md';old=blob(ledger).decode();cur=Path(ledger).read_text();expected=old.replace('当前 tracked 清单：3,318。','当前 tracked 清单：3,319。').replace('已读但待审：102；','已读但待审：103；').replace('合计未闭合：3,067。','合计未闭合：3,068。')
for r in load('before-sources.json')['files'][:3]:
 path=r['path'];a=next(l for l in old.splitlines() if l.startswith('| `'+path+'` |'));b=next(l for l in cur.splitlines() if l.startswith('| `'+path+'` |'));expected=expected.replace(a,b,1)
new=next(l for l in cur.splitlines() if l.startswith('| `packages/pal-extract/src/cli-entrypoint-paths.test.ts` |'));start=expected.index('| 文件 |');end=expected.index('\n\n',start);expected=expected[:end]+'\n'+new+expected[end:];assert expected==cur
q='docs/ops/evidence/QUALITY-PRE94-RETROSPECTIVE-1/all-cards.json';assert Path(q).read_bytes()==blob(q)
for path in sorted({r['review'] for r in load('review-chain.json')['bindings']}):
 old=json.loads(blob(path));cur=json.loads(Path(path).read_text());rebuilt=copy.deepcopy(cur)
 for bind in [r for r in load('review-chain.json')['bindings'] if r['review']==path]:
  before=next(r for r in old['entries'] if r['path']==bind['target']);after=next(r for r in cur['entries'] if r['path']==bind['target']);assert after['afterSha256']==sha(Path(bind['target']).read_bytes()) and after['revision']['history'][1:]==before['revision']['history'];r=copy.deepcopy(after);r['afterSha256']=before['afterSha256'];r['reviewedLines']=before['reviewedLines'];r['revision']['history']=before['revision']['history']
  for k in ['implementationSha','afterSha256']:
   if k in before['revision']:r['revision'][k]=before['revision'][k]
  if isinstance(before.get('evidence'),dict):
   for k in ['afterSha256','lineCount']:
    if k in before['evidence']:r['evidence'][k]=before['evidence'][k]
  assert r==before;rebuilt['entries'][rebuilt['entries'].index(after)]=before
 assert rebuilt==old
assert Path('docs/ops/tasks/QUALITY-EXTRACT-OUTPUT-BOUNDARY-1.md').read_bytes().startswith(blob('docs/ops/tasks/QUALITY-EXTRACT-OUTPUT-BOUNDARY-1.md'))
assert not subprocess.check_output(['git','diff','37e2cd7c9a54b29766a87d17ffed90e4dae465dd','--','scripts/docs/'])
allowed={r['path'] for r in load('before-sources.json')['files']}|{ledger,'docs/ops/board.md','docs/ops/tasks/QUALITY-EXTRACT-OUTPUT-BOUNDARY-1.md'}|{r['review'] for r in load('review-chain.json')['bindings']}
changed=[s.decode() for s in subprocess.check_output(['git','diff','--name-only','-z',base]).split(b'\0') if s];unknown=[s.decode() for s in subprocess.check_output(['git','ls-files','--others','--exclude-standard','-z']).split(b'\0') if s];assert set(changed)<=allowed and all(s.startswith(str(p)+'/') for s in unknown)
assert subprocess.check_output(['git','branch','--show-current'],text=True).strip()=='codex/code-quality-3y';subprocess.run(['git','diff','--check'],check=True)
print('PASS: frozen old implementations/new spec, 3 precise pre-fix AssertionErrors, final41 and identical full case identities, native/raw hashes; zero TC/lint/docs/ledger; helper JS identical; bounded live rows/history preserve all other records;83 card states unchanged; exclusive 3y scope.')
