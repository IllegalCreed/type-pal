import pathlib,tempfile,shutil,subprocess,json,datetime,hashlib,difflib
root=pathlib.Path(__file__).resolve().parents[2];out=pathlib.Path(__file__).parent
source=root/'packages/editor/src/ui/App.tsx';test=root/'packages/editor/src/ui/App.preview-initial-state.test.tsx';original=source.read_text();before='''                  onDispatchWithInitialStates={(command, library) =>
                    historyCoordinator.dispatch(
                      command,
                      new SetScriptPreviewLibraryCommand(library),
                    )
                  }''';after='''                  onDispatchWithInitialStates={(command, library) => {
                    scriptSession!.dispatch(command)
                    session.dispatch(new SetScriptPreviewLibraryCommand(library))
                  }}''';assert original.count(before)==1
mutant=original.replace(before,after)
(out/'counter-paired-save.patch').write_text(''.join(difflib.unified_diff(original.splitlines(True),mutant.splitlines(True),fromfile='App.tsx',tofile='App.tsx-mutant')))
sandbox=pathlib.Path(tempfile.mkdtemp(prefix='preview-pair-counter-'))
receipt={'actor':'/root/script_progress_ledger','startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source':str(source),'sourceSha256':hashlib.sha256(source.read_bytes()).hexdigest(),'testSha256':hashlib.sha256(test.read_bytes()).hexdigest(),'mutantSha256':hashlib.sha256(mutant.encode()).hexdigest(),'sandbox':str(sandbox),'mutation':'split existing coordinated Save into separate script/main history entries'}
def mirror(directory,target,overrides):
 target.mkdir(parents=True,exist_ok=True)
 for child in directory.iterdir():
  rel=child.relative_to(root).as_posix();to=target/child.name
  if rel in overrides: to.write_text(overrides[rel])
  elif any(k.startswith(rel+'/') for k in overrides): mirror(child,to,overrides)
  elif child.name not in ('.git','build','data','projects'): to.symlink_to(child,target_is_directory=child.is_dir())
try:
 config=(root/'packages/editor/vite.config.ts').read_text().replace('export default {', 'export default { server: { fs: { allow: '+json.dumps([str(root),str(sandbox)])+' } },',1)
 receipt['configAdaptation']='explicit Vite fs allow for source dependency symlinks and temporary root';receipt['temporaryConfigSha256']=hashlib.sha256(config.encode()).hexdigest()
 mirror(root,sandbox,{'packages/editor/vite.config.ts':config,'packages/editor/src/ui/App.tsx':mutant,'packages/editor/src/ui/App.preview-initial-state.test.tsx':test.read_text()})
 cwd=sandbox/'packages/editor';cmd=['pnpm','exec','vitest','run','src/ui/App.preview-initial-state.test.tsx','--reporter=default','--reporter=json','--outputFile='+str(out.resolve()/'counter-paired-save.json')];receipt.update(cwd=str(cwd),command=cmd)
 with (out/'counter-paired-save.log').open('w') as log:r=subprocess.run(cmd,cwd=cwd,stdout=log,stderr=subprocess.STDOUT)
 receipt.update(exit=r.returncode,signal=-r.returncode if r.returncode<0 else None,spawnError=None)
finally:
 shutil.rmtree(sandbox);receipt.update(finishedAt=datetime.datetime.now(datetime.timezone.utc).isoformat(),sandboxRemoved=not sandbox.exists(),sourceRestored=source.read_text()==original);(out/'counter-paired-save-execution.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
