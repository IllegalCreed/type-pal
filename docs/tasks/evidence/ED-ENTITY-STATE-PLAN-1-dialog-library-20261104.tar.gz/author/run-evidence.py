import subprocess,json,hashlib,datetime,pathlib,sys
root=pathlib.Path(__file__).resolve().parents[2]
name=sys.argv[1];cwd=root/sys.argv[2];cmd=sys.argv[3:];out=pathlib.Path(__file__).parent
files=subprocess.check_output(['git','diff','cb14db89d954231227e5ad162beded23adaaaa33','--name-only'],cwd=root,text=True).splitlines()
receipt={'cwd':str(cwd),'command':cmd,'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'actor':'/root/script_progress_ledger','candidateBase':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'node':subprocess.check_output(['node','--version'],text=True).strip(),'sourceHashes':{f:hashlib.sha256((root/f).read_bytes()).hexdigest() for f in files}}
try:
 with (out/(name+'.log')).open('w') as log:r=subprocess.run(cmd,cwd=cwd,stdout=log,stderr=subprocess.STDOUT)
 receipt.update(exit=r.returncode,signal=-r.returncode if r.returncode<0 else None,spawnError=None)
except OSError as error:receipt.update(exit=None,signal=None,spawnError=str(error))
receipt['finishedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat()
(out/(name+'-execution.json')).write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'name':name,'exit':receipt['exit'],'spawnError':receipt['spawnError']}))
sys.exit(0 if receipt['exit']==0 else 1)
