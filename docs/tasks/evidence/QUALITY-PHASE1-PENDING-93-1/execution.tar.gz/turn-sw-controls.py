from pathlib import Path
import subprocess, json, hashlib, difflib
root=Path('/Users/zhangxu/.codex/worktrees/quality-94-102/type-pal')
stage=Path(__file__).parent
runner=stage/'run-scoped.py'
controls=[
 ('turn-flee-floor', 'packages/game/src/core/battle/battle-system.ts', 'dex = Math.floor(dex * actionDexMultiplier(state.pendingActions.get(i), res.spells))', 'dex = dex * actionDexMultiplier(state.pendingActions.get(i), res.spells)', ['vitest','packages/game','src/core/battle/battle-turn-boundaries.glm-turn.test.ts','-t','行动倍率 flee'], ['vitest','packages/game','src/core/battle/battle-round-order.test.ts','-t','halves odd flee']),
 ('turn-auto-producer', 'packages/game/src/core/battle/battle-system.ts', 'state.prevPlayerAutoAtk = true', 'state.prevPlayerAutoAtk = false', ['vitest','packages/game','src/core/battle/battle-turn-boundaries.glm-turn.test.ts','-t','DL1 prevPlayerAutoAtk'], ['vitest','packages/game','src/core/battle/battle-round-lifecycle.test.ts','-t','a real auto-attack predecessor']),
 ('sw-current-cache-delete', 'packages/game/public/sw.js', 'k !== CACHE_NAME', 'true', ['command','.','node','--test','--test-name-pattern=^SW ','scripts/e2e/sw-cache.test.mjs'], ['command','.','node','--test','--test-name-pattern=^activation preserves','scripts/e2e/sw-cache.test.mjs']),
 ('sw-pause-bypass', 'packages/game/public/sw.js', 'await waitWhilePaused()', 'await Promise.resolve()', ['command','.','node','--test','--test-name-pattern=^SW ','scripts/e2e/sw-cache.test.mjs'], ['command','.','node','--test','--test-name-pattern=^a paused precache','scripts/e2e/sw-cache.test.mjs'])
]
reports=[]
for label, name, old, new, before_args, after_args in controls:
 path=root/name; data=path.read_bytes(); text=data.decode(); assert text.count(old)==1, label
 mutant=text.replace(old,new)
 patch=''.join(difflib.unified_diff(text.splitlines(True),mutant.splitlines(True),fromfile='a/'+name,tofile='b/'+name))
 (stage/(label+'.patch')).write_text(patch)
 try:
  path.write_text(mutant)
  results=[]
  for phase,args,expected in [('old',before_args,0),('new',after_args,1)]:
   run=subprocess.run(['python3',str(runner),label+'-'+phase,*args,'--inputs',name],cwd=root,stdout=subprocess.DEVNULL)
   assert run.returncode==expected,(label,phase,run.returncode)
   raw=(stage/(label+'-'+phase+'.stdout')).read_text()
   if args[0]=='vitest':
    report=json.loads((stage/(label+'-'+phase+'.vitest.json')).read_text())
    failed=[a for file in report['testResults'] for a in file['assertionResults'] if a['status']=='failed']
    assert len(failed)==expected,(label,phase,len(failed))
    if expected:assert 'AssertionError' in str(failed[0].get('failureMessages',[])), label
    results.append({'phase':phase,'exit':run.returncode,'passed':report['numPassedTests'],'failedFullNames':[a['fullName'] for a in failed]})
   else:
    assert '# fail '+str(expected) in raw
    if expected:assert 'AssertionError' in raw, label
    results.append({'phase':phase,'exit':run.returncode,'assertionFailure':bool(expected)})
 finally:
  path.write_bytes(data)
  assert hashlib.sha256(path.read_bytes()).digest()==hashlib.sha256(data).digest()
 reports.append({'label':label,'source':name,'beforeAndRestoredSha256':hashlib.sha256(data).hexdigest(),'mutantSha256':hashlib.sha256(mutant.encode()).hexdigest(),'results':results})
 print(label, 'old passed; new exactly one business assertion failed; source restored',flush=True)
(stage/'turn-sw-controls.json').write_text(json.dumps(reports,ensure_ascii=False,indent=2)+'\n')
