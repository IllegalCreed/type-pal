from pathlib import Path
import sys,subprocess,json,hashlib,datetime
root=Path('/Users/zhangxu/.codex/worktrees/quality-94-102/type-pal')
dest=Path(__file__).parent
label=sys.argv[1]; kind=sys.argv[2]; package=sys.argv[3]; args=sys.argv[4:]
base=dest/label
inputs=args[:]
if '--inputs' in args:
 i=args.index('--inputs');inputs=args[i+1:];args=args[:i]
cwd=root/package
if kind=='vitest':cmd=[str(root/'node_modules/.bin/vitest'),'run',*args,'--reporter=default','--reporter=json','--outputFile.json='+str(base)+'.vitest.json']
else:cmd=args
# Test arguments and additional inputs are both part of the execution identity.
identity_inputs = ([arg for arg in args if arg.endswith(('.ts', '.tsx'))] if kind == 'vitest' else []) + inputs
paths=[p if (root/p).exists() else str(Path(package)/p) for p in dict.fromkeys(identity_inputs)]
paths+=['pnpm-lock.yaml','packages/game/vite.config.ts','packages/game/package.json']
meta={'command':cmd,'cwd':str(cwd),'started':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'sha256':{p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths if (root/p).is_file()}}
with Path(str(base)+'.stdout').open('xb') as out,Path(str(base)+'.stderr').open('xb') as err:
 r=subprocess.run(cmd,cwd=cwd,stdout=out,stderr=err)
meta.update(ended=datetime.datetime.now(datetime.timezone.utc).isoformat(),exit=r.returncode,signal=-r.returncode if r.returncode<0 else None)
with Path(str(base)+'.json').open('x') as f:json.dump(meta,f,indent=2);f.write('\n')
print(Path(str(base)+'.stdout').read_text())
print('stderr bytes:',Path(str(base)+'.stderr').stat().st_size,'exit:',r.returncode)
if r.returncode:print(Path(str(base)+'.stderr').read_text())
sys.exit(r.returncode)
