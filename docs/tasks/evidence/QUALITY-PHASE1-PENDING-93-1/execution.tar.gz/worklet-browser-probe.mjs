import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import fs from 'node:fs'
import { createRequire } from 'node:module'
import { join, resolve } from 'node:path'
import { fileURLToPath, pathToFileURL } from 'node:url'
const root = process.cwd()
const stage = fileURLToPath(new URL('.', import.meta.url))
const require = createRequire(join(root, 'package.json'))
const { chromium } = require('playwright')
const gameRequire = createRequire(join(root, 'packages/game/package.json'))
const { createServer } = await import(pathToFileURL(gameRequire.resolve('vite')).href)
const cache = join(stage, 'worklet-vite-cache-' + process.pid)
const servedWorklets = []
let caseMode

process.env.E2E = '1'
const html = String.raw`<!doctype html><meta charset="utf-8"><title>Native MIDI component verification</title>
<button>Start real MIDI</button><button>Load missing worklet</button><script type="module">
import { createSpessaSynthBackend } from '/src/shell/audio-midi.ts';
const Native = window.AudioContext;
const contexts = [];
window.AudioContext = class extends Native { constructor(...args) { super(...args); contexts.push(this); } };
const wait = async (ready, ms) => { const end = performance.now() + ms; while (!ready()) { if (performance.now() > end) throw Error('native condition did not complete'); await new Promise(r => setTimeout(r, 20)); } };
for (const [index, mode] of ['positive', 'missing'].entries()) document.querySelectorAll('button')[index].onclick = async () => {
 window.result = {status: 'running', mode};
 let backend;
 try {
  backend = createSpessaSynthBackend({baseUrl:'/extracted',workletUrl:mode === 'positive' ? '/spessasynth_processor.min.js' : '/__quality_missing_processor.js',soundfontUrl:'/soundfont.sf3'});
  backend.setVolume(0.1);
  if (mode === 'missing') {
   let rejected;
   try { await backend.ready; } catch(error) { rejected = {name:error.name,message:error.message}; }
   if (!rejected) throw Error('missing module unexpectedly initialized');
   const context = contexts.at(-1);
   backend.dispose();
   await wait(() => context.state === 'closed', 2000);
   window.result = {status:'passed',mode,rejected,contextState:context.state,nativeContext:context instanceof Native};
  } else {
   await backend.ready;
   const tap = window.__tpmidi;
   const context = contexts.at(-1);
   if (!tap || tap.ctx !== context || !(context instanceof Native)) throw Error('real DEV audio context is required');
   const analyser = context.createAnalyser(); analyser.fftSize = 2048;
   const silent = context.createGain(); silent.gain.value = 0;
   tap.synth.connect(analyser); analyser.connect(silent); silent.connect(context.destination);
   backend.play(49, true);
   const data = new Float32Array(2048);
   let peak = 0;
   await wait(() => { analyser.getFloatTimeDomainData(data); peak = Math.max(...data.map(Math.abs)); return peak > 0.000001; }, 10000);
   const samples = Array.from(data);
   if (!samples.every(Number.isFinite)) throw Error('non-finite PCM');
   const rms = Math.sqrt(samples.reduce((sum, value) => sum + value * value, 0) / samples.length);
   const before = {state:context.state,currentTime:context.currentTime,sampleRate:context.sampleRate};
   backend.stop(); backend.dispose();
   await wait(() => context.state === 'closed', 2000);
   window.result = {status:'passed',mode,before,after:context.state,peak,rms,samples};
  }
 } catch(error) { backend?.dispose(); window.result = {status:'failed',mode,message:error.message,stack:error.stack}; }
};
window.componentReady = true;
</script>`
const report = {started: new Date().toISOString(), scope:'Actual MIDI backend + native Chromium AudioWorklet, real SF2 and track049. No game-story/E2E/physical-speaker/algorithm-quality claim.', node:process.version, inputs:{}, cases:[]}
for(const path of ['pnpm-lock.yaml','packages/game/package.json','packages/game/vite.config.ts','packages/game/public/spessasynth_processor.min.js','packages/game/public/spessasynth-LICENSE.txt','packages/game/public/soundfont.sf3','packages/game/src/shell/audio-midi.ts','packages/game/src/shell/audio.ts','packages/game/src/shell/bootstrap.ts','packages/game/src/shell/music-source.ts','data/extracted/music/049.mid']){
 const bytes=fs.readFileSync(join(root,path));report.inputs[path]={bytes:bytes.length,sha256:createHash('sha256').update(bytes).digest('hex')};
}
let server, browser
try {
 server = await createServer({root:join(root,'packages/game'),configFile:join(root,'packages/game/vite.config.ts'),cacheDir:cache,logLevel:'error',server:{host:'127.0.0.1',port:0,strictPort:false},plugins:[{name:'owned-native-worklet-probe',configureServer(server){server.middlewares.use((req,res,next)=>{if(req.url === '/spessasynth_processor.min.js' || req.url === '/__quality_missing_processor.js'){const chunks=[];const write=res.write;const end=res.end;const collect=(chunk,encoding)=>{if(chunk!==undefined && chunk!==null)chunks.push(Buffer.isBuffer(chunk)?Buffer.from(chunk):Buffer.from(chunk,typeof encoding==='string'?encoding:'utf8'))};res.write=function(...args){collect(args[0],args[1]);return write.apply(this,args)};res.end=function(...args){collect(args[0],args[1]);return end.apply(this,args)};res.once('finish',()=>servedWorklets.push({mode:caseMode,url:req.url,status:res.statusCode,bytes:Buffer.concat(chunks)}))}if(req.url === '/__quality_worklet.html'){res.setHeader('Content-Type','text/html');res.end(html)}else if(req.url === '/__quality_missing_processor.js'){res.statusCode=404;res.end('owned missing module')}else next()})}}]})
 await server.listen()
 const address=server.httpServer.address(); assert.ok(address && typeof address==='object')
 const base='http://127.0.0.1:'+address.port;report.origin=base
 await server.transformRequest('/src/shell/audio-midi.ts')
 browser=await chromium.launch({channel:'chrome',headless:true})
 report.browser=browser.version()
 for(const mode of ['missing']){
  caseMode=mode;const context=await browser.newContext();const page=await context.newPage(); const entry={mode,console:[],pageErrors:[],requests:[],failedRequests:[],responses:[]};report.cases.push(entry)
  page.on('console',msg=>entry.console.push({type:msg.type(),text:msg.text(),location:msg.location()}))
  page.on('pageerror',error=>entry.pageErrors.push({name:error.name,message:error.message,stack:error.stack}))
  page.on('request',request=>entry.requests.push(request.url()))
  page.on('requestfailed',request=>entry.failedRequests.push({url:request.url(),error:request.failure()}))
  const workletCopies=[]
  page.on('response',response=>{entry.responses.push({url:response.url(),status:response.status()});if(response.url()===base+'/spessasynth_processor.min.js')workletCopies.push(response.body())})
  try {
   await page.goto(base+'/__quality_worklet.html')
   await page.waitForFunction(()=>window.componentReady===true)
   await page.getByRole('button',{name:mode==='positive'?'Start real MIDI':'Load missing worklet',exact:true}).click()
   await page.waitForFunction(()=>window.result && window.result.status!=='running',null,{timeout:20000})
   const result=await page.evaluate(()=>window.result);entry.result={...result}; delete entry.result.samples
   assert.equal(result.status,'passed',JSON.stringify(result))
   assert.deepEqual(entry.pageErrors,[])
   assert.ok(entry.requests.every(url=>new URL(url).origin===base))
   if(mode==='positive'){
    assert.equal(result.before.state,'running');assert.equal(result.after,'closed');assert.ok(result.rms>0 && result.peak>0)
    assert.deepEqual(entry.failedRequests,[])
    const copies=servedWorklets.filter(row=>row.mode===mode);assert.equal(copies.length,1);assert.equal(copies[0].status,200);assert.deepEqual(copies[0].bytes,fs.readFileSync(join(root,'packages/game/public/spessasynth_processor.min.js')));entry.serverWorklet={status:copies[0].status,bytes:copies[0].bytes.length,sha256:createHash('sha256').update(copies[0].bytes).digest('hex')}
    assert.ok(entry.responses.some(r=>r.url.endsWith('/extracted/music/049.mid')&&r.status===200))
    const pcm=Buffer.alloc(result.samples.length*4);result.samples.forEach((v,i)=>pcm.writeFloatLE(v,i*4))
    const file=join(stage,'worklet-native-output-r3.f32le');fs.writeFileSync(file,pcm,{flag:'wx'});entry.pcm={path:file,format:'Float32LE mono analyser tap at synthesizer source',frames:result.samples.length,sha256:createHash('sha256').update(pcm).digest('hex')}
   } else {
    assert.equal(result.contextState,'closed');assert.equal(result.nativeContext,true);assert.ok(result.rejected.name)
    const missing=servedWorklets.filter(row=>row.mode===mode && row.url==='/__quality_missing_processor.js');assert.equal(missing.length,1);assert.equal(missing[0].status,404);entry.serverMissing={status:missing[0].status,bytes:missing[0].bytes.length}
   }
  }finally {await context.close()}
 }
 report.passed=true
 console.log(JSON.stringify({passed:true,browser:report.browser,cases:report.cases.map(c=>({mode:c.mode,result:c.result,consoleByType:c.console.reduce((out,e)=>(out[e.type]=(out[e.type]??0)+1,out),{}),pageErrors:c.pageErrors.length}))},null,2))
}catch(error){report.passed=false;report.failure={message:error.message,stack:error.stack};throw error}
finally{
 await browser?.close();await server?.close();fs.rmSync(cache,{recursive:true,force:true});report.ended=new Date().toISOString();report.ownedCacheRemoved=!fs.existsSync(cache);fs.writeFileSync(join(stage,'worklet-browser-report-missing-r3.json'),JSON.stringify(report,null,2)+'\n',{flag:'wx'})
}
