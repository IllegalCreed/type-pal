const ts=require("/Users/zhangxu/.codex/worktrees/quality-94-102/type-pal/node_modules/typescript");
module.exports=function normalize(source,name){const sf=ts.createSourceFile(name,source,ts.ScriptTarget.Latest,true);const edits=[];const removed=[];function scan(n){
 if(ts.isImportDeclaration(n)&&n.moduleSpecifier.text.endsWith('/grok-render-r1/dump-evidence.js')){edits.push([n.getStart(sf),n.getEnd(),'']);removed.push('capture-only import');return}
 if(ts.isExpressionStatement(n)){
  const e=n.expression;const call=ts.isAwaitExpression(e)?e.expression:e;
  if(ts.isCallExpression(call)&&ts.isIdentifier(call.expression)&&['dumpHost','dumpFramebuffer'].includes(call.expression.text)){edits.push([n.getStart(sf),n.getEnd(),'']);removed.push(call.expression.text);return}
  if(ts.isBinaryExpression(e)&&ts.isPropertyAccessExpression(e.left)&&['atDone','at599'].includes(e.left.expression.getText(sf))&&e.left.name.text==='flags'){edits.push([n.getStart(sf),n.getEnd(),'']);removed.push('synthetic metadata flags');return}
 }
 if(ts.isVariableStatement(n)&&n.declarationList.declarations.length===1){const d=n.declarationList.declarations[0];if(ts.isIdentifier(d.name)&&d.initializer){const name=d.name.text;const init=d.initializer;
  if(['atDone','at599'].includes(name)&&ts.isCallExpression(init)&&init.expression.getText(sf)==='readHost'){edits.push([n.getStart(sf),n.getEnd(),'']);removed.push('capture-only DOM snapshot');return}
  if(['snap','finalSnap'].includes(name)&&ts.isCallExpression(init)&&ts.isPropertyAccessExpression(init.expression)&&init.expression.name.text==='getImageData'){edits.push([n.getStart(sf),n.getEnd(),'']);removed.push('redundant full-canvas read');return}
 }}
 if(ts.isStringLiteral(n)){const old=n.text;const next=old.replace(/^G\d+-[A-Z]\d+\s+/,'').replace('Dialogue canvas and PNG output','Dialogue canvas output');if(next!==old)edits.push([n.getStart(sf),n.getEnd(),JSON.stringify(next)])}
 ts.forEachChild(n,scan)
}scan(sf);let out=source;for(const [a,b,v]of edits.sort((x,y)=>y[0]-x[0]))out=out.slice(0,a)+v+out.slice(b);
 const clean=ts.createSourceFile(name,out,ts.ScriptTarget.Latest,true);const asyncTokens=[];function hasAwait(n){let found=false;function walk(c){if(ts.isAwaitExpression(c))found=true;ts.forEachChild(c,walk)}walk(n);return found}
 function strip(n){if(ts.isArrowFunction(n)&&ts.isCallExpression(n.parent)&&['it','test'].includes(n.parent.expression.getText(clean))&&n.parent.arguments[1]===n&&n.modifiers?.some(m=>m.kind===ts.SyntaxKind.AsyncKeyword)&&!hasAwait(n.body)){for(const m of n.modifiers)if(m.kind===ts.SyntaxKind.AsyncKeyword)asyncTokens.push([m.getStart(clean),m.getEnd()])}ts.forEachChild(n,strip)}strip(clean);for(const[a,b]of asyncTokens.sort((x,y)=>y[0]-x[0]))out=out.slice(0,a)+out.slice(b);return{source:out,removed,asyncMarkersRemoved:asyncTokens.length}};
