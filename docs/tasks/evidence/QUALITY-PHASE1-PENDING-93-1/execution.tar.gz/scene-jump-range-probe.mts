import fs from 'node:fs'
import { SceneAssetsCache } from '/Users/zhangxu/.codex/worktrees/quality-94-102/type-pal/packages/game/src/assets/loader.ts'
import { freshPlayerOpcodeState } from '/Users/zhangxu/.codex/worktrees/quality-94-102/type-pal/packages/game/src/core/event-opcode-player.test-fixtures.ts'
import { buildLabelMap, setGlobalEvents } from '/Users/zhangxu/.codex/worktrees/quality-94-102/type-pal/packages/game/src/core/event-system.ts'
import { loadScene, tickSceneInput } from '/Users/zhangxu/.codex/worktrees/quality-94-102/type-pal/packages/game/src/core/scene-system.ts'
import { makeSceneAssets, snap } from '/Users/zhangxu/.codex/worktrees/quality-94-102/type-pal/packages/game/src/core/scene.test-fixtures.ts'
const json = (path) => JSON.parse(fs.readFileSync('/Users/zhangxu/.codex/worktrees/quality-94-102/type-pal/'+path,'utf8'))
const scene=json('data/extracted/data/scene/86.json')
const tilemap=json('data/extracted/data/tilemap/93.json')
const commands=json('data/extracted/events/all.json').segments[0].commands
setGlobalEvents(commands)
const cache=new SceneAssetsCache(async id=>({...makeSceneAssets(id,scene.eventObjects,commands,buildLabelMap(commands),scene.onEnterLabel),tilemap,mapNum:scene.mapNum}))
const gs=freshPlayerOpcodeState()
await loadScene({gs,sceneId:86,assets:cache,partyStart:{x:80,y:1048,facing:'down'}})
const results=[]
for(const [x,y] of [[80,1048],[160,1040],[176,1048]]) {
 const at=structuredClone(gs);at.party={x,y,facing:'down'};at.camera={x:x-160,y:y-112}
 const directions=[]
 for(const key of ['Down','Left','Up','Right']) {const moving=structuredClone(at);tickSceneInput(moving,snap([key]),{tilemap});directions.push({key,position:[moving.party.x,moving.party.y],moved:moving.party.x!==x||moving.party.y!==y})}
 results.push({start:[x,y],directions})
}
process.stdout.write(JSON.stringify({scene:gs.wNumScene,map:scene.mapNum,results},null,2)+'\n')
