// Reuse one completed official collection. Import/guard/writer bodies remain literal;
// only main's expensive collection prefix is replaced by its frozen result read.
import assert from 'node:assert/strict'
import { spawnSync } from 'node:child_process'
import { createHash } from 'node:crypto'
import { existsSync, readFileSync, writeFileSync } from 'node:fs'
import { resolve } from 'node:path'
import { pathToFileURL } from 'node:url'

const root = '/Users/zhangxu/.codex/worktrees/quality-94-102/type-pal'
const stage = '/Users/zhangxu/.codex/quality-evidence/type-pal/pending-93-20261103'
const hash = (bytes) => createHash('sha256').update(bytes).digest('hex')
const read = (name) => readFileSync(resolve(stage, name), 'utf8')
const source = readFileSync(resolve(root, 'scripts/coverage/run.mjs'), 'utf8')
const capture = JSON.parse(read('consolidated-coverage-initial.json'))
assert.equal(capture.exit, 1)
assert.equal(hash(source), capture.sha256['scripts/coverage/run.mjs'])
const frozen = JSON.parse(read('freeze-code-inputs.json'))
for (const [path, expected] of Object.entries(frozen.sourceSha256)) {
  assert.equal(hash(readFileSync(resolve(root, path))), expected, path)
}
const reportPath = resolve(stage, 'coverage-summary.json')
const reportBytes = readFileSync(reportPath)
const report = JSON.parse(reportBytes)
assert.equal(report.testCount, 20273)
assert.equal(report.sourceFileCount, 829)
const stdout = read('consolidated-coverage-initial.stdout')
for (const [id, pkg] of Object.entries(report.packages)) {
  const counts = [...stdout.matchAll(/Tests\s+(\d+) passed/g)].map((m) => Number(m[1]))
  assert.ok(counts.includes(pkg.selectedTests.testCount), id)
}
assert.ok(!/stderr \||Test Files\s+\d+ failed|Tests\s+\d+ failed/.test(stdout))
assert.match(read('consolidated-coverage-initial.stderr'), /^\n\[coverage:fast\] FAIL\n覆盖率不得下降:\n- game\.branches:[\s\S]+\n- total\.branches:[^\n]+\n$/)

const main = source.indexOf('\nasync function main() {')
const tail = source.indexOf('\n  let baseline\n', main)
assert.ok(main > 0 && tail > main)
const prefix = source.slice(0, main)
const comparisonAndExit = source.slice(tail)
const candidate = (prefix + '\nasync function main() {\n  await assertToolVersions()\n  const result = await readJson(' + JSON.stringify(reportPath) + ')\n' + comparisonAndExit)
  .replace(/from '(\.\/[\w.-]+)'/g, (_, path) => `from '${pathToFileURL(resolve(root, 'scripts/coverage', path)).href}'`)
const target = resolve(stage, 'coverage-runner-tail.mjs')
if (existsSync(target)) assert.equal(readFileSync(target, 'utf8'), candidate)
else writeFileSync(target, candidate, { flag: 'wx' })
const receiptPath = resolve(stage, 'same-report-extraction.json')
if (!existsSync(receiptPath)) writeFileSync(receiptPath, JSON.stringify({
  source: 'scripts/coverage/run.mjs', sourceSha256: hash(source),
  summary: 'coverage-summary.json', summarySha256: hash(reportBytes),
  originalPrefixSha256: hash(prefix), originalComparisonTailSha256: hash(comparisonAndExit),
  generatedSha256: hash(candidate),
  transformation: 'Only main collection prefix replaced by frozen result read, and static relative imports made absolute for the external script. Guard, protected baseline, exact approval, scope, comparator and atomic writer/exit bodies unchanged.',
  limitation: 'Not a second collection. The original collection exit1 is preserved; this invocation separately runs its unchanged acceptance/writer on that completed report.',
}, null, 2) + '\n', { flag: 'wx' })
const run = spawnSync(process.execPath, [target, 'fast', ...process.argv.slice(2)], { cwd: root, env: process.env, stdio: 'inherit' })
if (run.error) throw run.error
assert.equal(run.signal, null)
process.exitCode = run.status
