import assert from 'node:assert/strict'
import {createHash} from 'node:crypto'
import {readFileSync} from 'node:fs'
import {parseSlf} from '/Users/zhangxu/.codex/worktrees/quality-94-102/type-pal/packages/pal-extract/src/io/slf.ts'
import {parseSss} from '/Users/zhangxu/.codex/worktrees/quality-94-102/type-pal/packages/pal-extract/src/io/sss.ts'
import {parseMessages} from '/Users/zhangxu/.codex/worktrees/quality-94-102/type-pal/packages/pal-extract/src/io/msg.ts'
import {disasm} from '/Users/zhangxu/.codex/worktrees/quality-94-102/type-pal/packages/pal-extract/src/events/disasm.ts'
import {correctScripts} from '/Users/zhangxu/.codex/worktrees/quality-94-102/type-pal/packages/pal-extract/src/events/script-corrections.ts'
import {buildLanguagePack} from '/Users/zhangxu/.codex/worktrees/quality-94-102/type-pal/packages/pal-extract/src/localization/build-language-pack.ts'
import {englishRevisions} from '/Users/zhangxu/.codex/worktrees/quality-94-102/type-pal/packages/pal-extract/src/localization/english-revisions.ts'
const sha=(b:Uint8Array)=>createHash('sha256').update(b).digest('hex')
const slfBytes=readFileSync('/Users/zhangxu/illegal/type-pal/data/en/win_files/m_eng.slf')
const sssBytes=readFileSync('/Users/zhangxu/.codex/worktrees/quality-94-102/type-pal/data/raw/SSS.MKF')
const messageBytes=readFileSync('/Users/zhangxu/.codex/worktrees/quality-94-102/type-pal/data/raw/M.MSG')
const sss=parseSss(sssBytes)
const corrected=correctScripts(sss,sha(sssBytes),parseMessages(messageBytes,sss.messageOffsets))
const source={slfSha256:sha(slfBytes),scriptSha256:sha(corrected.sss.bytecode),messageSha256:sha(messageBytes)}
const slf=parseSlf(new TextDecoder('utf8',{fatal:true}).decode(slfBytes))
const pack=buildLanguagePack(slf,disasm(corrected.sss.bytecode,corrected.messages),source,englishRevisions)
assert.equal(source.slfSha256,englishRevisions.slfSha256)
assert.equal(Object.keys(englishRevisions.words).length,183)
assert.equal(Object.keys(englishRevisions.groups).length,21)
assert.equal(Object.keys(pack.words).length,578)
assert.equal(pack.groups.length,4768)
assert.equal(pack.groups.flatMap(g=>g.lines).filter(l=>l===null).length,364)
assert.equal(pack.groups.find(g=>g.start===0)?.lines[0],'$10Xiaoyao! Xiaoyao!~30')
assert.deepEqual(pack.groups.filter(g=>g.start===12749||g.start===12866).map(g=>[g.start,g.end]),[[12749,12752],[12866,12869]])
assert.ok(Object.values(pack.words).every(w=>!(/\p{Script=Han}/u.test(w))))
console.log(JSON.stringify({source,words:Object.keys(pack.words).length,groups:pack.groups.length,clearBoundaries:364,revisionWords:183,revisionGroups:21,aliases:2,scope:'readonly source build, no extraction output or gameplay/E2E claim'},null,2))
