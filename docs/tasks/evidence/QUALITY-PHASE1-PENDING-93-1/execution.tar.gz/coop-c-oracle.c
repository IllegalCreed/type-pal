#include <stdint.h>
#include <stdio.h>
typedef uint16_t WORD;
typedef int16_t SHORT;
typedef float FLOAT;
#define NUM_MAGIC_ELEMENTAL 5
struct Globals {
 struct {
  struct { struct { WORD wMagicNumber; } magic; } rgObject[1];
  struct { WORD wBaseDamage, wElemental; } lprgMagic[1];
  struct { SHORT rgsMagicEffect[5]; } lprgBattleField[1];
 } g;
 WORD wNumBattleField;
};
static struct Globals globals;
static struct Globals *gpGlobals = &globals;
static FLOAT RandomFloat(FLOAT from, FLOAT to) { (void)to; return from; }
static SHORT
PAL_CalcBaseDamage(
   WORD        wAttackStrength,
   WORD        wDefense
)
/*++
  Purpose:

    Calculate the base damage value of attacking.

  Parameters:

    [IN]  wAttackStrength - attack strength of attacker.

    [IN]  wDefense - defense value of inflictor.

  Return value:

    The base damage value of the attacking.

--*/
{
   SHORT            sDamage;

   //
   // Formula courtesy of palxex and shenyanduxing
   //
   if (wAttackStrength > wDefense)
   {
      sDamage = (SHORT)(wAttackStrength * 2 - wDefense * 1.6 + 0.5);
   }
   else if (wAttackStrength > wDefense * 0.6)
   {
      sDamage = (SHORT)(wAttackStrength - wDefense * 0.6 + 0.5);
   }
   else
   {
      sDamage = 0;
   }

   return sDamage;
}

static SHORT
PAL_CalcMagicDamage(
   WORD             wMagicStrength,
   WORD             wDefense,
   const WORD       rgwElementalResistance[NUM_MAGIC_ELEMENTAL],
   WORD             wPoisonResistance,
   WORD             wResistanceMultiplier,
   WORD             wMagicID
)
/*++
   Purpose:

     Calculate the damage of magic.

   Parameters:

     [IN]  wMagicStrength - magic strength of attacker.

     [IN]  wDefense - defense value of victim.

     [IN]  rgwElementalResistance - victim's resistance to the elemental magics.

     [IN]  wPoisonResistance - victim's resistance to poison.

     [IN]  wResistanceMultiplier - multiplier of resistance value.

     [IN]  wMagicID - object ID of the magic.

   Return value:

     The damage value of the magic attack.

--*/
{
   SHORT           sDamage;
   WORD            wElem;

   wMagicID = gpGlobals->g.rgObject[wMagicID].magic.wMagicNumber;

   //
   // Formula courtesy of palxex and shenyanduxing
   //
   wMagicStrength *= RandomFloat(10, 11);
   wMagicStrength /= 10;

   sDamage = PAL_CalcBaseDamage(wMagicStrength, wDefense);
   sDamage /= 4;

   sDamage += gpGlobals->g.lprgMagic[wMagicID].wBaseDamage;

   if (gpGlobals->g.lprgMagic[wMagicID].wElemental != 0)
   {
      wElem = gpGlobals->g.lprgMagic[wMagicID].wElemental;

      if (wElem > NUM_MAGIC_ELEMENTAL)
      {
         sDamage *= 10 - ((FLOAT)wPoisonResistance / wResistanceMultiplier);
      }
      else if (wElem == 0)
      {
         sDamage *= 5;
      }
      else
      {
         sDamage *= 10 - ((FLOAT)rgwElementalResistance[wElem - 1] / wResistanceMultiplier);
      }

      sDamage /= 5;

      if (wElem <= NUM_MAGIC_ELEMENTAL)
      {
         sDamage *= 10 + gpGlobals->g.lprgBattleField[gpGlobals->wNumBattleField].rgsMagicEffect[wElem - 1];
         sDamage /= 10;
      }
   }

   return sDamage;
}
int main(void) {
 WORD resist[5]={0};
 globals.g.lprgMagic[0].wBaseDamage=80;
 globals.g.lprgMagic[0].wElemental=1;
 printf("magic=%d\nphysical=%d\n",PAL_CalcMagicDamage(40,44,resist,0,1,0),PAL_CalcBaseDamage(40,44)+1);
 return 0;
}
