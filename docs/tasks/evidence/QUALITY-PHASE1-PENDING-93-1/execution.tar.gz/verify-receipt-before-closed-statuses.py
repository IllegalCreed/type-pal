"""Read-only receipt/identity check. This does not certify semantic code quality."""
from pathlib import Path
import hashlib
import json
import re
import subprocess
import sys
import tarfile

root = Path(sys.argv[1] if len(sys.argv) > 1 else '.').resolve()
bundle = root / 'docs/tasks/evidence/QUALITY-PHASE1-PENDING-93-1/execution.tar.gz'
with tarfile.open(bundle, 'r:gz') as archive:
    files = {}
    for member in archive:
        assert member.isfile() and '/' not in member.name, member.name
        assert member.name not in files, member.name
        files[member.name] = archive.extractfile(member).read()

manifest = json.loads(files.pop('receipt-manifest.json'))
assert set(files) == set(manifest['members'])
for name, body in files.items():
    pin = manifest['members'][name]
    assert len(body) == pin['bytes'], name
    assert hashlib.sha256(body).hexdigest() == pin['sha256'], name

code = json.loads(files['final-code-inputs.json'])
for path, pin in code['sha256'].items():
    current = root / path
    assert current.is_file(), 'missing current input: ' + path
    assert hashlib.sha256(current.read_bytes()).hexdigest() == pin, 'stale input: ' + path
for path in code['absent']:
    assert not (root / path).exists(), 'retired path restored: ' + path

proof = json.loads(files['final-original-scope-proof.json'])
audit = root / 'docs/tasks/evidence/QUALITY-PHASE1-PENDING-93-1/README.md'
assert hashlib.sha256(audit.read_bytes()).hexdigest() == proof['auditSha256'], 'audit changed'
base = proof['base']
paths = subprocess.check_output(['git', 'ls-tree', '-r', '--name-only', base], cwd=root, text=True).splitlines()
ledger = subprocess.check_output(['git', 'show', base + ':docs/tasks/audits/code-quality-file-ledger.md'], cwd=root, text=True)
recorded = set(re.findall(r'^\| `([^`]+)` \|', ledger, re.M))
original = {p for p in paths if p.startswith(('packages/game/', 'packages/pal-extract/')) and re.search(r'\.(js|mjs|mts|ts|tsx|json)$', p) and p not in recorded}
assert len(original) == proof['originalScope'] == proof['reviewedUnique'] == 93
assert sum(p.startswith('packages/game/') for p in original) == 78
assert sum(p.startswith('packages/pal-extract/') for p in original) == 15
assert not proof['remaining']
assert len(proof['acceptedCurrentPaths']) == 124
live_ledger = (root / 'docs/tasks/audits/code-quality-file-ledger.md').read_text()
live_recorded = {line.split('|')[1].strip().strip('`') for line in live_ledger.splitlines()
                 if line.startswith('| `') and line.split('|')[3].strip() == '已验证'}
assert set(proof['acceptedCurrentPaths']) <= live_recorded
ledger_run = subprocess.run(['node', 'scripts/quality/code-quality-ledger.mjs'], cwd=root, capture_output=True, text=True)
assert ledger_run.returncode == 0 and ledger_run.stderr == '', ledger_run.stderr
assert ledger_run.stdout.startswith('code-quality ledger: PASS'), ledger_run.stdout

def result(name):
    return json.loads(files[name])

for label, expected in [('approved-scene-coop-green', 46), ('audio-worklet-neighbors-final', 25)]:
    native = result(label + '.vitest.json')
    assert native['numPassedTests'] == expected and native['numFailedTests'] == 0, label
    assert result(label + '.json')['exit'] == 0 and files[label + '.stderr'] == b'', label
assert result('asset-server-ci-fixture-green.json')['exit'] == 0
assert files['asset-server-ci-fixture-green.stderr'] == b''
assert b'# pass 4' in files['asset-server-ci-fixture-green.stdout']
positive = result('worklet-browser-report-r2.json')['cases'][0]
assert positive['mode'] == 'positive' and positive['result']['status'] == 'passed'
assert positive['serverWorklet']['status'] == 200 and positive['result']['after'] == 'closed'
pcm = files['worklet-native-output-r2.f32le']
assert len(pcm) == 8192 and hashlib.sha256(pcm).hexdigest() == positive['pcm']['sha256']
missing = result('worklet-browser-report-missing-r3.json')
assert missing['passed'] is True and missing['cases'][0]['serverMissing']['status'] == 404
assert missing['cases'][0]['result']['contextState'] == 'closed'
for label in ['consolidated-ratchet-final', 'consolidated-protected-final',
              'consolidated-lint-current', 'editor-current-coverage',
              'remaining-migrate-and-types', 'final-editor-types',
              'testing-source-bridge-adjacent-final',
              'testing-source-bridge-real-model-frozen']:
    assert result(label + '.json')['exit'] == 0, label
    assert files[label + '.stderr'] == b'', label
assert b'# tests 96' in files['testing-source-bridge-adjacent-final.stdout']
assert b'0 issues' in files['testing-source-bridge-real-model-frozen.stdout']
assert result('consolidated-full-check-recovery-r2.json')['exit'] == 1
prefix = files['consolidated-full-check-recovery-r2.stdout']
docs, rest = prefix.split(b'> type-pal@ test:coverage-tools ', 1)
coverage_tools, _ = rest.split(b'> type-pal@ test:quality-tools ', 1)
for token in [b'# tests 528', b'# pass 528', b'# fail 0', b'docs: PASS (0 issues)', b'content review: PASS']:
    assert token in docs, token
for token in [b'# tests 163', b'# pass 163', b'# fail 0']:
    assert token in coverage_tools, token
resume = result('full-check-resume-plan.json')
official = json.loads((root / 'package.json').read_bytes())['scripts']['check']
assert official == resume['officialScript']
assert result('consolidated-full-check-suffix-r3.json')['command'] == ['/bin/sh', '-c', ' && '.join(official.split(' && ')[2:])]
assert result('consolidated-full-check-suffix-r3.json')['exit'] == 1
assert b'0 errors / 0 warnings / 0 infos' in files['consolidated-lint-current.stdout']
for label, count in [('pal-reference-census-restored', 9), ('project-save-term-green', 65)]:
    native = result(label + '.vitest.json')
    assert native['numPassedTests'] == count and native['numFailedTests'] == 0, label
    assert result(label + '.json')['exit'] == 0 and files[label + '.stderr'] == b'', label
base_report = result('coverage-summary.json')
assert result('editor-current-coverage-report.json') == base_report['packages']['editor']
assert result('coverage-final-applicability.json')['deepEqual'] is True
assert not (root / 'packages/editor/src/core/project-reference-census.probe.test.ts').exists()
assert result('consolidated-coverage-initial.json')['exit'] == 1
assert hashlib.sha256(files['coverage-summary.json']).hexdigest() == 'f762801dc3d75d50d80d2a05d2ff34d01971f2b6eceffaf83cdde25d75d9735d'
diagnostics = result('final-gate-diagnostics.json')
assert diagnostics['productRuntimeStderrBlocks'] == 0
assert diagnostics['hardStaticDiagnostics'] == {'error': 0, 'warning': 0, 'info': 0}
print(json.dumps({'receipt': 'matches', 'originalSubjects': 93, 'currentCodePins': len(code['sha256']), 'members': len(files), 'semanticReading': 'not certified by fingerprints', 'next': 'Read the existing per-file A-H/identity mappings only for changed or disputed claims.'}))
