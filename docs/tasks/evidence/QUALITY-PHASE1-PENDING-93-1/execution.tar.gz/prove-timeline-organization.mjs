import fs from 'node:fs'
import path from 'node:path'
import crypto from 'node:crypto'
import { execFileSync } from 'node:child_process'
import { createRequire } from 'node:module'
import { fileURLToPath } from 'node:url'

const root = '/Users/zhangxu/.codex/worktrees/quality-94-102/type-pal'
const stage = path.dirname(fileURLToPath(import.meta.url))
const ts = createRequire(path.join(root, 'package.json'))('typescript')
const metadata = JSON.parse(fs.readFileSync(path.join(stage, 'timeline-describe-organization.json'), 'utf8'))
const old = execFileSync('git', ['show', `${metadata.base}:packages/game/src/core/battle/anim-timeline.ts`], { cwd: root, encoding: 'utf8' })
const parse = text => ts.createSourceFile('source.ts', text, ts.ScriptTarget.Latest, true)
const declarations = text => new Map(parse(text).statements.flatMap(n => {
  const name = n.name?.text ?? n.declarationList?.declarations[0].name.text
  return name ? [[name, n]] : []
}))
function structure(n) {
  if (ts.isParenthesizedExpression(n)) return structure(n.expression)
  const text = ts.isIdentifier(n) || ts.isStringLiteral(n) || ts.isNumericLiteral(n) ? n.text : undefined
  const children = []
  ts.forEachChild(n, c => { if (c.kind !== ts.SyntaxKind.ExportKeyword) children.push(structure(c)) })
  return [n.kind, text, children]
}
const printer = ts.createPrinter({ removeComments: true })
function runtime(node) {
  const js = ts.transpileModule(printer.printNode(ts.EmitHint.Unspecified, node, node.getSourceFile()), { compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.ESNext } }).outputText
  return [...declarations(js)].map(([name, n]) => [name, structure(n)])
}
// Exactly two deleted guards were redundant after !!iBlow. No other runtime rewrite is allowed.
if (old.split('!!iBlow && iBlow !== 0 &&').length !== 3) throw new Error('Baseline guard identity changed')
const before = declarations(old.replaceAll('!!iBlow && iBlow !== 0 &&', '!!iBlow &&'))
const after = new Map()
const files = []
for (const [group, names] of Object.entries(metadata.declarations)) {
  const relative = `packages/game/src/core/battle/animation/${group}.ts`
  const source = fs.readFileSync(path.join(root, relative), 'utf8')
  const current = declarations(source)
  if (current.size !== names.length || names.some(name => !current.has(name))) throw new Error(`Declaration set changed: ${relative}`)
  for (const [name, n] of current) after.set(name, n)
  files.push({ path: relative, sha256: crypto.createHash('sha256').update(source).digest('hex'), lines: source.split('\n').length - 1 })
}
const results = [...before].map(([name, n]) => {
  const next = after.get(name)
  return {
    name,
    typeEqual: ts.isInterfaceDeclaration(n) ? JSON.stringify(structure(n)) === JSON.stringify(structure(next)) : undefined,
    runtimeEqual: ts.isInterfaceDeclaration(n) ? undefined : JSON.stringify(runtime(n)) === JSON.stringify(runtime(next)),
    parametersEqual: ts.isFunctionDeclaration(n) ? JSON.stringify(n.parameters.map(structure)) === JSON.stringify(next.parameters.map(structure)) : undefined,
    returnTypeEqual: ts.isFunctionDeclaration(n) ? JSON.stringify(n.type && structure(n.type)) === JSON.stringify(next.type && structure(next.type)) : undefined,
  }
})
const originalExports = [...before].filter(([,n]) => n.modifiers?.some(m => m.kind === ts.SyntaxKind.ExportKeyword)).map(([name]) => name).sort()
const facadeSource = fs.readFileSync(path.join(root, 'packages/game/src/core/battle/anim-timeline.ts'), 'utf8')
const facade = parse(facadeSource)
const currentExports = facade.statements.flatMap(n => ts.isExportDeclaration(n) && n.exportClause && ts.isNamedExports(n.exportClause) ? n.exportClause.elements.map(e => e.name.text) : []).sort()
const exportSetEqual = JSON.stringify(originalExports) === JSON.stringify(currentExports)
const noWrappers = facade.statements.every(n => ts.isExportDeclaration(n))
const constant = before.get('BATTLE_FRAME_TIME')
const wrong = declarations('export const BATTLE_FRAME_TIME = 41').get('BATTLE_FRAME_TIME')
const negativeControlRejected = JSON.stringify(runtime(constant)) !== JSON.stringify(runtime(wrong))
const allEqual = exportSetEqual && noWrappers && negativeControlRejected && results.every(row => Object.values(row).every(value => value !== false))
console.log(JSON.stringify({ base: metadata.base, tool: 'TypeScript AST; type-erased runtime compared by named declaration, comments/parentheses/export modifiers ignored', allowedRuntimeSimplification: 'exactly two redundant iBlow !== 0 terms after !!iBlow', exportSetEqual, noWrappers, negativeControlRejected, results, files, allEqual }, null, 2))
if (!allEqual) process.exitCode = 1
