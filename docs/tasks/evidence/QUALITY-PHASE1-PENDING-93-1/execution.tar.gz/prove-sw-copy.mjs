import { createRequire } from 'node:module'
import { readFileSync } from 'node:fs'
import { execFileSync } from 'node:child_process'
import { createHash } from 'node:crypto'
const root = '/Users/zhangxu/.codex/worktrees/quality-94-102/type-pal'
const ts = createRequire(root + '/package.json')('typescript')
const path = 'packages/game/public/sw.js'
const revision = '08d67e28ec454d29941f8fab614644c5e160d790'
const before = execFileSync('git', ['show', `${revision}:${path}`], { cwd: root, encoding: 'utf8' })
const current = readFileSync(root + '/' + path, 'utf8')
const printer = ts.createPrinter({ removeComments: true })
function body(text) {
 const source = ts.createSourceFile(path, text, ts.ScriptTarget.Latest, true, ts.ScriptKind.JS)
 if (source.parseDiagnostics.length) throw new Error('Invalid JavaScript')
 return execFileSync(root + '/node_modules/.bin/biome', ['format', '--stdin-file-path=scripts/e2e/sw-source-review.mjs'], {input:printer.printFile(source),encoding:'utf8'})
}
const equal = (a,b) => body(a) === body(b)
const counter = current.replace('const CONCURRENCY = 8', 'const CONCURRENCY = 9')
const report = { path, revision, beforeSha256: createHash('sha256').update(before).digest('hex'), currentSha256: createHash('sha256').update(current).digest('hex'), sameCommentFreeCode: equal(before, current), negativeControlRejected: counter !== current && !equal(current, counter), defaultReadOnly: true }
console.log(JSON.stringify(report, null, 2))
if (!report.sameCommentFreeCode || !report.negativeControlRejected) process.exitCode = 1
