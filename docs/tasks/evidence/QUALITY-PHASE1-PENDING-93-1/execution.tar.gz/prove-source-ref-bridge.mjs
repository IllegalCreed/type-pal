import { readFileSync, writeFileSync } from 'node:fs'
import { execFileSync } from 'node:child_process'
import { createHash } from 'node:crypto'
import { createRequire } from 'node:module'
const root = '/Users/zhangxu/.codex/worktrees/quality-94-102/type-pal'
const ts = createRequire(root + '/package.json')('typescript')
const stage = '/Users/zhangxu/.codex/quality-evidence/type-pal/pending-93-20261103'
const revision = '08d67e28ec454d29941f8fab614644c5e160d790'
const hash = bytes => createHash('sha256').update(bytes).digest('hex')
const printer = ts.createPrinter({ removeComments: true, newLine: ts.NewLineKind.LineFeed })
const parse = text => ts.createSourceFile('subject.ts', text, ts.ScriptTarget.Latest, true, ts.ScriptKind.TS)
const print = text => printer.printFile(parse(text))
const read = path => readFileSync(root + '/' + path, 'utf8')
const base = path => execFileSync('git', ['show', revision + ':' + path], { cwd: root, encoding: 'utf8' })
const paths = ['packages/game/src/core/inventory-state.ts', 'packages/game/src/core/equipment-state.ts', 'packages/game/src/core/object-script-state.ts', 'packages/game/src/shell/bootstrap.ts']
const files = paths.map(path => {
  const old = base(path), now = read(path)
  if (print(old) !== print(now)) throw new Error('Executable drift ' + path)
  return { path, baseRevision: revision, beforeSha256: hash(old), afterSha256: hash(now), typedCommentFreeCodeEqual: true, negativeControlRejected: print(old) !== print(now + '\n;0\n') }
})
const path = 'packages/game/src/localization/ui-text.ts'
const before = base(path), after = read(path)
function labels(text) {
  const sf = parse(text)
  let value
  function visit(node) {
    if (ts.isVariableDeclaration(node) && node.name.getText(sf) === 'ENGLISH_LABELS') value = printer.printNode(ts.EmitHint.Unspecified, node.initializer, sf)
    ts.forEachChild(node, visit)
  }
  visit(sf)
  if (!value) throw new Error('Missing labels')
  return value
}
if (labels(before) !== labels(after)) throw new Error('Label table changed')
if (!after.includes("'虚拟方向键 / 左摇杆顺时针旋转45°'")) throw new Error('Missing own rotation label')
const meta = JSON.parse(readFileSync(stage + '/pal-script-and-throw-restored.json', 'utf8'))
const palInputs = ['packages/game/src/core/script-story-corrections.pal.test.ts', 'packages/game/src/core/script-topology-corrections.pal.test.ts'].map(path => ({ path, sha256: hash(read(path)), sameAsExistingRestoredRun: meta.sha256[path] === hash(read(path)) }))
const output = { base: revision, files, uiText: { path, beforeSha256: hash(before), afterSha256: hash(after), labelObjectUnchanged: true, scope: 'Only unknown inherited keys change behavior. Rotation setting caller passes an explicit own literal key; label value and control adapters unchanged. Existing current fast collection includes its shell/settings neighbors; no new browser/hardware claim.' }, palInputs, existingRun: 'pal-script-and-throw-restored', note: 'Only this source-ref bridge. Dates/status/candidate/versions/runtime receipts/SCC/token/old counters remain historical.' }
writeFileSync(stage + '/source-ref-rebinding.json', JSON.stringify(output, null, 2) + '\n', { flag: 'wx' })
console.log(JSON.stringify(output, null, 2))
