import assert from 'node:assert/strict'
import { execFileSync } from 'node:child_process'
import { createHash } from 'node:crypto'
import { readFileSync } from 'node:fs'
import { createRequire } from 'node:module'
const root = '/Users/zhangxu/.codex/worktrees/quality-94-102/type-pal'
const ts = createRequire(root + '/package.json')('typescript')
const beforePath = 'scripts/docs/check-testing.mjs'
const afterPath = 'scripts/docs/testing-source-refs.mjs'
const before = execFileSync('git', ['show', '08d67e28ec454d29941f8fab614644c5e160d790:' + beforePath], { cwd: root, encoding: 'utf8' })
const after = readFileSync(root + '/' + afterPath, 'utf8')
const wrapper = readFileSync(root + '/' + beforePath, 'utf8')
const hash = bytes => createHash('sha256').update(bytes).digest('hex')
const parse = text => ts.createSourceFile('subject.mjs', text, ts.ScriptTarget.Latest, true, ts.ScriptKind.JS)
const printer = ts.createPrinter({ removeComments: true, newLine: ts.NewLineKind.LineFeed })
const canonical = text => execFileSync(root + '/node_modules/.bin/biome', ['format', '--stdin-file-path=scripts/docs/source-refs-proof.mjs'], { cwd: root, encoding: 'utf8', input: printer.printFile(parse(text)) })
function declaration(text, name) {
  const sf = parse(text), matches = []
  function visit(n) {
    if ((ts.isFunctionDeclaration(n) || ts.isVariableDeclaration(n)) && n.name?.getText(sf) === name) matches.push(n)
    ts.forEachChild(n, visit)
  }
  visit(sf)
  assert.equal(matches.length, 1, name)
  const node = matches[0]
  return node.body?.getText(sf) ?? node.initializer.getText(sf)
}
const oldBody = declaration(before, 'sourceRefIssues')
const adapted = oldBody
  .replace('    const absolute = resolve(sourceRoot, ref.path)\n', '')
  .replaceAll('existsSync(absolute)', 'sources.has(ref.path)')
  .replaceAll('readFileSync(absolute)', 'sources.read(ref.path)')
  .replaceAll('safePath(ref.path)', 'safeTestingPath(ref.path)')
  .replaceAll('digest(bytes)', "createHash('sha256').update(bytes).digest('hex')")
const wrap = body => canonical('function check(refs,prefix,sources) ' + body)
const newBody = declaration(after, 'testingSourceRefIssues')
const checks = {
  pathPredicate: canonical('const predicate=' + declaration(before, 'safePath')) === canonical('const predicate=' + declaration(after, 'safeTestingPath')),
  rangeParser: canonical('function parse(value)' + declaration(before, 'parseLineRange')) === canonical('function parse(value)' + declaration(after, 'parseLineRange')),
  validatorBodyAfterExplicitIoBridge: wrap(adapted) === wrap(newBody),
  wrapper: canonical('function check()' + declaration(wrapper, 'sourceRefIssues')) === canonical('function check(){return testingSourceRefIssues(refs,prefix,{has:(path)=>existsSync(resolve(sourceRoot,path)),read:(path)=>readFileSync(resolve(sourceRoot,path))})}'),
  negativeRangeControlRejected: wrap(adapted) !== wrap(newBody.replace('range.start < 1', 'range.start < 0')),
}
assert.ok(Object.values(checks).every(Boolean), JSON.stringify(checks))
console.log(JSON.stringify({ before: { path: beforePath, revision: '08d67e28ec454d29941f8fab614644c5e160d790', sha256: hash(before) }, after: { path: afterPath, sha256: hash(after), wrapperSha256: hash(wrapper) }, checks, limit: 'Only path/range/source-byte validation extraction. No semantic certification of document or runtime claims. Default is read-only.' }, null, 2))
