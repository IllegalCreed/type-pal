import assert from 'node:assert/strict'
import { spawnSync } from 'node:child_process'
import { createHash } from 'node:crypto'
import { readFileSync, writeFileSync } from 'node:fs'
import { createRequire } from 'node:module'
const root = '/Users/zhangxu/.codex/worktrees/quality-94-102/type-pal'
const stage = '/Users/zhangxu/.codex/quality-evidence/type-pal/pending-93-20261103'
const ts = createRequire(root + '/package.json')('typescript')
const path = 'scripts/docs/document-location.mjs'
const before = readFileSync(root + '/' + path, 'utf8')
const sf = ts.createSourceFile(path, before, ts.ScriptTarget.Latest, true, ts.ScriptKind.JS)
const calls = []
function visit(node) {
  if (ts.isExpressionStatement(node) && ts.isCallExpression(node.expression) && node.expression.expression.getText(sf) === 'assertTestingSourceBridge') calls.push(node)
  ts.forEachChild(node, visit)
}
visit(sf)
assert.equal(calls.length, 1)
const statement = calls[0]
const removed = before.slice(statement.getStart(sf), statement.getEnd())
const mutant = before.slice(0, statement.getStart(sf)) + 'void 0' + before.slice(statement.getEnd())
const hash = text => createHash('sha256').update(text).digest('hex')
function run(label) {
  const r = spawnSync('python3', [stage + '/run-scoped.py', label, 'command', '.', 'node', '--test', '--test-name-pattern=admitted.testing.source.bridges', 'scripts/docs/document-location.test.mjs', '--inputs', path, 'scripts/docs/document-location.test.mjs', 'scripts/docs/testing-source-bridge.mjs', 'scripts/docs/testing-source-refs.mjs'], { cwd: root, encoding: 'utf8' })
  assert.equal(r.signal, null)
  return r.status
}
const baseline = run('testing-bridge-wiring-baseline')
assert.equal(baseline, 0)
let rejected
try {
  writeFileSync(root + '/' + path, mutant)
  rejected = run('testing-bridge-wiring-red')
  assert.equal(rejected, 1)
  const raw = readFileSync(stage + '/testing-bridge-wiring-red.stdout', 'utf8')
  assert.match(raw, /Missing expected exception/)
  assert.match(raw, /ERR_ASSERTION/)
  assert.match(raw, /# fail 1\n/)
} finally {
  writeFileSync(root + '/' + path, before)
  assert.equal(hash(readFileSync(root + '/' + path)), hash(before))
}
const restored = run('testing-bridge-wiring-restored')
assert.equal(restored, 0)
writeFileSync(stage + '/testing-bridge-wiring-control.json', JSON.stringify({ path, beforeAndRestoredSha256: hash(before), mutantSha256: hash(mutant), replacement: { before: removed, after: 'void 0' }, baseline, rejected, restored, result: 'Actual loader rejects post-load source drift only when it calls the bridge; exactly one business AssertionError, source bytes restored.' }, null, 2) + '\n', { flag: 'wx' })
console.log('loader baseline0 -> exactly1 business red -> restored0; source SHA restored')
