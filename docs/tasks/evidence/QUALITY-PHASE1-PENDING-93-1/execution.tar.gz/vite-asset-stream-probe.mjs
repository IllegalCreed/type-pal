import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import fs from 'node:fs'
import { createRequire, syncBuiltinESMExports } from 'node:module'
import { resolve } from 'node:path'
import { Writable } from 'node:stream'
import { pathToFileURL } from 'node:url'

const root = '/Users/zhangxu/.codex/worktrees/quality-94-102/type-pal'
const require = createRequire(resolve(root, 'packages/game/package.json'))
const { loadConfigFromFile } = await import(pathToFileURL(require.resolve('vite')).href)
process.env.E2E = '1'
const loaded = await loadConfigFromFile(
  { command: 'serve', mode: 'development' },
  resolve(root, 'packages/game/vite.config.ts'),
  resolve(root, 'packages/game'),
  'silent',
  undefined,
  'runner',
)
const plugin = loaded.config.plugins.flat(Infinity).find((item) => item?.name === 'serve-extracted')
assert.ok(plugin)
let middleware
plugin.configureServer({ middlewares: { use(handler) { middleware = handler } } })
assert.equal(typeof middleware, 'function')
const chunks = []
const response = new Writable({ write(chunk, _encoding, next) { chunks.push(Buffer.from(chunk)); next() } })
response.setHeader = () => {}
response.removeHeader = () => {}
if (process.argv[2] === 'normal') {
  const done = new Promise((resolve, reject) => { response.on('finish', resolve); response.on('error', reject) })
  middleware({ url: '/extracted/data/battle-fields.json' }, response, () => { throw Error('unexpected next') })
  await done
  const bytes = Buffer.concat(chunks)
  assert.deepEqual(bytes, fs.readFileSync(resolve(root, 'data/extracted/data/battle-fields.json')))
  console.log(JSON.stringify({ mode: 'normal', bytes: bytes.length, sha256: createHash('sha256').update(bytes).digest('hex') }))
} else {
  const absent = resolve(root, 'data/extracted', `__quality_absent_${process.pid}.rle`)
  assert.equal(fs.existsSync(absent), false)
  const ownedFile = resolve(process.env.TP_PROBE_TMP, 'present.rle')
  fs.writeFileSync(ownedFile, Uint8Array.of(1))
  const stat = fs.statSync
  // Simulate a file disappearing between successful stat and asynchronous stream open.
  fs.statSync = (path, ...args) => path === absent ? stat(ownedFile, ...args) : stat(path, ...args)
  syncBuiltinESMExports()
  process.on('uncaughtExceptionMonitor', (error, origin) => {
    console.error('QUALITY_STREAM_UNHANDLED ' + JSON.stringify({ code: error.code, origin, message: error.message }))
  })
  middleware({ url: '/extracted/' + absent.split('/').at(-1) }, response, () => { throw Error('unexpected next') })
  await new Promise((resolve) => setTimeout(resolve, 100))
  throw Error('Expected current unhandled read failure was not observed')
}
