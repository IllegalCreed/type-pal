// Read-only: replay one canonical author-record change in memory; do not write projects/pal.
import { readFileSync, writeFileSync } from 'node:fs'
import { execFileSync } from 'node:child_process'
import { loadCurrentProjectFrom, loadAllAuthorScenes, loadStampTemplates } from '/Users/zhangxu/.codex/worktrees/quality-94-102/type-pal/packages/reforge/src/index.ts'
import { toEditorState } from '/Users/zhangxu/.codex/worktrees/quality-94-102/type-pal/packages/editor/src/core/project-io.ts'
import { collectEditorDiagnosticsSnapshot } from '/Users/zhangxu/.codex/worktrees/quality-94-102/type-pal/packages/editor/src/core/project-diagnostics.ts'
import { createProjectReferenceIndex } from '/Users/zhangxu/.codex/worktrees/quality-94-102/type-pal/packages/editor/src/core/project-reference.ts'
import { test } from 'vitest'

test('diagnostic replay of the canonical carrier record (not a product acceptance count)', async () => {
const root = '/Users/zhangxu/.codex/worktrees/quality-94-102/type-pal'
const historicalRevision = 'd1cadb32ea'
const scenePath = 'content/scenes/s005.json'
const oldScene = JSON.parse(execFileSync('git', ['show', `${historicalRevision}:projects/pal/${scenePath}`], { cwd: root, encoding: 'utf8' }))
const currentScene = JSON.parse(readFileSync(`${root}/projects/pal/${scenePath}`, 'utf8'))
const oldEntity = oldScene.entities.find((entity) => entity.id === 'e116')
const currentEntity = currentScene.entities.find((entity) => entity.id === 'e116')
if (!oldEntity || !currentEntity) throw new Error('The named canonical carrier is missing')
const beforeScene = structuredClone(currentScene)
beforeScene.entities[beforeScene.entities.findIndex((entity) => entity.id === 'e116')] = oldEntity
const result = { historicalRevision, sourceScene: scenePath, sourceEntity: 'e116', before: null, after: null }
for (const [label, overlay] of [['before', JSON.stringify(beforeScene)], ['after', null]]) {
  const read = (path) => path === scenePath && overlay !== null ? overlay : readFileSync(`${root}/projects/pal/${path}`, 'utf8')
  const source = { readText: async (path) => read(path), readJson: async (path) => JSON.parse(read(path)), readBytes: async (path) => new TextEncoder().encode(read(path)).buffer, urlFor: async (path) => `fixture://${path}` }
  const project = await loadCurrentProjectFrom(source)
  const [scenes, stamps] = await Promise.all([loadAllAuthorScenes(project), loadStampTemplates(project)])
  const state = toEditorState(project, scenes, {}, {}, stamps)
  const canonical = { scenes: structuredClone(scenes), items: structuredClone(project.authorContent.items), sharedScripts: structuredClone(project.authorContent.sharedScripts) }
  const diagnostics = collectEditorDiagnosticsSnapshot(state, canonical)
  const index = createProjectReferenceIndex(diagnostics.projectReferences)
  const edges = index.allReferences()
  result[label] = { entityAddresses: diagnostics.entityAddressReferences.length, actionEdges: edges.filter((e) => e.relation.kind === 'world-sprite-action-use').length, behaviorEdges: edges.filter((e) => e.relation.kind === 'behavior-reference').length, rows: diagnostics.projectReferences.rows.length, targetEdgeIds: diagnostics.projectReferences.targetEdgeIds.length, carrierAddresses: diagnostics.entityAddressReferences.filter((r) => r.locator.kind === 'scene-entity' && r.locator.sceneId === 's005' && r.locator.entityId === 'e116' && r.path.includes('.behaviors.auto.')), carrierEdges: edges.filter((e) => (e.source.owner.kind === 'scene-page' && e.source.owner.sceneId === 's005' && e.source.owner.entityId === 'e116') || (e.source.owner.kind === 'script-owner' && e.source.owner.owner.kind === 'entity-behavior' && e.source.owner.owner.sceneId === 's005' && e.source.owner.owner.entityId === 'e116' && e.source.owner.owner.channel === 'auto')) }
}
const output = JSON.stringify(result, null, 2) + '\n'
writeFileSync('/Users/zhangxu/.codex/quality-evidence/type-pal/pending-93-20261103/pal-reference-causal-delta-output.json', output, { flag: 'wx' })
console.log(output)

}, 30000)
